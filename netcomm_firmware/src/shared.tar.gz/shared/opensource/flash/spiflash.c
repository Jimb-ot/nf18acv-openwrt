/*
   <:copyright-BRCM:2012:DUAL/GPL:standard
   
      Copyright (c) 2012 Broadcom 
      All Rights Reserved
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License, version 2, as published by
   the Free Software Foundation (the "GPL").
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   
   A copy of the GPL is available at http://www.broadcom.com/licenses/GPLv2.php, or by
   writing to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
   
   :> 
*/                       

/** Includes. **/
#ifdef _CFE_                                                
#include "lib_types.h"
#include "lib_printf.h"
#include "lib_string.h"
#include "bcm_map_part.h"  
#define printk  printf
#else       // linux
#include <linux/version.h>
#include <linux/param.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,29)
#include <linux/semaphore.h>
#endif
#include <linux/hardirq.h>

#include <bcm_map_part.h> 
#define printf  printk
#endif

#include "bcmtypes.h"
#include "bcm_hwdefs.h"
#include "flash_api.h"
#include "bcmSpiRes.h"

#ifndef INC_BTRM_BUILD                                                
#define INC_BTRM_BUILD 0
#endif

/** Defines. **/
#define OSL_DELAY(X)                        \
    do { { int i; for( i = 0; i < (X) * 500; i++ ) ; } } while(0)

#define MAX_RETRY           3

#ifndef NULL
#define NULL 0
#endif

#if (INC_BTRM_BUILD==1)
/* reduce the memory usage for BTRM which only need to access up to 512KB */
#define MAXSECTORS          128     
#else
#define MAXSECTORS          8192    /* maximum number of sectors supported */
#endif

#define FLASH_PAGE_256      256
#define FLASH_PAGE_512      512
#define SECTOR_SIZE_4K      (4 * 1024)
#define SECTOR_SIZE_64K     (64 * 1024)

/* Standard Boolean declarations */
#define TRUE                1
#define FALSE               0

/* Command codes for the flash_command routine */
#define FLASH_WRST          0x01    /* write status register */
#define FLASH_PROG          0x02    /* program data into memory array */
#define FLASH_READ          0x03    /* read data from memory array */
#define FLASH_WRDI          0x04    /* reset write enable latch */
#define FLASH_RDSR          0x05    /* read status register */
#define FLASH_WREN          0x06    /* set write enable latch */
#define FLASH_READ_FAST     0x0B    /* read data from memory array */
#define FLASH_SERASE        0x20    /* erase one sector in memory array */
#define FLASH_BERASE        0xD8    /* erase one block in memory array */
#define FLASH_RDID          0x9F    /* read manufacturer and product id */
#define FLASH_EN4B          0xB7    /* Enable 4 byte address mode */
#define FLASH_EXIT4B        0xE9    /* Exit 4 byte address mode */
#define FLASH_READ_DOR      0x3B    /* dual output read */
#define FLASH_READ_DIOR     0xBB    /* dual i/o read */

/* Spansion Extended Addressing opcodes for 4byte addresses */
#define FLASH_4PROG         0x12    /* program data into memory array */
#define FLASH_4READ         0x13    /* read data from memory array */
#define FLASH_4READ_FAST    0x0C    /* read data from memory array */
#define FLASH_4SERASE       0x21    /* erase one sector in memory array */
#define FLASH_4BERASE       0xDC    /* erase one block in memory array */
#define FLASH_4READ_DOR     0x3C    /* dual output read */
#define FLASH_4READ_DIOR    0xBC    /* dual i/o read */


/* Spansion specific commands */  
#define FLASH_RDCR          0x35    /* Read Configuration Register */


/* RDSR return status bit definition */
#define SR_WPEN             0x80
#define SR_BP3              0x20
#define SR_BP2              0x10
#define SR_BP1              0x08
#define SR_BP0              0x04
#define SR_WEN              0x02
#define SR_RDY              0x01

/* Return codes from flash_status */
#define STATUS_READY        0       /* ready for action */
#define STATUS_BUSY         1       /* operation in progress */
#define STATUS_TIMEOUT      2       /* operation timed out */
#define STATUS_ERROR        3       /* unclassified but unhappy status */

/* Define different type of flash */
#define FLASH_UNDEFINED     0
#define FLASH_SPAN          2

/* SST's manufacturer ID */
#define SSTPART             0xBF
/* A list of SST device IDs */
#define ID_SST25VF016       0x41
#define ID_SST25VF032       0x4A
#define ID_SST25VF064       0x4B

/* SPANSION manufacturer IDs */
#define SPANPART            0x01
/* SPANSION device ID's */
#define ID_SPAN25FL016      0x14
#define ID_SPAN25FL032      0x15
#define ID_SPAN25FL064      0x16
#define ID_SPAN25FL164      0x17
#define ID_SPAN25FL128      0x18
#define ID_SPAN25FL256      0x19


/* EON manufacturer ID */
#define EONPART             0x1C
/* NUMONYX manufacturer ID */
#define NUMONYXPART         0x20
/* AMIC manufacturer ID */
#define AMICPART            0x37
/* Macronix manufacturer ID */
#define MACRONIXPART        0xC2
/* Winbond's manufacturer ID */
#define WBPART              0xEF

/* JEDEC device IDs */
#define ID_M25P16           0x15
#define ID_M25P32           0x16
#define ID_M25P64           0x17
#define ID_M25P128          0x18
#define ID_M25P256          0x19

/* flash memory type, the second byte returned from the READ ID instruction*/
#define FLASH_MEMTYPE_NULL  0x00
#define FLASH_MEMTYPE_20    0x20
#define FLASH_MEMTYPE_BA    0xBA

//#define CONFIG_FLASH_PROTECT

#define UNIFORM_SECTOR
#ifdef UNIFORM_SECTOR
#define spi_get_abso_addr(sector)\
{\
    (FLASH_BASE + f_info.s_size*sector)\
}
#else
#define spi_get_abso_addr(sector)\
{\
    (FLASH_BASE + f_info.s_base[sector])\
}
#endif

/** Structs. **/
/* A structure for identifying a flash part.  There is one for each
 * of the flash part definitions.  We need to keep track of the
 * sector organization, the address register used, and the size
 * of the sectors.
 */
struct flashinfo {
    char*          p_name;              /* "AT25F512", etc. */
  //unsigned int   addr;                /* physical address, once translated */
    unsigned int   mtc_id;
    unsigned int   t_size;
    unsigned short n_secs;              /* # of sectors */
    unsigned short B_page;
    unsigned char  cmd_idx;
    unsigned char  cmd_erase;                //cmd
    unsigned char  cmd_wren;                //cmd
    unsigned char  cmd_prog;
    unsigned char  cmd_read;
    //signed char  wp_flag;
    unsigned char  pad[2];  // 4 byte align, otherwise will cause cpu0 if force wp_mask to int*
    unsigned char  wp_mask[4];    
   unsigned  char  flg_ad32;
   unsigned  char  flg_dummy;
   unsigned  char  flg_mbit;
   #ifdef UNIFORM_SECTOR
    unsigned int   s_size;
   #else
    unsigned int   s_size[MAXSECTORS];  /* # of bytes in this sector */
    unsigned int   s_base[MAXSECTORS];  /* offset from beginning of device */
   #endif
};

#ifndef INC_BTRM_BOOT
#define INC_BTRM_BOOT 0
#endif

/** Prototypes. **/
static int my_spi_read( struct spi_transfer *xfer );
static int my_spi_write( unsigned char *msg_buf, int nbytes );

int spi_flash_init(flash_device_info_t **flash_info);
static int spi_flash_sector_erase_int(unsigned short sector);
static int spi_flash_reset(void);
#if (INC_BTRM_BOOT==0) && defined(_CFE_) && defined(CFG_RAMAPP)
static 
#endif
int spi_flash_read_buf(unsigned short sector, int offset, unsigned char *buffer, int nbytes);
static int spi_flash_ub(unsigned short sector);
static int spi_flash_write(unsigned short sector, int offset,
    unsigned char *buffer, int nbytes);
static int spi_flash_write_buf(unsigned short sector, int offset,
    unsigned char *buffer, int nbytes);
static int spi_flash_get_numsectors(void);
#if (INC_BTRM_BOOT==0) && defined(_CFE_) && defined(CFG_RAMAPP)
static 
#endif
int spi_flash_get_sector_size(unsigned short sector);
//static unsigned char *spi_get_flash_memptr(unsigned short sector);
static unsigned char *spi_flash_get_memptr(unsigned short sector);
static int spi_flash_status(void);
static unsigned int spi_flash_get_device_id(void);
static int spi_flash_get_blk(int addr);
static int spi_flash_get_total_size(void);
#if 0
static int spi_flash_en4b(void);
static int spi_flash_disable4b(void);
#endif
//static char spi_flash_protect(char isEnable);
static void spi_flash_set_ad4B(char  isEnable);
static void spi_flash_show_list(void);
//static unsigned int spi_flash_get_device_extid(void);

//static void spi_flash_multibit_en(void);

/** Variables. **/
static flash_device_info_t flash_spi_dev =
{
    0,
    "",
    FLASH_IFC_SPI,
    spi_flash_sector_erase_int,
    spi_flash_read_buf,
    spi_flash_write_buf,
    spi_flash_get_numsectors,
    spi_flash_get_sector_size,
    spi_flash_get_memptr,
    spi_flash_get_blk,
    spi_flash_get_total_size,
    NULL,
#ifdef CONFIG_MIPS_TW
    //spi_flash_protect,
    spi_flash_set_ad4B,
    spi_flash_show_list
#endif
};


/* the controller will handle operati0ns that are greater than the FIFO size
   code that relies on READ_BUF_LEN_MAX, READ_BUF_LEN_MIN or spi_para.max_op_len
   could be changed */
#define READ_BUF_LEN_MAX   544    /* largest of the maximum transaction sizes for SPI */
#define READ_BUF_LEN_MIN   60     /* smallest of the maximum transaction sizes for SPI */
/* this is the slave ID of the SPI flash for use with the SPI controller */
#define SPI_FLASH_SLAVE_DEV_ID    0
/* clock defines for the flash */
#define SPI_FLASH_DEF_CLOCK       781000

#ifndef _CFE_
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36)
static DEFINE_SEMAPHORE(spi_flash_lock);
#else
static DECLARE_MUTEX(spi_flash_lock);
#endif
static bool bSpiFlashSlaveRes = FALSE;
#endif

typedef struct spi_para_{
    /* default to smallest transaction size - updated later */
    int max_op_len ;
    /* default to legacy controller - updated later */
    int flash_clock;
    int flash_busnum;
    int ctrlState;
}  spi_para_t; 

static spi_para_t spi_para =
{
    READ_BUF_LEN_MIN,
    SPI_FLASH_DEF_CLOCK,
    LEG_SPI_BUS_NUM,
    SPI_CONTROLLER_STATE_DEFAULT
};

static struct flashinfo f_info; /* Flash information structure */
//��̬����ע���ʼ����ע���Ӻ���Ƕ��ʱ���ܴ��ڵķ���
static struct spi_transfer xfer;

static int my_spi_read(struct spi_transfer *xfer)
{
    int status;

#ifndef _CFE_
    if ( FALSE == bSpiFlashSlaveRes )
#endif
    {
        status = BcmSpi_MultibitRead(xfer, spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID);
    }
#ifndef _CFE_
    else
    {
        status = BcmSpiSyncMultTrans(xfer, 1, spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID);
    }
#endif

    return status;
}

static int my_spi_write(unsigned char *msg_buf, int nbytes)
{
    int status; 

#ifndef _CFE_
    if ( FALSE == bSpiFlashSlaveRes )
#endif
    {
        status = BcmSpi_Write(msg_buf, nbytes, spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID, spi_para.flash_clock);
    }
#ifndef _CFE_
    else
    {
        status = BcmSpiSyncTrans(msg_buf, NULL, 0, nbytes, spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID);
    }
#endif
    return status;
}

static void my_spi_init(void)
{
#if defined(_BCM96816_) || defined(CONFIG_BCM96816) || defined(_BCM96818_) || defined(CONFIG_BCM96818)
    uint32 miscStrapBus = MISC->miscStrapBus;

    if ( miscStrapBus & MISC_STRAP_BUS_LS_SPIM_ENABLED )
    {
        spi_para.flash_busnum = LEG_SPI_BUS_NUM;
        if ( miscStrapBus & MISC_STRAP_BUS_SPI_CLK_FAST )
        {
            spi_para.flash_clock = 20000000;
        }
        else
        {
            spi_para.flash_clock = 781000;
        }
    }
    else
    {
        spi_para.flash_busnum = HS_SPI_BUS_NUM;
        if ( miscStrapBus & MISC_STRAP_BUS_SPI_CLK_FAST )
        {
            spi_para.flash_clock = 20000000;
        }
        else
        {
            spi_para.flash_clock = 66666667;
        }
    }
#endif
#if defined(_BCM96328_) || defined(CONFIG_BCM96328)
    uint32 miscStrapBus = MISC->miscStrapBus;

    spi_para.flash_busnum = HS_SPI_BUS_NUM;
    if ( miscStrapBus & MISC_STRAP_BUS_HS_SPIM_FAST_B_MASK )
        spi_para.flash_clock = 33333334;
    else
        spi_para.flash_clock = 16666667;
#endif
#if defined(_BCM96362_) || defined(CONFIG_BCM96362) || defined(_BCM963268_) || defined(CONFIG_BCM963268) || defined(_BCM96828_) || defined(CONFIG_BCM96828)
    uint32 miscStrapBus = MISC->miscStrapBus;

    spi_para.flash_busnum = HS_SPI_BUS_NUM;
    if ( miscStrapBus & MISC_STRAP_BUS_HS_SPIM_CLK_SLOW_N_FAST )
        spi_para.flash_clock = 40000000;
    else
        spi_para.flash_clock = 20000000;
#endif
#if defined(_BCM96368_) || defined(CONFIG_BCM96368)
    uint32 miscStrapBus = GPIO->StrapBus;
 
    if ( miscStrapBus & MISC_STRAP_BUS_SPI_CLK_FAST )
       spi_para.flash_clock = 20000000;
    else
       spi_para.flash_clock = 781000;
#endif

#if defined(_BCM96318_) || defined(CONFIG_BCM96318)
       spi_para.flash_busnum = HS_SPI_BUS_NUM;
       spi_para.flash_clock = 62500000; 
       //spi_para.flash_clock = 12500000; Default clock
#endif

#if defined(_BCM96838_) || defined(CONFIG_BCM96838)
       spi_para.flash_busnum = HS_SPI_BUS_NUM;
       spi_para.flash_clock = 20000000; // reset value 
#endif

#if defined(_BCM960333_) || defined(CONFIG_BCM960333)
       spi_para.flash_busnum = HS_SPI_BUS_NUM;
       spi_para.flash_clock = 20000000; // reset value
#endif

#if defined(_BCM963138_) || defined(CONFIG_BCM963138) || defined(_BCM963381_) || defined(CONFIG_BCM963381) || defined(_BCM963148_) || defined(CONFIG_BCM963148)
       uint32 miscStrapBus = MISC->miscStrapBus;
       if( miscStrapBus & MISC_STRAP_BUS_HS_SPIM_CLK_SLOW_N_FAST )
           spi_para.flash_clock = 50000000; 
       else
           spi_para.flash_clock = 20000000; // reset value 
       spi_para.flash_busnum = HS_SPI_BUS_NUM;
#endif

#if defined(_BCM968500_) || defined(CONFIG_BCM968500)
    lilac_spi_setup_slave (0, 6, CONFIG_SF_DEFAULT_SPEED, SPI_MODE_3);
#else
    /* retrieve the maximum read/write transaction length from the SPI controller */
    spi_para.max_op_len = BcmSpi_GetMaxRWSize( spi_para.flash_busnum, 1);
    //printf("maxoplen=%d\n",spi_para.max_op_len);

    /* set the controller state, spi_mode_0 */
    spi_para.ctrlState = SPI_CONTROLLER_STATE_DEFAULT;
    if ( spi_para.flash_clock > SPI_CONTROLLER_MAX_SYNC_CLOCK )
       spi_para.ctrlState |= SPI_CONTROLLER_STATE_ASYNC_CLOCK;
    BcmSpi_SetCtrlState(spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID, SPI_MODE_DEFAULT, spi_para.ctrlState);

    if (HS_SPI_BUS_NUM == spi_para.flash_busnum)
        flash_spi_dev.flash_type = FLASH_IFC_HS_SPI;
#endif
}


/*********************************************************************/
typedef struct spi_flash_type_
{
    char *         p_name;
    unsigned int   mtc_id;       //mtcid
    unsigned short MB_size;      //MB
	//unsigned short n_secs;     //m
	unsigned char  cmd_idx;
	  signed char  wp_idx;
}spi_flash_type_t;

typedef struct para_idx_
{
	unsigned short KB_sec;         //KB
	unsigned short B_page;         //B    
	unsigned char  cmd_erase;      //cmd
	unsigned char  cmd_wren;       //cmd
	unsigned char  cmd_prog;       //cmd
	unsigned char  cmd_read;       //cmd
	
}para_idx_t;

//EN��Bϵ�е�Bot,Top,Uni���ͺ�Pϵ��MTCID��ͬ����MDID����ͬ
//��ʶno��Ϊδ���Ի�û����Ƭ�����б�ҪԤ��֧�ֵ��ͺ�
//��ʶok��Ϊ�в��Խ�����������ͣ��������ο�����Բ�ͬ����оƬ�Ͱ��ӽ�����ܻ��в�ͬ�Ľ��
static const spi_flash_type_t g_flash_table[]=
{   //name              id      sz pa wp
                                      //64K*32
    {"AT26DF080"   ,0x1F4500,1 ,3,-1},//
    {"AT26DF081A"  ,0x1F4501,1 ,3,-1},//
    {"AT25DF080"   ,0x1F4502,1 ,3,-1},//
    {"A25L80"      ,0x373014,1 ,3, 1},//
    {"EN25P80"     ,0x1C3014,1 ,3, 1},//
    {"EN25P80"     ,0x1C2014,1 ,3, 1},//
    {"EN25F80"     ,0x1C3114,1 ,3, 1},//
    {"GD25Q80"     ,0XC84014,1, 3, 1},//
  //{"F25L080AT"   ,0x8C2014,1 ,3, 1},//ESMT
  //{"F25L080AB"   ,0x8C2114,1 ,3, 1},//
    {"MX25L8005D"  ,0xc22014,1 ,3, 2},//
    {"MX25L8035D"  ,0xc22414,1 ,3, 2},//
    {"M25P80"      ,0x202014,1 ,3, 1},//numonyx
    {"W25X80"      ,0xEF3014,1 ,3, 1},
    {"W25Q80"      ,0xEF4014,1 ,3, 1},
  //{"QH25FL080"   ,0x898910,1 ,3, 0},//intel//������
    {"S25FL080A"   ,0x010213,1 ,3, 1},//
  //{"SST25VF080"  ,0xBF258E,1 ,3, 0},//NO
                                      //64K*32
    {"AT26DF161"   ,0x1F4600,2 ,3,-1},//ok
    {"AT26DF161A"  ,0x1F4601,2 ,3,-1},//ok
    {"AT25DF161"   ,0x1F4602,2 ,3,-1},//ok
    {"A25L016"     ,0x373015,2 ,3, 1},//ok AMIC
    {"EN25P16"     ,0x1C3015,2 ,3, 1},//ok
    {"EN25F16"     ,0x1C3115,2 ,3, 1},//ok
    {"GD25Q16"     ,0XC84015,2, 3, 1},//OK
  //{"F25L016AT"   ,0x8C2015,2 ,3, 1},//ESMT
  //{"F25L016AB"   ,0x8C2115,2 ,3, 1},
    {"MX25L1605D"  ,0xc22015,2 ,3, 2},//ok
    {"MX25L1635D"  ,0xc22415,2 ,3, 2},//ok
    {"M25P16"      ,0x202015,2 ,3, 1},//ok numonyx
    {"W25X16"      ,0xEF3015,2 ,3, 1},//ok
    {"W25Q16"      ,0xEF4015,2 ,3, 1},//ok
  //{"QH25FL016"   ,0x898911,2 ,3, 0},//intel//������
    {"S25FL016A"   ,0x010214,2 ,3, 1},//ok
  //{"SST25VF016"  ,0xBF2541,2 ,3, 0},//NO
                                      //64K*64
    {"AT25DF321"   ,0x1F4700,4 ,3, 2},//ok
    {"AT25DF321"   ,0x1F4701,4 ,3, 2},//ok
    {"A25L032"     ,0x373016,4 ,3, 1},//OK
    {"EN25P32"     ,0x1C2016,4 ,3, 1},//OK
    {"EN25F32"     ,0x1C3116,4 ,3, 1},//OK
    {"EN25Q32"     ,0x1C3316,4 ,3, 1},//OK no use
    {"EN25Q32A"    ,0x1C3016,4 ,3, 1},//NO
    {"GD25Q32"     ,0XC84016,4, 3, 1},//OK
    {"M25P32"      ,0x202016,4 ,3, 1},//NO
    {"MX25L3205D"  ,0xc22016,4 ,3, 2},//OK
    {"MX25L3235D"  ,0xc22416,4 ,3, 2},//OK
    {"N25S32"      ,0xD53016,4 ,3, 1},//FAIL CRC FAIL
    {"W25P32"      ,0xEF2016,4 ,3, 1},//OK
    {"W25X32"      ,0xEF3016,4 ,3, 1},//OK
    {"W25Q32"      ,0xEF4016,4 ,3, 1},//OK
  //{"QH25FL032"   ,0x898912,4 ,3, 0},//NO
    {"S25FL032A"   ,0x010215,4 ,3, 1},//OK
  //{"SST25VF032"  ,0xBF254A,4 ,3, 0},//FAIL
                                      //64K*128
    {"AT25DF641"   ,0x1F4800,8 ,3, 2},//NO
    {"A25L064"     ,0x373017,8 ,3, 1},//NO
    {"EN25P64"     ,0x1C2017,8 ,3, 1},//asB64
    {"EN25Q64"     ,0x1C3017,8 ,3, 1},//OK
    {"GD25Q64"     ,0XC84017,8, 3, 1},//OK
    {"M25P64"      ,0x202017,8 ,3, 1},//OK
    {"N25Q64"      ,0x20BA17,8 ,3, 1},//OK
    {"MX25L64"     ,0xc22017,8 ,3, 2},//OK 
    {"W25X64"      ,0xEF3017,8 ,3, 1},//NO
    {"W25Q64"      ,0xEF4017,8 ,3, 1},//OK
  //{"QH25FL064"   ,0x898913,8 ,3, 0},//NO
    {"S25FL064A"   ,0x010216,8 ,3, 1},//OK
                                      //64K*256
    {"AT25DF128"   ,0x1F4900,16,3, 2},//NO
    {"A25L128"     ,0x373018,16,3, 1},//NO
    {"EN25P128"    ,0x1C2018,16,3, 1},//NO
    {"EN25Q128"    ,0x1C3018,16,3, 1},//OK
    {"GD25Q128"    ,0XC84018,16,3, 1},//OK	
  //{"M25P128"     ,0x202018,16,4, 1},//FAIL
    {"N25Q128"     ,0x20BA18,16,3, 1},//OK
    {"MX25L128"    ,0xc22018,16,3, 2},//OK 
    {"W25X128"     ,0XEF3018,16,3, 1},//NO
    {"W25Q128"     ,0XEF4018,16,3, 1},//OK
    {"S25FL128"    ,0X012018,16,3, 1},//OK
  //{"S25FL128P"   ,0X012018,16,4, 0},//need extid

    {"AT25DF256"   ,0x1F4A00,32,3, 2},//NO
    {"A25L256"     ,0x373019,32,3, 1},//NO
    {"EN25P256"    ,0x1C2019,32,3, 1},//NO
    {"EN25Q256"    ,0x1C3019,32,3, 1},//NO
    {"N25Q256"     ,0x20BA19,32,3, 1},//NO
    {"MX25L256"    ,0xc22019,32,3, 2},//OK
    {"W25X256"     ,0XEF3019,32,3, 1},//NO
    {"W25Q256"     ,0XEF4019,32,3, 1},//NO
    {"GD25Q256"    ,0XC84019,32,3, 1},//OK	
  #if 1  //�̶����ɣ��ֶ��޸ģ������Ӻ�
    {"S25FL256S"   ,0X010219,32,3, 1},//ok//������ͨ��ģʽ�л�ʵ��4B add
  #else
    {"S25FL256S"   ,0X010219,32,6, 1},//ok//������ͨ��ָ��ʵ��4B add
  #endif  

    {"S25FL512S"   ,0X010220,64,4, 1},//ok

    {"Unknown"     ,0       ,0 ,0, 0}
};

static const para_idx_t g_para_tabel[]=
{//����block��С��Ҫ��menuconfig������,Ĭ��֧��64K
    //sec page er wren prog read
    {64 ,  0,   0,   0,   0,   0},// 0 Ĭ��ֵ����һ��ֵ����Ϊ0
    { 4 ,256,0x20,0x06,0x02,0x0B},// 1 ���÷�ʽ ��ע��sector�������Ƿ����
    {32 ,256,0x52,0x06,0x02,0x0B},// 2 ���÷�ʽ
    {64 ,256,0xD8,0x06,0x02,0x0B},// 3 ��Ҫ��ʽ
    {256,512,0xD8,0x06,0x02,0x0B},// 4 s25fl512s
    { 4 ,256,0x20,0x50,0xAD,0x0B},// 5 for SST Ŀǰ��˾����
    {64 ,256,0xDC,0x06,0x12,0x0C},// 6 s25fl256s
};

static const unsigned char g_wp_mask_table[][4]=
{
    // 0:   enabe set 0 mask; 1: enable set 1 mask
    // 2: disable set 0 mask; 2:disable set 1 mask
    //en0 en1  dis0 dis1
    {0,    0,   0,    0 }, //ռλ��ֵ��ʹ��
    //W25Q32 m25p64 s25fl064 w25q64 N25Q128 s25fl128 w25q128 a25l032
                           //|SRP0 SEC TB BP2 BP1 BP0 WEL BUSY|
    {0x7f,0x1c,            //| 0   x   x   1   1   1   x   x  |
               0x63,0x00}, //| 0   x   x   0   0   0   x   x  | 
    // MX25L6405D  MX25L12805 at32 at64
    // 2-1                 //|SRP WPDS BP3 BP2 BP1 BP0 WEL WIP|
    {0x7f,0x3c,            //| 0   x   1   1   1   1   x   x  |
               0x43,0x00}  //| 0   x   0   0   0   0   x   x  | 
    // MX25L6405D  MX25L12805 at32 at64                        
};

#define NONE_PROTECT 0
#define CHIP_PROTECT 1
#define SECT_PROTECT -1


/*********************************************************************/
/* Init_flash is used to build a sector table. This information is   */
/* translated from erase_block information to base:offset information*/
/* for each individual sector. This information is then stored       */
/* in the meminfo structure, and used throughout the driver to access*/
/* sector information.                                               */
/*                                                                   */
/* This is more efficient than deriving the sector base:offset       */
/* information every time the memory map switches (since on the      */
/* development platform can only map 64k at a time).  If the entire  */
/* flash memory array can be mapped in, then the addition static     */
/* allocation for the meminfo structure can be eliminated, but the   */
/* drivers will have to be re-written.                               */
/*                                                                   */
/* The meminfo struct occupies 44 bytes of heap space, depending     */
/* on the value of the define MAXSECTORS.  Adjust to suit            */
/* application                                                       */ 
/*********************************************************************/

int spi_flash_init(flash_device_info_t **flash_info)
{
    int i; 
    int idx =0;
    unsigned int B_sec;

    my_spi_init();

    *flash_info = &flash_spi_dev;
#if 0
    /* 
     * in case of flash corrupt, the following steps can erase the flash
     * 1. jumper USE_SPI_SLAVE to make SPI in slave mode
     * 2. start up JTAG debuger and remove the USE_SPI_SLAVE jumper 
     * 3. run the following code to erase the flash
     */
    flash_sector_erase_int(0);
    flash_sector_erase_int(1);
    printk("flash_init: erase all sectors\n");
    return FLASH_API_OK;
#endif

    flash_spi_dev.flash_device_id = spi_flash_get_device_id();

    for(i =0; i < (sizeof(g_flash_table)/sizeof(g_flash_table[0])); i++)
	{
        if((g_flash_table[i].mtc_id == flash_spi_dev.flash_device_id )
        || (g_flash_table[i].mtc_id == 0))
        {
            idx = i;
			break;
        }
	}
	
    strcpy( flash_spi_dev.flash_device_name, g_flash_table[idx].p_name);
    f_info.mtc_id       = g_flash_table[idx].mtc_id;
    f_info.cmd_idx      = g_flash_table[idx].cmd_idx;
    f_info.t_size       =(unsigned int)g_flash_table[idx].MB_size <<20;
    f_info.B_page       = g_para_tabel[g_flash_table[idx].cmd_idx].B_page;
    f_info.cmd_erase    = g_para_tabel[g_flash_table[idx].cmd_idx].cmd_erase;
    f_info.cmd_wren     = g_para_tabel[g_flash_table[idx].cmd_idx].cmd_wren;
    f_info.cmd_prog     = g_para_tabel[g_flash_table[idx].cmd_idx].cmd_prog;
    f_info.cmd_read     = g_para_tabel[g_flash_table[idx].cmd_idx].cmd_read;
     
	B_sec =((unsigned int)g_para_tabel[g_flash_table[idx].cmd_idx].KB_sec) <<10;
    f_info.n_secs = B_sec? (f_info.t_size/B_sec): 0;    
    
	printf("flash=%s size=%dMB id=0x%06x  sector=%dk spiclk=%dM\n",g_flash_table[idx].p_name,  g_flash_table[idx].MB_size,
	    flash_spi_dev.flash_device_id, g_para_tabel[g_flash_table[idx].cmd_idx].KB_sec, spi_para.flash_clock/1000000);

   #ifdef UNIFORM_SECTOR
    f_info.s_size = B_sec;
   #else
    if(f_info.n_secs > MAXSECTORS)
    {
        printf("secs overlay\n");// 4k��Сsector���������
        f_info.mtc_id    = 0;
        return FLASH_API_ERROR;
    }
    for (i = 0; i < f_info.n_secs; i++) 
    {
        f_info.s_size[i] = B_sec;
        f_info.s_base[i] = i? (f_info.s_base[i-1] + f_info.s_size[i]) :0;
        //printf("size[%d]=%d ",i,f_info.s_size[i]);
    }
   #endif
   
    //f_info.wp_flag = NONE_PROTECT;   //0 ��д����,��ԭ��д����ģʽ 
   #if  0   //def CONFIG_FLASH_PROTECT
    if(g_flash_table[idx].wp_idx < 0)
    {
        f_info.wp_flag = SECT_PROTECT;//atmel ʹ��sector����д����
    }
    else if(g_flash_table[idx].wp_idx > 0)
    {
        f_info.wp_flag = CHIP_PROTECT;//��ͨ��ʹ��ȫ�ּ�д����
        //�Գƴ����ɲ����ֽ���
		//д����ƫ�ƴ��ᵼ��mx��flashд������������
		//S25FL128P uniform 64K sector has BP0-BP4 bit to enable protect
		if((f_info.mtc_id == 0x012018) && (spi_flash_get_device_extid() == 0x0301))
		{
            memcpy(f_info.wp_mask, g_wp_mask_table[2], sizeof(f_info.wp_mask));
		}
		else
		{
            memcpy(f_info.wp_mask, g_wp_mask_table[g_flash_table[idx].wp_idx], sizeof(f_info.wp_mask));
        }
        spi_flash_protect(1);
    }    
   #endif
   
   // 16M���ϵĵ�ַλ���л�Ϊ4�ֽ�
   f_info.flg_ad32 = ((g_flash_table[idx].MB_size >16))? 1: 0;
   if(f_info.flg_ad32)
   { 
        spi_flash_set_ad4B(1);//enable
   }

   f_info.flg_dummy = 1;  //�������Ҫdummy��Ӧ�����ñ�����д 
   f_info.flg_mbit  = 0;  //�ݲ�ʹ��
   //�����Ӧ�Ķ�bitģʽ���ݲ�����
   //spi_flash_multibit_en();

    //readcmd��Ҫ��ѡ��
#if !defined(_BCM968500_) && !defined(CONFIG_BCM968500) && !defined(_BCM963138_) && !defined(CONFIG_BCM963138) && !defined(_BCM963148_) && !defined(CONFIG_BCM963148)
    BcmSpi_SetFlashCtrl(f_info.cmd_read, 1, f_info.flg_dummy, spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID, spi_para.flash_clock, f_info.flg_mbit);
#endif
  
    return (g_flash_table[idx].mtc_id? FLASH_API_OK: FLASH_API_ERROR);
}

#ifdef CONFIG_MIPS_TW
#if 0
#define CMD_RD_ST_REG1  0x05
#define CMD_RD_ST_REG2  0x35
#define CMD_WR_ST_REG   0x01
//����д�������ܵĿ���
static char spi_flash_protect(char isEnable)
{
#ifdef CONFIG_FLASH_PROTECT
    unsigned char buf[4];
    unsigned char stL;
    unsigned char stupL;
    
  #ifndef _CFE_
    down(&spi_flash_lock);
  #endif 

    if(CHIP_PROTECT == f_info.wp_flag)
    {
        buf[0] = CMD_RD_ST_REG1;
        memset(&xfer, 0, sizeof(struct spi_transfer));
        xfer.tx_buf      = buf;
        xfer.rx_buf      = buf;
        xfer.len         = 1;
        xfer.prepend_cnt = 1;
        xfer.speed_hz    = spi_para.flash_clock;
        my_spi_read(&xfer);
        stL = buf[0];    
        //printf(" wp1=%02x ", stL);

        //����״̬
        //REG1:|SRP0_SEC_TB_BP2_BP1_BP0_WEL_BUSY|
        //     | 0  _ x _x _ 1 _ 1 _ 1 _ x _ x  |enable
        //     | 0  _ x _x _ 0 _ 0 _ 0 _ x _ x  |disable
		/*stupL = isEnable? ((stL & 0x7f) | 0x1c) //b0xx111xx
                        : ((stL & 0x63) | 0x00);//b0xx000xx8*/

        //wp_mask [en0,en1,dis0,dis1]�ò�����������Ĭ��ֵ��������
        stupL = isEnable? ((stL & f_info.wp_mask[0]) | f_info.wp_mask[1])  
                        : ((stL & f_info.wp_mask[2]) | f_info.wp_mask[3]);

        //����Ƿ���ͬ
        if(stupL != stL)
        {
            //����д�Ĵ���
            buf[0] = FLASH_WREN;
            my_spi_write(buf, 1);
            while (spi_flash_status() != STATUS_READY);
            buf[0] = FLASH_WRST;
            buf[1] = stupL;
            my_spi_write(buf, 2);
            while (spi_flash_status() != STATUS_READY);
            //�Ƿ�Ҫ��鲢�������
        #if 0
            //�ض���У�飬����ʱ��
            //��ȡ״̬1��
            buf[0] = CMD_RD_ST_REG1;
            memset(&xfer, 0, sizeof(struct spi_transfer));
            xfer.tx_buf      = buf;
            xfer.rx_buf      = buf;
            xfer.len         = 1;
            xfer.prepend_cnt = 1;
            xfer.speed_hz    = spi_para.flash_clock;
            my_spi_read(&xfer);
            stL = buf[0];    
            printf(" wp2=%02x\n", stL);
        #endif        
        }
    }
    
    //����������д�Ĵ��� ��ȷ�ϻ��Զ���λ��ɲ�д    
    if(isEnable)
    {
        buf[0] = FLASH_WRDI;
        my_spi_write(buf, 1);
        while (spi_flash_status() != STATUS_READY);
    }
    else
    {
        buf[0] = FLASH_WREN;
        my_spi_write(buf, 1);
        while (spi_flash_status() != STATUS_READY);
        #if 0
            //�ض���У�飬����ʱ��
            //��ȡ״̬1��
            buf[0] = CMD_RD_ST_REG1;
            memset(&xfer, 0, sizeof(struct spi_transfer));
            xfer.tx_buf      = buf;
            xfer.rx_buf      = buf;
            xfer.len         = 1;
            xfer.prepend_cnt = 1;
            xfer.speed_hz    = spi_para.flash_clock;
            my_spi_read(&xfer);
            stL = buf[0];    
            printf(" wp3=%02x\n", stL);
        #endif        
    }
  #ifndef _CFE_
    up(&spi_flash_lock);
  #endif

#endif
    return (CHIP_PROTECT == f_info.wp_flag)? 1: 0;
}
#endif

/*********************************************************************/
/* flash_ub() places the flash into unlock bypass mode.  This        */
/* is REQUIRED to be called before any of the other unlock bypass    */
/* commands will become valid (most will be ignored without first    */
/* calling this function.                                            */
/*********************************************************************/

static int spi_flash_ub(unsigned short sector)
{
    unsigned char buf[4];


    //if(NONE_PROTECT ==f_info.wp_flag) 
    {
        do {
            buf[0]           = FLASH_RDSR;
            memset(&xfer, 0, sizeof(struct spi_transfer));
            xfer.tx_buf      = buf;
            xfer.rx_buf      = buf;
            xfer.len         = 1;
            xfer.speed_hz    = spi_para.flash_clock;
            xfer.prepend_cnt = 1;
            if (my_spi_read(&xfer) == SPI_STATUS_OK) {
                while (spi_flash_status() != STATUS_READY);
                if (buf[0] & (SR_BP3|SR_BP2|SR_BP1|SR_BP0)) {
                    /* Sector is write protected. Unprotect it */
                    buf[0] = FLASH_WREN;
                    if (my_spi_write(buf, 1) == SPI_STATUS_OK) {
                        buf[0] = FLASH_WRST;
                        buf[1] = 0;
                        if (my_spi_write(buf, 2) == SPI_STATUS_OK)
                            while (spi_flash_status() != STATUS_READY);
                    }
                }
                else {
                    break;
                }
            }
            else {
                break;
            }
        } while (1);
    }

    /* set device to write enabled */
    buf[0] = FLASH_WREN;

    /* check device is ready */
    if (my_spi_write(buf, 1) == SPI_STATUS_OK) {
        while (spi_flash_status() != STATUS_READY);
        do {
            buf[0]           = FLASH_RDSR;
            memset(&xfer, 0, sizeof(struct spi_transfer));
            xfer.tx_buf      = buf;
            xfer.rx_buf      = buf;
            xfer.len         = 1;
            xfer.speed_hz    = spi_para.flash_clock;
            xfer.prepend_cnt = 1;
            if (my_spi_read(&xfer) == SPI_STATUS_OK) {
                while (spi_flash_status() != STATUS_READY);
                if (buf[0] & SR_WEN) {
                    break;
                }
            } 
            else {
                break;
            }
        } while (1);
    }

    return(FLASH_API_OK);
}

// �������ֽڵ�ַģʽ
//�˳�4Bģʽ����������ǰ��Ҫ�л���24λģʽ
static void spi_flash_set_ad4B(char  isEnable)
{
    unsigned char buf[4];
    
    
    if(f_info.flg_ad32)
    {
      #ifndef _CFE_
        down(&spi_flash_lock);
      #endif
      
        if(f_info.mtc_id == 0x010219 || f_info.mtc_id == 0x010220)//s25fl256s/512s
        {
            if(f_info.cmd_idx ==3 || f_info.cmd_idx == 4)
            {//�˴������ǲ���ָ�����ģʽ�л�ʵ��4B
                buf[0] = 0x16;//��bank reg extadd
                memset(&xfer, 0, sizeof(struct spi_transfer));
                xfer.tx_buf      = buf;
                xfer.rx_buf      = buf;
                xfer.len         = 1;
                xfer.prepend_cnt = 1;
                xfer.speed_hz    = spi_para.flash_clock;
                my_spi_read(&xfer);
                while (spi_flash_status() != STATUS_READY);
                
				//�Զ���ֵ�޸�
				buf[1] = isEnable? (buf[0] | 0x80): (buf[0] & 0x7f); 
                buf[0] = 0x17;//дbank reg extadd
				//buf[1]��������ֵ               
                my_spi_write(buf, 2);
                while (spi_flash_status() != STATUS_READY);
            }
            else//idx ==6
            {
                #ifndef _CFE_
                  up(&spi_flash_lock);
                #endif  
                return;//��ָ����л�ģʽ
            }    
        }
        else//����mx st����
        {
            // numoney����д֮ǰ��������д
            buf[0] = FLASH_WREN;
            my_spi_write(buf, 1);
            while (spi_flash_status() != STATUS_READY);
            
            printf("flash 4B addr %s\n", isEnable? "enable": "disable");
            buf[0] = isEnable? FLASH_EN4B: FLASH_EXIT4B;
            my_spi_write(buf, 1);
            while (spi_flash_status() != STATUS_READY);
        } 

      #ifndef _CFE_
        up(&spi_flash_lock);
      #endif  
    }
    
    return;
}

static void spi_flash_show_list(void)
{
    int i;
    printf("flash id  name\n");
    for(i =0; i < (sizeof(g_flash_table)/sizeof(g_flash_table[0]))-1; i++)
	{    
	    printf("0x%6x  %s\n",g_flash_table[i].mtc_id ,g_flash_table[i].p_name);
	} 
    return;
}
#endif

#if 0
/*******************************************************************************/
/* flash_get_device_extid() return the device extern id of the component.      */
/*******************************************************************************/
static unsigned int spi_flash_get_device_extid(void)
{
    unsigned char buf[5];
    memset(&xfer, 0, sizeof(struct spi_transfer));
    buf[0]           = FLASH_RDID;
    
    xfer.tx_buf      = buf;
    xfer.rx_buf      = buf;
    xfer.len         = 5;
    xfer.speed_hz    = spi_para.flash_clock;
    xfer.prepend_cnt = 1;
    my_spi_read(&xfer);
    while(spi_flash_status() != STATUS_READY);
    return( buf[3]<<8 | buf[4] );
}
#endif

/*********************************************************************/
/* Flash_sector_erase_int() wait until the erase is completed before */
/* returning control to the calling function.  This can be used in   */
/* cases which require the program to hold until a sector is erased, */
/* without adding the wait check external to this function.          */
/*********************************************************************/

static int spi_flash_sector_erase_int(unsigned short sector)
{
    unsigned char buf[6];
    unsigned int cmd_length;
    unsigned int addr;

    if (!f_info.mtc_id)
        return FLASH_API_ERROR;

    printf("e%u",sector);

#ifndef _CFE_
    down(&spi_flash_lock);
#endif

    /* set device to write enabled */
    spi_flash_reset();
    spi_flash_ub(sector);

    /* erase the sector  */
    addr = (unsigned int) spi_get_abso_addr(sector);

    cmd_length = 0;
    buf[cmd_length++] = f_info.cmd_erase;

    if ( f_info.flg_ad32 )
        buf[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);

    buf[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
    buf[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
    buf[cmd_length++] = (unsigned char)(addr & 0x000000ff);

    /* check device is ready */
    if (my_spi_write(buf, cmd_length) == SPI_STATUS_OK) {
        while (spi_flash_status() != STATUS_READY);
    }

#ifndef _CFE_
    up(&spi_flash_lock);
#endif

    return(FLASH_API_OK);
}

#if 0
/*********************************************************************/
/* spi_flash_en4b() will enable the flash part to start using 4 byte addressing mode. */
/*********************************************************************/

static int spi_flash_en4b(void)
{
    unsigned char buf[4];
    static int initialized = 0;

    if (flashManufacturer == SPANPART)
    {        
        int latencyCode = 0;
        struct spi_transfer xfer;

        if (!initialized)
        {
            initialized             = 1;
            spi_read_cmd            = FLASH_4READ_FAST;
            spi_dualOut_read_cmd    = FLASH_4READ_DOR;
            spi_dualIO_read_cmd     = FLASH_4READ_DIOR;
            spi_write_cmd           = FLASH_4PROG;
            spi_erase_cmd           = FLASH_4BERASE;
            spi_serase_cmd          = FLASH_4SERASE;
     
            memset(&xfer, 0, sizeof(struct spi_transfer));
            buf[0]           = FLASH_RDCR;
            xfer.tx_buf      = buf;
            xfer.rx_buf      = buf;
            xfer.len         = 1;
            xfer.speed_hz    = spi_para.flash_clock;
            xfer.prepend_cnt = 1;
            my_spi_read(&xfer);
            while (spi_flash_status() != STATUS_READY);
    
            latencyCode = (buf[0] & 0xC0) >> 6;
            if (latencyCode == 0x3)
            {
                spi_dummy_bytes = 0;  
            }
        }
    }
    else
    {
        if ( (flashManufacturer == NUMONYXPART) && (flashMemtype == FLASH_MEMTYPE_BA) && !initialized)
        {
            initialized             = 1;
            spi_read_cmd            = FLASH_4READ_FAST;
            spi_dualOut_read_cmd    = FLASH_4READ_DOR;
            spi_dualIO_read_cmd     = FLASH_4READ_DIOR;
            spi_write_cmd           = FLASH_4PROG;
            spi_erase_cmd           = FLASH_4BERASE;
            spi_serase_cmd          = FLASH_4SERASE;
        }
        /* set device to enter 4 byte addressing mode */
        buf[0] = FLASH_EN4B;
        my_spi_write(buf, 1);
        while (spi_flash_status() != STATUS_READY);
    }


    return(FLASH_API_OK);
}

/*********************************************************************/
/* spi_flash_disable4b() will disable the 4byte addressing mode on the flash part. */
/*********************************************************************/

static int spi_flash_disable4b(void)
{
    if (flashManufacturer != SPANPART)
    {       
        unsigned char buf[4];
        buf[0] = FLASH_EXIT4B; 
        my_spi_write(buf, 1);
        while (spi_flash_status() != STATUS_READY);
    }

    return(FLASH_API_OK);

}
#endif

/*********************************************************************/
/* flash_reset() will reset the flash device to reading array data.  */
/* It is good practice to call this function after autoselect        */
/* sequences had been performed.                                     */
/*********************************************************************/

static int spi_flash_reset(void)
{
    unsigned char buf[4];

    /* set device to write disabled */
    buf[0]        = FLASH_WRDI;
    my_spi_write(buf, 1);
    while (spi_flash_status() != STATUS_READY);

    return(FLASH_API_OK);
}

/*********************************************************************/
/* flash_read_buf() reads buffer of data from the specified          */
/* offset from the sector parameter.                                 */
/*********************************************************************/

#if (INC_BTRM_BOOT==0) && defined(_CFE_) && defined(CFG_RAMAPP)
static
#endif
int spi_flash_read_buf(unsigned short sector, int offset,
    unsigned char *buffer, int nbytes)
{
    unsigned char buf[READ_BUF_LEN_MAX];
    unsigned int cmd_length;
    unsigned int addr;
    int maxread;
    int size_read = 0;
    //int multiOffset = 0;
    struct spi_transfer xfer;
    if (!f_info.mtc_id)
        return FLASH_API_ERROR;

    memset(&xfer, 0, sizeof(struct spi_transfer));
#ifndef _CFE_
    down(&spi_flash_lock);
#endif

    addr = (unsigned int) spi_get_abso_addr(sector);
    addr += offset;
    

    while (nbytes > 0) {
        maxread = (nbytes < spi_para.max_op_len) ? nbytes : spi_para.max_op_len;

        cmd_length = 0;
		//���д���Ҫ����
        buf[cmd_length++] = f_info.cmd_read;
        if ( f_info.flg_ad32 )
        {
            buf[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);
        }
        buf[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
        buf[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
        buf[cmd_length++] = (unsigned char)(addr & 0x000000ff);
        if (f_info.flg_dummy)
        {
            buf[cmd_length++] = (unsigned char)0xff;
        }

#if 0
        if (spi_multibit_en)
        {
            if ( spi_read_cmd == spi_dualOut_read_cmd )
               multiOffset = cmd_length; /* only read data is multibit */
            else
               multiOffset = 1; /* addr and data is multibit */
        }
#endif

        xfer.tx_buf                 = buf;
        xfer.rx_buf                 = buffer;
        xfer.len                    = maxread;
        xfer.speed_hz               = spi_para.flash_clock;
        xfer.prepend_cnt            = cmd_length;
        xfer.multi_bit_en           = f_info.flg_mbit;
		//����datasheet�о���ʽ���
        xfer.multi_bit_start_offset = f_info.flg_mbit? ((f_info.cmd_read == FLASH_READ_DOR)? cmd_length: 1): 0 ;
        xfer.addr_len               = (f_info.flg_ad32 ? 4 : 3);
        xfer.addr_offset            = 1;
        xfer.hdr_len                = cmd_length;
        xfer.unit_size              = 1;
        my_spi_read(&xfer);
#if defined(CONFIG_BRCM_IKOS) && (defined(_BCM963138_) || defined(CONFIG_BCM963138) || defined(_BCM963148_) || defined(CONFIG_BCM963148))
        /* simulator only support read cmd */
        {
	    int i;
            for( i = 0; i < 256; i++ );
        }
#else
        while (spi_flash_status() != STATUS_READY);
#endif
        
        buffer += maxread;
        nbytes -= maxread;
        addr += maxread;
        size_read += maxread;
    }

#ifndef _CFE_
    up(&spi_flash_lock);
#endif

    return size_read;
}

/*********************************************************************/
/* flash_write_buf() utilizes                                        */
/* the unlock bypass mode of the flash device.  This can remove      */
/* significant overhead from the bulk programming operation, and     */
/* when programming bulk data a sizeable performance increase can be */
/* observed.                                                         */
/*********************************************************************/

static int spi_flash_write(unsigned short sector, int offset, unsigned char *buffer, int nbytes)
{
    unsigned char buf[FLASH_PAGE_512 + 32];
    unsigned int cmd_length;
    unsigned int addr;
    int maxwrite;
    int pagelimit;
    int bytes_written = 0;

#ifndef _CFE_
    down(&spi_flash_lock);
#endif

    addr = (unsigned int) spi_get_abso_addr(sector);
    addr += offset;

    while (nbytes > 0) {
        spi_flash_ub(sector); /* enable write */

        cmd_length = 0;
        buf[cmd_length++] = f_info.cmd_prog;
        if ( f_info.flg_ad32 )
            buf[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);
        buf[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
        buf[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
        buf[cmd_length++] = (unsigned char)(addr & 0x000000ff);

        /* set length to the smaller of controller limit (spi_para.max_op_len) or nbytes
           spi_para.max_op_len considers both controllers */
        maxwrite = (nbytes < (spi_para.max_op_len - cmd_length)) ? nbytes : (spi_para.max_op_len - cmd_length);
        /* maxwrite is limit to page boundary */
        pagelimit = f_info.B_page - (addr & (f_info.B_page - 1));
        maxwrite = (maxwrite < pagelimit) ? maxwrite : pagelimit;

        memcpy(&buf[cmd_length], buffer, maxwrite);
        my_spi_write(buf, maxwrite + cmd_length);

        while (spi_flash_status() != STATUS_READY);

        buffer += maxwrite;
        nbytes -= maxwrite;
        addr += maxwrite;
        bytes_written += maxwrite;
    }

    spi_flash_reset();    

#ifndef _CFE_
    up(&spi_flash_lock);
#endif

    return( bytes_written );
}

/*********************************************************************/
/* flash_write_buf() utilizes                                        */
/* the unlock bypass mode of the flash device.  This can remove      */
/* significant overhead from the bulk programming operation, and     */
/* when programming bulk data a sizeable performance increase can be */
/* observed.                                                         */
/*********************************************************************/
static int spi_flash_write_buf(unsigned short sector, int offset,
    unsigned char *buffer, int nbytes)
{
    int ret = FLASH_API_ERROR;

    if (!f_info.mtc_id)
        return FLASH_API_ERROR;

    ret = spi_flash_write(sector, offset, buffer, nbytes);

#if (INC_BTRM_BOOT==0)
    if( ret == FLASH_API_ERROR )
        printk( "Flash write error. Verify failed\n" );
#endif

    return( ret );
}

/*********************************************************************/
/* Usefull funtion to return the number of sectors in the device.    */
/* Can be used for functions which need to loop among all the        */
/* sectors, or wish to know the number of the last sector.           */
/*********************************************************************/

static int spi_flash_get_numsectors(void)
{
    return f_info.n_secs;
}

/*********************************************************************/
/* flash_get_sector_size() is provided for cases in which the size   */
/* of a sector is required by a host application.  The sector size   */
/* (in bytes) is returned in the data location pointed to by the     */
/* 'size' parameter.                                                 */
/*********************************************************************/
#if (INC_BTRM_BOOT==0) && defined(_CFE_) && defined(CFG_RAMAPP)
static
#endif
int spi_flash_get_sector_size(unsigned short sector)
{
   #ifdef UNIFORM_SECTOR
    return f_info.s_size;
   #else
    return f_info.s_size[sector];
   #endif
}

/*********************************************************************/
/* The purpose of get_flash_memptr() is to return a memory pointer   */
/* which points to the beginning of memory space allocated for the   */
/* flash.  All function pointers are then referenced from this       */
/* pointer.                                  */
/*                                                                   */
/* Different systems will implement this in different ways:          */
/* possibilities include:                                            */
/*  - A direct memory pointer                                        */
/*  - A pointer to a memory map                                      */
/*  - A pointer to a hardware port from which the linear             */
/*    address is translated                                          */
/*  - Output of an MMU function / service                            */
/*                                                                   */
/* Also note that this function expects the pointer to a specific    */
/* sector of the device.  This can be provided by dereferencing      */
/* the pointer from a translated offset of the sector from a         */
/* global base pointer (e.g. flashptr = base_pointer + sector_offset)*/
/*                                                                   */
/* Important: Many AMD flash devices need both bank and or sector    */
/* address bits to be correctly set (bank address bits are A18-A16,  */
/* and sector address bits are A18-A12, or A12-A15).  Flash parts    */
/* which do not need these bits will ignore them, so it is safe to   */
/* assume that every part will require these bits to be set.         */
/*********************************************************************/


static unsigned char *spi_flash_get_memptr(unsigned short sector)
{
   #ifdef UNIFORM_SECTOR
    return (unsigned char*)(FLASH_BASE + f_info.s_size*sector);
   #else
    return (unsigned char*)(FLASH_BASE + f_info.s_base[sector]);
   #endif
}

/*********************************************************************/
/* Flash_status return an appropriate status code                    */
/*********************************************************************/

static int spi_flash_status(void)
{
    unsigned char buf[4];
    int retry = 10;

    /* check device is ready */
    memset(&xfer, 0, sizeof(struct spi_transfer));
    do {
        buf[0]           = FLASH_RDSR;
        xfer.tx_buf      = buf;
        xfer.rx_buf      = buf;
        xfer.len         = 1;
        xfer.speed_hz    = spi_para.flash_clock;
        xfer.prepend_cnt = 1;
        if (my_spi_read(&xfer) == SPI_STATUS_OK) {
            if (!(buf[0] & SR_RDY)) {
                return STATUS_READY;
            }
        } else {
            return STATUS_ERROR;
        }
        OSL_DELAY(10);
    } while (retry--);

    return STATUS_TIMEOUT;
}

/*********************************************************************/
/* flash_get_device_id() return the device id of the component.      */
/*********************************************************************/

static unsigned int spi_flash_get_device_id(void)
{
#if defined(CONFIG_BRCM_IKOS) && (defined(_BCM963138_) || defined(CONFIG_BCM963138) || defined(_BCM963148_) || defined(CONFIG_BCM963148))
    return 0x0e0e;
#else
    unsigned char buf[4];

    memset(&xfer, 0, sizeof(struct spi_transfer));
    buf[0]           = FLASH_RDID;
    xfer.tx_buf      = buf;
    xfer.rx_buf      = buf;
    xfer.len         = 3;
    xfer.speed_hz    = spi_para.flash_clock;
    xfer.prepend_cnt = 1;
    my_spi_read(&xfer);
    
    while (spi_flash_status() != STATUS_READY);

    /* return manufacturer code and device code */
    return((buf[0]<<16)|(buf[1]<<8)|buf[2]);
#endif
}

/*********************************************************************/
/* The purpose of flash_get_blk() is to return a the block number */
/* for a given memory address.                                       */
/*********************************************************************/

static int spi_flash_get_blk(int addr)
{
    int relative_addr = addr - (int)FLASH_BASE;
   #ifdef UNIFORM_SECTOR
    return (relative_addr/f_info.s_size);
   #else
    int blk_start, i;
    int last_blk = f_info.n_secs;

    for(blk_start=0, i=0; i < relative_addr && blk_start < last_blk; blk_start++)
        i += f_info.s_size[blk_start];

    if( (unsigned int)i > (unsigned int)relative_addr ) 
    {
        blk_start--;        // last blk, dec by 1
    } 
    else 
    {
        if( blk_start == last_blk )
        {
#if (INC_BTRM_BOOT==0)
            printf("Address is too big.\n");
#endif
            blk_start = -1;
        }
    }

    return( blk_start );
   #endif
}

/************************************************************************/
/* The purpose of flash_get_total_size() is to return the total size of */
/* the flash                                                            */
/************************************************************************/
static int spi_flash_get_total_size(void)
{
    return f_info.t_size;
}

#if 0
static void spi_flash_multibit_en( void )
{
   unsigned char       buf[16];
   unsigned char       bufCmp[16];
   unsigned int        cmd_length;
   unsigned int        addr;
   struct spi_transfer xfer;
   int                 i;

   memset(&xfer, 0, sizeof(struct spi_transfer));

#ifndef _CFE_
   down(&spi_flash_lock);
#endif

   /* read 16 bytes of data form the first sector of flash
      this will be used to compare to the data read using the DOR
      and DIOR commands */
   addr              = (unsigned int) spi_get_flash_memptr(NVRAM_SECTOR);
   cmd_length        = 0;
   buf[cmd_length++] = spi_read_cmd;
   if ( f_info.flg_ad32 )
   {
       spi_flash_en4b();
       buf[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);
   }
   buf[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
   buf[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
   buf[cmd_length++] = (unsigned char)(addr & 0x000000ff);
   if ( spi_dummy_bytes ) 
      buf[cmd_length++] = (unsigned char)0xff;

   xfer.tx_buf      = buf;
   xfer.rx_buf      = buf;
   xfer.len         = 16;
   xfer.speed_hz    = spi_para.flash_clock;
   xfer.prepend_cnt = cmd_length;
   my_spi_read(&xfer);
   while (spi_flash_status() != STATUS_READY);

   /* if the data read above is all 1's then we cannot determine if multibit is
      supported by the flash so just return */
   for ( i = 0; i < 16; i++)
   {
      if ( buf[i] != 0xFF )
      {
         break;
      }
      if ( 15 == i )
      {
          if ( f_info.flg_ad32 )
          {
              spi_flash_disable4b();
          }
      
#ifndef _CFE_

          up(&spi_flash_lock);
#endif      
         return;
      }
   }

   /* try the DIOR instruction
      if the data matches the previously read data then it is supported */
   addr              = (unsigned int) spi_get_flash_memptr(NVRAM_SECTOR);
   cmd_length        = 0;
   bufCmp[cmd_length++] = spi_dualIO_read_cmd;

   if ( f_info.flg_ad32 )
      bufCmp[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);
   
   bufCmp[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
   bufCmp[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
   bufCmp[cmd_length++] = (unsigned char)(addr & 0x000000ff);
   if (spi_dummy_bytes)
   {
       bufCmp[cmd_length++] = (unsigned char)0xff;
   }

   xfer.tx_buf                 = bufCmp;
   xfer.rx_buf                 = bufCmp;
   xfer.len                    = 16;
   xfer.speed_hz               = spi_para.flash_clock;
   xfer.prepend_cnt            = cmd_length;
   xfer.multi_bit_en           = 1;
   xfer.multi_bit_start_offset = 1;
   my_spi_read(&xfer);
   while (spi_flash_status() != STATUS_READY);

   if ( 0 == memcmp(buf, bufCmp, 16) )
   {
      /* DIOR command is supported */
      spi_read_cmd    = spi_dualIO_read_cmd;
      spi_multibit_en = 1;
      if ( f_info.flg_ad32 )
      {
          spi_flash_disable4b();
      }
      
#ifndef _CFE_
      up(&spi_flash_lock);
#endif
      return;
   }

   /* try the DOR command
      if the data matches the previously read data then it is supported */
   addr              = (unsigned int) spi_get_flash_memptr(NVRAM_SECTOR);
   cmd_length        = 0;
   bufCmp[cmd_length++] = spi_dualOut_read_cmd;
   if ( f_info.flg_ad32 )
      bufCmp[cmd_length++] = (unsigned char)((addr & 0xff000000) >> 24);
   bufCmp[cmd_length++] = (unsigned char)((addr & 0x00ff0000) >> 16);
   bufCmp[cmd_length++] = (unsigned char)((addr & 0x0000ff00) >> 8);
   bufCmp[cmd_length++] = (unsigned char)(addr & 0x000000ff);
   if (spi_dummy_bytes)
   {
       bufCmp[cmd_length++] = (unsigned char)0xff;
   }
   
   xfer.tx_buf                 = bufCmp;
   xfer.rx_buf                 = bufCmp;
   xfer.len                    = 16;
   xfer.speed_hz               = spi_para.flash_clock;
   xfer.prepend_cnt            = cmd_length;
   xfer.multi_bit_en           = 1;
   xfer.multi_bit_start_offset = cmd_length;
   my_spi_read(&xfer);
   while (spi_flash_status() != STATUS_READY);

   if ( 0 == memcmp(buf, bufCmp, 16) )
   {
      /* DOR command is supported */
      spi_read_cmd    = spi_dualOut_read_cmd;
      spi_multibit_en = 1;
      if ( f_info.flg_ad32 )
      {
          spi_flash_disable4b();
      }
      
#ifndef _CFE_
      up(&spi_flash_lock);
#endif
      return;
   }
   
   if ( f_info.flg_ad32 )
   {
       spi_flash_disable4b();
   }

#ifndef _CFE_
    up(&spi_flash_lock);
#endif

}
#endif

#ifndef _CFE_
static int __init BcmSpiflash_init(void)
{
    int flashType;
    int spiCtrlState;

    /* If serial flash is present then register the device. Otherwise do nothing */
    flashType  = flash_get_flash_type();
    if ((FLASH_IFC_SPI == flashType) || (FLASH_IFC_HS_SPI == flashType))
    {
        /* register the device */
        spi_para.ctrlState = SPI_CONTROLLER_STATE_DEFAULT;
        if ( spi_para.flash_clock > SPI_CONTROLLER_MAX_SYNC_CLOCK )
           spi_para.ctrlState |= SPI_CONTROLLER_STATE_ASYNC_CLOCK;
        
        BcmSpiReserveSlave2(spi_para.flash_busnum, SPI_FLASH_SLAVE_DEV_ID, 
                            spi_para.flash_clock, SPI_MODE_DEFAULT, spi_para.ctrlState);
        bSpiFlashSlaveRes = TRUE;
		//���ؽ��Ϊ-1,�ᵼ��cpu0��panic��ȥ��
        //spi_para.max_op_len    = BcmSpi_GetMaxRWSize( spi_para.flash_busnum, 1 );
    }

    return 0;
}
module_init(BcmSpiflash_init);

static void __exit BcmSpiflash_exit(void)
{
    bSpiFlashSlaveRes = FALSE;
}
module_exit(BcmSpiflash_exit);
#endif

