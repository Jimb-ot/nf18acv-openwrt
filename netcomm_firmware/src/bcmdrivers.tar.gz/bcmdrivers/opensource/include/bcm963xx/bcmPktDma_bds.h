#ifndef __PKTDMA_BDS_H_INCLUDED__
#define __PKTDMA_BDS_H_INCLUDED__

#include <bcm_pkt_lengths.h>
#define DMA_MAX_BURST_LENGTH    8       /* in 64 bit words */


#endif /* __PKTDMA_BDS_H_INCLUDED__ */
