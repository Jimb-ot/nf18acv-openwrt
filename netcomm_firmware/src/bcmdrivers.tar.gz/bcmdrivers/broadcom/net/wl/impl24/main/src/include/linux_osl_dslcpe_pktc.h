/*
    Copyright (c) 2017 Broadcom
    All Rights Reserved

    <:label-BRCM:2017:DUAL/GPL:standard

    Unless you and Broadcom execute a separate written software license
    agreement governing use of this software, this software is licensed
    to you under the terms of the GNU General Public License version 2
    (the "GPL"), available at http://www.broadcom.com/licenses/GPLv2.php,
    with the following added to such license:

       As a special exception, the copyright holders of this software give
       you permission to link this software with independent modules, and
       to copy and distribute the resulting executable under terms of your
       choice, provided that you also meet, for each linked independent
       module, the terms and conditions of the license of that module.
       An independent module is a module which is not derived from this
       software.  The special exception does not apply to any modifications
       of the software.

    Not withstanding the above, under no circumstances may you combine
    this software in any way with any other Broadcom software provided
    under a license other than the GPL, without Broadcom's express prior
    written consent.

    :>
*/

#ifndef _linux_osl_dslcpe_pktc_h_
#define _linux_osl_dslcpe_pktc_h_

#if defined(DSLCPE) && defined(PKTC)

/* Use 8 bytes of skb pktc_cb field to store below info */
struct chain_node {
        struct sk_buff  *link;
        unsigned int    flags:3, pkts:9, bytes:20;
};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36)
#define CHAINED (1 << 3)
#define PKTISCHAINED(skb)       (IS_SKBUFF_PTR(skb) ? (((struct sk_buff*)(skb))->pktc_flags & CHAINED) : FALSE)
#ifndef CHAIN_NODE
#define CHAIN_NODE(skb)         ((struct chain_node*)(((struct sk_buff*)skb)->pktc_cb))
#endif
#endif

#ifndef PKTCLINK
#define PKTCLINK(skb)           (CHAIN_NODE(skb)->link)
#endif

/* PKTC requests */
#define BRC_HOT_INIT                    1    /* Initialize hot bridge table */
#define BRC_HOT_GET_BY_DA               2    /* Get BRC_HOT pointer for pkt chaining by dest addr */
#define BRC_HOT_GET_BY_IDX              3    /* Get BRC_HOT pointer for pkt chaining by table index */
#define UPDATE_BRC_HOT                  4    /* To update BRC_HOT entry */
#define UPDATE_WLAN_HANDLE              5    /* To update wlan handle */
#define SET_PKTC_TX_MODE                6    /* To set pktc tx mode: enabled=0, disabled=1 */
#define GET_PKTC_TX_MODE                7    /* To get pktc tx mode: enabled=0, disabled=1 */
#define DELETE_BRC_HOT                  8    /* To delete BRC_HOT entry */
#define DUMP_BRC_HOT                    9    /* To dump BRC_HOT table */
#define BRC_HOT_GET_TABLE_TOP           10   /* Get the address/top of BRC_HOT table */
#define DELETE_WLAN_HANDLE              11   /* To delete wlan handle in wldev table */
#define UPDATE_WFD_IDX_BY_WL_DEV        12   /* To update WFD Index by WLAN Dev */
#define FLUSH_BRC_HOT                   13   /* To flush out entire BRC_HOT table */
#define BRC_HOT_SET_STA_ASSOC           14   /* To set STA state in the BRC_HOT entry */

extern uint32_t wl_pktc_req(int req_id, uint32_t param0, uint32_t param1, uint32_t param2);
extern uint32_t wl_pktc_req_with_lock(int req_id, uint32_t param0, uint32_t param1, uint32_t param2);
extern uint32_t (*wl_pktc_req_hook)(int req_id, uint32_t param0, uint32_t param1, uint32_t param2);

#if defined(CONFIG_BCM963138) || defined(CONFIG_BCM963148) || defined(CONFIG_BCM96838) || defined(CONFIG_BCM96848)
#define INVALID_CHAIN_IDX  0x3FFE
#else
#define INVALID_CHAIN_IDX  0xFE
#endif

#define WFD_IDX_UINT16_BIT_MASK   (0xC000)
#define WFD_IDX_UINT16_BIT_POS    14

#endif /* DSLCPE && PKTC */

#endif
