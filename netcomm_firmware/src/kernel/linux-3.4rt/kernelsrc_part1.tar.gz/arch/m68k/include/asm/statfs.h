#ifndef _M68K_STATFS_H
#define _M68K_STATFS_H

#include <asm-generic/statfs.h>

#endif /* _M68K_STATFS_H */
