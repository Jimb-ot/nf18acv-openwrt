#ifndef __M68K_CPUTIME_H
#define __M68K_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __M68K_CPUTIME_H */
