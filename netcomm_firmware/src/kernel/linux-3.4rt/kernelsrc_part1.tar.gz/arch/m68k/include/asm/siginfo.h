#ifndef _M68K_SIGINFO_H
#define _M68K_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
