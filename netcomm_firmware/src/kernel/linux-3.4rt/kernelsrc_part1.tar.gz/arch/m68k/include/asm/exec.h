#ifndef _M68K_EXEC_H
#define _M68K_EXEC_H

#define arch_align_stack(x) (x)

#endif /* _M68K_EXEC_H */
