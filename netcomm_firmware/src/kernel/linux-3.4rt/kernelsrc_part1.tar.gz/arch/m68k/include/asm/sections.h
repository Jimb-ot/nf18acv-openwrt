#ifndef _ASM_M68K_SECTIONS_H
#define _ASM_M68K_SECTIONS_H

#include <asm-generic/sections.h>

extern char _sbss[], _ebss[];

#endif /* _ASM_M68K_SECTIONS_H */
