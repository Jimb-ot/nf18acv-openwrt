#ifndef __ASM_AVR32_DIV64_H
#define __ASM_AVR32_DIV64_H

#include <asm-generic/div64.h>

#endif /* __ASM_AVR32_DIV64_H */
