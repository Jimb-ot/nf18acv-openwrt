#ifndef __ASM_AVR32_CPUTIME_H
#define __ASM_AVR32_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __ASM_AVR32_CPUTIME_H */
