#ifndef __ASM_AVR32_RESOURCE_H
#define __ASM_AVR32_RESOURCE_H

#include <asm-generic/resource.h>

#endif /* __ASM_AVR32_RESOURCE_H */
