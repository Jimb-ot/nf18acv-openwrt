#ifndef _ASM_XOR_H
#define _ASM_XOR_H

#include <asm-generic/xor.h>

#endif
