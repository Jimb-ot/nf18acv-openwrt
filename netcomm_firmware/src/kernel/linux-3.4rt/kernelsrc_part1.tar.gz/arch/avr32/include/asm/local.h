#ifndef __ASM_AVR32_LOCAL_H
#define __ASM_AVR32_LOCAL_H

#include <asm-generic/local.h>

#endif /* __ASM_AVR32_LOCAL_H */
