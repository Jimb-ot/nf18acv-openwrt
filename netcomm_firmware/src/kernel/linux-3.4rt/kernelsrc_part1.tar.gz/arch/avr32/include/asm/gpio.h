#ifndef __ASM_AVR32_GPIO_H
#define __ASM_AVR32_GPIO_H

#include <mach/gpio.h>

#endif /* __ASM_AVR32_GPIO_H */
