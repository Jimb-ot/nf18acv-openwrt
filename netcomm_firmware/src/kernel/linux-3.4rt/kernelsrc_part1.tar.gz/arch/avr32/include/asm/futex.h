#ifndef __ASM_AVR32_FUTEX_H
#define __ASM_AVR32_FUTEX_H

#include <asm-generic/futex.h>

#endif /* __ASM_AVR32_FUTEX_H */
