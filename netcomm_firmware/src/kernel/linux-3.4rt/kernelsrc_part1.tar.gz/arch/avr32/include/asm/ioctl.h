#ifndef __ASM_AVR32_IOCTL_H
#define __ASM_AVR32_IOCTL_H

#include <asm-generic/ioctl.h>

#endif /* __ASM_AVR32_IOCTL_H */
