#ifndef __ASM_AVR32_NUMNODES_H
#define __ASM_AVR32_NUMNODES_H

/* Max 4 nodes */
#define NODES_SHIFT	2

#endif /* __ASM_AVR32_NUMNODES_H */
