#ifndef __ASM_AVR32_HARDIRQ_H
#define __ASM_AVR32_HARDIRQ_H
#ifndef __ASSEMBLY__
#include <asm-generic/hardirq.h>
#endif /* __ASSEMBLY__ */
#endif /* __ASM_AVR32_HARDIRQ_H */
