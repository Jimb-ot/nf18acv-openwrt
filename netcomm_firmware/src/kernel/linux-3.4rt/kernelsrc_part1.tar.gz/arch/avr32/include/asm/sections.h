#ifndef __ASM_AVR32_SECTIONS_H
#define __ASM_AVR32_SECTIONS_H

#include <asm-generic/sections.h>

#endif /* __ASM_AVR32_SECTIONS_H */
