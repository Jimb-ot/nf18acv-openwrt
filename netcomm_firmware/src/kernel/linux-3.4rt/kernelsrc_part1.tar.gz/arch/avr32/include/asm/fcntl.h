#ifndef __ASM_AVR32_FCNTL_H
#define __ASM_AVR32_FCNTL_H

#include <asm-generic/fcntl.h>

#endif /* __ASM_AVR32_FCNTL_H */
