/*
 * AVR32 endian-conversion functions.
 */
#ifndef __ASM_AVR32_BYTEORDER_H
#define __ASM_AVR32_BYTEORDER_H

#include <linux/byteorder/big_endian.h>

#endif /* __ASM_AVR32_BYTEORDER_H */
