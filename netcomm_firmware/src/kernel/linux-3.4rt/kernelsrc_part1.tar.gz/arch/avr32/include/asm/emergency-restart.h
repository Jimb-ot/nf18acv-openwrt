#ifndef __ASM_AVR32_EMERGENCY_RESTART_H
#define __ASM_AVR32_EMERGENCY_RESTART_H

#include <asm-generic/emergency-restart.h>

#endif /* __ASM_AVR32_EMERGENCY_RESTART_H */
