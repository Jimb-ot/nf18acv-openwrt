#ifndef __ASM_AVR32_PCI_H__
#define __ASM_AVR32_PCI_H__

/* We don't support PCI yet, but some drivers require this file anyway */

#define PCI_DMA_BUS_IS_PHYS	(1)

#include <asm-generic/pci-dma-compat.h>

#endif /* __ASM_AVR32_PCI_H__ */
