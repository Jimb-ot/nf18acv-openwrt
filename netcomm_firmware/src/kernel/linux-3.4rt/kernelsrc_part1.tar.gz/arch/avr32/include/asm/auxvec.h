#ifndef __ASM_AVR32_AUXVEC_H
#define __ASM_AVR32_AUXVEC_H

#endif /* __ASM_AVR32_AUXVEC_H */
