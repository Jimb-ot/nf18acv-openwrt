#ifndef __ASM_AVR32_STATFS_H
#define __ASM_AVR32_STATFS_H

#include <asm-generic/statfs.h>

#endif /* __ASM_AVR32_STATFS_H */
