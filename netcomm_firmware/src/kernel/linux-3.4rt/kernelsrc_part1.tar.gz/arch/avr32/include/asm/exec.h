/*
 * Copyright (C) 2004-2006 Atmel Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#ifndef __ASM_AVR32_EXEC_H
#define __ASM_AVR32_EXEC_H

#define arch_align_stack(x)	(x)

#endif /* __ASM_AVR32_EXEC_H */
