#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

#define __ALIGN .balign 2
#define __ALIGN_STR ".balign 2"

#endif /* __ASM_LINKAGE_H */
