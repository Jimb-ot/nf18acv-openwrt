#ifndef __ASM_AVR32_ERRNO_H
#define __ASM_AVR32_ERRNO_H

#include <asm-generic/errno.h>

#endif /* __ASM_AVR32_ERRNO_H */
