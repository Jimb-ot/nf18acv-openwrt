#ifndef _AVR32_SIGINFO_H
#define _AVR32_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
