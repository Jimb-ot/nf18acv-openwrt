#ifndef __ASM_AVR32_TOPOLOGY_H
#define __ASM_AVR32_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* __ASM_AVR32_TOPOLOGY_H */
