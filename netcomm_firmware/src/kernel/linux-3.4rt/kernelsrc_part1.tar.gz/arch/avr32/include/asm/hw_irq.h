#ifndef __ASM_AVR32_HW_IRQ_H
#define __ASM_AVR32_HW_IRQ_H

static inline void hw_resend_irq(struct irq_chip *h, unsigned int i)
{
	/* Nothing to do */
}

#endif /* __ASM_AVR32_HW_IRQ_H */
