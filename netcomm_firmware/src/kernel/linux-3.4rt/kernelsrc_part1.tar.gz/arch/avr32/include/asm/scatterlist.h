#ifndef __ASM_AVR32_SCATTERLIST_H
#define __ASM_AVR32_SCATTERLIST_H

#include <asm-generic/scatterlist.h>

#endif /* __ASM_AVR32_SCATTERLIST_H */
