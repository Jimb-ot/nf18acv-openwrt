#ifndef __BOARDS_HAMMERHEAD_FLASH_H
#define __BOARDS_HAMMERHEAD_FLASH_H

struct platform_device *at32_add_device_hh_fpga(void);

#endif /* __BOARDS_HAMMERHEAD_FLASH_H */
