# 
# Please read merge-igd.d/0000-README.txt first for general information.
# This file contains only Dev2 (PURE181) information.

# The number ranges are defined as follows (note this applies to merge-dev2.d only):
# 1000      : must be the first file and contain the "base" command.  This is
#             the only file that can contain the base command.  This file only
#             creates a stub for the entire TR181 tree.
# 1001-2999 : TR181 objects
# 3000-3999 : Broadcom defined objects 
# 4000-4999 : Other Broadband Forum data models
# 5000-5999 : PON data models
# 6000-8000 : Reserved
# 8000-9999 : For customer use

