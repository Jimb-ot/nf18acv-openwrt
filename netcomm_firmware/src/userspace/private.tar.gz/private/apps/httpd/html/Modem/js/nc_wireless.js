//2.4g
var switch_idex_24 = '<%ejGetWl(switch_index_2)%>';

var nc_ssid = '<%ejGetWl(wlSsid_wl0v0)%>';
var nc_ssid_enbl = '<%ejGetWl(wlEnbl_wl0v0)%>';
var nc_wpaPskKey = '<%ejGetWl(wlWpaPsk)%>';

var nc_ssid_2 = '<%ejGetWl(wlSsid_2)%>';
var nc_enbl_2 = '<%ejGetWl(wlEnbl_2)%>';
var nc_wpaPskKey_2 = '<%ejGetWl(wlWpaPsk_wl0v1)%>';

//channel list
var nc_phy = '<%ejGetWl(wlPhyType)%>';
var nc_channel = '<%ejGetWl(wlChannel)%>';
var nc_band= '<%ejGetWl(wlBand)%>';
var nc_nbwcap= '<%ejGetWl(wlNBwCap)%>'; 
var nc_nctrlsb = '<%ejGetWl(wlNCtrlsb)%>';

var nc_maxAssoc = '<%ejGetWl(wlMaxAssoc_wl0v0)%>';
var nc_maxGuestAssoc = '<%ejGetWl(wlMaxAssoc_wl0v1)%>';

var nc_apIsolation= '<%ejGetWl(wlAPIsolation_wl0v0)%>';
var nc_apGuestIsolation= '<%ejGetWl(wlAPIsolation_wl0v1)%>';

var nc_authMode = '<%ejGetWl(wlAuthMode)%>';
var nc_authMode_2 = '<%ejGetWl(wlAuthMode_wl0v1)%>';
var nc_bit = '<%ejGetWl(wlKeyBit)%>';
var nc_bit_2 = '<%ejGetWl(wlKeyBit_wl0v1)%>';
var nc_keys = new Array( "<%ejGetWl(wlKey1)%>", "<%ejGetWl(wlKey2)%>",
                      "<%ejGetWl(wlKey3)%>", "<%ejGetWl(wlKey4)%>" );
var nc_keys_2 = new Array( "<%ejGetWl(wlKey1_wl0v1)%>", "<%ejGetWl(wlKey2_wl0v1)%>",
                      "<%ejGetWl(wlKey3_wl0v1)%>", "<%ejGetWl(wlKey4_wl0v1)%>" );
var nc_keyIdx = '<%ejGetWl(wlKeyIndex)%>';
var nc_keyIdx_2 = '<%ejGetWl(wlKeyIndex_wl0v1)%>';
var nc_wep = '<%ejGetWl(wlWep)%>';
var nc_wep_2 = '<%ejGetWl(wlWep_wl0v1)%>';
var nc_wpa = '<%ejGetWl(wlWpa)%>';
var nc_wpa_2 = '<%ejGetWl(wlWpa_wl0v1)%>';

var nc_radiusServerIP = '<%ejGetWl(wlRadiusServerIP)%>';
var nc_radiusServerIP_2 = '<%ejGetWl(wlRadiusServerIP_wl0v1)%>';
var nc_radiusPort = '<%ejGetWl(wlRadiusPort)%>';
var nc_radiusPort_2 = '<%ejGetWl(wlRadiusPort_wl0v1)%>';
var nc_radiusKey = '<%ejGetWl(wlRadiusKey)%>';
var nc_radiusKey_2 = '<%ejGetWl(wlRadiusKey_wl0v1)%>';
var nc_varNetReauth = '<%ejGetWl(wlNetReauth)%>';
var nc_varNetReauth_2 = '<%ejGetWl(wlNetReauth_wl0v1)%>';
var nc_wpaGTKRekey = '<%ejGetWl(wlWpaGTKRekey)%>';
var nc_wpaGTKRekey_2 = '<%ejGetWl(wlWpaGTKRekey_wl0v1)%>';

var nc_varPreauth = '<%ejGetWl(wlPreauth)%>';
var nc_varPreauth_2 = '<%ejGetWl(wlPreauth_wl0v1)%>';

var nc_WscMode       = '<%ejGetWl(wlWscMode)%>';
var nc_WscMode_2       = '<%ejGetWl(wlWscMode_wl0v1)%>';
var nc_WscDevPin    = '<%ejGetWl(wlWscDevPin)%>';
var nc_WscDevPin_2    = '<%ejGetWl(wlWscDevPin_wl0v1)%>';

var nc_WscCfgMethod	= '<%ejGetWl(wlWscCfgMethod)%>';
var nc_WscStaPin	= '<%ejGetWl(wlWscStaPin)%>';

function loadChannelList_24(OnPageLoad)
{
   var sel_ch;
   var sel_band;
   var sel_nbw_cap;
   var sel_sb;
   var idx;
      
   /* save selected */   
   if(OnPageLoad) {      
      sel_ch = nc_channel;
      sel_band = nc_band;
      sel_nbw_cap = nc_nbwcap;
      sel_sb = nc_nctrlsb;
   } else {
      sel_ch = $("select[name=24GHzMainNTChannel]").val();
      sel_band = nc_band;
      sel_nbw_cap = $("select[name=24GHzMainNTChannelBandWidth]").val();
      sel_sb = nc_nctrlsb;
   }

   /* load list */

	$("select[name=24GHzMainNTChannel]").empty();
	
   if ((sel_band == "2") && ((nc_phy != "n") && (nc_phy != "v"))) {
      <%ejGetWl(wlChannelList_24_newgui, b, b, 20)%>
   }
   else  if ((sel_band == "2") && (nc_phy == "n") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, n, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, n, b, 40, "lower")%>         
         }            
      } else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_24_newgui, n, b, 20 )%>
      }         
   }      
   else  if ((sel_band == "2") && (nc_phy == "v") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, v, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, v, b, 40, "lower")%>         
         }            
      } else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_24_newgui, v, b, 20 )%>
      }         
   }      
   else {
		$("select[name=24GHzMainNTChannel]").append("<option value='0'>Auto</option>");			   
   }
         
	$("select[name=24GHzMainNTChannel] option[value='" + sel_ch + "']").prop("selected", true);										

}

//5g 
var switch_idex_5 = '<%ejGetWl(switch_index_5)%>';
var nc_ssid_5 = '<%ejGetWl(wlSsid_wl0v0)%>';
var nc_ssid_enbl_5 = '<%ejGetWl(wlEnbl_wl0v0)%>';
var nc_wpaPskKey_5 = '<%ejGetWl(wlWpaPsk)%>';

var nc_ssid_2_5 = '<%ejGetWl(wlSsid_2)%>';
var nc_enbl_2_5 = '<%ejGetWl(wlEnbl_2)%>';
var nc_wpaPskKey_2_5 = '<%ejGetWl(wlWpaPsk_wl0v1)%>';

//channel list
var nc_phy_5 = '<%ejGetWl(wlPhyType)%>';
var nc_channel_5 = '<%ejGetWl(wlChannel)%>';
var nc_band_5 = '<%ejGetWl(wlBand)%>';
var nc_nbwcap_5 = '<%ejGetWl(wlNBwCap)%>'; 
var nc_nctrlsb_5 = '<%ejGetWl(wlNCtrlsb)%>';

var nc_maxAssoc_5 = '<%ejGetWl(wlMaxAssoc_wl0v0)%>';
var nc_maxGuestAssoc_5 = '<%ejGetWl(wlMaxAssoc_wl0v1)%>';

var nc_apIsolation_5 = '<%ejGetWl(wlAPIsolation_wl0v0)%>';
var nc_apGuestIsolation_5 = '<%ejGetWl(wlAPIsolation_wl0v1)%>';

var nc_authMode_5 = '<%ejGetWl(wlAuthMode)%>';
var nc_authMode_2_5 = '<%ejGetWl(wlAuthMode_wl0v1)%>';
var nc_bit_5 = '<%ejGetWl(wlKeyBit)%>';
var nc_bit_2_5 = '<%ejGetWl(wlKeyBit_wl0v1)%>';
var nc_keys_5 = new Array( "<%ejGetWl(wlKey1)%>", "<%ejGetWl(wlKey2)%>",
                      "<%ejGetWl(wlKey3)%>", "<%ejGetWl(wlKey4)%>" );
var nc_keys_2_5 = new Array( "<%ejGetWl(wlKey1_wl0v1)%>", "<%ejGetWl(wlKey2_wl0v1)%>",
                      "<%ejGetWl(wlKey3_wl0v1)%>", "<%ejGetWl(wlKey4_wl0v1)%>" );
var nc_keyIdx_5 = '<%ejGetWl(wlKeyIndex)%>';
var nc_keyIdx_2_5 = '<%ejGetWl(wlKeyIndex_wl0v1)%>';
var nc_wep_5 = '<%ejGetWl(wlWep)%>';
var nc_wep_2_5 = '<%ejGetWl(wlWep_wl0v1)%>';
var nc_wpa_5 = '<%ejGetWl(wlWpa)%>';
var nc_wpa_2_5 = '<%ejGetWl(wlWpa_wl0v1)%>';

var nc_radiusServerIP_5 = '<%ejGetWl(wlRadiusServerIP)%>';
var nc_radiusServerIP_2_5 = '<%ejGetWl(wlRadiusServerIP_wl0v1)%>';
var nc_radiusPort_5 = '<%ejGetWl(wlRadiusPort)%>';
var nc_radiusPort_2_5 = '<%ejGetWl(wlRadiusPort_wl0v1)%>';
var nc_radiusKey_5 = '<%ejGetWl(wlRadiusKey)%>';
var nc_radiusKey_2_5 = '<%ejGetWl(wlRadiusKey_wl0v1)%>';
var nc_varNetReauth_5 = '<%ejGetWl(wlNetReauth)%>';
var nc_varNetReauth_2_5 = '<%ejGetWl(wlNetReauth_wl0v1)%>';
var nc_wpaGTKRekey_5 = '<%ejGetWl(wlWpaGTKRekey)%>';
var nc_wpaGTKRekey_2_5 = '<%ejGetWl(wlWpaGTKRekey_wl0v1)%>';

var nc_varPreauth_5 = '<%ejGetWl(wlPreauth)%>';
var nc_varPreauth_2_5 = '<%ejGetWl(wlPreauth_wl0v1)%>';

var nc_WscMode_5       = '<%ejGetWl(wlWscMode)%>';
var nc_WscMode_2_5       = '<%ejGetWl(wlWscMode_wl0v1)%>';
var nc_WscDevPin_5    = '<%ejGetWl(wlWscDevPin)%>';
var nc_WscDevPin_2_5    = '<%ejGetWl(wlWscDevPin_wl0v1)%>';

var nc_WscCfgMethod_5	= '<%ejGetWl(wlWscCfgMethod)%>';
var nc_WscStaPin_5	= '<%ejGetWl(wlWscStaPin)%>';

var nc_enableBFR = '<%ejGetWl(wlEnableBFR)%>';
var nc_enableBFE = '<%ejGetWl(wlEnableBFE)%>';

function loadChannelList_5(OnPageLoad)
{
   var sel_ch;
   var sel_band;
   var sel_nbw_cap;
   var sel_sb;
   var idx;
      
   /* save selected */   
   if(OnPageLoad) {  
      sel_ch = nc_channel_5;
      sel_band = nc_band_5;
      sel_nbw_cap = nc_nbwcap_5;
      sel_sb = nc_nctrlsb_5;
   } else {
      sel_ch = $("select[name=5GHzMainNTChannel]").val();
      sel_band = nc_band_5;
      sel_nbw_cap = $("select[name=5GHzMainNTChannelBandWidth]").val();
      sel_sb = nc_nctrlsb_5;
   }
   
   /* load list */
	$("select[name=5GHzMainNTChannel]").empty();
	if ((sel_band == "1") && ((nc_phy_5 != "n") && (nc_phy_5 != "v"))) {
      <%ejGetWl(wlChannelList_5_newgui, a, a, 20)%>
   }
   else  if ((sel_band == "1") && (nc_phy_5 == "n") ) {    
      if(sel_nbw_cap == "1" || sel_nbw_cap == "2") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, n, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, n, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_5_newgui, n, a, 20 )%>
      }         
   }      
   else if ((sel_band == "1") && (nc_phy_5 == "v") && (sel_nbw_cap == "7")) {    
      /* Band a and AC phy and 80M */
      <%ejGetWl(wlChannelList_5_newgui, v, a, 80 )%>
   }
   else  if ((sel_band == "1") && (nc_phy_5 == "v")) {    
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, v, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, v, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_5_newgui, v, a, 20 )%>
      }         
   }      
   else {
		$("select[name=5GHzMainNTChannel]").append("<option value='0'>Auto</option>");				      
   }
         
	$("select[name=5GHzMainNTChannel] option[value=" + sel_ch + "]").prop("selected", true);										
}

function initMainSSID(id){
	if(id == 1){
		if(nc_ssid_enbl == '1'){
			$("input[name='24GHzMain'][value='1']").prop("checked", true);
            $(".24MainSettings input").prop('disabled', false);
            $(".24MainSettings select").prop('disabled', false);
		}
		else {
			$("input[name='24GHzMain'][value='0']").prop("checked", true);
            $(".24MainSettings input").prop('disabled', true);
            $(".24MainSettings select").prop('disabled', true);						
		}
							
		$("input[name='24GHzMainName']").val(nc_ssid);
		$("input[name='24GHzMainPWD']").val(nc_wpaPskKey);	

		switch (nc_authMode){
			case "open":
				$("input[name='24GHzMainSecurity']").val("Open");
				break;
			case "shared":
				$("input[name='24GHzMainSecurity']").val("Shared");
				break;
			case "radius":
				$("input[name='24GHzMainSecurity']").val("802.1x");
				break;
			case "wpa2":
				$("input[name='24GHzMainSecurity']").val("WPA2");
				break;
			case "psk2":
				$("input[name='24GHzMainSecurity']").val("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("input[name='24GHzMainSecurity']").val("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("input[name='24GHzMainSecurity']").val("Mixed WPA / WPA2-PSK");
				break;		
		}				
	}
	else if (id == 0) {
		if(nc_ssid_enbl_5 == '1'){
			$("input[name='5GHzMain'][value='1']").prop("checked", true);
            $(".5MainSettings input").prop('disabled', false);
            $(".5MainSettings select").prop('disabled', false);
		}
		else {
			$("input[name='5GHzMain'][value='0']").prop("checked", true);
            $(".5MainSettings input").prop('disabled', true);
            $(".5MainSettings select").prop('disabled', true);						
		}

		$("input[name='5GHzMainName']").val(nc_ssid_5);
		$("input[name='5GHzMainPWD']").val(nc_wpaPskKey_5);

		switch (nc_authMode_5){
			case "open":
				$("input[name='5GHzMainSecurity']").val("Open");
				break;
			case "shared":
				$("input[name='5GHzMainSecurity']").val("Shared");
				break;
			case "radius":
				$("input[name='5GHzMainSecurity']").val("802.1x");
				break;
			case "wpa2":
				$("input[name='5GHzMainSecurity']").val("WPA2");
				break;
			case "psk2":
				$("input[name='5GHzMainSecurity']").val("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("input[name='5GHzMainSecurity']").val("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("input[name='5GHzMainSecurity']").val("Mixed WPA / WPA2-PSK");
				break;		
		}				
	}
}
function initGuestSSID(id){
	if(id == 1){
		if(nc_enbl_2 == '1'){
			$("input[name='24GHzGuest'][value='1']").prop("checked", true);
            $(".24GuestSettings input").prop('disabled', false);
            $(".24GuestSettings select").prop('disabled', false);
		}
		else {
			$("input[name='24GHzGuest'][value='0']").prop("checked", true);
            $(".24GuestSettings input").prop('disabled', true);
            $(".24GuestSettings select").prop('disabled', true);
		}

		$("input[name='24GHzGuestName']").val(nc_ssid_2);
		$("input[name='24GHzGuestPWD']").val(nc_wpaPskKey_2);
		$("input[name='24GHzGuestNTMaxDevices']").val(nc_maxGuestAssoc);
		$("input[name='24GHzGuestNTDevIsolation'][value='" + nc_apGuestIsolation + "']").prop("checked", true);					

		switch (nc_authMode_2){
			case "open":
				$("input[name='24GHzGuestSecurity']").val("Open");
				break;
			case "shared":
				$("input[name='24GHzGuestSecurity']").val("Shared");
				break;
			case "radius":
				$("input[name='24GHzGuestSecurity']").val("802.1x");
				break;
			case "wpa2":
				$("input[name='24GHzGuestSecurity']").val("WPA2");
				break;
			case "psk2":
				$("input[name='24GHzGuestSecurity']").val("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("input[name='24GHzGuestSecurity']").val("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("input[name='24GHzGuestSecurity']").val("Mixed WPA / WPA2-PSK");
				break;		
		}
		

	}
	else if (id == 0) {
		if(nc_enbl_2_5 == '1'){
			$("input[name='5GHzGuest'][value='1']").prop("checked", true);
            $(".5GuestSettings input").prop('disabled', false);
            $(".5GuestSettings select").prop('disabled', false);
		}
		else {
			$("input[name='5GHzGuest'][value='0']").prop("checked", true);
            $(".5GuestSettings input").prop('disabled', true);
            $(".5GuestSettings select").prop('disabled', true);						
		}

		$("input[name='5GHzGuestName']").val(nc_ssid_2_5);
		$("input[name='5GHzGuestPWD']").val(nc_wpaPskKey_2_5);
		$("input[name='5GHzGuestNTMaxDevices']").val(nc_maxGuestAssoc_5);		

		$("input[name='5GHzGuestNTDevIsolation'][value='" + nc_apGuestIsolation_5 + "']").prop("checked", true);					

		switch (nc_authMode_2_5){
			case "open":
				$("input[name='5GHzGuestSecurity']").val("Open");
				break;
			case "shared":
				$("input[name='5GHzGuestSecurity']").val("Shared");
				break;
			case "radius":
				$("input[name='5GHzGuestSecurity']").val("802.1x");
				break;
			case "wpa2":
				$("input[name='5GHzGuestSecurity']").val("WPA2");
				break;
			case "psk2":
				$("input[name='5GHzGuestSecurity']").val("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("input[name='5GHzGuestSecurity']").val("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("input[name='5GHzGuestSecurity']").val("Mixed WPA / WPA2-PSK");
				break;		
		}				
	}
}			

function initMainAuthMode(id){
	if(id == 1){
		$("input[name='24GHzMainNTMaxDevices']").val(nc_maxAssoc);	
		$("input[name='24MainNTDevIsolation'][value='" + nc_apIsolation + "']").prop("checked", true);					

		$("select[name=24GHzMainNTAuth] option[value='" + nc_authMode +"']").prop("selected", true);
		
		if(nc_authMode == 'shared' || nc_authMode == 'radius' || nc_authMode == 'open'){
			$("select[name=24GHzMainNTEncryptStr] option[value='" + nc_bit +"']").prop("selected", true);
			$("select[name=24GHzMainNTKey] option[value='" + nc_keyIdx +"']").prop("selected", true);																						
		}	
        
		if(nc_authMode == 'open' || nc_authMode == 'radius' || nc_authMode == 'shared'){
            $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);					
		}
		else {
            $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);										
		}

		if(nc_authMode == 'wpa2' || nc_authMode == 'wpa wpa2'){
            $("select[name=24GHzMainPreauth] option[value='" + nc_varPreauth + "']").prop("selected", true);					
		}
		
		$("input[name='24GHzMainNTRadiusIP']").val(nc_radiusServerIP);
		$("input[name='24GHzMainNTRadiusPort']").val(nc_radiusPort);
		$("input[name='24GHzMainNTRadiusKey']").val(nc_radiusKey);

		$("input[name='24GHzMainNTAuthInterval']").val(nc_varNetReauth);
		$("input[name='24GHzMainNTWPARekeyInterval']").val(nc_wpaGTKRekey);
		$("input[name='24GHzMainNTPSK']").val(nc_wpaPskKey);

		$("input[name='24GHzMainNTWEPKey1']").val(nc_keys[0]);
		$("input[name='24GHzMainNTWEPKey2']").val(nc_keys[1]);
		$("input[name='24GHzMainNTWEPKey3']").val(nc_keys[2]);
		$("input[name='24GHzMainNTWEPKey4']").val(nc_keys[3]);				

		authModeChange(true, 1);
		encrypChange(true, 1);
	}
	else{
		$("input[name='5GHzMainNTMaxDevices']").val(nc_maxAssoc_5);
		$("input[name='5MainNTDevIsolation'][value='" + nc_apIsolation_5 + "']").prop("checked", true);									
		
		$("select[name=5GHzMainNTAuth] option[value='" + nc_authMode_5 +"']").prop("selected", true);

		if(nc_authMode_5 == 'shared' || nc_authMode_5 == 'radius' || nc_authMode_5 == 'open'){
			$("select[name=5GHzMainNTEncryptStr] option[value='" + nc_bit_5 +"']").prop("selected", true);
			$("select[name=5GHzMainNTKey] option[value='" + nc_keyIdx_5 +"']").prop("selected", true);																						
		}
        
		if(nc_authMode_5 == 'open' || nc_authMode_5 == 'radius' || nc_authMode_5 == 'shared'){					
            $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wep_5 + "']").prop("selected", true);						                
		}
		else {
            $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wpa_5 + "']").prop("selected", true);										
		}

		if(nc_authMode_5 == 'wpa2' || nc_authMode_5 == 'wpa wpa2'){
            $("select[name=5GHzMainPreauth] option[value='" + nc_varPreauth_5 + "']").prop("selected", true);					
		}
		
		$("input[name='5GHzMainNTRadiusIP']").val(nc_radiusServerIP_5);
		$("input[name='5GHzMainNTRadiusPort']").val(nc_radiusPort_5);
		$("input[name='5GHzMainNTRadiusKey']").val(nc_radiusKey_5);

		$("input[name='5GHzMainNTAuthInterval']").val(nc_varNetReauth_5);
		$("input[name='5GHzMainNTWPARekeyInterval']").val(nc_wpaGTKRekey_5);
		$("input[name='5GHzMainNTPSK']").val(nc_wpaPskKey_5);
		
		$("input[name='5GHzMainNTWEPKey1']").val(nc_keys_5[0]);
		$("input[name='5GHzMainNTWEPKey2']").val(nc_keys_5[1]);
		$("input[name='5GHzMainNTWEPKey3']").val(nc_keys_5[2]);
		$("input[name='5GHzMainNTWEPKey4']").val(nc_keys_5[3]);	

		authModeChange(true, 0);	
		encrypChange(true, 0);
	}
}

function initGuestAuthMode(id){
	if(id == 1){					
		$("select[name=24GHzGuestNTAuth] option[value='" + nc_authMode_2 +"']").prop("selected", true);

		if(nc_authMode_2 == 'shared' || nc_authMode_2 == 'radius'){
			$("select[name=24GHzGuestNTEncryptStr] option[value=" + nc_bit_2 +"]").prop("selected", true);
			$("select[name=24GHzGuestNTKey] option[value=" + nc_keyIdx_2 +"]").prop("selected", true);																						
		}

		$("input[name='24GHzGuestNTWEPKey1']").val(nc_keys_2[0]);
		$("input[name='24GHzGuestNTWEPKey2']").val(nc_keys_2[1]);
		$("input[name='24GHzGuestNTWEPKey3']").val(nc_keys_2[2]);
		$("input[name='24GHzGuestNTWEPKey4']").val(nc_keys_2[3]);		
        
		if(nc_authMode_2 == 'open' || nc_authMode_2 == 'radius' || nc_authMode_2 == 'shared'){
            $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wep_2 + "']").prop("selected", true);					
		}
		else {					
            $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wpa_2 + "']").prop("selected", true);										
		}

		if(nc_authMode == 'wpa2' || nc_authMode == 'wpa wpa2'){
            $("select[name=24GHzGuestPreauth] option[value='" + nc_varPreauth_2 + "']").prop("selected", true);					
		}
		
		$("input[name='24GHzGuestNTRadiusIP']").val(nc_radiusServerIP_2);
		$("input[name='24GHzGuestNTRadiusPort']").val(nc_radiusPort_2);
		$("input[name='24GHzGuestNTRadiusKey']").val(nc_radiusKey_2);

		$("input[name='24GHzGuestNTAuthInterval']").val(nc_varNetReauth_2);
		$("input[name='24GHzGuestNTWPARekeyInterval']").val(nc_wpaGTKRekey_2);
		$("input[name='24GHzGuestNTPSK']").val(nc_wpaPskKey_2);

		authModeGuestChange(true, 1);
		encrypGuestChange(true, 1);
	}
	else {
		$("select[name=5GHzGuestNTAuth] option[value='" + nc_authMode_2_5 +"']").prop("selected", true);

		if(nc_authMode_2_5 == 'shared' || nc_authMode_2_5 == 'radius'){
			$("select[name=5GHzGuestNTEncryptStr] option[value=" + nc_bit_2_5 +"]").prop("selected", true);
			$("select[name=5GHzGuestNTKey] option[value=" + nc_keyIdx_2_5 +"]").prop("selected", true);																						
		}

		$("input[name='5GHzGuestNTWEPKey1']").val(nc_keys_2_5[0]);
		$("input[name='5GHzGuestNTWEPKey2']").val(nc_keys_2_5[1]);
		$("input[name='5GHzGuestNTWEPKey3']").val(nc_keys_2_5[2]);
		$("input[name='5GHzGuestNTWEPKey4']").val(nc_keys_2_5[3]);	
        
		if(nc_authMode_2_5 == 'open' || nc_authMode_2_5 == 'radius' || nc_authMode_2_5 == 'shared'){					
            $("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wep_2_5 + "']").prop("selected", true);					
		}
		else {				
            $("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wpa_2_5 + "']").prop("selected", true);										
		}

		if(nc_authMode_5 == 'wpa2' || nc_authMode_5 == 'wpa wpa2'){
            $("select[name=5GHzGuestPreauth] option[value='" + nc_varPreauth_2_5 + "']").prop("selected", true);					
		}

		$("input[name='5GHzGuestNTRadiusIP']").val(nc_radiusServerIP_2_5);
		$("input[name='5GHzGuestNTRadiusPort']").val(nc_radiusPort_2_5);
		$("input[name='5GHzGuestNTRadiusKey']").val(nc_radiusKey_2_5);

		$("input[name='5GHzGuestNTAuthInterval']").val(nc_varNetReauth_2_5);
		$("input[name='54GHzGuestNTWPARekeyInterval']").val(nc_wpaGTKRekey_2_5);
		$("input[name='5GHzGuestNTPSK']").val(nc_wpaPskKey_2_5);

		authModeGuestChange(true, 0);
		encrypGuestChange(true, 0);
	}
}
	
function initWirelessType(id) {
	if(id == 1)
	{
        $(".5GHz").hide();
        $(".24GHz").show();
		moreSettingsVisibility = $(".5GHzSettings").is(':visible'); 
		if (moreSettingsVisibility == true) {
			$(".24GHzSettings").show();
    		$(".5GHzSettings").hide();
		}
	}
	else if (id == 0)
	{
        $(".24GHz").hide();
        $(".5GHz").show();   
		moreSettingsVisibility = $(".24GHzSettings").is(':visible'); 
		if (moreSettingsVisibility == true) {
			$(".24GHzSettings").hide();
    		$(".5GHzSettings").show();
		}		
		//initBeamforming();	
	}
	initMainSSID(id);	
	initGuestSSID(id);
	initChannelList(id);
	initNbwcap(id);
	initMainAuthMode(id);
	initGuestAuthMode(id);					
	initWPS(id);
	initGuestWPS(id);	
}

function initChannelList(id){
	if(id == 1)				
		loadChannelList_24(true);
	else if(id == 0)
		loadChannelList_5(true);
}

function initNbwcap(id){
	if(id == 1){
		if(nc_nbwcap == '1')
			$("select[name='24GHzMainNTChannelBandWidth'] option[value='1']").prop("selected", true);
		else if(nc_nbwcap == '3')
			$("select[name='24GHzMainNTChannelBandWidth'] option[value='3']").prop("selected", true);										
	}
	else if(id == 0){
		if(nc_nbwcap_5 == '1')
			$("select[name='5GHzMainNTChannelBandWidth'] option[value='1']").prop("selected", true);
		else if(nc_nbwcap_5 == '3')
			$("select[name='5GHzMainNTChannelBandWidth'] option[value='3']").prop("selected", true);
		else if (nc_nbwcap_5 == '7')
			$("select[name='5GHzMainNTChannelBandWidth'] option[value='7']").prop("selected", true);				
	}			
}

function authModeChange(OnPageLoad, id) {
	var authValue = '';

	if(id == 1){
		authValue = $("select[name=24GHzMainNTAuth]").val();
		
		$("input[name=24GHzMainPWD]").prop('disabled', false);
	    if ( authValue == "open" ) {
			$("input[name=24GHzMainPWD]").prop('disabled', true);
	        $("input[name=24GHzMainWlAuth]").val('0');			    
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").show();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").hide();
			//if(OnPageLoad == false){
		        $("select[name=24GHzMainNTEncrypt] option[value=disabled]").prop("selected", true);
			//}else{
		    //    $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);
			//}
				
	        $(".Wep_2M").hide();
	        $(".PwdShowOrHide_2M").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                        
	        $(".radiusServer_2M").hide();  

			$(".24MainSettingsWps").show();
	    } else if ( authValue == "shared" ) {
			$("input[name=24GHzMainPWD]").prop('disabled', true);
	        $("input[name=24GHzMainWlAuth]").val('1');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
	        	$("select[name=24GHzMainNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=24GHzMainNTEncryptStr] option[value='0']").prop("selected", true);                                                
		      $("select[name=24GHzMainNTEncrypt] option[value=enabled]").prop("selected", true);						
	        	$("select[name=24GHzMainNTKey] option[value='2']").prop("selected", true);                                                                        				        
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);					
			}

	        $(".Wep_2M").show();
	        $(".PwdShowOrHide_2M").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                                                
	        $(".radiusServer_2M").hide();
	        
	        $("input[name=24GHzMainNTWEPKey1]").prop('disabled', true);
	        $("input[name=24GHzMainNTWEPKey2]").prop('disabled', false);
	        $("input[name=24GHzMainNTWEPKey3]").prop('disabled', false);
	        $("input[name=24GHzMainNTWEPKey4]").prop('disabled', true);                        
			
			$(".24MainSettingsWps").hide();
	    } else if ( authValue == "radius" ) {
	    $("input[name=24GHzMainPWD]").prop('disabled', true);
	        $("input[name=24GHzMainWlAuth]").val('0');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
	      	  $("select[name=24GHzMainNTEncrypt] option[value=enabled]").prop("selected", true);
	        	$("select[name=24GHzMainNTEncryptStr] option[value='0']").prop("selected", true);                                                                        
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);					
			}

			$(".Wep_2M").show();
	        $(".PwdShowOrHide_2M").hide();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                                                
	        $(".field.wpa2.psk").hide();
	        $(".radiusServer_2M").show();
			
			$(".24MainSettingsWps").hide();
	    } else if ( authValue == "wpa2" ) {
	        $("input[name=24GHzMainWlAuth]").val('0');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=24GHzMainNTEncrypt] option[value=aes]").prop("selected", true);
				$("select[name=24GHzMainPreauth] option[value=0]").prop("selected", true);                        
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);					
			}
	        $(".Wep_2M").hide();
	        $(".PwdShowOrHide_2M").hide();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2").show();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2M").show();
			
			$(".24MainSettingsWps").hide();
	    } else if ( authValue == "psk2" ) {
	        $("input[name=24GHzMainWlAuth]").val('0');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
	     	   $("select[name=24GHzMainNTEncrypt] option[value=aes]").prop("selected", true);
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);					
			}

	        $(".Wep_2M").hide();
	        $(".PwdShowOrHide_2M").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                        
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2M").hide();
			
			$(".24MainSettingsWps").show();
	    } else if ( authValue == "wpa wpa2" ) {
	        $("input[name=24GHzMainWlAuth]").val('0');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").show();
	       
			if(OnPageLoad == false){
				$("select[name=24GHzMainPreauth] option[value=0]").prop("selected", true);                        
				$("select[name=24GHzMainNTEncrypt] option[value='tkip+aes']").prop("selected", true);
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);					
			}					
	        $(".Wep_2M").hide();
	        $(".PwdShowOrHide_2M").hide();
	        $(".field.wpa2").show();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2M").show();
			
			$(".24MainSettingsWps").hide();
	    } else if ( authValue == "psk psk2" ) {
	        $("input[name=24GHzMainWlAuth]").val('0');
	        $("select[name=24GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzMainNTEncrypt] .wpaTKIP").show();

			if(OnPageLoad == false){
				$("select[name=24GHzMainNTEncrypt] option[value='tkip+aes']").prop("selected", true);
			}else{
		        $("select[name=24GHzMainNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);					
			}
	        
	        $(".Wep_2M").hide();
	        $(".PwdShowOrHide_2M").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2M").hide();
			
			$(".24MainSettingsWps").show();
	    }	
		encrypChange(true, 1);
	}
	else {
		authValue = $("select[name=5GHzMainNTAuth]").val();
		
		$("input[name=5GHzMainPWD]").prop('disabled', false);
	    if ( authValue == "open" ) {
			$("input[name=5GHzMainPWD]").prop('disabled', true);
	        $("input[name=5GHzMainWlAuth]").val('0');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").show();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").hide();
			//if(OnPageLoad == false){
		        $("select[name=5GHzMainNTEncrypt] option[value=disabled]").prop("selected", true);				        
			//}else{
		    //  $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wep_5 + "']").prop("selected", true);					
			//}
			
	        $(".Wep_5M").hide();
	        $(".PwdShowOrHide_5M").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                        
	        $(".radiusServer_5M").hide();

			$(".5MainSettingsWps").show();
	    } else if ( authValue == "shared" ) {
	    $("input[name=5GHzMainPWD]").prop('disabled', true);
	        $("input[name=5GHzMainWlAuth]").val('1');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
	        	$("select[name=5GHzMainNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=5GHzMainNTEncryptStr] option[value='0']").prop("selected", true);                                                
		        $("select[name=5GHzMainNTKey] option[value='2']").prop("selected", true);                                                                        							
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wep_5 + "']").prop("selected", true);					
			}

	        $(".Wep_5M").show();
	        $(".PwdShowOrHide_5M").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                                                
	        $(".radiusServer_5M").hide();
	        $("input[name=5GHzMainNTWEPKey1]").prop('disabled', true);
	        $("input[name=5GHzMainNTWEPKey2]").prop('disabled', false);
	        $("input[name=5GHzMainNTWEPKey3]").prop('disabled', false);
	        $("input[name=5GHzMainNTWEPKey4]").prop('disabled', true);  

			$(".5MainSettingsWps").hide();			
	    } else if ( authValue == "radius" ) {
	    $("input[name=5GHzMainPWD]").prop('disabled', true);
	        $("input[name=5GHzMainWlAuth]").val('0');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
	      	  $("select[name=5GHzMainNTEncrypt] option[value=enabled]").prop("selected", true);
	        	$("select[name=5GHzMainNTEncryptStr] option[value='0']").prop("selected", true);                                                                        
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wep_5 + "']").prop("selected", true);					
			}

			$(".Wep_5M").show();
	        $(".PwdShowOrHide_5M").hide();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                                                
	        $(".field.wpa2.psk").hide();
	        $(".radiusServer_5M").show();
			
			$(".5MainSettingsWps").hide();
	    } else if ( authValue == "wpa2" ) {
	        $("input[name=5GHzMainWlAuth]").val('0');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=5GHzMainNTEncrypt] option[value=aes]").prop("selected", true);
				$("select[name=5GHzMainPreauth] option[value=0]").prop("selected", true);                        
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wpa_5 + "']").prop("selected", true);					
			}
	        $(".Wep_5M").hide();
	        $(".PwdShowOrHide_5M").hide();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2").show();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5M").show();
			
			$(".5MainSettingsWps").hide();
	    } else if ( authValue == "psk2" ) {
	        $("input[name=5GHzMainWlAuth]").val('0');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=5GHzMainNTEncrypt] option[value=aes]").prop("selected", true);
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wpa_5 + "']").prop("selected", true);					
			}
			
	        $(".Wep_5M").hide();
	        $(".PwdShowOrHide_5M").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                        
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5M").hide();
			
			$(".5MainSettingsWps").show();
	    } else if ( authValue == "wpa wpa2" ) {
	        $("input[name=5GHzMainWlAuth]").val('0');
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").show();
	        
			if(OnPageLoad == false){
		        $("select[name=5GHzMainNTEncrypt] option[value='tkip+aes']").prop("selected", true);
				$("select[name=24GHzMainPreauth] option[value=0]").prop("selected", true);                        
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wpa_5 + "']").prop("selected", true);					
			}

	        $(".Wep_5M").hide();
	        $(".PwdShowOrHide_5M").hide();
	        $(".field.wpa2").show();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5M").show();
			
			$(".5MainSettingsWps").hide();
	    } else if ( authValue == "psk psk2" ) {
	        $("input[name=5GHzMainWlAuth]").val('0');			    
	        $("select[name=5GHzMainNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzMainNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzMainNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzMainNTEncrypt] .wpaTKIP").show();

			if(OnPageLoad == false){
				$("select[name=5GHzMainNTEncrypt] option[value='tkip+aes']").prop("selected", true);
			}else{
		        $("select[name=5GHzMainNTEncrypt] option[value='" + nc_wpa_5 + "']").prop("selected", true);					
			}
	        
	        $(".Wep_5M").hide();
	        $(".PwdShowOrHide_5M").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5M").hide();
			
			$(".5MainSettingsWps").show();
	    }	
		encrypChange(true, 0);
	}
}

function authModeGuestChange(OnPageLoad, id) {
	var authValue = '';

	if(id == 1){
		authValue = $("select[name=24GHzGuestNTAuth]").val();
		
		$("input[name=24GHzGuestPWD]").prop('disabled', false);
	    if ( authValue == "open" ) {
			$("input[name=24GHzGuestPWD]").prop('disabled', true);
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").show();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").hide();
	        $("input[name=24GHzGuestWlAuth]").val('0');
			//if(OnPageLoad == false){				
		        $("select[name=24GHzGuestNTEncrypt] option[value=disabled]").prop("selected", true);
			//}else {
		    //    $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);
			//}
	        $(".Wep_2G").hide();
	        $(".PwdShowOrHide_2G").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                        
	        $(".radiusServer_2G").hide();
	    } else if ( authValue == "shared" ) {
	    $("input[name=24GHzGuestPWD]").prop('disabled', true);
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").hide();
	        $("input[name=24GHzGuestWlAuth]").val('1');
			
			if(OnPageLoad == false){
	        	$("select[name=24GHzGuestNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=24GHzGuestNTEncryptStr] option[value='0']").prop("selected", true);                                                
			}else {
		        $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);
			}

	        $(".Wep_2G").show();
	        $(".PwdShowOrHide_2G").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                                                
	        $(".radiusServer_2G").hide();
			if(OnPageLoad == false)			
	        	$("select[name=24GHzGuestNTKey] option[value='2']").prop("selected", true);                                                                        
						
	        $("input[name=24GHzGuestNTWEPKey1]").prop('disabled', true);
	        $("input[name=24GHzGuestNTWEPKey2]").prop('disabled', false);
	        $("input[name=24GHzGuestNTWEPKey3]").prop('disabled', false);
	        $("input[name=24GHzGuestNTWEPKey4]").prop('disabled', true);                        
	    } else if ( authValue == "radius" ) {
	    $("input[name=24GHzGuestPWD]").prop('disabled', true);
	        $("input[name=24GHzGuestWlAuth]").val('0');			    
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
				$("select[name=24GHzGuestNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=24GHzGuestNTEncryptStr] option[value='0']").prop("selected", true);                                                                        
			}else {
		        $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wep + "']").prop("selected", true);
			}

			$(".Wep_2G").show();
	        $(".PwdShowOrHide_2G").hide();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                                                
	        $(".field.wpa2.psk").hide();
	        $(".radiusServer_2G").show();
	    } else if ( authValue == "wpa2" ) {
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").show();
	        $("input[name=24GHzGuestWlAuth]").val('0');			        
			if(OnPageLoad == false){
				$("select[name=24GHzGuestNTEncrypt] option[value=aes]").prop("selected", true);
				$("select[name=24GHzGuestPreauth] option[value=0]").prop("selected", true);                        
			}else {
		        $("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);
			}
	        $(".Wep_2G").hide();
	        $(".PwdShowOrHide_2G").hide();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2").show();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2G").show();
	    } else if ( authValue == "psk2" ) {
	        $("input[name=24GHzGuestWlAuth]").val('0');			    
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=24GHzGuestNTEncrypt] option[value=aes]").prop("selected", true);
			}else {
				$("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);
			}
	     	   
	        $(".Wep_2G").hide();
	        $(".PwdShowOrHide_2G").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                        
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2G").hide();
	    } else if ( authValue == "wpa wpa2" ) {
	        $("input[name=24GHzGuestWlAuth]").val('0');			    
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").show();
	        
			if(OnPageLoad == false){
				$("select[name=24GHzGuestPreauth] option[value=off]").prop("selected", true);                        
				$("select[name=24GHzGuestNTEncrypt] option[value='tkip+aes']").prop("selected", true);				
			}else {
				$("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);
			}
	        $(".Wep_2G").hide();
	        $(".PwdShowOrHide_2G").hide();
	        $(".field.wpa2").show();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2G").show();
	    } else if ( authValue == "psk psk2" ) {
	        $("input[name=24GHzGuestWlAuth]").val('0');			    
	        $("select[name=24GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=24GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=24GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=24GHzGuestNTEncrypt] .wpaTKIP").show();

			if(OnPageLoad == false){
				$("select[name=24GHzGuestNTEncrypt] option[value='tkip+aes']").prop("selected", true);
			}else {
				$("select[name=24GHzGuestNTEncrypt] option[value='" + nc_wpa + "']").prop("selected", true);
			}
	        $(".Wep_2G").hide();
	        $(".PwdShowOrHide_2G").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_2G").hide();
	    }	
	}
	else {
		authValue = $("select[name=5GHzGuestNTAuth]").val();
		
		$("input[name=5GHzGuestPWD]").prop('disabled', false);
	    if ( authValue == "open" ) {
			$("input[name=5GHzGuestPWD]").prop('disabled', true);
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").show();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").hide();
			//if(OnPageLoad == false){
		        $("select[name=5GHzGuestNTEncrypt] option[value=disabled]").prop("selected", true);
			//}else {
			//	$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wep_2_5 + "']").prop("selected", true);
			//}
	        $(".Wep_5G").hide();
	        $(".PwdShowOrHide_5G").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                        
	        $(".radiusServer_5G").hide();                                                
	    } else if ( authValue == "shared" ) {
	    $("input[name=5GHzGuestPWD]").prop('disabled', true);
	        $("input[name=5GHzGuestWlAuth]").val('1');
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
	        	$("select[name=5GHzGuestNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=5GHzGuestNTEncryptStr] option[value='0']").prop("selected", true);                                                
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wep_2_5 + "']").prop("selected", true);
			}

	        $(".Wep_5G").show();
	        $(".PwdShowOrHide_5G").hide();
	        $(".field.wpa2").hide();
	        $(".field.wpa2.psk").hide();
	        $(".field.preauth").hide();                                                
	        $(".radiusServer_5G").hide();
	        $("select[name=5GHzGuestNTKey] option[value='2']").prop("selected", true);                                                                        
	        $("input[name=5GHzGuestNTWEPKey1]").prop('disabled', true);
	        $("input[name=5GHzGuestNTWEPKey2]").prop('disabled', false);
	        $("input[name=5GHzGuestNTWEPKey3]").prop('disabled', false);
	        $("input[name=5GHzGuestNTWEPKey4]").prop('disabled', true);                        
	    } else if ( authValue == "radius" ) {
	    $("input[name=5GHzGuestPWD]").prop('disabled', true);
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").hide();

			if(OnPageLoad == false){
				$("select[name=5GHzGuestNTEncrypt] option[value=enabled]").prop("selected", true);
				$("select[name=5GHzGuestNTEncryptStr] option[value='0']").prop("selected", true);                                                                        
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wep_2_5 + "']").prop("selected", true);
			}

			$(".Wep_5G").show();
	        $(".PwdShowOrHide_5G").hide();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                                                
	        $(".field.wpa2.psk").hide();
	        $(".radiusServer_5G").show();
	    } else if ( authValue == "wpa2" ) {
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=5GHzGuestNTEncrypt] option[value=aes]").prop("selected", true);
				$("select[name=5GHzGuestPreauth] option[value=0]").prop("selected", true);                        
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wpa_2_5 + "']").prop("selected", true);
			}
	        $(".Wep_5G").hide();
	        $(".PwdShowOrHide_5G").hide();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2").show();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5G").show();
	    } else if ( authValue == "psk2" ) {
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").show();
			if(OnPageLoad == false){
				$("select[name=5GHzGuestNTEncrypt] option[value=aes]").prop("selected", true);
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wpa_2_5 + "']").prop("selected", true);
			}

	        $(".Wep_5G").hide();
	        $(".PwdShowOrHide_5G").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();                        
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5G").hide();
	    } else if ( authValue == "wpa wpa2" ) {
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").show();

			if(OnPageLoad == false){
				$("select[name=5GGHzGuestPreauth] option[value=off]").prop("selected", true);                        
		        $("select[name=5GHzGuestNTEncrypt] option[value='tkip+aes']").prop("selected", true);						
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wpa_2_5 + "']").prop("selected", true);
			}
				
	        $(".Wep_5G").hide();
	        $(".PwdShowOrHide_5G").hide();
	        $(".field.wpa2").show();
	        $(".field.preauth").show();                                                
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5G").show();
	    } else if ( authValue == "psk psk2" ) {
	        $("input[name=5GHzGuestWlAuth]").val('0');			    
	        $("select[name=5GHzGuestNTEncrypt] .sharedNone").hide();
	        $("select[name=5GHzGuestNTEncrypt] .sharedWEP").hide();
	        $("select[name=5GHzGuestNTEncrypt] .wpaAES").show();
	        $("select[name=5GHzGuestNTEncrypt] .wpaTKIP").show();

			if(OnPageLoad == false){
				$("select[name=5GHzGuestNTEncrypt] option[value='tkip+aes']").prop("selected", true);
			}else {
				$("select[name=5GHzGuestNTEncrypt] option[value='" + nc_wpa_2_5 + "']").prop("selected", true);
			}
	        $(".Wep_5G").hide();
	        $(".PwdShowOrHide_5G").show();
	        $(".field.wpa2").hide();
	        $(".field.preauth").hide();
	        $(".field.wpa2.psk").show();
	        $(".radiusServer_5G").hide();
	    }	
	}
}
	
function encrypChange(OnPageLoad, id){
	var authValue;
	if(id == 1){
		if($("select[name=24GHzMainNTEncrypt]").val() == 'enabled'){
			$("input[name=24GHzMainWlWep]").val("enabled");
			$("input[name=24GHzMainWlWpa]").val("aes");	
			$(".Wep_2M").show();
		}
		else if($("select[name=24GHzMainNTEncrypt]").val() == 'disabled'){
			$("input[name=24GHzMainWlWep]").val("disabled");
			$("input[name=24GHzMainWlWpa]").val("aes");				
			$(".Wep_2M").hide();
		}
		else if($("select[name=24GHzMainNTEncrypt]").val() == 'aes'){
			$("input[name=24GHzMainWlWep]").val("disabled");
			$("input[name=24GHzMainWlWpa]").val("aes");				
			$(".Wep_2M").hide();
		}
		else if($("select[name=24GHzMainNTEncrypt]").val() == 'tkip+aes'){
			$("input[name=24GHzMainWlWep]").val("disabled");
			$("input[name=24GHzMainWlWpa]").val("tkip+aes");				
			$(".Wep_2M").hide();
		}				
	}else {
		if($("select[name=5GHzMainNTEncrypt]").val() == 'enabled'){
			$("input[name=5GHzMainWlWep]").val("enabled");
			$("input[name=5GHzMainWlWpa]").val("aes");					
			$(".Wep_5M").show();
		}
		else if($("select[name=5GHzMainNTEncrypt]").val() == 'disabled'){
			$("input[name=5GHzMainWlWep]").val("disabled");
			$("input[name=5GHzMainWlWpa]").val("aes");				
			$(".Wep_5M").hide();
		}
		else if($("select[name=5GHzMainNTEncrypt]").val() == 'aes'){
			$("input[name=5GHzMainWlWep]").val("disabled");
			$("input[name=5GHzMainWlWpa]").val("aes");				
			$(".Wep_5M").hide();
		}
		else if($("select[name=5GHzMainNTEncrypt]").val() == 'tkip+aes'){
			$("input[name=5GHzMainWlWep]").val("disabled");
			$("input[name=5GHzMainWlWpa]").val("tkip+aes");				
			$(".Wep_5M").hide();
		}				
	}
}  
function encrypGuestChange(OnPageLoad, id){
	var authValue;
	if(id == 1){
		authValue = $("select[name=24GHzGuestNTAuth]").val();
		if(authValue == 'open'){
			if($("select[name=24GHzGuestNTEncrypt]").val() == 'enabled'){
				$(".Wep_2G").show();	
				$("input[name=24GHzGuestNTWEPKey1]").prop('disabled', true);
				$("input[name=24GHzGuestNTWEPKey2]").prop('disabled', true);
				$("input[name=24GHzGuestNTWEPKey3]").prop('disabled', true);
				$("input[name=24GHzGuestNTWEPKey4]").prop('disabled', true);						
			}else {
				$(".Wep_2G").hide();
			}										
		}
		if($("select[name=24GHzGuestNTEncrypt]").val() == 'enabled'){
			$("input[name=24GHzGuestWlWep]").val("enabled");
			$("input[name=24GHzGuestWlWpa]").val("aes");
			$(".Wep_2G").show();
		}
		else if($("select[name=24GHzGuestNTEncrypt]").val() == 'disabled'){
			$("input[name=24GHzGuestWlWep]").val("disabled");
			$("input[name=24GHzGuestWlWpa]").val("aes");				
			$(".Wep_2G").hide();
		}
		else if($("select[name=24GHzGuestNTEncrypt]").val() == 'aes'){
			$("input[name=24GHzGuestWlWep]").val("disabled");
			$("input[name=24GHzGuestWlWpa]").val("aes");				
			$(".Wep_2G").hide();
		}
		else if($("select[name=24GHzGuestNTEncrypt]").val() == 'tkip+aes'){
			$("input[name=24GHzGuestWlWep]").val("disabled");
			$("input[name=24GHzGuestWlWpa]").val("tkip+aes");				
			$(".Wep_2G").hide();
		}				
	}else {
		authValue = $("select[name=5GHzGuestNTAuth]").val();
		if(authValue == 'open'){
			if($("select[name=5GHzGuestNTEncrypt]").val() == 'enabled'){
				$(".Wep_5G").show();	
				$("input[name=5GHzGuestNTWEPKey1]").prop('disabled', true);
				$("input[name=5GHzGuestNTWEPKey2]").prop('disabled', true);
				$("input[name=5GHzGuestNTWEPKey3]").prop('disabled', true);
				$("input[name=5GHzGuestNTWEPKey4]").prop('disabled', true);						
			}else {
				$(".Wep_5G").hide();
			}										
		}
		if($("select[name=5GHzGuestNTEncrypt]").val() == 'enabled'){
			$("input[name=5GHzGuestWlWep]").val("enabled");
			$("input[name=5GHzGuestWlWpa]").val("aes");	
			$(".Wep_5G").show();
		}
		else if($("select[name=5GHzGuestNTEncrypt]").val() == 'disabled'){
			$("input[name=5GHzGuestWlWep]").val("disabled");
			$("input[name=5GHzGuestWlWpa]").val("aes");				
			$(".Wep_5G").hide();
		}
		else if($("select[name=5GHzGuestNTEncrypt]").val() == 'aes'){
			$("input[name=5GHzGuestWlWep]").val("disabled");
			$("input[name=5GHzGuestWlWpa]").val("aes");				
			$(".Wep_5G").hide();
		}
		else if($("select[name=5GHzGuestNTEncrypt]").val() == 'tkip+aes'){
			$("input[name=5GHzGuestWlWep]").val("disabled");
			$("input[name=5GHzGuestWlWpa]").val("tkip+aes");				
			$(".Wep_5G").hide();
		}				
	}
}

function initBeamforming(){
	$("select[name=5GHzMainNTBFR] option[value='" + nc_enableBFR + "']").prop("selected", true);										
	$("select[name=5GHzMainNTBFE] option[value='" + nc_enableBFR + "']").prop("selected", true);										
}

function initWPS(id){
	var authValue = '';
	if(id == 1){
		authValue = $("select[name=24GHzMainNTAuth]").val();
		if(authValue == "radius" || authValue == "wpa2" || authValue == "wpa wpa2"){
			$(".24MainSettingsWps").hide();
		}
		else{
			$(".24MainSettingsWps").show();
			if(nc_WscMode == "disabled" || nc_WscMode == "off"){
			$("input[name='24GHzMainNTWPS'][value='disabled']").prop("checked", true);
			$(".24GHzMainWPS").hide();
			$(".24GHzMainNTWPSPush").hide();
			}
			else if(nc_WscMode == "enabled"){
				$(".24GHzMainNTWPSRou").hide();
				$(".24GHzMainNTWPSDev").hide();
				$(".24GHzMainNTWPSPush").show();
				$("input[name='24GHzMainNTWPS'][value='enabled']").prop("checked", true);
				$("input[name='24GHzMainNTWPSPIN']").val(nc_WscDevPin);
				$("input[name='24GHzMainNTWPSDevPIN']").val(nc_WscStaPin);
				
				if(nc_WscCfgMethod == "ap-pin"){
					$(".24GHzMainNTWPSDev").hide();
					$(".24GHzMainNTWPSRou").show();
					$("input[name='24GHzMainNTWPSMode'][value='Router']").prop("checked", true);
				}
				else if(nc_WscCfgMethod == "sta-pin"){
					$(".24GHzMainNTWPSRou").hide();
					$(".24GHzMainNTWPSDev").show();
					$("input[name='24GHzMainNTWPSMode'][value='Device']").prop("checked", true);			
				}
				else{
					$("input[name='24GHzMainNTWPSMode'][value='Push Button']").prop("checked", true);
				}
			}		
		}
	}
	else if(id == 0){
		authValue = $("select[name=5GHzMainNTAuth]").val();
		if(authValue == "radius" || authValue == "wpa2" || authValue == "wpa wpa2"){
			$(".5MainSettingsWps").hide();
		}
		else{
			$(".5MainSettingsWps").show();
			if(nc_WscMode_5 == "disabled" || nc_WscMode_5 == "off"){
				$("input[name='5GHzMainNTWPS'][value='disabled']").prop("checked", true);
				$(".5GHzMainWPS").hide();
				$(".5GHzMainNTWPSPush").hide();
			}
			else if (nc_WscMode_5 == "enabled"){
				$("input[name='5GHzMainNTWPS'][value='enabled']").prop("checked", true);         
				$(".5GHzMainNTWPSRou").hide();
				$(".5GHzMainNTWPSDev").hide();
				$(".5GHzMainNTWPSPush").show();  
				$("input[name='5GHzMainNTWPS'][value='enabled']").prop("checked", true);
				$("input[name='5GHzMainNTWPSPIN']").val(nc_WscDevPin_5);
				$("input[name='5GHzMainNTWPSDevPIN']").val(nc_WscStaPin_5);
				
				if(nc_WscCfgMethod_5 == "ap-pin"){
					$(".5GHzMainNTWPSDev").hide();
					$(".5GHzMainNTWPSRou").show();
					$("input[name='5GHzMainNTWPSMode'][value='Router']").prop("checked", true);
				}
				else if(nc_WscCfgMethod_5 == "sta-pin"){
					$(".5GHzMainNTWPSRou").hide();
					$(".5GHzMainNTWPSDev").show();
					$("input[name='5GHzMainNTWPSMode'][value='Device']").prop("checked", true);			
				}
				else{
					$("input[name='5GHzMainNTWPSMode'][value='Push Button']").prop("checked", true);
				}		 
			}
		}
	}
}

function initGuestWPS(id){
	if(id == 1){
		if(nc_WscMode_2 == "disabled" || nc_WscMode_2 == "off"){
			$("input[name='24GHzGuestNTWPS'][value='disabled']").prop("checked", true);
         $(".24GHzGuestWPS").hide();
         $(".24GHzGuestNTWPSPush").hide();
       }
		else if (nc_WscMode_2 == "enabled"){
			$("input[name='24GHzGuestNTWPS'][value='enabled']").prop("checked", true);

         $(".24GHzGuestNTWPSRou").hide();
         $(".24GHzGuestNTWPSDev").hide();
         $(".24GHzGuestNTWPSPush").show();         
       }
      $("input[name='24GHzGuestNTWPSMode'][value='Push Button']").prop("checked", true);
      $("input[name='24GHzGuestNTWPSPIN']").val(nc_WscDevPin_2);
	}
	else if(id == 0){
		if(nc_WscMode_2_5 == "disabled" || nc_WscMode_2_5 == "off"){
			$("input[name='5GHzGuestNTWPS'][value='disabled']").prop("checked", true);
         $(".5GHzGuestWPS").hide();
         $(".5GHzGuestNTWPSPush").hide();
       }
		else if (nc_WscMode_2_5 == "enabled"){
			$("input[name='5GHzGuestNTWPS'][value='enabled']").prop("checked", true);
         $(".5GHzGuestNTWPSRou").hide();
         $(".5GHzGuestNTWPSDev").hide();
         $(".5GHzGuestNTWPSPush").show();         
       }
      $("input[name='5GHzGuestNTWPSMode'][value='Push Button']").prop("checked", true);      
      $("input[name='5GHzGuestNTWPSPIN']").val(nc_WscDevPin_2_5);
	}		
}

function isValidWPAPskKey(val) {
   var ret = false;
   var len = val.length;
   var maxSize = 64;
   var minSize = 8;

   if ( len >= minSize && len < maxSize )
      ret = true;
   else if ( len == maxSize ) {
      for ( i = 0; i < maxSize; i++ )
         if ( isHexaDigit(val.charAt(i)) == false )
            break;
      if ( i == maxSize )
         ret = true;
   } else
      ret = false;

   return ret;
}
function getPreauth(wlPreauth) {
   var ret;

   if ( wlPreauth == "on" )
      ret = 1;
   else
      ret = 0;
   return ret;
}
function wpsConnect_Guest_5(){
   var loc = '';
   var wpsMode = '';      
   loc += "nc_wps_5.ncwl?";
   wpsMode = $("input[name=5GHzGuestNTWPSMode]:checked").val();
   var encrypt = $("select[name=5GHzGuestNTEncrypt]").val();
   if(wpsMode == "Router"){
		loc += 'wlWscDevPin=' + $("input[name=5GHzGuestNTWPSPIN]").val();
		loc += '&wlWscCfgMethod=ap-pin';
		loc += '&wlWscConfig=ap-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
   }
   else if (wpsMode == "Device"){
		loc += 'wlWscStaPin=' + $("input[name=5GHzGuestNTWPSDevPIN]").val();
		loc += '&wlWscConfig=client-pin';
		loc += '&wlWscCfgMethod=sta-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';			
   }
   else if(wpsMode == "Push Button"){
		loc += 'wlWscStaPin=';
		loc += '&wlWscConfig=client-pbc';
		loc += '&wlWscCfgMethod=pbc';
		loc += '&wsc_event=a';
		loc += '&wsc_method=2';
		loc += '&wsc_config_command=1';		
   }
   
   loc += '&wsc_force_restart=y'; 
   loc += '&wlWscMode=enabled';
   loc += '&wlWscIRMode=enabled';
   loc += '&wlWscAPMode=1';

   var authMode = $("select[name=24GHzMainNTAuth]").val();
   loc += '&wlAuthMode=';
   loc += authMode;
   if (authMode == 'shared') {
      loc += '&wlAuth=1';
   }
   else {
      loc += '&wlAuth=0';
   }
   
   loc += '&wlMFP=0';
   var value; 

   if (authMode.indexOf("psk")!= -1) {
      value = $("input[name=5GHzGuestNTPSK]").val();
      if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
         alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
         return;
      }
      loc += '&wlWpaPsk=' + encodeUrl(encode(value));
   }

   if (authMode.indexOf("wpa")!= -1 || authMode.indexOf("psk")!= -1){
      //check GTK interval
      value = parseInt($("input[name=5GHzGuestNTWPARekeyInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Group Rekey Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlWpaGTKRekey=' + value;

      //check Reauth interval
      value = parseInt($("input[name=5GHzGuestNTAuthInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Network Reauthentication Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlNetReauth=' + value;
   }

   if (authMode.indexOf("wpa")!= -1 || authMode == 'radius') {
      if ( isValidIpAddress($("input[name=5GHGuestNTRadiusIP]").val()) == false ) {
         alert("RADIUS Server IP Address '" + $("input[5GHGuestNTRadiusIP]").val() + "' is invalid IP address.");
         return;
      }
      loc += '&wlRadiusServerIP=' + $("input[name=5GHGuestNTRadiusIP]").val();
      loc += '&wlRadiusPort=' + $("input[name=5GHzGuestNTRadiusPort]").val();
      loc += '&wlRadiusKey=' + encodeUrl($("input[5GHzGuestNTRadiusKey]").val());
   }

   if(authMode.indexOf("shared")!= -1 || authMode == 'radius' || authMode == 'open'){
      loc += "&wlWep=" + $("select[name=5GHzGuestNTEncrypt]").val();
   } 
   else
   {
      loc += "&wlWpa=" + $("select[name=5GHzGuestNTEncrypt]").val();
   }

   loc += "&wlKeyBit=" + $("select[name=5GHzGuestNTKey]").val();;
   loc += '&wlPreauth=' + getPreauth($("select[name=5GHzGuestPreauth]").val());

   if ($("select[name=5GHzGuestNTEncrypt]").val() == "enabled") {
      /*
            var i, val;
            var cbit = getSelect(wlKeyBit);
            for(i=0; i < 4; i++ ) {
            val = wlKeys[i].value;
            if ( val == '' && !(swep == 'enabled' && authMode == 'radius')) {
            alert(_("wlsecurityAlert13"));
            return;
            }
            if ( val != '' ) {
            if ( cbit == '0' ) {
            if ( isValidKey(val, 13) == false ) {
            alert(_("wlsecurityAlert14") + val + _("wlsecurityAlert15"));
            wlKeys[i].focus();
            return;
            }
            } else {
            if ( isValidKey(val, 5) == false ) {
            alert(_("wlsecurityAlert16") + val + _("wlsecurityAlert17"));
            wlKeys[i].focus();
            return;
            }
         }
         }
         }
      */         
      loc += "&wlKeyIndex="+$("select[name=5GHzGuestNTKey]").val();
      loc += '&wlKey1=' + encodeUrl($("input[name=5GHzGuestNTWEPKey1]").val());
      loc += '&wlKey2=' + encodeUrl($("input[name=5GHzGuestNTWEPKey2]").val());
      loc += '&wlKey3=' + encodeUrl($("input[name=5GHzGuestNTWEPKey3]").val());
      loc += '&wlKey4=' + encodeUrl($("input[name=5GHzGuestNTWEPKey4]").val());
   }

   // the last one to submit - if changing ssid above variables belong to previous ssid
   loc += "&wlSsidIdx=1";
   loc += '&wlSyncNvram=1';
   $.get(loc);
}
function wpsConnect_Main_5(){
   var loc = '';
   var wpsMode = '';      
   loc += "nc_wps_5.ncwl?";
   wpsMode = $("input[name=5GHzMainNTWPSMode]:checked").val();
   var encrypt = $("select[name=5GHzMainNTEncrypt]").val();
   if(wpsMode == "Router"){
		loc += 'wlWscDevPin=' + $("input[name=5GHzMainNTWPSPIN]").val()
		loc += '&wlWscCfgMethod=ap-pin';
		loc += '&wlWscConfig=ap-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
   }
   else if (wpsMode == "Device"){
		loc += 'wlWscStaPin=' + $("input[name=5GHzMainNTWPSDevPIN]").val();
		loc += '&wlWscConfig=client-pin';
		loc += '&wlWscCfgMethod=sta-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
   }
   else if(wpsMode == "Push Button"){
		loc += 'wlWscStaPin=';
		loc += '&wlWscConfig=client-pbc';
		loc += '&wlWscCfgMethod=pbc';
		loc += '&wsc_event=a';
		loc += '&wsc_method=2';
		loc += '&wsc_config_command=1';		
   }
   
   loc += '&wsc_force_restart=y'; 
   loc += '&wlWscMode=enabled';
   loc += '&wlWscIRMode=enabled';
   loc += '&wlWscAPMode=1';

   var authMode = $("select[name=5GHzMainNTAuth]").val();
   loc += '&wlAuthMode=';
   loc += authMode;
   if (authMode == 'shared') {
      loc += '&wlAuth=1';
   }
   else {
      loc += '&wlAuth=0';
   }
   loc += '&wlMFP=0';

   var value; 

   if (authMode.indexOf("psk")!= -1) {
      value = $("input[name=5GHzMainNTPSK]").val();
      if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
         alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
         return;
      }
      loc += '&wlWpaPsk=' + encodeUrl(encode(value));
   }

   if (authMode.indexOf("wpa")!= -1 || authMode.indexOf("psk")!= -1){
      //check GTK interval
      value = parseInt($("input[name=5GHzMainNTWPARekeyInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Group Rekey Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlWpaGTKRekey=' + value;

      //check Reauth interval
      value = parseInt($("input[name=5GHzMainNTAuthInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Network Reauthentication Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlNetReauth=' + value;
   }

   if (authMode.indexOf("wpa")!= -1 || authMode == 'radius') {
      if ( isValidIpAddress($("input[name=5GHzMainNTRadiusIP]").val()) == false ) {
         alert("RADIUS Server IP Address '" + $("input[name=5GHzMainNTRadiusIP]").val() + "' is invalid IP address.");
         return;
      }
      loc += '&wlRadiusServerIP=' + $("input[name=5GHzMainNTRadiusIP]").val();
      loc += '&wlRadiusPort=' + $("input[name=5GHzMainNTRadiusPort]").val();
      loc += '&wlRadiusKey=' + encodeUrl($("input[name=5GHzMainNTRadiusKey]").val());
   }

   if(authMode.indexOf("shared")!= -1 || authMode == 'radius' || authMode == 'open'){
      loc += "&wlWep=" + $("select[name=5GHzMainNTEncrypt]").val();
   } 
   else
   {
      loc += "&wlWpa=" + $("select[name=5GHzMainNTEncrypt]").val();
   }

   loc += "&wlKeyBit=" + $("select[name=5GHzMainNTKey]").val();;
   loc += '&wlPreauth=' + getPreauth($("select[name=5GHzMainPreauth]").val());

   if ($("select[name=5GHzMainNTEncrypt]").val() == "enabled") {
      /*
            var i, val;
            var cbit = getSelect(wlKeyBit);
            for(i=0; i < 4; i++ ) {
            val = wlKeys[i].value;
            if ( val == '' && !(swep == 'enabled' && authMode == 'radius')) {
            alert(_("wlsecurityAlert13"));
            return;
            }
            if ( val != '' ) {
            if ( cbit == '0' ) {
            if ( isValidKey(val, 13) == false ) {
            alert(_("wlsecurityAlert14") + val + _("wlsecurityAlert15"));
            wlKeys[i].focus();
            return;
            }
            } else {
            if ( isValidKey(val, 5) == false ) {
            alert(_("wlsecurityAlert16") + val + _("wlsecurityAlert17"));
            wlKeys[i].focus();
            return;
            }
         }
         }
         }
      */         
      loc += "&wlKeyIndex="+$("select[name=5GHzMainNTKey]").val();
      loc += '&wlKey1=' + encodeUrl($("input[name=5GHzMainNTWEPKey1]").val());
      loc += '&wlKey2=' + encodeUrl($("input[name=5GHzMainNTWEPKey2]").val());
      loc += '&wlKey3=' + encodeUrl($("input[name=5GHzMainNTWEPKey3]").val());
      loc += '&wlKey4=' + encodeUrl($("input[name=5GHzMainNTWEPKey4]").val());
   }

   // the last one to submit - if changing ssid above variables belong to previous ssid
   loc += "&wlSsidIdx=0";
   loc += '&wlSyncNvram=1';
   $.get(loc);
}
function wpsConnect_Guest_24(){
   var loc = '';
   var wpsMode = '';      
   loc += "nc_wps_24.ncwl?";
   wpsMode = $("input[name=24GHzGuestNTWPSMode]:checked").val();
   var encrypt = $("select[name=24GHzGuestNTEncrypt]").val();
   if(wpsMode == "Router"){
		loc += 'wlWscDevPin=' + $("input[name=24GHzGuestNTWPSPIN]").val();
		loc += '&wlWscCfgMethod=ap-pin';
		loc += '&wlWscConfig=ap-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
		loc += '&wsc_force_restart=y';
   }
   else if (wpsMode == "Device"){
		loc += 'wlWscStaPin=' + $("input[name=24GHzGuestNTWPSDevPIN]").val();
		loc += '&wlWscConfig=client-pin';
		loc += '&wlWscCfgMethod=sta-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';	
		loc += '&wsc_force_restart=n';
   }
   else if(wpsMode == "Push Button"){
		loc += 'wlWscStaPin=';
		loc += '&wlWscConfig=client-pbc';
		loc += '&wlWscCfgMethod=pbc';
		loc += '&wsc_event=a';
		loc += '&wsc_method=2';
		loc += '&wsc_config_command=1';	
		loc += '&wsc_force_restart=n';
   }
   
   loc += '&wlWscMode=enabled';
   loc += '&wlWscIRMode=enabled';
   loc += '&wlWscAPMode=1';

   var authMode = $("select[name=24GHzMainNTAuth]").val();
   loc += '&wlAuthMode=';
   loc += authMode;
   if (authMode == 'shared') {
      loc += '&wlAuth=1';
   }
   else {
      loc += '&wlAuth=0';
   }
   
   loc += '&wlMFP=0';
   var value; 

   if (authMode.indexOf("psk")!= -1) {
      value = $("input[name=24GHzGuestNTPSK]").val();
      if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
         alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
         return;
      }
      loc += '&wlWpaPsk=' + encodeUrl(encode(value));
   }

   if (authMode.indexOf("wpa")!= -1 || authMode.indexOf("psk")!= -1){
      //check GTK interval
      value = parseInt($("input[name=24GHzGuestNTWPARekeyInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Group Rekey Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlWpaGTKRekey=' + value;

      //check Reauth interval
      value = parseInt($("input[name=24GHzGuestNTAuthInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Network Reauthentication Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlNetReauth=' + value;
   }

   if (authMode.indexOf("wpa")!= -1 || authMode == 'radius') {
      if ( isValidIpAddress($("input[name=24GHGuestNTRadiusIP]").val()) == false ) {
         alert("RADIUS Server IP Address '" + $("input[24GHGuestNTRadiusIP]").val() + "' is invalid IP address.");
         return;
      }
      loc += '&wlRadiusServerIP=' + $("input[name=24GHGuestNTRadiusIP]").val();
      loc += '&wlRadiusPort=' + $("input[name=24GHzGuestNTRadiusPort]").val();
      loc += '&wlRadiusKey=' + encodeUrl($("input[24GHzGuestNTRadiusKey]").val());
   }

   if(authMode.indexOf("shared")!= -1 || authMode == 'radius' || authMode == 'open'){
      loc += "&wlWep=" + $("select[name=24GHzGuestNTEncrypt]").val();
   } 
   else
   {
      loc += "&wlWpa=" + $("select[name=24GHzGuestNTEncrypt]").val();
   }

   loc += "&wlKeyBit=" + $("select[name=24GHzGuestNTKey]").val();;
   loc += '&wlPreauth=' + getPreauth($("select[name=24GHzGuestPreauth]").val());

   if ($("select[name=24GHzGuestNTEncrypt]").val() == "enabled") {
      /*
            var i, val;
            var cbit = getSelect(wlKeyBit);
            for(i=0; i < 4; i++ ) {
            val = wlKeys[i].value;
            if ( val == '' && !(swep == 'enabled' && authMode == 'radius')) {
            alert(_("wlsecurityAlert13"));
            return;
            }
            if ( val != '' ) {
            if ( cbit == '0' ) {
            if ( isValidKey(val, 13) == false ) {
            alert(_("wlsecurityAlert14") + val + _("wlsecurityAlert15"));
            wlKeys[i].focus();
            return;
            }
            } else {
            if ( isValidKey(val, 5) == false ) {
            alert(_("wlsecurityAlert16") + val + _("wlsecurityAlert17"));
            wlKeys[i].focus();
            return;
            }
         }
         }
         }
      */         
      loc += "&wlKeyIndex="+$("select[name=24GHzGuestNTKey]").val();
      loc += '&wlKey1=' + encodeUrl($("input[name=24GHzGuestNTWEPKey1]").val());
      loc += '&wlKey2=' + encodeUrl($("input[name=24GHzGuestNTWEPKey2]").val());
      loc += '&wlKey3=' + encodeUrl($("input[name=24GHzGuestNTWEPKey3]").val());
      loc += '&wlKey4=' + encodeUrl($("input[name=24GHzGuestNTWEPKey4]").val());
   }

   // the last one to submit - if changing ssid above variables belong to previous ssid
   loc += "&wlSsidIdx=1";
   loc += '&wlSyncNvram=1';
   $.get(loc);
}
   
function wpsConnect_Main_24(){
   var loc = '';
   var wpsMode = '';      
   loc += "nc_wps_24.ncwl?";
   wpsMode = $("input[name=24GHzMainNTWPSMode]:checked").val();
   var encrypt = $("select[name=24GHzMainNTEncrypt]").val();
   if(wpsMode == "Router"){
		loc += 'wlWscDevPin=' + $("input[name=24GHzMainNTWPSPIN]").val();
		loc += '&wlWscCfgMethod=ap-pin';
		loc += '&wlWscConfig=ap-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
		loc += '&wsc_force_restart=y'; 
   }
   else if (wpsMode == "Device"){
		loc += 'wlWscStaPin=' + $("input[name=24GHzMainNTWPSDevPIN]").val();
		loc += '&wlWscConfig=client-pin';
		loc += '&wlWscCfgMethod=sta-pin';
		loc += '&wsc_proc_status=0';
		loc += '&wsc_method=1';
		loc += '&wsc_config_command=1';
		loc += '&wsc_force_restart=n'; 
   }
   else if(wpsMode == "Push Button"){
		loc += 'wlWscStaPin=';
		loc += '&wlWscConfig=client-pbc';
		loc += '&wlWscCfgMethod=pbc';
		loc += '&wsc_event=a';
		loc += '&wsc_method=2';
		loc += '&wsc_config_command=1';
		loc += '&wsc_force_restart=n'; 
   }
   
   loc += '&wlWscMode=enabled';
   loc += '&wlWscIRMode=enabled';
   loc += '&wlWscAPMode=1';

   var authMode = $("select[name=24GHzMainNTAuth]").val();
   loc += '&wlAuthMode=';
   loc += authMode;
   if (authMode == 'shared') {
      loc += '&wlAuth=1';
   }
   else {
      loc += '&wlAuth=0';
   }
   
   loc += '&wlMFP=0';
   var value;  
   if (authMode.indexOf("psk")!= -1) {
      value = $("input[name=24GHzMainNTPSK]").val();
      if ( isValidWPAPskKey(value) == false  && encrypt != "disabled") {
         alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
         return;
      }
      loc += '&wlWpaPsk=' + encodeUrl(encode(value));
   }

   if (authMode.indexOf("wpa")!= -1 || authMode.indexOf("psk")!= -1){
      //check GTK interval
      value = parseInt($("input[name=24GHzMainNTWPARekeyInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Group Rekey Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }
	  
      loc += '&wlWpaGTKRekey=' + value;

      //check Reauth interval
      value = parseInt($("input[name=24GHzMainNTAuthInterval]").val());
      if (  isNaN(value) == true || value < 0 || value > 0xffffffff ) {
         alert("WPA Network Reauthentication Interval '" + value + "' should be between 0 and 4294967295.");
         return;
      }

      loc += '&wlNetReauth=' + value;
   }

   if (authMode.indexOf("wpa")!= -1 || authMode == 'radius') {
      if ( isValidIpAddress($("input[name=24GHzMainNTRadiusIP]").val()) == false ) {
         alert("RADIUS Server IP Address '" + $("input[name=24GHzMainNTRadiusIP]").val() + "' is invalid IP address.");
         return;
      }
      loc += '&wlRadiusServerIP=' + $("input[name=24GHzMainNTRadiusIP]").val();
      loc += '&wlRadiusPort=' + $("input[name=24GHzMainNTRadiusPort]").val();
      loc += '&wlRadiusKey=' + encodeUrl($("input[name=24GHzMainNTRadiusKey]").val());
   }

   if(authMode.indexOf("shared")!= -1 || authMode == 'radius' || authMode == 'open'){
      loc += "&wlWep=" + $("select[name=24GHzMainNTEncrypt]").val();
   } 
   else
   {
      loc += "&wlWpa=" + $("select[name=24GHzMainNTEncrypt]").val();
   }

   loc += "&wlKeyBit=" + $("select[name=24GHzMainNTKey]").val();;
   loc += '&wlPreauth=' + getPreauth($("select[name=24GHzMainPreauth]").val());

   if ($("select[name=24GHzMainNTEncrypt]").val() == "enabled") {
      /*
            var i, val;
            var cbit = getSelect(wlKeyBit);
            for(i=0; i < 4; i++ ) {
            val = wlKeys[i].value;
            if ( val == '' && !(swep == 'enabled' && authMode == 'radius')) {
            alert(_("wlsecurityAlert13"));
            return;
            }
            if ( val != '' ) {
            if ( cbit == '0' ) {
            if ( isValidKey(val, 13) == false ) {
            alert(_("wlsecurityAlert14") + val + _("wlsecurityAlert15"));
            wlKeys[i].focus();
            return;
            }
            } else {
            if ( isValidKey(val, 5) == false ) {
            alert(_("wlsecurityAlert16") + val + _("wlsecurityAlert17"));
            wlKeys[i].focus();
            return;
            }
         }
         }
         }
      */         
      loc += "&wlKeyIndex="+$("select[name=24GHzMainNTKey]").val();
      loc += '&wlKey1=' + encodeUrl($("input[name=24GHzMainNTWEPKey1]").val());
      loc += '&wlKey2=' + encodeUrl($("input[name=24GHzMainNTWEPKey2]").val());
      loc += '&wlKey3=' + encodeUrl($("input[name=24GHzMainNTWEPKey3]").val());
      loc += '&wlKey4=' + encodeUrl($("input[name=24GHzMainNTWEPKey4]").val());
   }


   // the last one to submit - if changing ssid above variables belong to previous ssid
   loc += "&wlSsidIdx=0";
   loc += '&wlSyncNvram=1';
   $.get(loc);
}

function nc_basicSave_24(){
	value1 = $("input[name=24GHzMainPWD]").val();
	MainName = $("input[name=24GHzMainName]").val();
	var encrypt = $("select[name=24GHzMainNTEncrypt]").val();

    if ( isValidWPAPskKey(value1) == false && encrypt != "disabled") {
        alert("2.4GHz Main Password should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
        return false;
    }
    if ( MainName.length>32) {
        alert("2.4GHz Main Name should not be longer than 32 characters.");
        return false;
    }
    if ( MainName=='') {
        alert("2.4GHz Main Name should not be empty.");
        return false;
    }
	value2 = $("input[name=24GHzGuestPWD]").val();
	GuestName = $("input[name=24GHzGuestName]").val();
	encrypt = $("select[name=24GHzGuestNTEncrypt]").val();
    if ( isValidWPAPskKey(value2) == false && encrypt != "disabled") {
        alert("2.4GHz Guest Password should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
        return false;
    }
    if ( GuestName.length>32) {
        alert("2.4GHz Guest Name should not be longer than 32 characters.");
        return false;
    }
    if ( GuestName=='') {
        alert("2.4GHz Guest Name should not be empty.");
        return false;
    }    

    value1 = encodeUrl(encode($("input[name=24GHzMainPWD]").val()));
    $("input[name=24GHzMainPWD]").val(value1);

    value2 = encodeUrl(encode($("input[name=24GHzGuestPWD]").val()));
    $("input[name=24GHzGuestPWD]").val(value2);

	return true;
}

function nc_basicSave_5(){
	value3 = $("input[name=5GHzMainPWD]").val();
	MainName = $("input[name=5GHzMainName]").val();
	var encrypt = $("select[name=5GHzMainNTEncrypt]").val();

    if ( isValidWPAPskKey(value3) == false && encrypt != "disabled") {
        alert("5G Main Password should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
        return false;
    }
    if ( MainName.length>32) {
        alert("5GHz Main Name should not be longer than 32 characters.");
        return false;
    }
    if ( MainName=='') {
        alert("5GHz Main Name should not be empty.");
        return false;
    }	
	value4 = $("input[name=5GHzGuestPWD]").val();
	GuestName = $("input[name=5GHzGuestName]").val();
	encrypt = $("select[name=5GHzGuestNTEncrypt]").val();
    if ( isValidWPAPskKey(value4) == false && encrypt != "disabled") {
        alert("5G Guest Password should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
        return false;
    }
    if ( GuestName.length>32) {
        alert("5GHz Guest Name should not be longer than 32 characters.");
        return false;
    }
    if ( GuestName=='') {
        alert("5GHz Guest Name should not be empty.");
        return false;
    }    

    value3 = encodeUrl(encode($("input[name=5GHzMainPWD]").val()));
    $("input[name=5GHzMainPWD]").val(value3);

    value4 = encodeUrl(encode($("input[name=5GHzGuestPWD]").val()));
    $("input[name=5GHzGuestPWD]").val(value4);
    
	return true;
}
function nc_authMainSave_24(){
	var authMode = $("select[name=24GHzMainNTAuth]").val();
	M24 = parseInt($("input[name=24GHzMainNTMaxDevices]").val());
	var encrypt = $("select[name=24GHzMainNTEncrypt]").val();
	if(M24 < 1){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	else if(M24 > 32){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	if (1) {
        value = $("input[name=24GHzMainNTPSK]").val();
        if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
            alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
            return false;
        }
        value = encodeUrl(encode($("input[name=24GHzMainNTPSK]").val()));
        $("input[name=24GHzMainNTPSK]").val(value);
    }
	var wep_24Main = $('select[name="24GHzMainNTEncrypt"]').val();
	$("input[name=24GHzMainWlWep]").val(wep_24Main);
	
	return true;
}
function nc_authGuestSave_24(){
	var authMode = $("select[name=24GHzGuestNTAuth]").val();
	G24 = parseInt($("input[name=24GHzGuestNTMaxDevices]").val());
	var encrypt = $("select[name=24GHzGuestNTEncrypt]").val();
	if(G24 < 1){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	else if(G24 > 32){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	if (1) {
        value = $("input[name=24GHzGuestNTPSK]").val();
        if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
            alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
            return false;
        }
        value = encodeUrl(encode($("input[name=24GHzGuestNTPSK]").val()));
        $("input[name=24GHzGuestNTPSK]").val(value);        
    }
	var wep_24Guset = $('select[name="24GHzGuestNTEncrypt"]').val();
	$("input[name=24GHzGuestWlWep]").val(wep_24Guset);
	
	return true;
}
function nc_authMainSave_5(){
	var authMode = $("select[name=5GHzMainNTAuth]").val();
	M5 = parseInt($("input[name=5GHzMainNTMaxDevices]").val());
	var encrypt = $("select[name=5GHzMainNTEncrypt]").val();
	if(M5 < 1){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	else if(M5 > 32){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	if (1) {
        value = $("input[name=5GHzMainNTPSK]").val();
        if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
            alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
            return false;
        }
        value = encodeUrl(encode($("input[name=5GHzMainNTPSK]").val()));
        $("input[name=5GHzMainNTPSK]").val(value);         
    }
	var wep_5Main = $('select[name="5GHzMainNTEncrypt"]').val();
	$("input[name=5GHzMainWlWep]").val(wep_5Main);

	
	return true;
}
function nc_authGuestSave_5(){
	var authMode = $("select[name=5GHzGuestNTAuth]").val();
	var G5 = parseInt($("input[name=5GHzGuestNTMaxDevices]").val());
	var encrypt = $("select[name=5GHzGuestNTEncrypt]").val();
	if(G5 < 1){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
	else if(G5 > 32){
		alert("Max Connected Devices should be between 1 and 32!");
		return false;
	}
    if (1) {
        value = $("input[name=5GHzGuestNTPSK]").val();
        if ( isValidWPAPskKey(value) == false && encrypt != "disabled") {
            alert("WPA Pre-Shared Key should be between 8 and 63 ASCII characters or 64 hexadecimal digits.");
            return false;
        }
        value = encodeUrl(encode($("input[name=5GHzGuestNTPSK]").val()));
        $("input[name=5GHzGuestNTPSK]").val(value);        
    }
	var wep_5Guset = $('select[name="5GHzGuestNTEncrypt"]').val();
	$("input[name=5GHzGuestWlWep]").val(wep_5Guset);
	 
	return true;
}

function displayPsk(type){
   if(type == "24Main"){
      $("#display24MainPskText").empty();
      $("#display24MainPskText").append("<p>" + $("input[name=24GHzMainNTPSK]").val()+"</p>");
   }
   else if (type == "24Guest"){
      $("#display24GuestPskText").empty();
      $("#display24GuestPskText").append("<p>" + $("input[name=24GHzGuestNTPSK]").val()+"</p>");
   }
   else if (type == "5Main"){
      $("#display5MainPskText").empty();
      $("#display5MainPskText").append("<p>" + $("input[name=5GHzMainNTPSK]").val()+"</p>");
   }
   else if (type == "5Guest"){
      $("#display5GuestPskText").empty();
      $("#display5GuestPskText").append("<p>" + $("input[name=5GHzGuestNTPSK]").val()+"</p>");
   }
}

function MoreSetting_Cancel(id){
	if(id == 1){
		$(".24GHzSettings").hide();
		$(".24GHzMoreSettingBtn").text("More Settings");
	}
	else if(id == 0){
		$(".5GHzSettings").hide();
		$(".5GHzMoreSettingBtn").text("More Settings");
	}		
}
