function wl_recalc(OnPageLoad, id) {
   initWlNmode(OnPageLoad, id);
   phyChange(OnPageLoad, id);
   genericChange(OnPageLoad, id);
   updateCurChannel(OnPageLoad, id);      
   onBandChange(OnPageLoad, id);       
   gModeChange(OnPageLoad, id);
   wl_ewc_options(OnPageLoad, id);    
   RegModeChange(OnPageLoad, id);
   wl_mcs_onchange(OnPageLoad, id);
   OnRxChainPowerSaveChange(OnPageLoad, id);
   wmeChange(OnPageLoad, id);      
   wl_afterburner_options(OnPageLoad, id);        
   wl_vec_options(OnPageLoad, id);
   wl_iperf_options(OnPageLoad, id);

}

function  wlinitCountryList(OnPageLoad, id){
   if(id == 1)				
      wlLoadCountryList_24(OnPageLoad);
   else if(id == 0)
      wlLoadCountryList_5(OnPageLoad);
}

function CountryonChange(OnPageLoad, id){
   if(id == 1){
	var selcountry=$("select[name=wl1Country]").find('option:selected').text();
	if(selcountry!=curcountry_24) 
	{
		$("input[name=wl1RegRev]").val(0);
		curcountry_24=selcountry;
	}
   }else if(id == 0){
	var selcountry=$("select[name=wl0Country]").find('option:selected').text();
	if(selcountry!=curcountry_5) 
	{
		$("input[name=wl0RegRev]").val(0);
		curcountry_5=selcountry;
	}
   }
}

function wl_iperf_options(OnPageLoad, id) {
   if(id == 1){
      if(OnPageLoad) 				
         setSelectbyIndex("24GhzWlIperf", iperf_24);
      if ( (hasvec_24 != 1) )
         setSelectbyValue("24GhzWlIperf", "0");
   }else{
      if(OnPageLoad) 				
         setSelectbyIndex("5GhzWlIperf", iperf_5);
      if ( (hasvec_5 != 1) )
         setSelectbyValue("5GhzWlIperf", "0");
   }
}

function getVecIndex(vec) {
   var ret;

   if ( vec == "0" )
      ret = 0;
   else if ( vec == "1" )
      ret = 1;
   else if ( vec == "2" )
      ret = 2;
   else if ( vec == "10" )
      ret = 3;
   else if ( vec == "6" )
      ret = 4;
   else if ( vec == "14" )
      ret = 5;
   else
      ret = 0;
   return ret;
}
function wl_vec_options(OnPageLoad, id)
{
   var hide = false;

   if(id == 1){
      if(OnPageLoad) {
         setSelectbyIndex("24GhzWlVec", getVecIndex(vec_24));
      }

      if ( (hasvec_24 != 1) ){
         hide = true;
         setSelectbyValue("24GhzWlVec", "0");
      }   
      showhideByJqId("VEC_24", !hide);
   }
   else {
      if(OnPageLoad) {
         setSelectbyIndex("5GhzWlVec", getVecIndex(vec_5));
      }

      if ( (hasvec_5 != 1) ){
         hide = true;
         setSelectbyValue("5GhzWlVec", "0");
      }   
      showhideByJqId("VEC_5", !hide);
   }
}
function getAfterBurnerIndex(afterburner) {
   var ret;

   if ( afterburner == "auto" )
      ret = 1;
   else
      ret = 0;
   return ret;
}
function wl_afterburner_options(OnPageLoad, id) {
   var hideAB = false;
   var enableABSel = true; 
   var hideWarning = true;  

   if(id == 1){
      var sel_nmode = $("select[name=24GhzWlNmode]").val();
      if(OnPageLoad) {
         sel_nmode = nmode_24;
         setSelectbyIndex("24GhzWlAfterBurnerEn", getAfterBurnerIndex(afterburneren_24));
      } else {
         sel_nmode = $("select[name=24GhzWlNmode]").val();        
      }

      if ( (hasafterburner_24 != 1) ){
         hideAB = true;
      }

      if((phy_24 == "n" || phy_24 == "v") && sel_nmode == "auto") {
         hideAB = true;        
      }

      if (parseInt($("select[name=24GhzWlFrgThrshld]").val()) != 2346 ){
         //alert('wlFrgThrshld.value "' + parseInt(wlFrgThrshld.value) +'"');
         enableABSel = false; 
         hideWarning = false;        	
      }

      if($("select[name=24GhzWlWme]").val()!= 0) {
         enableABSel = false; 
      }

      if (hideAB ||!enableABSel) {
         setSelectbyValue("24GhzWlAfterBurnerEn", "off");
      } 

      showhideByJqId("AFB_24", !hideAB);
      $("select[name=24GhzWlFrgThrshld]").prop("disabled", !enableABSel);
   }
   else{
      var sel_nmode = $("select[name=5GhzWlNmode]").val();
         if(OnPageLoad) {
         sel_nmode = nmode_5;
         setSelectbyIndex("5GhzWlAfterBurnerEn", getAfterBurnerIndex(afterburneren_5));
      } else {
         sel_nmode = $("select[name=5GhzWlNmode]").val();        
      }

      if ( (hasafterburner_5 != 1) ){
         hideAB = true;
      }

      if((phy_5 == "n" || phy_5 == "v") && sel_nmode == "auto") {
         hideAB = true;        
      }

      if (parseInt($("select[name=5GhzWlFrgThrshld]").val()) != 2346 ){
         //alert('wlFrgThrshld.value "' + parseInt(wlFrgThrshld.value) +'"');
         enableABSel = false; 
         hideWarning = false;        	
      }

      if($("select[name=5GhzWlWme]").val()!= 0) {
         enableABSel = false; 
      }

      if (hideAB ||!enableABSel) {
         setSelectbyValue("5GhzWlAfterBurnerEn", "off");
      } 

      showhideByJqId("AFB_5", !hideAB);
      $("select[name=5GhzWlFrgThrshld]").prop("disabled", !enableABSel);
   }
}

function wmeChange(OnPageLoad, id) {
   if(id == 1){
      if(OnPageLoad) {  
         if(haswme_24 == '1'){
            $("#WLWMM_24").show();
            $("#WLWMMNOACK_24").show();
            $("#WLWMMAPSD_24").show();
         }
         else if (haswme_24 == '0'){
            $("#WLWMM_24").hide();
            $("#WLWMMNOACK_24").hide();
            $("#WLWMMAPSD_24").hide();
         }
         setSelectbyValue("24GhzWlWme", wme_24);
         setSelectbyValue("24GhzWlWmeNoAck", wmenoack_24);
         setSelectbyValue("24GhzWlWmeApsd", wmeapsd_24);
      }
      $("select[name=24GhzWlWmeNoAck]").prop("disabled", $("select[name=24GhzWlWme]").val() == '0');
      $("select[name=24GhzWlWmeApsd]").prop("disabled", $("select[name=24GhzWlWme]").val() == '0');		      
   }
   else {
      if(OnPageLoad) {  
         if(haswme_5 == '1'){
            $("#WLWMM_5").show();
            $("#WLWMMNOACK_5").show();
            $("#WLWMMAPSD_5").show();
         }
         else if (haswme_5 == '0'){
            $("#WLWMM_5").hide();
            $("#WLWMMNOACK_5").hide();
            $("#WLWMMAPSD_5").hide();
         }
         setSelectbyValue("5GhzWlWme", wme_5);
         setSelectbyValue("5GhzWlWmeNoAck", wmenoack_5);
         setSelectbyValue("5GhzWlWmeApsd", wmeapsd_5);
      }
      $("select[name=5GhzWlWmeNoAck]").prop("disabled", $("select[name=5GhzWlWme]").val() == '0');
      $("select[name=5GhzWlWmeApsd]").prop("disabled", $("select[name=5GhzWlWme]").val() == '0');		      
   }
}                     
function OnRxChainPowerSaveChange(OnPageLoad, id) {	
   if (id == 1){
         $("input[name=24GhzWlRxChainPwrSaveQuietTime]").prop("disabled", $("select[name=24GhzWlRxChainPwrSaveEnable]").val() == '0');
         $("input[name=24GhzWlRxChainPwrSavePps]").prop("disabled", $("select[name=24GhzWlRxChainPwrSaveEnable]").val() == '0');
   }
   else{
         $("input[name=5GhzWlRxChainPwrSaveQuietTime]").prop("disabled", $("select[name=5GhzWlRxChainPwrSaveEnable]").val() == '0');
         $("input[name=5GhzWlRxChainPwrSavePps]").prop("disabled", $("select[name=5GhzWlRxChainPwrSaveEnable]").val() == '0');
      
   } 
}

function wl_mcs_onchange(OnPageLoad, id)
      {
   var sel_nmcsidx;
   var sel_nmode;

   if(id == 1){
      if(phy_24 != "n" && phy_24 != "v") 
         return;

      if(OnPageLoad) {
         sel_nmcsidx = nmcsidx_24;
         sel_nmode = nmode_24;
      } else {
         sel_nmcsidx = $("select[name=24GhzWlNMmcsidx]").val();
         sel_nmode = $("select[name=24GhzWlNmode]").val();     
      }      

      /* If using 'legacy rate' then enable */
      if (sel_nmcsidx == "-2" || sel_nmode == "off")
         $("select[name=24GhzWl54gRate]").prop("disabled", false);
      else
         $("select[name=24GhzWl54gRate]").prop("disabled", true);
   }
   else{
      if(phy_5 != "n" && phy_5 != "v") 
         return;

      if(OnPageLoad) {
         sel_nmcsidx = nmcsidx_5;
         sel_nmode = nmode_5;
      } else {
         sel_nmcsidx = $("select[name=5GhzWlNMmcsidx]").val();
         sel_nmode = $("select[name=5GhzWlNmode]").val();     
         }      

      /* If using 'legacy rate' then enable */
      if (sel_nmcsidx == "-2" || sel_nmode == "off")
         $("select[name=5GhzWl54gRate]").prop("disabled", false);
      else
         $("select[name=5GhzWl54gRate]").prop("disabled", true);
   }
}

function RegModeChange(OnPageLoad, id) {
   var sel_band;

   if(id == 1){
      /* save selected */      
      if(OnPageLoad) {
         sel_band = band_24;
      }      
      else {
         sel_band = band_24;
      }          

      if( $("select[name=24GhzWlRegMode]").get(0).selectedIndex != 1 ){
         $("input[name=24GhzWlDfsPreIsm]").prop("disabled", true);
         $("input[name=24GhzWlDfsPostIsm]").prop("disabled", true);
         $("input[name=24GhzWlTpcDb]").prop("disabled", true);			
      }
      else{ 
         $("input[name=24GhzWlDfsPreIsm]").prop("disabled", false);
         $("input[name=24GhzWlDfsPostIsm]").prop("disabled", false);
         $("input[name=24GhzWlTpcDb]").prop("disabled", false);
      }

      if (sel_band == "2") {
         $("#div_regMode_24").hide();   
      }
      else {
         $("#div_regMode_24").show();   
      }         
   }
   else{
      /* save selected */      
      if(OnPageLoad) {
         sel_band = band_5;
      }      
      else {
         sel_band = band_5;
      }          

      if( $("select[name=5GhzWlRegMode]").get(0).selectedIndex != 1 ){
         $("input[name=5GhzWlDfsPreIsm]").prop("disabled", true);
         $("input[name=5GhzWlDfsPostIsm]").prop("disabled", true);
         $("input[name=5GhzWlTpcDb]").prop("disabled", true);			
      }
      else{ 
         $("input[name=5GhzWlDfsPreIsm]").prop("disabled", false);
         $("input[name=5GhzWlDfsPostIsm]").prop("disabled", false);
         $("input[name=5GhzWlTpcDb]").prop("disabled", false);
      }

      if (sel_band == "2") {
         $("div_regMode_5").hide();   
      }
      else {
         $("div_regMode_5").show();   
      }         
   }
}
function initChannelList(OnPageLoad, id){
   if(id == 1)				
      loadChannelList_24(OnPageLoad);
   else if(id == 0)
      loadChannelList_5(OnPageLoad);
}
function  wl_ewc_options(OnPageLoad, id){
   if(id == 1)				
      wl_ewc_options_24(OnPageLoad);
   else if(id == 0)
      wl_ewc_options_5(OnPageLoad);
}

function loadMCastRateList(OnPageLoad, id) {
   var sel_band;
   var sel_rate;
   var idx;
   var sel_nmode;
   var sel_gmode;
   if(id == 1){
      /* save selected */
      if(OnPageLoad) {
         sel_band = band_24;
         sel_rate = mcastrate_24;
         sel_nmode = nmode_24;
         sel_gmode = gmode_24;      
      }
      else {
         sel_band = band_24;
         sel_rate = $("select[name=24GhzMulticastRate]").val();
         sel_nmode = $("select[name=24GhzWlNmode]").val();
         sel_gmode = $("select[name=24GhzWlgMode]").val();
      }

      if((phy_24 != "n" && phy_24 != "v")) sel_nmode = "off";

      $("select[name=24GhzMulticastRate]").empty();
      if (sel_band == "2") { // 2.4G
         if (phy_24 == "b" ||      
               (country_24 == "JP" && $("select[name=24GHzMainNTChannel]").val() == '14') ||
               (sel_nmode == "off" && sel_gmode == "0")) {
            $("select[name=24GhzMulticastRate]").append('<option value="0">Auto</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="1000000">1 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="2000000">2 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="5500000">5.5 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="11000000">11 Mbps</option>');
         }
         else {
            $("select[name=24GhzMulticastRate]").append('<option value="0">Auto</option>');	  	
            $("select[name=24GhzMulticastRate]").append('<option value="1000000">1 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="2000000">2 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="5500000">5.5 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="6000000">6 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="9000000">9 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="11000000">11 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="12000000">12 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="18000000">18 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="24000000">24 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="36000000">36 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="48000000">48 Mbps</option>');
            $("select[name=24GhzMulticastRate]").append('<option value="54000000">54 Mbps</option>');
         }
      }

      $("select[name=24GhzMulticastRate] option[value=" + sel_rate +"]").prop("selected", true);
   }  
   else {
      if(OnPageLoad) {
         sel_band = band_5;
         sel_rate = mcastrate_5;
         sel_nmode = nmode_5;
         sel_gmode = gmode_5;      
      }
      else {
         sel_band = band_5;
         sel_rate = $("select[name=5GhzMulticastRate]").val();
         sel_nmode = $("select[name=5GhzWlNmode]").val();;
         sel_gmode = $("select[name=5GhzWlgMode]").val();;
      }

      if((phy_5 != "n" && phy_5 != "v")) sel_nmode = "off";

      $("select[name=5GhzMulticastRate]").empty();
      if (sel_band == "1") { // 5G
         $("select[name=5GhzMulticastRate]").append('<option value="0">Auto</option>');	  	   
         $("select[name=5GhzMulticastRate]").append('<option value="6000000">6 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="9000000">9 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="12000000">12 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="18000000">18 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="24000000">24 Mbps</option>');			
         $("select[name=5GhzMulticastRate]").append('<option value="36000000">36 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="48000000">48 Mbps</option>');
         $("select[name=5GhzMulticastRate]").append('<option value="54000000">54 Mbps</option>');	   
      }
      $("select[name=5GhzMulticastRate] option[value=" + sel_rate +"]").prop("selected", true);
   }
}

function loadRateList(OnPageLoad, id) {
   var sel_band;
   var sel_rate;
   var idx;
   var sel_nmode;
   var sel_gmode;
   if(id == 1){         
      /* save selected */
      if(OnPageLoad) {
         sel_band = band_24;
         sel_rate = rate_24;
         sel_nmode = nmode_24;
         sel_gmode = gmode_24;
      }
      else {
         sel_band = band_24;
         sel_rate = $("select[name=24GhzWl54gRate]").val(); 
         sel_nmode = $("select[name=24GhzWlNmode]").val();
         sel_gmode = $("select[name=24GhzWlgMode]").val();;
      }

      if((phy_24 != "n") && (phy_24 != "v")) sel_nmode = "off";
      $("select[name=24GhzWl54gRate]").empty();
      if (sel_band == "2") { // 2.4G
         if (phy_24 == "b" || 
               (country_24 == "JP" && $("select[name=24GHzMainNTChannel]").val() == '14') ||
               (sel_nmode == "off" && sel_gmode == "0")) {
            $("select[name=24GhzWl54gRate]").append('<option value="0">Auto</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="1000000">1 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="2000000">2 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="5500000">5.5 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="11000000">11 Mbps</option>');			
         }
         else {
            $("select[name=24GhzWl54gRate]").append('<option value="0">Auto</option>');	  	
            $("select[name=24GhzWl54gRate]").append('<option value="1000000">1 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="2000000">2 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="5500000">5.5 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="6000000">6 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="9000000">9 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="11000000">11 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="12000000">12 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="18000000">18 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="24000000">24 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="36000000">36 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="48000000">48 Mbps</option>');
            $("select[name=24GhzWl54gRate]").append('<option value="54000000">54 Mbps</option>');	  	
         }
      }

      if(sel_nmode != "off") {
         /* exclude auto for 802.11a/b/g (Legacy) rates if 11n is enabled */
         $("select[name=24GhzWl54gRate]option[index=0]").remove();
      }

      $("select[name=24GhzWl54gRate]").get(0).value= sel_rate;
   }
   else{
      if(OnPageLoad) {
         sel_band = band_5;
         sel_rate = rate_5;
         sel_nmode = nmode_5;
         sel_gmode = gmode_5;
      }
      else {
         sel_band = band_5;
         sel_rate = $("select[name=5GhzWl54gRate]").val(); 
         sel_nmode = $("select[name=5GhzWlNmode]").val();
         sel_gmode = $("select[name=5GhzWlgMode]").val();
      }

      if((phy_5 != "n") && (phy_5 != "v")) sel_nmode = "off";

      $("select[name=5GhzWl54gRate]").empty();

      if (sel_band == "1") { // 5G
         $("select[name=5GhzWl54gRate]").append('<option value="0">Auto</option>');	  	   
         $("select[name=5GhzWl54gRate]").append('<option value="6000000">6 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="9000000">9 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="12000000">12 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="18000000">18 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="24000000">24 Mbps</option>');			
         $("select[name=5GhzWl54gRate]").append('<option value="36000000">36 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="48000000">48 Mbps</option>');
         $("select[name=5GhzWl54gRate]").append('<option value="54000000">54 Mbps</option>');	   
      }

      if(sel_nmode != "off") {
         /* exclude auto for 802.11a/b/g (Legacy) rates if 11n is enabled */
         $("select[name=5GhzWl54gRate]option[index=0]").remove();
      }

      $("select[name=5GhzWl54gRate]").get(0).value= sel_rate;
   }
}
function loadBasicRateList(OnPageLoad, id) {
   var sel_band;
   var sel_rate;
   var idx;

   if(id == 1){
      /* save selected */
      if(OnPageLoad) {
         sel_band = band_24;
         sel_rate = brate_24;
      }
      else {
         sel_band = band_24;
         sel_rate = $("select[name=24GhzWlBasicRate]").val();
      }

      $("select[name=24GhzWlBasicRate]").empty();

      if (sel_band == "2") { // 2.4G
         $("select[name=24GhzWlBasicRate]").append('<option value="default">Default</option>');	  	   
         $("select[name=24GhzWlBasicRate]").append('<option value="all">All</option>');
         $("select[name=24GhzWlBasicRate]").append('<option value="12">1 & 2 Mbps</option>');

         if (phy_24 != "b") {
            $("select[name=24GhzWlBasicRate]").append('<option value="wifi2">1 1 & 2 & 5.5 & 6 & 11 & 12 & 24 Mbps</option>');
         }

      }
      else {
         $("select[name=24GhzWlBasicRate]").append('<option value="0">Default</option>');	  	   
      }
      $("select[name=24GhzWlBasicRate]").get(0).value= sel_rate;
   }
   else {
      /* save selected */
      if(OnPageLoad) {
         sel_band = band_5;
         sel_rate = brate_5;
      }
      else {
         sel_band = band_5;
         sel_rate = $("select[name=5GhzWlBasicRate]").val();
      }

      $("select[name=5GhzWlBasicRate]").empty();

      if (sel_band == "1") { // 5G
         $("select[name=5GhzWlBasicRate]").append('<option value="default">Default</option>');	  	   
         $("select[name=5GhzWlBasicRate]").append('<option value="all">All</option>');
         $("select[name=5GhzWlBasicRate]").append('<option value="12">6 & 12 Mbps</option>');
         $("select[name=5GhzWlBasicRate]").append('<option value="wifi2">6 & 12 & 24 Mbps</option>');
      }
      else {
         $("select[name=5GhzWlBasicRate]").append('<option value="0">Default</option>');	  	   
      }
      $("select[name=5GhzWlBasicRate]").get(0).value= sel_rate;
   }
}

function onBandChange(OnPageLoad, id) {
   initChannelList(OnPageLoad, id);
   loadRateList(OnPageLoad, id);
   loadMCastRateList(OnPageLoad, id);
   loadBasicRateList(OnPageLoad, id);
}

function gModeChange(OnPageLoad, id) {
   var sel_band;
   var sel_gmode;
   var sel_pro;
   var sel_pre;
   var sel_nmode;
   if(id == 1){
      /* save selected */   
      if(OnPageLoad) {      
         sel_band = band_24;
         sel_gmode = gmode_24;
         sel_pro = pro_24;
         sel_nmode = nmode_24;
      } else {
         sel_band = band_24;
         sel_gmode = $("select[name=24GhzWlgMode]").val(); 
         sel_pro = $("select[name=24GhzWlProtection]").val();
         sel_nmode = $("select[name=24GhzWlNmode]").val();      
      }

      $("#preambleType_24").hide();

      var wlProtection = getGModeProtection(sel_pro);                                      
      $("select[name=24GhzWlProtection]").get(0).selectedIndex = 	wlProtection;

      if ((phy_24 == "n" || phy_24 == "v") && sel_nmode != "off") {
         $("#div_gMode_24").hide();				 
      } 
      else {
         switch(sel_gmode) {
         case '0':
            $("#preambleType_24").show();         
            $("select[name=24GhzWlgMode] option[value=0]").prop("selected", true);	
            break;
         case '4':
            $("select[name=24GhzWlgMode] option[value=4]").prop("selected", true);
            break;
         case '5':
            $("select[name=24GhzWlgMode] option[value=5]").prop("selected", true);
            break;
         default:
            $("select[name=24GhzWlgMode] option[value=1]").prop("selected", true);
            $("#preambleType_24").show();         
            break;
         }        
         if (sel_band == "2") {
            if (phy_24 == "b") { //11b
               $("#div_gMode_24").hide();				 
            }
            else { //11g
               $("#div_gMode_24").show();				 
            }
         }
         else { //11a
            $("#div_gMode_24").hide();				 
            $("#preambleType_24").hide();    
         }        
      }           
   }
   else {
      /* save selected */   
      if(OnPageLoad) {      
         sel_band = band_5;
         sel_gmode = gmode_5;
         sel_pro = pro_5;
         sel_nmode = nmode_5;
      } else {
         sel_band = band_5;
         sel_gmode = $("select[name=5GhzWlgMode]").val(); 
         sel_pro = $("select[name=5GhzWlProtection]").val();
         sel_nmode = $("select[name=5GhzWlNmode]").val();      
      }

      $("#preambleType_5").hide();

      var wlProtection = getGModeProtection(sel_pro); 
      $("select[name=5GhzWlProtection]").get(0).selectedIndex = 	wlProtection;
      if ((phy_24 == "n" || phy_24 == "v") && sel_nmode != "off") {
         $("#div_gMode_5").hide();				 
      } 
      else {
         switch(sel_gmode) {
            case '0':
               $("#preambleType_5").show();         
               $("select[name=5GhzWlgMode] option[index=3]").prop("selected", true);	
               break;
            case '4':
               $("select[name=5GhzWlgMode] option[index=1]").prop("selected", true);
               break;
            case '5':
               $("select[name=5GhzWlgMode] option[index=2]").prop("selected", true);
               break;
            default:
               $("select[name=5GhzWlgMode] option[index=0]").prop("selected", true);
               $("#preambleType_5").show();         
               break;
         }        
         if (sel_band == "2") {
            if (phy_5 == "b") { //11b
               $("#div_gMode_5").hide();				 
            }
            else { //11g
               $("#div_gMode_5").show();				 
            }
         }
         else { //11a
            $("#div_gMode_5").hide();				 
            $("#preambleType_5").hide();    
         }        
      }           
   }
}

function getGModeProtection(pro) {
   var ret;

   if ( pro == "auto" )
      ret = 1;
   else
      ret = 0;
   return ret;
}
function updateCurChannel(OnPageLoad, id) {
   if(id == 1){
      if(OnPageLoad) {          
         var curr_bw = parseInt(currbw_24);
         var chanimstate_str = "";

         if (chanimstate_24 == "0")
         chanimstate_str = " (interference: acceptable)";
         else
         chanimstate_str = " (interference: severe)";

         if(curr_bw == 2)
            curr_bw_str_24 = "20";
         else if (curr_bw == 3)
            curr_bw_str_24 = "40";
         else if (curr_bw == 4)
            curr_bw_str_24 = "80";
         else if (curr_bw == 1)
            curr_bw_str_24 = "10";               

         if (band_24 == "2")
            $("#CurChannel_24").html("<span id='CurChannel_24'>Current: "+ wlCurrentChannel_24 + chanimstate_str +"</span>");      
         else
            $("#CurChannel_24").html("<span id='CurChannel_24'>Current: "+ wlCurrentChannel_24 +"</span>");      

         $("#CurNbw_24").html("<span id='CurNbw_24'>Current: "+ curr_bw_str_24 + "MHz</span>");      
         $("#CurNCtrlsb_24").html("<span id='CurNCtrlsb_24'>Current: "+ curr_sb_str_24 + "</span>");      
      }
   }
   else{
      if(OnPageLoad) {          
         var curr_bw = parseInt(currbw_5);
         var chanimstate_str = "";

         if (chanimstate_5 == "0")
         chanimstate_str = " (interference: acceptable)";
         else
         chanimstate_str = " (interference: severe)";

         if(curr_bw == 2)
            curr_bw_str_5 = "20";
         else if (curr_bw == 3)
            curr_bw_str_5 = "40";
         else if (curr_bw == 4)
            curr_bw_str_5 = "80";
         else if (curr_bw == 1)
            curr_bw_str_5 = "10";               

         if (band_5 == "2")
            $("#CurChannel_5").html("<span id='CurChannel_5'>Current: "+ wlCurrentChannel_5 + chanimstate_str +"</span>");      
         else
            $("#CurChannel_5").html("<span id='CurChannel_5'>Current: "+ wlCurrentChannel_5 +"</span>");      

         $("#CurNbw_5").html("<span id='CurNbw_5'>Current: "+ curr_bw_str_5 + "MHz</span>");      
         $("#CurNCtrlsb_5").html("<span id='CurNCtrlsb_5'>Current: "+ curr_sb_str_5 + "</span>");      
      }
   }
}

function genericChange(OnPageLoad, id) {
   if(OnPageLoad) { 
      if(id == 1){
         $("select[name=24GhzWl54gRate]").get(0).selectedIndex = getRateIndex(rate_24, 1);
         $("select[name=24GhzMulticastRate]").get(0).selectedIndex = getRateIndex(mcastrate_24, 1);
         $("select[name=24GhzWlBasicRate]").get(0).selectedIndex = getRateIndex(brate_24, 1);
         $("select[name=24GhzWlFrameBurst]").get(0).selectedIndex = getFrameBurstIndex(fburst_24);

         if( TXBFCapable_24 == "1" ) {
            $("select[name=24GhzBFR]").get(0).selectedIndex = enableBFR_24 - '0';
            $("select[name=24GhzBFE]").get(0).selectedIndex = enableBFE_24 - '0';
         }
         else {
            $("select[name=24GhzBFR]").prop("disabled", true);
            $("select[name=24GhzBFE]").prop("disabled", true);
         }

         $("select[name=24GhzBandSteer]").get(0).selectedIndex = (bsd_role_24 == "0"? 0:1);
         $("input[name=24GhzbsdHelper]").val(bsd_helper_24);
         $("input[name=24GhzbsdHport]").val(bsd_hport_24);
         $("input[name=24GhzbsdPrimary]").val(bsd_primary_24);
         $("input[name=24GhzbsdPport]").val(bsd_pport_24);			
         $("select[name=24GhzTrafficScheduler]").get(0).selectedIndex = wl_taf_enable_24;
         $("select[name=24GhzAirtimeFairness]").get(0).selectedIndex = wl_atf_24;
         $("select[name=24GhzWlRifsAdvert]").get(0).selectedIndex = (rifsadvert_24 == "-1" ? 1 : 0);
         $("select[name=24GhzWlObssCoex]").get(0).value = obsscoex_24;
         $("select[name=24GhzWlRxChainPwrSaveEnable]").get(0).selectedIndex = rxchain_pwrsave_enable_24;
         $("input[name=24GhzWlRxChainPwrSaveQuietTime]").val(rxchain_pwrsave_quiet_time_24);						
         $("input[name=24GhzWlRxChainPwrSavePps]").val(rxchain_pwrsave_pps_24);							
         $("input[name=24GhzWlFrgThrshld]").val(frg_24);			
         $("input[name=24GhzWlRtsThrshld]").val(rts_24);			
         $("input[name=24GhzWlDtmIntvl]").val(dtm_24);			
         $("input[name=24GhzWlBcnIntvl]").val(bcn_24);			
         $("input[name=24GhzWlGlobalMaxAssoc]").val(globalmaxassoc_24);			
         $("input[name=24GhzChannelTimer]").val(acscsscantimer_24/60);
         $("select[name=24GhzWlTxPower]").get(0).selectedIndex =	((TxPwrPcnt_24/20) -1);
         $("select[name=24GhzWlRegMode]").get(0).selectedIndex =	reg_mode_24;
         $("input[name=24GhzWlDfsPreIsm]").val(dfs_preism_24);			
         $("input[name=24GhzWlDfsPostIsm]").val(dfs_postism_24);			
         $("select[name=24GhzWlTpcDb]").get(0).selectedIndex =	tpcDb_24;

         /* preamble */
         if ( pre_24 == 'short' )
            $("select[name=24GhzWlPreambleType]").get(0).selectedIndex = 1;
         else
            $("select[name=24GhzWlPreambleType]").get(0).selectedIndex = 0;	

         $("input[name=24GhzWlPspretendThreshold]").val(wl_pspretend_threshold_24);			
         $("input[name=24GhzWlPspretendRetryLimit]").val(wl_pspretend_retry_limit_24);			
      } 
      else{
         $("select[name=5GhzWl54gRate]").get(0).selectedIndex = getRateIndex(rate_5, 1);
         $("select[name=5GhzMulticastRate]").get(0).selectedIndex = getRateIndex(mcastrate_5, 1);
         $("select[name=5GhzWlBasicRate]").get(0).selectedIndex = getRateIndex(brate_5, 1);
         $("select[name=5GhzWlFrameBurst]").get(0).selectedIndex = getFrameBurstIndex(fburst_5);

         if( TXBFCapable_5 == "1" ) {
            $("select[name=5GhzBFR]").get(0).selectedIndex = enableBFR_5 - '0';
            $("select[name=5GhzBFE]").get(0).selectedIndex = enableBFE_5 - '0';
         }
         else {
            $("select[name=5GhzBFR]").prop("disabled", true);
            $("select[name=5GhzBFE]").prop("disabled", true);
         }

         $("select[name=5GhzBandSteer]").get(0).selectedIndex = (bsd_role_5 == "0"? 0:1);
         $("input[name=5GhzbsdHelper]").val(bsd_helper_5);
         $("input[name=5GhzbsdHport]").val(bsd_hport_5);
         $("input[name=5GhzbsdPrimary]").val(bsd_primary_5);
         $("input[name=5GhzbsdPport]").val(bsd_pport_5);			
         $("select[name=5GhzTrafficScheduler]").get(0).selectedIndex = wl_taf_enable_5;
         $("select[name=5GhzAirtimeFairness]").get(0).selectedIndex = wl_atf_5;
         $("select[name=5GhzWlRifsAdvert]").get(0).selectedIndex = (rifsadvert_5 == "-1" ? 1 : 0);
         $("select[name=5GhzWlObssCoex]").get(0).value = obsscoex_5;
         $("select[name=5GhzWlRxChainPwrSaveEnable]").get(0).selectedIndex = rxchain_pwrsave_enable_5;
         $("input[name=5GhzWlRxChainPwrSaveQuietTime]").val(rxchain_pwrsave_quiet_time_5);						
         $("input[name=5GhzWlRxChainPwrSavePps]").val(rxchain_pwrsave_pps_5);							
         $("input[name=5GhzWlFrgThrshld]").val(frg_5);			
         $("input[name=5GhzWlRtsThrshld]").val(rts_5);			
         $("input[name=5GhzWlDtmIntvl]").val(dtm_5);			
         $("input[name=5GhzWlBcnIntvl]").val(bcn_5);			
         $("input[name=5GhzWlGlobalMaxAssoc]").val(globalmaxassoc_5);			
         $("input[name=5GhzChannelTimer]").val(acscsscantimer_5/60);
         $("select[name=5GhzWlTxPower]").get(0).selectedIndex =	((TxPwrPcnt_5/20) -1);
         $("select[name=5GhzWlRegMode]").get(0).selectedIndex =	reg_mode_5;
         $("input[name=5GhzWlDfsPreIsm]").val(dfs_preism_5);			
         $("input[name=5GhzWlDfsPostIsm]").val(dfs_postism_5);			
         $("select[name=5GhzWlTpcDb]").get(0).selectedIndex =	tpcDb_5;

         /* preamble */
         if ( pre_5 == 'short' )
            $("select[name=5GhzWlPreambleType]").get(0).selectedIndex = 1;
         else
            $("select[name=5GhzWlPreambleType]").get(0).selectedIndex = 0;	

         $("input[name=5GhzWlPspretendThreshold]").val(wl_pspretend_threshold_5);			
         $("input[name=5GhzWlPspretendRetryLimit]").val(wl_pspretend_retry_limit_5);			
      }
   }
}
function phyChange(OnPageLoad, id) {
   if(id == 1){
      if (phy_24 == "n" || phy_24 == "v") {
         $("#div_nMode_24").show();
         $("#div_nMode_sel_24").show();
         $("#div_gMode_24").hide();		
      } else {
         $("#div_nMode_24").hide();
         $("#div_nMode_sel_24").hide();
         $("#div_gMode_24").show();	
      }         
   }
   else{
      if (phy_5 == "n" || phy_5 == "v") {
         $("#div_nMode_5").show();
         $("#div_nMode_sel_5").show();
         $("#div_gMode_5").hide();		
      } else {
         $("#div_nMode_5").hide();
         $("#div_nMode_sel_5").hide();
         $("#div_gMode_5").show();	
      }         
   }
}

function getFrameBurstIndex(frameburst) {
   var ret;

   if ( frameburst == "off" )
      ret = 0;
   else
      ret = 1;
   return ret;
}
function getRateIndex(r, id) {
   var rateNum = parseInt(r);
   var ret = 0;
   var band;
   var phy;
   if(id ==1){
      band = band_24;
      phy = phy_24;
   }
   else {
      band = band_5;
      phy = phy_5;
   }	

   if ( band == '2') {
      if ( phy == "b" ) { //11b
         switch ( rateNum ) {
            case 1000000:
               ret = 1;
               break;
            case 2000000:
               ret = 2;
               break;
            case 5500000:
               ret = 3;
               break;
            case 11000000:
               ret = 4;
               break;
            default:
               ret = 0;
               break;
         }
      }
      // physical type is 802.11g
      else {
         switch ( rateNum ) {
            case 1000000:
               ret = 1;
               break;
            case 2000000:
               ret = 2;
               break;
            case 5500000:
               ret = 3;
               break;
            case 6000000:
               ret = 4;
               break;
            case 9000000:
               ret = 5;
               break;
            case 11000000:
               ret = 6;
               break;
            case 12000000:
               ret = 7;
               break;
            case 18000000:
               ret = 8;
               break;
            case 24000000:
               ret = 9;
               break;
            case 36000000:
               ret = 10;
               break;
            case 48000000:
               ret = 11;
               break;
            case 54000000:
               ret = 12;
               break;
            default:
               ret = 0;
               break;
         }
      }
   }
   // physical type is 802.11a
   else if ( band == '1' ) { // 11a
      switch ( rateNum ) {
         case 6000000:
            ret = 1;
            break;
         case 9000000:
            ret = 2;
            break;
         case 12000000:
            ret = 3;
            break;
         case 18000000:
            ret = 4;
            break;
         case 24000000:
            ret = 5;
            break;
         case 36000000:
            ret = 6;
            break;
         case 48000000:
            ret = 7;
            break;
         case 54000000:
            ret = 8;
            break;
         default:
            ret = 0;
            break;
      }
   }
   return ret;
}

function getTpcDbIndex(val) {
   var ret;

   if ( val == "0" )
      ret = 0;
   else if ( val == "2" )
      ret = 1;
   else if ( val == "3" )
      ret = 2;
   else if ( val == "4" )
      ret = 3;
   else ret = 0;
      return ret;
}

function bsd_role_change(id){	
   if($("select[name="+id+"GhzBandSteer]").val() != '1' && $("select[name="+id+"GhzBandSteer]").val() != '2'){
      $("select[name="+id+"GhzbsdPrimary]").prop("disabled", true);
      $("select[name="+id+"GhzbsdPport]").prop("disabled", true);
      $("select[name="+id+"GhzbsdHelper]").prop("disabled", true);
      $("select[name="+id+"GhzbsdHport]").prop("disabled", true);	  		
   }
   else{
      $("select[name="+id+"GhzbsdPrimary]").prop("disabled", false);
      $("select[name="+id+"GhzbsdPport]").prop("disabled", false);
      $("select[name="+id+"GhzbsdHelper]").prop("disabled", false);
      $("select[name="+id+"GhzbsdHport]").prop("disabled", false);	  				
   }
}
function onNmodeChange(OnPageLoad, id)
{   
   wl_recalc(OnPageLoad, id);
   if(id == 1)
      $("select[name=24GhzWl54gRate]").get(0).selectedIndex = 0;
   else
      $("select[name=5GhzWl54gRate]").get(0).selectedIndex = 0;
}

function initWlNmode(OnPageLoad, id){
   if(OnPageLoad == false)
      return;
      
   if(id == 1){
      if (wpa_24 == "tkip")
      {
         $("select[name=24GhzWlNmode]").empty();
         $("select[name=24GhzWlNmode]").append("<option value='off'>Disabled</option>");
      }
      else
      {
         $("select[name=24GhzWlNmode]").empty();
         $("select[name=24GhzWlNmode]").append("<option value='auto'>Auto</option>");
         $("select[name=24GhzWlNmode]").append("<option value='off'>Disabled</option>");
      }	
   }
   else{
      if (wpa_5 == "tkip")
      {
         $("select[name=5GhzWlNmode]").empty();
         $("select[name=5GhzWlNmode]").append("<option value='off'>Disabled</option>");
      }
      else
      {
         $("select[name=5GhzWlNmode]").empty();
         $("select[name=5GhzWlNmode]").append("<option value='auto'>Auto</option>");
         $("select[name=5GhzWlNmode]").append("<option value='off'>Disabled</option>");
      }	
   }
}
function apply24(){
   var loc = 'nc_wlCfg_adv_24.ncwl?';
   var idx, frgNum, rtsNum, dtmNum, bcnNum, frmburstNum, globalMaxAssocNum;

   if ( enbl_24 == '0' ) {
      alert('Cannot apply the change since wireless is currently disabled.');
      return;
   }

   wl_recalc(false, 0); 

   var sel_nmode = $("select[name=24GhzWlNmode]").val();
   var sel_nmcsidx = $("select[name=24GhzWlNMmcsidx]").val();

   frgNum = parseInt($("input[name=24GhzWlFrgThrshld]").val());
   if ( isNaN(frgNum) == true || frgNum < 256 || frgNum > 2346 ) {
      alert("Fragmentation threshold &quot;" + $("input[name=24GhzWlFrgThrshld]").val() + "&quot; should be between 256 and 2346.");
      return;
   }

   rtsNum = parseInt($("input[name=24GhzWlRtsThrshld]").val());
   if ( isNaN(rtsNum) == true || rtsNum < 0 || rtsNum > 2347 ) {
      alert("RTS threshold &quot;" + $("input[name=24GhzWlRtsThrshld]").val() + "&quot; should be between 0 and 2347.");
      return;
   }

   dtmNum = parseInt($("input[name=24GhzWlDtmIntvl]").val());
   if ( isNaN(dtmNum) == true || dtmNum < 1 || dtmNum > 255 ) {
      alert("DTIM interval &quot;" + $("input[name=24GhzWlDtmIntvl]").val() + "&quot; should be between 1 and 255.");
      return;
   }

   bcnNum = parseInt($("input[name=24GhzWlBcnIntvl]").val());
   if ( isNaN(bcnNum) == true || bcnNum < 1 || bcnNum > 65535 ) {
      alert("Beacon interval &quot;" + $("input[name=24GhzWlBcnIntvl]").val() + "&quot; should be between 1 and 65535.");
      return;
   }

   globalMaxAssocNum = parseInt($("input[name=24GhzWlGlobalMaxAssoc]").val());
   if ( isNaN(globalMaxAssocNum) == true || globalMaxAssocNum < 1 || globalMaxAssocNum > 129 ) {
      alert("Global Max Clients: &quot;" + $("input[name=24GhzWlGlobalMaxAssoc]").val() + "&quot; should be between 1 and 128.");
      return;
   }
   
   loc += 'wlCountry=' + $("select[name=wl1Country]").val();
   loc += '&wlRegRev=' + encodeUrl($("input[name=wl1RegRev]").val());
   loc += '&wlChannel=' + $("select[name=24GHzMainNTChannel]").val();
   loc += '&wlNmode=' + sel_nmode;
   loc += '&wlNReqd=' + $("select[name=24GhzWlNReqd]").val();      
   loc += '&wlBasicRate=' + $("select[name=24GhzWlBasicRate]").val();
   loc += '&wlFrgThrshld=' + $("input[name=24GhzWlFrgThrshld]").val();
   loc += '&wlRtsThrshld=' + $("input[name=24GhzWlRtsThrshld]").val();
   loc += '&wlDtmIntvl=' + $("input[name=24GhzWlDtmIntvl]").val();
   loc += '&wlBcnIntvl=' + $("input[name=24GhzWlBcnIntvl]").val();
   loc += '&wlGlobalMaxAssoc=' + $("input[name=24GhzWlGlobalMaxAssoc]").val();      
   loc += '&wlFrameBurst=' + $("select[name=24GhzWlFrameBurst]").val();
   loc += '&wlRifsAdvert=' + $("select[name=24GhzWlRifsAdvert]").val();
   loc += '&wlObssCoex=' + $("select[name=24GhzWlObssCoex]").val();
   loc += '&wlRxChainPwrSaveEnable=' + $("select[name=24GhzWlRxChainPwrSaveEnable]").val();
   loc += '&wlRxChainPwrSaveQuietTime=' +  $("input[name=24GhzWlRxChainPwrSaveQuietTime]").val();
   loc += '&wlRxChainPwrSavePps=' + $("input[name=24GhzWlRxChainPwrSavePps]").val();
   loc += '&wlBand=' + band_24;
   loc += '&wlMCastRate=' + $("select[name=24GhzMulticastRate]").val();
   if (hasafterburner_24 == '1') {
      loc += '&wlAfterBurnerEn=' + $("select[name=24GhzWlAfterBurnerEn]").val();
   }
   else {
      loc += '&wlAfterBurnerEn=off';
   }

   /* rate */
   if ( (phy_24 != "n" && phy_24 != "v") || ((phy_24 == "n" || phy_24 == "v") && (sel_nmode == "off" || sel_nmcsidx == -2)))
      loc += '&wlRate=' + $("select[name=24GhzWl54gRate]").val();

   /* b/g mode */
   if ( band_24 == '2') { // 2.4G
      if (phy_24 == "b") { // 802.11b
         loc += '&wlPreambleType=' + $("select[name=24GhzWlPreambleType]").val();
      } else if (((phy_24 == "n" || phy_24 == "v") && sel_nmode == "off") || phy_24 == "g" || phy_24 == "a") { // 802.11g
         loc += '&wlgMode=' + $("select[name=24GhzWlgMode]").val();
         loc += '&wlProtection=' + $("select[name=24GhzWlProtection]").val();
         if ($("select[name=24GhzWlgMode]").selectedIndex == 0 || $("select[name=24GhzWlgMode]").selectedIndex == 3) {
            loc += '&wlPreambleType=' + $("select[name=24GhzWlPreambleType]").val();
         }
      }         
   }

   loc += '&wlTxPwrPcnt=' + $("select[name=24GhzWlTxPower]").val();
   loc += '&wlRegMode=' + $("select[name=24GhzWlRegMode]").val();

   if((phy_24 == "n") || (phy_24 == "v")) {
      loc += '&wlNBwCap=' + $("select[name=24GHzMainNTChannelBandWidth]").val();

      if ($("select[name=24GHzMainNTChannelBandWidth]").val() != "7") {

         if((band_24.value=="1" && $("select[name=24GHzMainNTChannelBandWidth]").val() == "0") ||
            (band_24.value=="2" && ($("select[name=24GHzMainNTChannelBandWidth]").val() == "1")))
            loc += '&wlNCtrlsb=' + 0;
         else   
            loc += '&wlNCtrlsb=' + $("select[name=24GhzWlNCtrlsb]").val();
      }   
      loc += '&wlNProtection=' + $("select[name=24GhzWlNProtection]").val();
      loc += '&wlNMcsidx=' +$("select[name=24GhzWlNMmcsidx]").val();
   }

   if($("select[name=24GhzWlRegMode]").selectedIndex == 1) {
      DfsPreIsmNum = parseInt($("input[name=24GhzWlDfsPreIsm]").val());
      if ( isNaN(DfsPreIsmNum) == true || DfsPreIsmNum < -1 || DfsPreIsmNum > 99 ) {
         alert("Pre-Network Radar Check &quot;" + $("input[name=24GhzWlDfsPreIsm]").val() + "&quot; should be between 0 and 99.");
         return;
      }

      DfsPostNum = parseInt($("input[name=24GhzWlDfsPostIsm]").val());
      if ( isNaN(DfsPostNum) == true || DfsPostNum < -1 || DfsPostNum > 99 ) {
         alert("In-Network Radar Check: &quot;" + $("input[name=24GhzWlDfsPostIsm]").val() + "&quot; should be between 10 and 99.");
         return;
      } 

      loc += '&wlDfsPreIsm=' + $("input[name=24GhzWlDfsPreIsm]").val();
      loc += '&wlDfsPostIsm=' + $("input[name=24GhzWlDfsPostIsm]").val();       
      loc += '&wlTpcDb=' + $("select[name=24GhzWlTpcDb]");
   }    


   loc += '&wlWme=' + parseInt($("select[name=24GhzWlWme]").val());
   loc += '&wlWmeNoAck=' + parseInt($("select[name=24GhzWlWmeNoAck]").val());
   loc += '&wlWmeApsd=' + parseInt($("select[name=24GhzWlWmeApsd]").val());      

   if (hasvec_24 == '1') {
      loc += '&wlVec=' + parseInt($("select[name=24GhzWlVec]").val());
      loc += '&wlIperf=' + parseInt($("select[name=24GhzWlIperf]").val());
   }



   if ( TXBFCapable_24 == "1" ) {
      loc += '&wlEnableBFR=' + $("select[name=24GhzBFR]").val();
      loc += '&wlEnableBFE=' + $("select[name=24GhzBFE]").val();
   }
   var acscstimerinsecond=parseInt($("input[name=24GhzChannelTimer]").val())*60;

   loc += '&bsdRole=' + $("select[name=24GhzBandSteer]").val();
   loc += '&bsdHelper=' + $("input[name=24GhzbsdHelper]").val(); 
   loc += '&bsdHport=' + $("input[name=24GhzbsdHport]").val(); 
   loc += '&bsdPrimary=' + $("input[name=24GhzbsdPrimary]").val();  
   loc += '&bsdPport=' + $("input[name=24GhzbsdPport]").val(); 
   loc += '&wlTafEnable=' +  $("select[name=24GhzTrafficScheduler]").val();
   loc += '&wlAtf=' + $("select[name=24GhzAirtimeFairness]").val();
   loc += '&wlPspretendThreshold=' + $("input[name=24GhzWlPspretendThreshold]").val();
   loc += '&wlPspretendRetryLimit=' + $("input[name=24GhzWlPspretendRetryLimit]").val();
   loc += '&wlSyncNvram=1';
   var code = 'location="' + loc + '"';
   eval(code);
}

function apply5(){
   var loc = 'nc_wlCfg_adv_5.ncwl?';
   var idx, frgNum, rtsNum, dtmNum, bcnNum, frmburstNum, globalMaxAssocNum;

   if ( enbl_5 == '0' ) {
      alert('Cannot apply the change since wireless is currently disabled.');
      return;
   }

   wl_recalc(false, 0); 

   var sel_nmode = $("select[name=5GhzWlNmode]").val();
   var sel_nmcsidx = $("select[name=5GhzWlNMmcsidx]").val();

   frgNum = parseInt($("input[name=5GhzWlFrgThrshld]").val());
   if ( isNaN(frgNum) == true || frgNum < 256 || frgNum > 2346 ) {
      alert("Fragmentation threshold &quot;" + $("input[name=5GhzWlFrgThrshld]").val() + "&quot; should be between 256 and 2346.");
      return;
   }

   rtsNum = parseInt($("input[name=5GhzWlRtsThrshld]").val());
   if ( isNaN(rtsNum) == true || rtsNum < 0 || rtsNum > 2347 ) {
      alert("RTS threshold &quot;" + $("input[name=5GhzWlRtsThrshld]").val() + "&quot; should be between 0 and 2347.");
      return;
   }

   dtmNum = parseInt($("input[name=5GhzWlDtmIntvl]").val());
   if ( isNaN(dtmNum) == true || dtmNum < 1 || dtmNum > 255 ) {
      alert("DTIM interval &quot;" + $("input[name=5GhzWlDtmIntvl]").val() + "&quot; should be between 1 and 255.");
      return;
   }

   bcnNum = parseInt($("input[name=5GhzWlBcnIntvl]").val());
   if ( isNaN(bcnNum) == true || bcnNum < 1 || bcnNum > 65535 ) {
      alert("Beacon interval &quot;" + $("input[name=5GhzWlBcnIntvl]").val() + "&quot; should be between 1 and 65535.");
      return;
   }

   globalMaxAssocNum = parseInt($("input[name=5GhzWlGlobalMaxAssoc]").val());
   if ( isNaN(globalMaxAssocNum) == true || globalMaxAssocNum < 1 || globalMaxAssocNum > 129 ) {
      alert("Global Max Clients: &quot;" + $("input[name=5GhzWlGlobalMaxAssoc]").val() + "&quot; should be between 1 and 128.");
      return;
   }
   
   loc += 'wlCountry=' + $("select[name=wl0Country]").val();
   loc += '&wlRegRev=' + encodeUrl($("input[name=wl0RegRev]").val());
   loc += '&wlChannel=' + $("select[name=5GHzMainNTChannel]").val();
   loc += '&wlNmode=' + sel_nmode;
   loc += '&wlNReqd=' + $("select[name=5GhzWlNReqd]").val();      
   loc += '&wlBasicRate=' + $("select[name=5GhzWlBasicRate]").val();
   loc += '&wlFrgThrshld=' + $("input[name=5GhzWlFrgThrshld]").val();
   loc += '&wlRtsThrshld=' + $("input[name=5GhzWlRtsThrshld]").val();
   loc += '&wlDtmIntvl=' + $("input[name=5GhzWlDtmIntvl]").val();
   loc += '&wlBcnIntvl=' + $("input[name=5GhzWlBcnIntvl]").val();
   loc += '&wlGlobalMaxAssoc=' + $("input[name=5GhzWlGlobalMaxAssoc]").val();      
   loc += '&wlFrameBurst=' + $("select[name=5GhzWlFrameBurst]").val();
   loc += '&wlRifsAdvert=' + $("select[name=5GhzWlRifsAdvert]").val();
   loc += '&wlObssCoex=' + $("select[name=5GhzWlObssCoex]").val();
   loc += '&wlRxChainPwrSaveEnable=' + $("select[name=5GhzWlRxChainPwrSaveEnable]").val();
   loc += '&wlRxChainPwrSaveQuietTime=' +  $("input[name=5GhzWlRxChainPwrSaveQuietTime]").val();
   loc += '&wlRxChainPwrSavePps=' + $("input[name=5GhzWlRxChainPwrSavePps]").val();
   loc += '&wlBand=' + band_5;
   loc += '&wlMCastRate=' + $("select[name=5GhzMulticastRate]").val();
   if (hasafterburner_5 == '1') {
      loc += '&wlAfterBurnerEn=' + $("select[name=5GhzWlAfterBurnerEn]").val();
   }
   else {
      loc += '&wlAfterBurnerEn=off';
   }

   /* rate */
   if ( (phy_5 != "n" && phy_5 != "v") || ((phy_5 == "n" || phy_5 == "v") && (sel_nmode == "off" || sel_nmcsidx == -2)))
      loc += '&wlRate=' + $("select[name=5GhzWl54gRate]").val();

   /* b/g mode */
   if ( band_5 == '2') { // 2.4G
      if (phy_5 == "b") { // 802.11b
         loc += '&wlPreambleType=' + $("select[name=5GhzWlPreambleType]").val();
      } else if (((phy_5 == "n" || phy_5 == "v") && sel_nmode == "off") || phy_5 == "g" || phy_5 == "a") { // 802.11g
         loc += '&wlgMode=' + $("select[name=5GhzWlgMode]").val();
         loc += '&wlProtection=' + $("select[name=5GhzWlProtection]").val();
         if ($("select[name=5GhzWlgMode]").selectedIndex == 0 || $("select[name=5GhzWlgMode]").selectedIndex == 3) {
            loc += '&wlPreambleType=' + $("select[name=5GhzWlPreambleType]").val();
         }
      }         
   }

   loc += '&wlTxPwrPcnt=' + $("select[name=5GhzWlTxPower]").val();
   loc += '&wlRegMode=' + $("select[name=5GhzWlRegMode]").val();

   if((phy_5 == "n") || (phy_5 == "v")) {
      loc += '&wlNBwCap=' + $("select[name=5GHzMainNTChannelBandWidth]").val();

      if ($("select[name=5GHzMainNTChannelBandWidth]").val() != "7") {

         if((band_5.value=="1" && $("select[name=5GHzMainNTChannelBandWidth]").val() == "0") ||
            (band_5.value=="2" && ($("select[name=5GHzMainNTChannelBandWidth]").val() == "1")))
            loc += '&wlNCtrlsb=' + 0;
         else   
            loc += '&wlNCtrlsb=' + $("select[name=5GhzWlNCtrlsb]").val();
      }   
      loc += '&wlNProtection=' + $("select[name=5GhzWlNProtection]").val();
      loc += '&wlNMcsidx=' +$("select[name=5GhzWlNMmcsidx]").val();
   }

   if($("select[name=5GhzWlRegMode]").selectedIndex == 1) {
      DfsPreIsmNum = parseInt($("input[name=5GhzWlDfsPreIsm]").val());
      if ( isNaN(DfsPreIsmNum) == true || DfsPreIsmNum < -1 || DfsPreIsmNum > 99 ) {
         alert("Pre-Network Radar Check &quot;" + $("input[name=5GhzWlDfsPreIsm]").val() + "&quot; should be between 0 and 99.");
         return;
      }

      DfsPostNum = parseInt($("input[name=5GhzWlDfsPostIsm]").val());
      if ( isNaN(DfsPostNum) == true || DfsPostNum < -1 || DfsPostNum > 99 ) {
         alert("In-Network Radar Check: &quot;" + $("input[name=5GhzWlDfsPostIsm]").val() + "&quot; should be between 10 and 99.");
         return;
      } 

      loc += '&wlDfsPreIsm=' + $("input[name=5GhzWlDfsPreIsm]").val();
      loc += '&wlDfsPostIsm=' + $("input[name=5GhzWlDfsPostIsm]").val();       
      loc += '&wlTpcDb=' + $("select[name=5GhzWlTpcDb]");
   }    


   loc += '&wlWme=' + parseInt($("select[name=5GhzWlWme]").val());
   loc += '&wlWmeNoAck=' + parseInt($("select[name=5GhzWlWmeNoAck]").val());
   loc += '&wlWmeApsd=' + parseInt($("select[name=5GhzWlWmeApsd]").val());      

   if (hasvec_5 == '1') {
      loc += '&wlVec=' + parseInt($("select[name=5GhzWlVec]").val());
      loc += '&wlIperf=' + parseInt($("select[name=5GhzWlIperf]").val());
   }



   if ( TXBFCapable_5 == "1" ) {
      loc += '&wlEnableBFR=' + $("select[name=5GhzBFR]").val();
      loc += '&wlEnableBFE=' + $("select[name=5GhzBFE]").val();
   }
   var acscstimerinsecond=parseInt($("input[name=5GhzChannelTimer]").val())*60;

   loc += '&bsdRole=' + $("select[name=5GhzBandSteer]").val();
   loc += '&bsdHelper=' + $("input[name=5GhzbsdHelper]").val(); 
   loc += '&bsdHport=' + $("input[name=5GhzbsdHport]").val(); 
   loc += '&bsdPrimary=' + $("input[name=5GhzbsdPrimary]").val();  
   loc += '&bsdPport=' + $("input[name=5GhzbsdPport]").val(); 
   loc += '&wlTafEnable=' +  $("select[name=5GhzTrafficScheduler]").val();
   loc += '&wlAtf=' + $("select[name=5GhzAirtimeFairness]").val();
   loc += '&wlPspretendThreshold=' + $("input[name=5GhzWlPspretendThreshold]").val();
   loc += '&wlPspretendRetryLimit=' + $("input[name=5GhzWlPspretendRetryLimit]").val();
   loc += '&wlSyncNvram=1';
   var code = 'location="' + loc + '"';

   eval(code);
}
