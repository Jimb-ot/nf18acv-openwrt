/*! speedtest - v0.0.0
 *  Release on: 2015-10-15
 *  Copyright (c) 2015 Hubert Pietrusiak
 *  Licensed Private */
(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module unless amdModuleId is set
    define([], function () {
      return (root['SpeedTest'] = factory());
    });
  } else if (typeof exports === 'object') {
    // Node. Does not work with strict CommonJS, but
    // only CommonJS-like environments that support module.exports,
    // like Node.
    module.exports = factory();
  } else {
    root['SpeedTest'] = factory();
  }
}(this, function (root) {

'use strict';

function getRequest() {
  return new getJsonp();
}

function getJsonp(url, callback) {
  var counter = 0, head, config = {}, self = this;

  function load(url, pfnError) {
    var script = document.createElement('script'),
      done = false;

    script.src = url;
    script.async = true;

    var errorHandler = pfnError || config.error;
    if (typeof errorHandler === 'function') {
      script.onerror = function (ex) {
        errorHandler({url: url, event: ex});
      };
    }

    script.onload = script.onreadystatechange = function () {
      if (!done && (!this.readyState || this.readyState === "loaded" || this.readyState === "complete")) {
        done = true;
        script.onload = script.onreadystatechange = null;
        if (script && script.parentNode) {
          script.parentNode.removeChild(script);
        }
      }
    };

    if (!head) {
      head = document.getElementsByTagName('head')[0];
    }
    head.appendChild(script);
  }

  function jsonp(url, params, callback, callbackName) {
    var query = (url||'').indexOf('?') === -1 ? '?' : '&', key;

    callbackName = (callbackName||config['callbackName']||'callback');
    var uniqueName = callbackName + "_json" + (Math.abs(~~(Math.random()*10000000000)));

    params = params || {};
    for ( key in params ) {
      if ( params.hasOwnProperty(key) ) {
        query += encode(key) + "=" + encode(params[key]) + "&";
      }
    }

    window[ uniqueName ] = function(data){
      callback(data);
      try {
        delete window[ uniqueName ];
      } catch (e) {}
      window[ uniqueName ] = null;
    };

    load(url + query + callbackName + '=' + uniqueName, null, uniqueName);
    return uniqueName;
  }

  function encode(str) {
    return encodeURIComponent(str);
  }

  jsonp(url, {}, function(data){
    callback(data);
  });
}

function setDefault(obj, key, value) {
  obj[key] = obj[key] || value
}

String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};

function isFlashSupported() {
  var hasFlash = false;
  try {
    var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
    if (fo) {
      hasFlash = true;
    }
  } catch (e) {
    if (navigator.mimeTypes
      && navigator.mimeTypes['application/x-shockwave-flash'] != undefined
      && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
      hasFlash = true;
    }
  }

  return hasFlash;
}

function isPepperFlash() {
  var isPPAPI = false;
  var type = 'application/x-shockwave-flash';
  var mimeTypes = navigator.mimeTypes;

  function endsWith(str, suffix) {
    return str.indexOf(suffix, str.length - suffix.length) !== -1;
  }

  if (mimeTypes && mimeTypes[type] && mimeTypes[type].enabledPlugin &&
    (mimeTypes[type].enabledPlugin.filename.toLowerCase() == "pepflashplayer.dll" ||
    mimeTypes[type].enabledPlugin.filename.toLowerCase() == "libpepflashplayer.so" ||
    mimeTypes[type].enabledPlugin.filename.toLowerCase() == "pepperflashplayer.plugin")) {
    isPPAPI = true;
  }

  return isPPAPI;
}

var createSwfObject = function(src, attributes, parameters, success, error) {
  var i, html, div, obj, attr = attributes || {}, param = parameters || {};
  attr.type = 'application/x-shockwave-flash';
  if (window.ActiveXObject) {
    attr.classid = 'clsid:d27cdb6e-ae6d-11cf-96b8-444553540000';
    param.movie = src;
  }
  else {
    attr.data = src;
  }
  html = '<object';
  for (i in attr) {
    html += ' ' + i + '="' + attr[i] + '"';
  }
  html += '>';
  for (i in param) {
    html += '<param name="' + i + '" value="' + param[i] + '" />';
  }
  html += '</object>';
  div = document.createElement('div');
  div.style.position = 'absolute';
  div.style.opacity = 0;
  div.id = "FlashContainer";
  div.innerHTML = html;
  document.body.appendChild(div);

  var flash = document.getElementById(attributes.id || 'SpeedTestFlash');
  var interval = setInterval(function(){
    if(flash.setTestServerAddress) {
      success();
      clearInterval(interval);
      clearTimeout(timeout);
    }
  }, 250);
  var timeout = setTimeout(function(){
    if(interval) {
      clearInterval(interval);
      error();
    }
  }, 5000);
  return document.getElementById(attributes.id || 'SpeedTestFlash');
};

var SpeedTest = function (options) {
  var self = this,
    test = null,
    flashStarted = false,
    flashError = false,
    interval = null,
    retryCount = 0;

  function getJsonP (url, hook, callback) {
    getJsonp(url, function(data) {
      if(hook && hook !== '') {
        self[hook](data);
      }
      if(callback && typeof callback === 'function') {
        callback(data);
      }
    })
  }

  var endpoints = {
    getip: 'getip',
    start: 'start?origin=webui',
    status: 'status',
    stop: 'stop'
  };

  options = options || {};

  this.type = options.type || 'get';
  this.url = options.url || 'http://internetbox-nas.home:57337/test/';
  this.timeout = options.timeout || 30000;
  this.dataType = options.dataType || 'jsonp';
  this.flashUrl = options.flashUrl || 'internetbox-nas.home:7000';
  this.swfUrl = options.swfUrl || "SpeedTest.swf";

  this.onAll = function() {};

  this.onStarting = function() {};
  this.onStarted = function() {};
  this.onError = function() {};
  this.onStopped = function() {};
  this.onDone = function() {};

  this.onWanStarting = function() {};
  this.onWanStarted = function() {};
  this.onWanProgress = function() {};
  this.onWanError = function() {};
  this.onWanStopped = function() {};
  this.onWanDone = function() {};

  this.onLanStarting = function() {};
  this.onLanStarted = function() {};
  this.onLanProgress = function() {};
  this.onLanError = function() {};
  this.onLanStopped = function() {};
  this.onLanDone = function() {};

  this.onDownloadStarted = function() {};
  this.onDownloadDone = function() {};
  this.onDownloadProgress = function() {};

  this.onUploadStarted = function() {};
  this.onUploadDone = function() {};
  this.onUploadProgress = function() {};

  this.onGotIp = function() {};
  this.onProgress = function() {};
  this.onPing = function() {};
  this.onPretestDone = function() {};

  this.onFlashLoaded = function() {};
  this.onFlashError = function() {};

  function processEvents(data) {
    console.log(data);
    if(data.event === 'IDLE') {
      return;
    }

    if(data.event.indexOf('PING') > -1) {
      self.onPing(data);
    }

    if(data.event.indexOf('PROGRESS') > -1) {
      if(data.event.indexOf('PRETEST') > -1) {
        self.onPretestDone(data);
      }
      else {
        self['on' + (self.test.capitalize()+'Progress')](data);
        self['on' + (data.event.indexOf('UPLOAD') > -1 ? 'Upload' : 'Download') + 'Progress'](data);
        if(self.test === 'lan' && interval && data.current_value && data.current_value !== 0) {
          clearTimeout(interval);
        }
      }
    }
    else if(data.event.indexOf('DONE') > -1) {
      if(data.event.indexOf('PRETEST') < 0) {
        self['on' + (data.event.indexOf('UPLOAD') > -1 ? 'Upload' : 'Download') + 'Done'](data);
      }
      if(data.event.indexOf('UPLOAD') > -1) {
        self['on' + (self.test.capitalize()+'Done')](data);
        console.log(self.test === 'lan', !self.opts.lan);
        if(self.test === 'lan' || !self.opts.lan) {
          self['onDone'](data);
        } else {
          self.startLan();
        }
      }
    }
  }

  function getProgress() {
    getJsonP(self.url + endpoints.status, 'onProgress', function(data){
      processEvents(data);
      if(data.event.indexOf('IDLE') === -1) {
        getProgress();
      }
    })
  }

  for(var i in this) {
    if(this.hasOwnProperty(i) && i.indexOf('on') === 0) {
      this[i] = (function(i) {
        return function(data) {
          console.log(i, data)
        }
      })(i);
    }
  }

  this.getIp = function(callback) {
    getJsonP(self.url + endpoints.getip, 'onGotIp', callback);
  };

  this.startWan = function() {
    self.onWanStarting({time: new Date()});

    getJsonP(self.url + endpoints.start,'', function(data){
      if(data.status !== 'SUCCESS') {
        self.onWanError(data);
      } else {
        self.onStarted(data);
        self.onWanStarted();
        self.test = 'wan';
        getProgress();
      }
    });
  };

  this.startLan = function() {
    self.onLanStarting({time: new Date()});
    console.log(this.flashError);
    if(!this.flashError) {
      setTimeout(function(){
        console.log(self.flash.startTest);
        console.log(self.sessionId);
        self.flash.startTest(self.sessionId);
        self.test = "lan";
        self.onLanStarted();
        interval = setTimeout(function(){
          self.flash.stopTest();
          removeFlash();
          self.flash = embedFlash();
          setTimeout(function(){
            if(retryCount < 5) {
              retryCount++;
              self.onError({event: "TEST_RETRY", test_type: "LAN", count: retryCount});
              self.onLanError({event: "TEST_RETRY", test_type: "LAN", count: retryCount});
              self.startLan();
            } else {
              self.onStopped({event: "TEST_STOPPED", test_type: "LAN", reason: "NO_DATA"});
              self.onLanStopped({event: "TEST_STOPPED", test_type: "LAN", reason: "NO_DATA"});
              retryCount = 0;
            }
          }, 1000);
        }, 1000);
      }, 1000);
    }
  };

  this.start = function(opts) {
    opts = opts || {wan: true, lan: true};
    self.opts = opts; //TODO
    self.onStarting({time: new Date()});

    self.sessionId = opts.sessionId || null;

    if(opts.wan) {
      self.startWan(function(){
        if(opts.lan) {
          self.startLan();
        }
      });
    } else {
      self.startLan();
    }
  };

  this.stop = function() {
    self.onStopping({time: new Date()});
    getJsonP(self.url + endpoints.stop, 'onStopped');
  };

  window.flashCallback = function(data) {
    data = JSON.parse(data);
    self.onProgress(data);
    processEvents(data);
  };

  function embedFlash() {
    return createSwfObject(self.swfUrl,
      {id: 'SpeedTestFlash', width: 1, height: 1, style: "visibility: hidden"},
      {},
      function() {
        self.onFlashLoaded();
        self.flash.setCallback(['flashCallback']);
        self.flash.setTestServerAddress(self.flashUrl);
      },
      function() {
        self.flashError = true;
        self.onFlashError();
      }
    );
  }

  function removeFlash() {
    document.body.removeChild(document.getElementById('FlashContainer'));
  }

  var flash = embedFlash();

  this.flash = flash;

};

return SpeedTest;

}));
