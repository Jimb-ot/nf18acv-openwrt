
function BridgeRestrictChange(id) {
   if(id == 1){
      var restrict = $("select[name=24GhzBridgeRestrict]").val();
      switch ( restrict ) {
         case '0':
            $(".24GhzStaticWds").show();
            $(".24GhzDynamicWds").hide();         
            break;
         case '1':
            $(".24GhzStaticWds").hide();
            $(".24GhzDynamicWds").hide();         
            break;
         case '2':
            $(".24GhzDynamicWds").show(); 
            $(".24GhzStaticWds").hide(); 
            refreshClick(id);
         break;
      }
      $(".24GHzAPShow").hide();
   }
   else if(id == 0){
      var restrict = $("select[name=5GhzBridgeRestrict]").val();

      switch ( restrict ) {
         case '0':
            $(".5GhzStaticWds").show();
            $(".5GhzDynamicWds").hide();         
            break;
         case '1':
            $(".5GhzStaticWds").hide();
            $(".5GhzDynamicWds").hide();         
            break;
         case '2':
            $(".5GhzDynamicWds").show(); 
            $(".5GhzStaticWds").hide();             
            refreshClick(id);
         break;
      }  
      $(".5GHzAPShow").hide();      
   }
}

function refreshClick(id) {
   if(id == 1){
      var lst = '';
      var restrict = $("select[name=24GhzBridgeRestrict]").get(0).selectedIndex;

      if (restrict != 1) {
         alert("Refresh only allowed when Bridge Restrict has 'Enabled(Scan)' selected.");
         return;
      }
      $.get("nc_wlbrScan_24.html",
      		function(data,status){
            $("#24GHzDynamicWdsSSIDList").empty();
      		$("#24GHzDynamicWdsSSIDList").append(data);
      	});
   }
   else if(id == 0){
      var lst = '';
      var restrict = $("select[name=5GhzBridgeRestrict]").get(0).selectedIndex;
      if (restrict != 1) {
         alert("Refresh only allowed when Bridge Restrict has 'Enabled(Scan)' selected.");
         return;
      }
      $.get("nc_wlbrScan_5.html",
         function(data,status){
            $("#5GHzDynamicWdsSSIDList").empty();
      		$("#5GHzDynamicWdsSSIDList").append(data);
      });
   }
}

function parseRestrictIndex(restrict) {
   var ret;
      switch(restrict) {
      case '0':
         ret = 0;
         break;
      case '2':
         ret = 1;
         break;
      default:
         ret = 2;
         break;
   }
   return ret;
}

function initWlBridge(id){
   if(id == 1){
      if ( wlMode_24 == 'ap' )
         $("select[name=24GhzAPMode]").get(0).selectedIndex = 0;
      else
         $("select[name=24GhzAPMode]").get(0).selectedIndex = 0; 
      
      $("select[name=24GhzBridgeRestrict]").get(0).selectedIndex = parseRestrictIndex(wlLazyWds_24);      

      $("input[name=24GhzBridgeMacAddr1]").val(wlWds0_24);
      $("input[name=24GhzBridgeMacAddr2]").val(wlWds1_24);
      $("input[name=24GhzBridgeMacAddr3]").val(wlWds2_24);
      $("input[name=24GhzBridgeMacAddr4]").val(wlWds3_24);
      
      if(wlLazyWds_24 == '2'){
         $(".24GhzDynamicWds").show();
         $(".24GhzStaticWds").hide();
      }
      else{
         BridgeRestrictChange(1);   
      }         
   }
   else {
      if ( wlMode_5 == 'ap' )
         $("select[name=5GhzAPMode]").get(0).selectedIndex = 0;
      else
         $("select[name=5GhzAPMode]").get(0).selectedIndex = 0; 
      
      $("select[name=5GhzBridgeRestrict]").get(0).selectedIndex = parseRestrictIndex(wlLazyWds_5); 

      $("input[name=5GhzBridgeMacAddr1]").val(wlWds0_5);
      $("input[name=5GhzBridgeMacAddr2]").val(wlWds1_5);
      $("input[name=5GhzBridgeMacAddr3]").val(wlWds2_5);
      $("input[name=5GhzBridgeMacAddr4]").val(wlWds3_5);
      
      if(wlLazyWds_5 == '2'){
         $(".5GhzDynamicWds").show();
         $(".5GhzStaticWds").hide();
      }
      else{
         BridgeRestrictChange(0);   
      }         
      
   }
}


function wlBrdigeSave24() {
   var loc = 'nc_wlwds_24.ncwl?action=save';

   var idx;

   if ( enbl_24 == '0' ) {
      alert("Cannot apply the change since wireless is currently disabled.");
      return;
   }

   var idx;
   var restrict;
   
   loc += '&wlMode=' + $("select[name=24GhzAPMode]").val();;
   loc += '&wlLazyWds=' + $("select[name=24GhzBridgeRestrict]").val();
   restrict = $("select[name=24GhzBridgeRestrict]").val();
   switch ( restrict ) {
   case '0':
      if($("input[name=24GhzBridgeMacAddr1]").val() != '' && isValidMacAddress($("input[name=24GhzBridgeMacAddr1]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=24GhzBridgeMacAddr1]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=24GhzBridgeMacAddr2]").val() != '' && isValidMacAddress($("input[name=24GhzBridgeMacAddr2]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=24GhzBridgeMacAddr2]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=24GhzBridgeMacAddr3]").val() != '' && isValidMacAddress($("input[name=24GhzBridgeMacAddr3]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=24GhzBridgeMacAddr3]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=24GhzBridgeMacAddr4]").val() != '' && isValidMacAddress($("input[name=24GhzBridgeMacAddr4]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=24GhzBridgeMacAddr4]").val() + "&quot; is invalid MAC address.");
         return;
      }      
      loc += '&wlWds0=' + $("input[name=24GhzBridgeMacAddr1]").val();
      loc += '&wlWds1=' + $("input[name=24GhzBridgeMacAddr2]").val();
      loc += '&wlWds2=' + $("input[name=24GhzBridgeMacAddr3]").val();
      loc += '&wlWds3=' + $("input[name=24GhzBridgeMacAddr4]").val();

      break;
   case '2':
      var lst = '';
      var wdschoose = 0;
      var scanwds = $("input[name=scanwds_24]");
      if ($(scanwds).length > 0){
         for (i = 0; i < $(scanwds).length; i++) {            
            if ( $(scanwds[i]).is(':checked') ){
               lst += $(scanwds[i]).val() + ', ';
               wdschoose++;
            }
         }
         if(wdschoose>4){
            wdschoose = 0;
            alert("The number of SSID you choose can't be more than 4.");
            return;
         }
      }
      else if ( $(scanwds).is(':checked') )
         lst = $(scanwds).val();
         loc += '&wdsLst=' + lst;

      break;
   case '1':
      break;
   }

   loc += '&wlSyncNvram=1';
   var code = 'location="' + loc + '"';
   eval(code);
}
function wlBrdigeSave5() {
   var loc = 'nc_wlwds_5.ncwl?action=save';

   var idx;

   if ( enbl_5 == '0' ) {
      alert("Cannot apply the change since wireless is currently disabled.");
      return;
   }

   var idx;
   var restrict;
   
   loc += '&wlMode=' + $("select[name=5GhzAPMode]").val();;
   loc += '&wlLazyWds=' + $("select[name=5GhzBridgeRestrict]").val();
   restrict = $("select[name=5GhzBridgeRestrict]").val();
   switch ( restrict ) {
   case '0':
      if($("input[name=5GhzBridgeMacAddr1]").val() != '' && isValidMacAddress($("input[name=5GhzBridgeMacAddr1]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=5GhzBridgeMacAddr1]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=5GhzBridgeMacAddr2]").val() != '' && isValidMacAddress($("input[name=5GhzBridgeMacAddr2]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=5GhzBridgeMacAddr2]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=5GhzBridgeMacAddr3]").val() != '' && isValidMacAddress($("input[name=5GhzBridgeMacAddr3]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=5GhzBridgeMacAddr3]").val() + "&quot; is invalid MAC address.");
         return;
      }
      if($("input[name=5GhzBridgeMacAddr4]").val() != '' && isValidMacAddress($("input[name=5GhzBridgeMacAddr4]").val()) == false){
         alert("Remote Bridge MAC address &quot;" + $("input[name=5GhzBridgeMacAddr4]").val() + "&quot; is invalid MAC address.");
         return;
      }      
      loc += '&wlWds0=' + $("input[name=5GhzBridgeMacAddr1]").val();
      loc += '&wlWds1=' + $("input[name=5GhzBridgeMacAddr2]").val();
      loc += '&wlWds2=' + $("input[name=5GhzBridgeMacAddr3]").val();
      loc += '&wlWds3=' + $("input[name=5GhzBridgeMacAddr4]").val();

      break;
   case '2':
      var lst = '';
      var wdschoose = 0;
      var scanwds = $("input[name=scanwds_5]");
      if ($(scanwds).length > 0){
         for (i = 0; i < $(scanwds).length; i++) {            
            if ( $(scanwds[i]).is(':checked') ){
               lst += $(scanwds[i]).val() + ', ';
               wdschoose++;
            }
         }
         if(wdschoose>4){
            wdschoose = 0;
            alert("The number of SSID you choose can't be more than 4.");
            return;
         }
      }
      else if ( $(scanwds).is(':checked') )
         lst = $(scanwds).val();
         loc += '&wdsLst=' + lst;

      break;
   case '1':
      break;
   }

   loc += '&wlSyncNvram=1';
   var code = 'location="' + loc + '"';
   eval(code);
}

