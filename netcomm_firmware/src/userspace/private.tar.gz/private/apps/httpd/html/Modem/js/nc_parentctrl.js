//get and show the profiles info in the page

var profileList = '<%ejGetObject(MDMOID_PARENT_CONTROL_PROFILE_CFG)%>';
var obj1Rows = numOfRow(profileList);
var profileNameArray = getColFromList(profileList, 'PrName');					
var className = "blackoutCell";

function deleteRow(obj, eID) 
{
	var hostName = $(obj).parents("tr").find("td:eq(0)").text();		
	var connType = $(obj).parents("tr").find("td:eq(1)").text();	
	var mac = $(obj).parents("tr").find("td:eq(2)").text();
	var index = obj.parentNode.parentNode.parentNode.rowIndex;
	var table = document.getElementById(eID);
	table.deleteRow(index);
	addDevsFromList(mac, connType, hostName);
	
} 

function deleteItem(obj) 
{
	var delListArry, delUrlName, pListArry;
	delUrlName = $(obj).parent().parent().text();
	pListArry = $(obj).parent().parent().parent().parent().parent().find("input[name='urlArry']").val();
	if(pListArry == '')
	{
		delListArry = delUrlName + "," + "delete|";
	}
	else
	{
		delListArry = pListArry + "|" + delUrlName + "," + "delete|";
	}
	delListArry = delListArry.substring(0, delListArry.length-1);

	$(obj).parent().parent().parent().parent().parent().find("input[name='urlArry']").val(delListArry);
	$(obj).parent().parent().remove();
} 				

function addDevsFromList(obj, connType, hostName)
{
	if(connType == "Wired")
	{
		$('#wiredDevices').append('<option value=' + hostName + '|' + obj + '>' + hostName + '</option>');
	}
	else if(connType == "Wireless")
	{
		$('#wirelessDevices').append('<option value=' + hostName + '|' + obj + '>' + hostName + '</option>');		
	}
	
}

function rmDevsFromList(obj)
{
	var i, n, devicesInfo, isUsedMac;
	var objItems = '<%ejGetOther(devicesList)%>';
	var devicesArray = objItems.split('|');

	var devList = '<%ejGetObject(MDMOID_DEVICES_CFG)%>';
	var obj2Rows = numOfRow(devList);
	var macArray = getColFromList(devList, 'MacAddr');
	$('#wiredDevices').empty();			
	$('#wirelessDevices').empty();						
	for(i = 0; i < devicesArray.length; i++)
	{
		devicesInfo = devicesArray[i].split(',');
		isUsedMac = false;
		for(n = 0; n < obj2Rows; n++)
		{
			//display the devices when Edit Devices 
			if(devicesInfo[2] == macArray[n])
			{
				isUsedMac = true;
				break;
			}
		}
		
		$("#currentdevices tbody tr").each(function()
		{
			var addr = $(this).children("td:nth-child(3)").text();
			if(addr == devicesInfo[2])
			{
				isUsedMac = true;
				return false;						
			}
		});

		if(isUsedMac != true)
		{
			if(devicesInfo[1] == "Ethernet")
			{
				$('#wiredDevices').append('<option value=' + devicesInfo[0] + '|' + devicesInfo[2] + '>' + devicesInfo[0] + '</option>');
			}
			else if(devicesInfo[1] == "802.11")
			{
				$('#wirelessDevices').append('<option value=' + devicesInfo[0] + '|' + devicesInfo[2] + '>' + devicesInfo[0] + '</option>');		
			}
		}
	}


}

function profile_SaveNext()
{
	var addrArry = '';
	var	newPrName = $("input[name='profileName']").val();
	var currPrName = $("input[name='oldPrName']").val();
	$("#currentdevices tbody tr").each(function()
	{
		addrArry += $(this).children("td:nth-child(1)").text();
		addrArry += ',';
		addrArry += $(this).children("td:nth-child(2)").text();
		addrArry += ',';
		addrArry += $(this).children("td:nth-child(3)").text();
		addrArry += '|';
	});	
	//remove the first null obj and the last '|'
	addrArry = addrArry.substring(3, addrArry.length-1);
	if(addrArry == "|")
	{
		alert("Error: you should select at least one device.");
		return false
	}
	for(i = 0; i < obj1Rows; i++)
	{	
		//if(profileNameArray[i] == prName) /*users can not save the config if use this condition when user has no changes on profile name.*/
		if((currPrName != newPrName) && (profileNameArray[i] == newPrName))
		{
			alert("Error: The profile name has already existed.");
			return false;
		}
	}
	$('input[name=selectDevs]').val(addrArry);
	return true;				
}

function pre_SaveCheck(obj)
{
	var i;
	var catname = $(obj).children().find("input[name='catName']").val();
	var idex = $(obj).attr("id");
	for(i = 0; i < 8; i++)
	{
		var temp = "editBlockList_" + i;
		if(temp != idex)
		{
			var blockList = $("#editBlockList_" + i).find("input[name='catName']").val();
			if(catname == blockList)
			{
				alert("Error: The Category Name has already existed.");
				return false;		
			}
		}
	
	}
}
function applyBlocking(className) 
{
	var buf = '';
	this.className = className;
	$(".timeSlots td.selected").each(function()
	{
		$(this).removeClass();
		$(this).addClass("selectee");
		$(this).addClass(className);
		var row = $(this).parent().index();
		var col = $(this).index();
		var attribute = $(this).attr("class");
		if(attribute == "selectee blackoutCell")
			attribute = "blocked";
		else if(attribute == "selectee timedBlockingCell")
			attribute = "scheduled";
		
		buf += (row - 1) + ":00" + ',' + row + ":00" + ',' + col + ',' +  attribute + '|';//HourStart, HourEnd, WeekDay, BehavMode
	});
	
	buf = buf.substring(0, buf.length-1);
	//����ѡ�е�td	��timedBlockingCellList blackoutCellList
	if(className == "blackoutCell")
	{
		$("#blackoutCellList").val(buf);
	}
	else
	{
		$("#timedBlockingCellList").val(buf);		
	}
	this.className = "selected";
}


function collectDayTimeData()
{
	var buf1 = '';
	var buf2 = '';
	
	$(".timeSlots td").each(function()
	{
		var row = $(this).parent().index();
		var col = $(this).index();
		var attribute = $(this).attr("class");
		if(attribute == "selectee blackoutCell")
			attribute = "blocked";
		else if(attribute == "selectee timedBlockingCell")
			attribute = "scheduled";

		if(attribute == "blocked")
		{
			buf1 += (row - 1) + ":00" + ',' + row + ":00" + ',' + col + ',' +  attribute + '|';//HourStart, HourEnd, WeekDay, BehavMode
		}
		else if(attribute == "scheduled")
		{
			buf2 += (row - 1) + ":00" + ',' + row + ":00" + ',' + col + ',' +  attribute + '|';//HourStart, HourEnd, WeekDay, BehavMode
		}
	});	
	buf1 = buf1.substring(0, buf1.length-1);
	buf2 = buf2.substring(0, buf2.length-1);
	//����ѡ�е�td	��timedBlockingCellList blackoutCellList

	$("#blackoutCellList").val(buf1);
	$("#timedBlockingCellList").val(buf2);							
}

function showTimeInfo(idNum, dayArray)
{
	var i;
	for(i = 0; i < dayArray.length; i++)
	{
		var dayTimesArry = dayArray[i].split(',');
		var row = dayTimesArry[1].split(':');
		var rows = parseInt(row[0]) + 1;
		var col = parseInt(dayTimesArry[3]) - 1;						
		if(idNum == dayTimesArry[0])
		{
			$(".timeSlots").find("tr").eq(rows).find("td").eq(col).removeClass("selectee");	
			$(".timeSlots").find("tr").eq(rows).find("td").eq(col).addClass("selectee");	
			if(dayTimesArry[4] == "blocked")
			{
				$(".timeSlots").find("tr").eq(rows).find("td").eq(col).addClass("blackoutCell");	
			}
			else
			{
				$(".timeSlots").find("tr").eq(rows).find("td").eq(col).addClass("timedBlockingCell");	
			}
		}
	}	
	
}

function showDevInfo(idNum, devArray)
{
	var i;
	$('#currentdevices tbody').empty();
	for(i = 0; i < devArray.length; i++)
	{
		var devicesArry = devArray[i].split(',');
		if(idNum == devicesArry[0])
		{
			$('#currentdevices tbody').append('<tr><td>' + devicesArry[1] + '</td><td>' + devicesArry[2] + '</td><td>' + devicesArry[3] + '</td><td><a><span class="icon-No" onClick="Javacsript:deleteRow(this, \'currentdevices\');"></span></a></td></tr>');
		}
	}	
}

function showRulesInfo(idNum, rulArray)
{
	var i;
	for(i = 0; i < rulArray.length; i++)
	{
		var rulesArry = rulArray[i].split(',');
		if(idNum == rulesArry[0])
		{
			for (var k = 0; k < 8; k++)
			{	
				var splist = document.getElementById("sp_" + k).innerText;//$("#sp_" + k).text(); when use the text(), "if(rulesArry[1] == splist)" will always be false since the attribute of the text() is different from rulesArry[1];
				if(rulesArry[1] == splist)
				{	
					switch(rulesArry[2])
					{
						case "0":
							$("#list_" + k).prop("checked", false);	
							$("#list_" + k).val("disabled");							
							$("#sp_" + k).addClass('disabled');	
							$("#selected_" + k).prop('disabled', true);	
							break;
						case "1":
							$("#list_" + k).prop("checked", true);	
							$("#list_" + k).val("enabled");							
							$("#sp_" + k).removeClass('disabled');	
							$("#selected_" + k).prop('disabled', false);	
							$("#selected_" + k + " option[value='Permanent Blocking']").attr("selected", true);																
							break;
						case "2":
							$("#list_" + k).prop("checked", true);	
							$("#list_" + k).val("enabled");														
							$("#sp_" + k).removeClass('disabled');	
							$("#selected_" + k).prop('disabled', false);	
							$("#selected_" + k + " option[value='Scheduled Blocking']").attr("selected", true);								
							break;
					}	
					break;
				}
			}
		}
	}	
}

function showProImgArea(ProImgClass)
{
	var displayChosenProImg;
	$("#glyphiconplus").hide();
	$("#chosenProImg").empty();
	displayChosenProImg='';
	displayChosenProImg += "<div class='user " + ProImgClass + "'>";
	displayChosenProImg +="<span style='width: 130px;' class='imageIdex'></span>";
	displayChosenProImg +="</div>";
	$("#chosenProImg").append(displayChosenProImg);
	$("#chosenProImg").show();
}
