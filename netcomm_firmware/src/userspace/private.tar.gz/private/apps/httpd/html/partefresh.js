/*
  *author:zhoumingming
  *date:2017-03-05
  *function:part refresh for html
  *if you want to try to use me, enter url(http://xxx.xxx.xxx.xxx/ajax.html) on your broswer
  *if you want to develop base on me, make a page like ajax.html, and add a extend c-code in httpd.c(file) -> do_infos(function)
  *
  *follow the steps and then your pages will support current special function:
  *1)in your page:
  *1.1)include part refresh javascript, like "<script type="text/javascript" src="partefresh.js"></script>"
  *1.2)call function "updateTextDomainByInterval" and ive the right parameters.
  *2)in httpd.c(file) -> do_infos(function)
  *2.1)extend your domain to put special content you want.
  *That's all.
  *
  */
var infomations = new Infomation();

function Infomation() {
	this.setTextDomain = function(domain) { 
		this.po = "/"+domain+".info";
	};
	
	this.setKeyDomain = function(key) { 
		this.key = key;
	};
	
	this.initialize = function() {
		try { this.request = new XMLHttpRequest(); } catch(e1) {
			try { this.request = new ActiveXObject("Msxml2.XMLHTTP"); } catch(e2) {
				try { this.request = new ActiveXObject("Microsoft.XMLHTTP"); } catch(e3) { 
					//window.alert("can not create a Ajax object");
					return false; 
				}
			}
		};

		return true;
	};

	this.update = function() {
		this.request.open("GET",this.po,false); 
		this.request.send(null);
		if(this.request.status==200) { 
			this.text = this.request.responseText;
			//window.alert(this.text);
			return true;
		}
                  
		return false;
	};
	
	this.getText = function() { 
		return this.text; 
	};

	this.setKeyValue = function() {
		var obj;
		obj = document.getElementById(this.key);
		if(obj) {/*check if the id is exist*/
			if((obj.tagName == 'input') || (obj.tagName == 'INPUT')) { /*if obj type is button*/
				obj.value = this.getText();
			}
			else {
   				obj.innerHTML = this.getText();
			}
		}
	}

   this.setITValue = function(IT) {
		this.IT = IT;
	}
}


function updateTextDomain(){
	if(!infomations.update()){
		;//window.alert("update error this time");
	}else{
	   
		infomations.setKeyValue();
      if(infomations.getText().indexOf("testing") == -1)
      {
         window.clearInterval(infomations.IT); 
      }
	}
	
}


//�ظ�ִ�ж�ʱ��
function updateTextDomainByInterval(domain, key, interval){
	var IT;
	
	infomations.setTextDomain(domain);
	infomations.setKeyDomain(key);
	if(infomations.initialize()){
		IT = window.setInterval("updateTextDomain()",interval);
      infomations.setITValue(IT);
	}
	
	return IT;
}

//window.clearInterval(IT); 


//һ��ִ�ж�ʱ��
function updateTextDomainByTimeout(domain, key, timeout){
	var TO;
	
	infomations.setTextDomain(domain);
	infomations.setKeyDomain(key);
	if(infomations.initialize()){
		TO = window.setTimeout("updateTextDomain()",timeout);
	}
	
	return TO;
}

//window.clearTimeout(TO); 



