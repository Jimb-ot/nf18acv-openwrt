// PLEASE NOTE THAT A SPACE BETWEEN TWO WORDS IS TAKEN AS TWO SEPERATE
// WORDS. PLEASE KEEP THIS FILE CONSISTENT.
//
// For each Linux interface name in the boardparms.c file, add
// a corresponding Linux interface name and a user-friendly name
// of its equivalent that must be displayed on the WEB UI. It is
// best if the new inteface names are added at the end.
// Make sure modifications to portName_L are consistent with
//portName_U and viceversa

//Keep #define WL_MAX_NUM_SSID here for Mbss Tag

 portName_L = [
// Wireless interfac Linux interface name
'wl0',
// Wireless interfac Linux interface name
'wl1',
// USB interface Linux interface name
'usb0',

// Board ID 963138BGW Linux name
'963138_T281_C|eth0',
'963138_T281_C|eth1',
'963138_T281_C|eth2',
'963138_T281_C|eth3',
'963138_T281_C|eth4',
'963138_T281_C|eth0.1',
'963138_T281_C|eth1.0',
'963138_T281_C|eth2.0',
'963138_T281_C|eth3.0',
'963138_T281_C|eth4.0',

// Board ID 96368VVW Linux name
'96368VVW|eth0',
'96368VVW|eth1',
'96368VVW|eth2',
'96368VVW|eth3',

// Board ID 96362ADVNG Linux name
'96362ADVNG|eth0',
'96362ADVNG|eth1',
'96362ADVNG|eth2',
'96362ADVNG|eth3',
'96362ADVNG|eth4',

// Board ID 963168GW_T182_B Linux name
'963168GW_T182_B|eth0',
'963168GW_T182_B|eth1',
'963168GW_T182_B|eth2',
'963168GW_T182_B|eth3',
'963168GW_T182_B|eth4'
];

var portName_U = [
// Wireless interface user-friendly name
'wl0/5G',
// Wireless interface user-friendly name
'wl1/2.4G',
// USB user-friendly name
'USB',

// Board ID 963138BGW Linux name
'963138_T281_C|ETHWAN',
'963138_T281_C|ENET1',
'963138_T281_C|ENET2',
'963138_T281_C|ENET3',
'963138_T281_C|ENET4',

// Board ID 96368VVW user-friendly name
'96368VVW|ENET1',
'96368VVW|ENET2',
'96368VVW|ENET3',
'96368VVW|ENET4',

// Board ID 96362ADVNG user-friendly name
'96362ADVNG|ENET1',
'96362ADVNG|ENET2',
'96362ADVNG|ENET3',
'96362ADVNG|ENET4',
'96362ADVNG|ENET5',

// Board ID 963168GW_T182_B user-friendly name
'963168GW_T182_B|LAN1',
'963168GW_T182_B|LAN2',
'963168GW_T182_B|LAN3',
'963168GW_T182_B|LAN4',
'963168GW_T182_B|WAN'
];

function getUNameByLName(name) {
   var index = 0;
   var uName   = '';
   var wlName   = '';
   var mPoint = '';
   
   // SafetyNet if someone sends a name without prefixing the
   // board ID and |, then return that name.
   if (name.indexOf('|') == -1)
      return name;
      
   /*Wlan naming: Could be a better name*/
   if (name.indexOf('wl0.') != -1) {
      wlName = name.split('|');
      return (wlName[1]);
   }
   else if (name.indexOf('wl0') != -1) {
      return 'wl0/5G';
   }
   else if (name.indexOf('wl1.') != -1) {
      wlName = name.split('|');
      return (wlName[1]);
   }
   else if (name.indexOf('wl1') != -1) {
      return 'wl1/2.4G';
   }

   if (name.indexOf('usb0') != -1) {
      return 'USB';
   }
   for (index = 0; index < portName_L.length; index++) {
      if (portName_L[index] == name) {
         uName = portName_U[index].split('|');
         return uName[1];
      }
      else if(name.indexOf(portName_L[index]) != -1 && name.indexOf('eth') != -1 && name.indexOf('.') != -1)
      {      
         mPoint = name.split('.');
         uName = portName_U[index].split('|');  
         return uName[1] + '.' + mPoint[1];
      }
   }
   uName = name.split('|');
   return uName[1];
}

function getLNameByUName(name) {
   var index = 0;
   var brdIntf = name.split('|');
   var lName   = '';
   var uName   = '';
   var intName   = '';

   // SafetyNet if someone sends a name without prefixing the
   // board ID and |, then return that name.
   if (name.indexOf('|') == -1)
      return name;

   if (name.indexOf('wl0_Guest') != -1) {
      intName = brdIntf[1].substring(9);
      return ('wl0.' + intName);
   }
   if (name.indexOf('wl0/5G') != -1)
      return 'wl0';

   if (name.indexOf('wl1_Guest') != -1)	{
      intName = brdIntf[1].substring(9);
      return ('wl1.' + intName);
   }
   if (name.indexOf('wl1/2.4G') != -1)
      return 'wl1';
      
   if (name.indexOf('USB') != -1)
      return 'usb0';
   for (index = 0; index < portName_U.length; index++) {
      //uName = portName_U[index].split('|');
      if (portName_U[index] == name) {
         lName = portName_L[index].split('|');
         return lName[1];
      }
   }
   lName = name.split('|');
   return lName[1];
}
