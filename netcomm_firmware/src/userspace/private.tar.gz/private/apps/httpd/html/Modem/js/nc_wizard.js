	var index_2 = '<%ejGetWl(switch_index_2)%>';
	var wlStatus_2 = '<%ejGetWl(wlEnbl)%>';
	var wlSsid_2 = '<%ejGetWl(wlSsid)%>';
	var wlSecty_2 = '<%ejGetWl(wlAuthMode)%>';
	var wlPwd_2 = '<%ejGetWl(wlWpaPsk)%>';


	var index_5 = '<%ejGetWl(switch_index_5)%>';
	var wlStatus_5 = '<%ejGetWl(wlEnbl)%>';
	var wlSsid_5 = '<%ejGetWl(wlSsid)%>';
	var wlSecty_5 = '<%ejGetWl(wlAuthMode)%>';
	var wlPwd_5 = '<%ejGetWl(wlWpaPsk)%>';

	function	wl_wizardAppend()
	{
		if(wlStatus_2 == '1')
			$("input[name$='24GHZ'][value='On']").prop("checked", true)
		else
			$("input[name$='24GHZ'][value='Off']").prop("checked", true)

		$("input[name='24GHZSSID']").val(wlSsid_2);
		
		if(wlSecty_2 == "open")
			$("select[name='24GHZSceurityType'] option[value='OPEN']").prop("selected", "true");
		else if(wlSecty_2 == "psk2")
			$("select[name='24GHZSceurityType'] option[value='WPA2-PSK']").prop("selected", "true");
		else if(wlSecty_2 == "psk psk2")
			$("select[name='24GHZSceurityType'] option[value='WPA-PSK/WPA2-PSK']").prop("selected", "true");
		else
			$("select[name='24GHZSceurityType'] option[value='Other']").prop("selected", "true");

		if(wlSecty_2 == "open")	
			{	
			$("input[name='24GHZPWD']").prop('disabled', true);
			$("input[name='24GHZPWD']").val("");		
			}
		else
			{
			 $("input[name='24GHZPWD']").prop('disabled', false);
			$("input[name='24GHZPWD']").val(wlPwd_2);
			}

		if(wlStatus_5 == '1')
			$("input[name$='5GHZ'][value='On']").prop("checked", true)
		else
			$("input[name$='5GHZ'][value='Off']").prop("checked", true)

		$("input[name='5GHZSSID']").val(wlSsid_5);
		
		if(wlSecty_5 == "open")
			$("select[name='5GHZSceurityType'] option[value='OPEN']").prop("selected", "true");
		else if(wlSecty_5 == "psk2")
			$("select[name='5GHZSceurityType'] option[value='WPA2-PSK']").prop("selected", "true");
		else if(wlSecty_5 == "psk psk2")
			$("select[name='5GHZSceurityType'] option[value='WPA-PSK/WPA2-PSK']").prop("selected", "true");
		else
			$("select[name='5GHZSceurityType'] option[value='Other']").prop("selected", "true");

		if(wlSecty_5 == "open")	
			{
			$("input[name='5GHZPWD']").prop('disabled', true);
			$("input[name='5GHZPWD']").val("");
			}
		else
			{
			$("input[name='5GHZPWD']").prop('disabled', false);
			$("input[name='5GHZPWD']").val(wlPwd_5);
			}
		
	}
      function authModeChange2_4()
      {
       var authMode2_4 = $('select[name="24GHZSceurityType"]').val();

	    if (authMode2_4 == "OPEN") 
			$("input[name='24GHZPWD']").prop('disabled', true);
		else
			 $("input[name='24GHZPWD']").prop('disabled', false);

       }
      function authModeChange5()
	{
        var authMode5 = $('select[name="5GHZSceurityType"]').val();

	    if (authMode5 == "OPEN") 
			$("input[name='5GHZPWD']").prop('disabled', true);
		else
			 $("input[name='5GHZPWD']").prop('disabled', false);

       }
	function summary_wizardAppend()
	{
		var dataArry, wanStatus, vtpStatus;
		var timeZoneVal = $("#timezone").val();
		var sntp = timeZoneVal.split('|');

		var userName = $("input[name$='routeruid']").val();
		var pwd = $("input[name$='routerpwd']").val();
		
		var ssid_2 = $("input[name='24GHZSSID']").val();
		var pwd_2 = $("input[name='24GHZPWD']").val();
		var authMode_2 = $('select[name="24GHZSceurityType"]').val();

		var ssid_5 = $("input[name='5GHZSSID']").val();
		var pwd_5 = $("input[name='5GHZPWD']").val();
		var authMode_5 = $('select[name="5GHZSceurityType"]').val();

		$("#syncsuccess").hide();
		$("#syncfail").hide();
		$("#inprogress").show();

		$("#line1success").hide();
		$("#line1fail").hide();
		$("#line1inprogress").show();	

		$("#line2fail").hide();
		$("#line2success").hide();
		$("#line2inprogress").show();		


      $.get("nc_wizardstus.html", function(data, status)
		{
			dataArry = data.split("|");
			if(dataArry[0] == "&nbsp")
			{
				$("#syncsuccess").hide();
				$("#syncfail").show();
				$("#inprogress").hide();
			}
			else
			{
				$("#syncsuccess").show();
				$("#syncfail").hide();
				$("#inprogress").hide();
			}

			eval(dataArry[1]);
			if(regst0_0 == "Up")
			{
				$("#line1success").show();
				$("#line1fail").hide();
				$("#line1inprogress").hide();
			}
			else
			{
				$("#line1fail").show();
				$("#line1success").hide();
				$("#line1inprogress").hide();
			}
			if(regst0_1 == "Up")
			{
				$("#line2success").show();
				$("#line2fail").hide();
				$("#line2inprogress").hide();
			}
			else
			{
				$("#line2fail").show();
				$("#line2success").hide();
				$("#line2inprogress").hide();
			}
			
		});

		$("#timeZoneVal").text(sntp[1]);
		$("#loginUserName").text(userName);
		$("#loginPwd").text(pwd);
		$("#wl2Ssid").text(ssid_2);
		$("#wl5Ssid").text(ssid_5);
		
		if(authMode_2 == "OPEN")
			$("#wl2Pwd").text("(OPEN)");
		else
			$("#wl2Pwd").text(pwd_2);
		
		if(authMode_5 == "OPEN")
			$("#wl5Pwd").text("(OPEN)");
		else
			$("#wl5Pwd").text(pwd_5);

	}

