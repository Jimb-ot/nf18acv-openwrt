var switch_idex_24 = '<%ejGetWl(switch_index_2)%>';
var syncNvram_24 = '<%ejGetWl(wlSyncNvram)%>';
var enbl_24 = '<%ejGetWl(wlEnbl_wl0v0)%>';
var country_24 = '<%ejGetWl(wlCountry)%>';
var channel_24 = '<%ejGetWl(wlChannel)%>';
var rate_24 = '<%ejGetWl(wlRate)%>';
var frg_24 = '<%ejGetWl(wlFrgThrshld)%>';
var rts_24 = '<%ejGetWl(wlRtsThrshld)%>';
var dtm_24 = '<%ejGetWl(wlDtmIntvl)%>';
var bcn_24 = '<%ejGetWl(wlBcnIntvl)%>';
var phy_24 = '<%ejGetWl(wlPhyType)%>';
var brate_24 = '<%ejGetWl(wlBasicRate)%>';
var fburst_24 = '<%ejGetWl(wlFrameBurst)%>';
var gmode_24 = '<%ejGetWl(wlgMode)%>';
var pro_24 = '<%ejGetWl(wlProtection)%>';
var pre_24 = '<%ejGetWl(wlPreambleType)%>';
var band_24 = '<%ejGetWl(wlBand)%>';
var mcastrate_24 = '<%ejGetWl(wlMCastRate)%>';
var hasafterburner_24 = '<%ejGetWl(wlHasAfterburner)%>';
var afterburneren_24 = '<%ejGetWl(wlAfterBurnerEn)%>';
var TxPwrPcnt_24 = '<%ejGetWl(wlTxPwrPcnt)%>';
var reg_mode_24 = '<%ejGetWl(wlRegMode)%>';
var dfs_preism_24 = '<%ejGetWl(wlDfsPreIsm)%>';
var dfs_postism_24 = '<%ejGetWl(wlDfsPostIsm)%>';
var tpcDb_24 = '<%ejGetWl(wlTpcDb)%>';
var wme_24 = '<%ejGetWl(wlWme)%>';
var wlCurrentChannel_24 = '<%ejGetWl(wlCurrentChannel)%>';
var acscsscantimer_24 = '<%ejGetWl(wlAcsCsScanTimer)%>';
var nctrlsb_24 = '<%ejGetWl(wlNCtrlsb)%>';
var npro_24 = '<%ejGetWl(wlNProtection)%>';
var nmcsidx_24 = '<%ejGetWl(wlNMcsidx)%>';
var curr_sb_str_24 = '<%ejGetWl(wlCurrentSb)%>';
var currbw_24 = '<%ejGetWl(wlCurrentBw)%>';
var nmode_24 = '<%ejGetWl(wlNmode)%>'; 
var nreqd_24 = '<%ejGetWl(wlNReqd)%>'; 
var wmenoack_24= '<%ejGetWl(wlWmeNoAck)%>';
var wmeapsd_24= '<%ejGetWl(wlWmeApsd)%>';
var nbwcap_24= '<%ejGetWl(wlNBwCap)%>'; 
var haswme_24= '<%ejGetWl(wlHasWme)%>';
var globalmaxassoc_24 = '<%ejGetWl(wlGlobalMaxAssoc)%>';
var curr_bw_str_24 = "";
var hasvec_24 = '<%ejGetWl(wlHasVec)%>';
var iperf_24 = '<%ejGetWl(wlIperf)%>';
var vec_24 = '<%ejGetWl(wlVec)%>';
var wpa_24 = '<%ejGetWl(wlWpa)%>';
var chanimstate_24 = '<%ejGetWl(wlChanImState)%>';
var rifsadvert_24 = '<%ejGetWl(wlRifsAdvert)%>';
var obsscoex_24 = '<%ejGetWl(wlObssCoex)%>';
var rxchain_pwrsave_enable_24 = '<%ejGetWl(wlRxChainPwrSaveEnable)%>';
var rxchain_pwrsave_quiet_time_24 = '<%ejGetWl(wlRxChainPwrSaveQuietTime)%>';
var rxchain_pwrsave_pps_24 = '<%ejGetWl(wlRxChainPwrSavePps)%>';
var TXBFCapable_24 = '<%ejGetWl(wlTXBFCapable)%>';
var enableBFR_24 = '<%ejGetWl(wlEnableBFR)%>';
var enableBFE_24 = '<%ejGetWl(wlEnableBFE)%>';
var bsd_role_24 = '<%ejGetWl(bsdRole)%>';
var bsd_hport_24 = '<%ejGetWl(bsdHport)%>';
var bsd_pport_24 = '<%ejGetWl(bsdPport)%>';
var bsd_helper_24 = '<%ejGetWl(bsdHelper)%>';
var bsd_primary_24 = '<%ejGetWl(bsdPrimary)%>';

var wl_taf_enable_24 = '<%ejGetWl(wlTafEnable)%>';
var wl_atf_24 = '<%ejGetWl(wlAtf)%>';

var wl_pspretend_threshold_24 = '<%ejGetWl(wlPspretendThreshold)%>';
var wl_pspretend_retry_limit_24 = '<%ejGetWl(wlPspretendRetryLimit)%>';
var enableUre_24 = '<%ejGetWl(wlEnableUre)%>';
var sta_retry_time_24 = '<%ejGetWl(wlStaRetryTime)%>';

//bridge
var wlWds0_24 = '<%ejGetWl(wlWds0)%>';
var wlWds1_24 = '<%ejGetWl(wlWds1)%>';
var wlWds2_24 = '<%ejGetWl(wlWds2)%>';
var wlWds3_24 = '<%ejGetWl(wlWds3)%>';
var wlMode_24 = '<%ejGetWl(wlMode)%>';
var wlLazyWds_24 = '<%ejGetWl(wlLazyWds)%>'; 

//macfilter
var mainssid_24 = '<%ejGetWl(wlSsid_wl0v0)%>';
var guestssid1_24 = '<%ejGetWl(wlSsid_wl0v1)%>';
var guestssid2_24 = '<%ejGetWl(wlSsid_wl0v2)%>';
var guestssid3_24 = '<%ejGetWl(wlSsid_wl0v3)%>';

var regrev_24 = '<%ejGetWl(wlRegRev)%>';
var curcountry_24=country_24;

function wl_ewc_options_24(OnPageLoad, id)
{
	var sel_nbw;
	var sel_nmcsidx;
	var idx;   
	var sel_ch;
	var sel_nmode;
	var sel_nreqd;
	var sel_nbw_cap;
	var sel_band;
	var bw;
	if(phy_24 != "n" && phy_24 != "v")
	return;

	if(OnPageLoad) {
   	sel_ch = channel_24;
   	sel_nmode = nmode_24;
   	sel_nreqd = nreqd_24; 
   	sel_band = band_24;
   	sel_nbw_cap = nbwcap_24;

   	$("select[name=24GhzWlNProtection]").get(0).value= npro_24;

   	sel_nmcsidx = nmcsidx_24;
   	if(nctrlsb_24 == 0) {
      	$("select[name=24GhzWlNCtrlsb]").get(0).selectedIndex = 0;				
      	$("select[name=24GhzWlNCtrlsb]").prop("disabled", true);		
   	} else{     
      	$("select[name=24GhzWlNCtrlsb]").get(0).value = nctrlsb_24;								
   	}

   	$("select[name=24GhzWlNReqd]").get(0).value = nreqd_24;								

   	if(sel_nmode == "off") {
      	$("select[name=24GhzWlNmode]").get(0).selectedIndex = 1;
   	}
   	$("select[name=24GHzMainNTChannelBandWidth]").get(0).value = sel_nbw_cap;								
	} else {
   	sel_ch = $("select[name=24GHzMainNTChannel]").val();   
   	sel_nmcsidx = $("select[name=24GhzWlNMmcsidx]").val();
   	sel_nmode = $("select[name=24GhzWlNmode]").val();
   	sel_nreqd = $("select[name=24GhzWlNReqd]").val();
   	sel_band = band_24;
   	sel_nbw_cap = $("select[name=24GHzMainNTChannelBandWidth]").val();
	}

	if(sel_nmode == "off") {
   	$("select[name=24GhzWlNMmcsidx]").prop("disabled", true);
   	$("select[name=24GhzWlNProtection]").prop("disabled", true);
   	$("select[name=24GhzWlNReqd]").prop("disabled", true);
   	$("select[name=24GhzWlNCtrlsb]").prop("disabled", true);	 

   	$("#div_nMode_24").hide();
   	bw = "20";
	} else {
   	$("select[name=24GhzWlNMmcsidx]").prop("disabled", false);
   	$("select[name=24GhzWlNProtection]").prop("disabled", false);
   	$("select[name=24GhzWlNReqd]").prop("disabled", false);
   	$("select[name=24GhzWlNCtrlsb]").prop("disabled", false);	 
   	$("#div_nMode_24").show();
   	if (sel_nbw_cap == "3")   
      	bw = "40";
   	else
      	bw = "20";      
	}  

	$("select[name=24GhzWlNMmcsidx]").prop("disabled", false);

	/* load n phy rates */
	if(sel_ch == 0) {
   	$("select[name=24GhzWlNCtrlsb]").prop("disabled", true);
   	<%ejGetWl(wlNPhyRates_24, "0");%>   
	} else if (bw == "40") {
   	/* Control sb is allowed only for 40MHz BW Channels */   
   	$("select[name=24GhzWlNCtrlsb]").prop("disabled", false);
   	<%ejGetWl(wlNPhyRates_24, "40");%>
	} else if (bw == "20") {
   	$("select[name=24GhzWlNCtrlsb]").get(0).selectedIndex = 0;
   	$("select[name=24GhzWlNCtrlsb]").prop("disabled", true);
   	<%ejGetWl(wlNPhyRates_24, "20");%>
	} 
	$("select[name=24GhzWlNMmcsidx]").get(0).value = sel_nmcsidx;
	/* mark selected */ 
	$("select[name=24GhzWlNmode]").get(0).value = sel_nmode;
}

function loadChannelList_24(OnPageLoad)
{
   var sel_ch;
   var sel_band;
   var sel_nbw_cap;
   var sel_sb;
   var idx;

   /* save selected */   
   if(OnPageLoad) {      
      sel_ch = channel_24;
      sel_band = band_24;
      sel_nbw_cap = nbwcap_24;
      sel_sb = nctrlsb_24;
   } else {
      sel_ch = $("select[name=24GHzMainNTChannel]").val();
      sel_band = band_24;
      sel_nbw_cap = $("select[name=24GHzMainNTChannelBandWidth]").val();
      sel_sb = $("select[name=24GhzWlNCtrlsb]").val();
   }

   /* load list */

   $("select[name=24GHzMainNTChannel]").empty();
   if ((sel_band == "2") && ((phy_24 != "n") && (phy_24 != "v"))) {
      <%ejGetWl(wlChannelList_24_newgui, b, b, 20)%>
   }
   else  if ((sel_band == "1") && ((phy_24 != "n") && (phy_24 != "v"))) {
      <%ejGetWl(wlChannelList_24_newgui, a, a, 20)%>
   }
   else  if ((sel_band == "2") && (phy_24 == "n") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, n, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, n, b, 40, "lower")%>         
         }            
      } 
      else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_24_newgui, n, b, 20 )%>
      }         
   }
   else  if ((sel_band == "1") && (phy_24 == "n") ) {    
      if(sel_nbw_cap == "1" || sel_nbw_cap == "2") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, n, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, n, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_24_newgui, n, a, 20 )%>
      }         
   }      
   else if ((sel_band == "1") && (phy_24 == "v") && (sel_nbw_cap == "7")) {    
      /* Band a and AC phy and 80M */
      <%ejGetWl(wlChannelList_24_newgui, v, a, 80 )%>
   }
   else  if ((sel_band == "2") && (phy_24 == "v") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, v, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, v, b, 40, "lower")%>         
         }            
      } else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_24_newgui, v, b, 20 )%>
      }         
   }
   else  if ((sel_band == "1") && (phy_24 == "v")) {    
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_24_newgui, v, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_24_newgui, v, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_24_newgui, v, a, 20 )%>
      }         
   }      
   else {
      $("select[name=24GHzMainNTChannel]").append("<option value='0'>Auto</option>");			   
   }

   $("select[name=24GHzMainNTChannel]").get(0).value= sel_ch;
   if($("select[name=24GHzMainNTChannel]").get(0).selectedIndex == 0){
      $("input[name=24GhzChannelTimer]").prop("disabled", true);
   }      
   else{
      $("input[name=24GhzChannelTimer]").prop("disabled", false);      
   }
      
}

function wlLoadCountryList_24(OnPageLoad)
{
   $("input[name=wl1RegRev]").val(regrev_24);
   var i = 0;
   if (band_24 == "2") { // 2.4G
      <%ejGetWl(wlCountryList_24_newgui,b)%>	  	
   } 
   
   for (i=0; i< document.forms[10].wl1Country.options.length; i++) {
      if (document.forms[10].wl1Country.options[i].value == country_24) {
         document.forms[10].wl1Country.options[i].selected = true;
         break;
      }
   }

   /* set to all(the last one) if not found */
   if( i == document.forms[10].wl1Country.options.length)
      document.forms[10].wl1Country.options[i-1].selected = true;
   
}

var switch_idex_5 = '<%ejGetWl(switch_index_5)%>';
var syncNvram_5 = '<%ejGetWl(wlSyncNvram)%>';
var enbl_5 = '<%ejGetWl(wlEnbl_wl0v0)%>';
var country_5 = '<%ejGetWl(wlCountry)%>';
var channel_5 = '<%ejGetWl(wlChannel)%>';
var rate_5 = '<%ejGetWl(wlRate)%>';
var frg_5 = '<%ejGetWl(wlFrgThrshld)%>';
var rts_5 = '<%ejGetWl(wlRtsThrshld)%>';
var dtm_5 = '<%ejGetWl(wlDtmIntvl)%>';
var bcn_5 = '<%ejGetWl(wlBcnIntvl)%>';
var phy_5 = '<%ejGetWl(wlPhyType)%>';
var brate_5 = '<%ejGetWl(wlBasicRate)%>';
var fburst_5 = '<%ejGetWl(wlFrameBurst)%>';
var gmode_5 = '<%ejGetWl(wlgMode)%>';
var pro_5 = '<%ejGetWl(wlProtection)%>';
var pre_5 = '<%ejGetWl(wlPreambleType)%>';
var band_5 = '<%ejGetWl(wlBand)%>';
var mcastrate_5 = '<%ejGetWl(wlMCastRate)%>';
var hasafterburner_5 = '<%ejGetWl(wlHasAfterburner)%>';
var afterburneren_5 = '<%ejGetWl(wlAfterBurnerEn)%>';
var TxPwrPcnt_5 = '<%ejGetWl(wlTxPwrPcnt)%>';
var reg_mode_5 = '<%ejGetWl(wlRegMode)%>';
var dfs_preism_5 = '<%ejGetWl(wlDfsPreIsm)%>';
var dfs_postism_5 = '<%ejGetWl(wlDfsPostIsm)%>';
var tpcDb_5 = '<%ejGetWl(wlTpcDb)%>';
var wme_5 = '<%ejGetWl(wlWme)%>';
var wlCurrentChannel_5 = '<%ejGetWl(wlCurrentChannel)%>';
var acscsscantimer_5 = '<%ejGetWl(wlAcsCsScanTimer)%>';
var nctrlsb_5 = '<%ejGetWl(wlNCtrlsb)%>';
var npro_5 = '<%ejGetWl(wlNProtection)%>';
var nmcsidx_5 = '<%ejGetWl(wlNMcsidx)%>';
var curr_sb_str_5 = '<%ejGetWl(wlCurrentSb)%>';
var currbw_5 = '<%ejGetWl(wlCurrentBw)%>';
var nmode_5 = '<%ejGetWl(wlNmode)%>'; 
var nreqd_5 = '<%ejGetWl(wlNReqd)%>'; 
var wmenoack_5= '<%ejGetWl(wlWmeNoAck)%>';
var wmeapsd_5= '<%ejGetWl(wlWmeApsd)%>';
var nbwcap_5= '<%ejGetWl(wlNBwCap)%>'; 
var haswme_5= '<%ejGetWl(wlHasWme)%>';
var globalmaxassoc_5 = '<%ejGetWl(wlGlobalMaxAssoc)%>';
var curr_bw_str_5 = "";
var hasvec_5 = '<%ejGetWl(wlHasVec)%>';
var iperf_5 = '<%ejGetWl(wlIperf)%>';
var vec_5 = '<%ejGetWl(wlVec)%>';
var wpa_5 = '<%ejGetWl(wlWpa)%>';
var chanimstate_5 = '<%ejGetWl(wlChanImState)%>';
var rifsadvert_5 = '<%ejGetWl(wlRifsAdvert)%>';
var obsscoex_5 = '<%ejGetWl(wlObssCoex)%>';
var rxchain_pwrsave_enable_5 = '<%ejGetWl(wlRxChainPwrSaveEnable)%>';
var rxchain_pwrsave_quiet_time_5 = '<%ejGetWl(wlRxChainPwrSaveQuietTime)%>';
var rxchain_pwrsave_pps_5 = '<%ejGetWl(wlRxChainPwrSavePps)%>';
var TXBFCapable_5 = '<%ejGetWl(wlTXBFCapable)%>';
var enableBFR_5 = '<%ejGetWl(wlEnableBFR)%>';
var enableBFE_5 = '<%ejGetWl(wlEnableBFE)%>';
var bsd_role_5 = '<%ejGetWl(bsdRole)%>';
var bsd_hport_5 = '<%ejGetWl(bsdHport)%>';
var bsd_pport_5 = '<%ejGetWl(bsdPport)%>';
var bsd_helper_5 = '<%ejGetWl(bsdHelper)%>';
var bsd_primary_5 = '<%ejGetWl(bsdPrimary)%>';

var wl_taf_enable_5 = '<%ejGetWl(wlTafEnable)%>';
var wl_atf_5 = '<%ejGetWl(wlAtf)%>';

var wl_pspretend_threshold_5 = '<%ejGetWl(wlPspretendThreshold)%>';
var wl_pspretend_retry_limit_5 = '<%ejGetWl(wlPspretendRetryLimit)%>';
var enableUre_5 = '<%ejGetWl(wlEnableUre)%>';
var sta_retry_time_5 = '<%ejGetWl(wlStaRetryTime)%>';

//bridge
var wlWds0_5 = '<%ejGetWl(wlWds0)%>';
var wlWds1_5 = '<%ejGetWl(wlWds1)%>';
var wlWds2_5 = '<%ejGetWl(wlWds2)%>';
var wlWds3_5 = '<%ejGetWl(wlWds3)%>';
var wlMode_5 = '<%ejGetWl(wlMode)%>';
var wlLazyWds_5 = '<%ejGetWl(wlLazyWds)%>'; 

//filter
var mainssid_5 = '<%ejGetWl(wlSsid_wl0v0)%>';
var guestssid1_5 = '<%ejGetWl(wlSsid_wl0v1)%>';
var guestssid2_5 = '<%ejGetWl(wlSsid_wl0v2)%>';
var guestssid3_5 = '<%ejGetWl(wlSsid_wl0v3)%>';

var regrev_5 = '<%ejGetWl(wlRegRev)%>';
var curcountry_5=country_5;


function wl_ewc_options_5(OnPageLoad, id){
   if(phy_5 != "n" && phy_5 != "v")
      return;

   if(OnPageLoad) {
      sel_ch = channel_5;
      sel_nmode = nmode_5;
      sel_nreqd = nreqd_5; 
      sel_band = band_5;
      sel_nbw_cap = nbwcap_5;

      $("select[name=5GhzWlNProtection]").get(0).value= npro_5;

      sel_nmcsidx = nmcsidx_5;
      if(nctrlsb_5 == 0) {
         $("select[name=5GhzWlNCtrlsb]").get(0).selectedIndex = 0;				
         $("select[name=5GhzWlNCtrlsb]").prop("disabled", true);		
      } else{     
         $("select[name=5GhzWlNCtrlsb]").get(0).value = nctrlsb_5;								
      }

      $("select[name=5GhzWlNReqd]").get(0).value = nreqd_24;								

      if(sel_nmode == "off") {
         $("select[name=5GhzWlNmode]").get(0).selectedIndex = 1;
      }
      $("select[name=5GHzMainNTChannelBandWidth]").get(0).value = sel_nbw_cap;								
   } else {
      sel_ch = $("select[name=5GHzMainNTChannel]").val();   
      sel_nmcsidx = $("select[name=5GhzWlNMmcsidx]").val();
      sel_nmode = $("select[name=5GhzWlNmode]").val();
      sel_nreqd = $("select[name=5GhzWlNReqd]").val();
      sel_band = band_5;
      sel_nbw_cap = $("select[name=5GHzMainNTChannelBandWidth]").val();
   }

   if(sel_nmode == "off") {
      $("select[name=5GhzWlNMmcsidx]").prop("disabled", true);
      $("select[name=5GhzWlNProtection]").prop("disabled", true);
      $("select[name=5GhzWlNReqd]").prop("disabled", true);
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", true);	 

      $("#div_nMode_5").hide();
      bw = "20";
   } else {
      $("select[name=5GhzWlNMmcsidx]").prop("disabled", false);
      $("select[name=5GhzWlNProtection]").prop("disabled", false);
      $("select[name=5GhzWlNReqd]").prop("disabled", false);
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", false);	 
      $("#div_nMode_5").show();
      if (sel_nbw_cap == "3")   
         bw = "40";
      else if ((sel_band == "1") && (sel_nbw_cap == "7"))
         bw = "80";
      else
         bw = "20";      
   }  

   $("select[name=5GhzWlNMmcsidx]").prop("disabled", false);

   /* load n phy rates */
   if(sel_ch == 0) {
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", true);
      <%ejGetWl(wlNPhyRates_5, "0");%>   
   } else if (bw == "40") {
      /* Control sb is allowed only for 40MHz BW Channels */   
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", false);
      <%ejGetWl(wlNPhyRates_5, "40");%>
   } else if (bw == "20") {
      $("select[name=5GhzWlNCtrlsb]").get(0).selectedIndex = 0;
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", true);
      <%ejGetWl(wlNPhyRates_24, "20");%>
   } else if (bw == "80") {
      $("select[name=5GhzWlNCtrlsb]").get(0).selectedIndex = 0;
      $("select[name=5GhzWlNCtrlsb]").prop("disabled", true);
      $("select[name=5GhzWlNMmcsidx]").empty();			
      $('select[name=5GhzWlNMmcsidx]').append("<option value='-1'>Auto</option>");	  
      $("select[name=5GhzWlNMmcsidx]").get(0).selectedIndex = 0;			
   }
   $("select[name=5GhzWlNMmcsidx]").get(0).value = sel_nmcsidx;
   /* mark selected */ 
   $("select[name=5GhzWlNmode]").get(0).value = sel_nmode;
}
function loadChannelList_5(OnPageLoad)
{
   var sel_ch;
   var sel_band;
   var sel_nbw_cap;
   var sel_sb;
   var idx;

   /* save selected */   
   if(OnPageLoad) {      
      sel_ch = channel_5;
      sel_band = band_5;
      sel_nbw_cap = nbwcap_5;
      sel_sb = nctrlsb_5;
   } else {
      sel_ch = $("select[name=5GHzMainNTChannel]").val();
      sel_band = band_5;
      sel_nbw_cap = $("select[name=5GHzMainNTChannelBandWidth]").val();
      sel_sb = $("select[name=5GhzWlNCtrlsb]").val();;
   }

   /* load list */

   $("select[name=5GHzMainNTChannel]").empty();
      if ((sel_band == "2") && ((phy_5 != "n") && (phy_5 != "v"))) {
      <%ejGetWl(wlChannelList_5_newgui, b, b, 20)%>
   }
   else  if ((sel_band == "1") && ((phy_5 != "n") && (phy_5 != "v"))) {
      <%ejGetWl(wlChannelList_5_newgui, a, a, 20)%>
   }
   else  if ((sel_band == "2") && (phy_5 == "n") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, n, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, n, b, 40, "lower")%>         
         }            
      } else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_5_newgui, n, b, 20 )%>
      }         
   }
   else  if ((sel_band == "1") && (phy_5 == "n") ) {    
      if(sel_nbw_cap == "1" || sel_nbw_cap == "2") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, n, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, n, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_5_newgui, n, a, 20 )%>
      }         
   }      
   else if ((sel_band == "1") && (phy_5 == "v") && (sel_nbw_cap == "7")) {    
         /* Band a and AC phy and 80M */
      <%ejGetWl(wlChannelList_5_newgui, v, a, 80 )%>
   }
   else  if ((sel_band == "2") && (phy_5 == "v") ) { 
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, v, b, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, v, b, 40, "lower")%>         
         }            
      } else if(sel_nbw_cap == "1"){      
         <%ejGetWl(wlChannelList_5_newgui, v, b, 20 )%>
      }         
   }
   else  if ((sel_band == "1") && (phy_5 == "v")) {    
      if(sel_nbw_cap == "3") {
         if(sel_sb == 1) {
            <%ejGetWl(wlChannelList_5_newgui, v, a, 40, "upper")%>
         } else {
            <%ejGetWl(wlChannelList_5_newgui, v, a, 40, "lower")%>         
         }  
      } else if (sel_nbw_cap == "1") {
         <%ejGetWl(wlChannelList_5_newgui, v, a, 20 )%>
      }         
   }      
   else {
      $("select[name=5GHzMainNTChannel]").append("<option value='0'>Auto</option>");				      
   }

   $("select[name=5GHzMainNTChannel]").get(0).value= sel_ch;   
   if($("select[name=5GHzMainNTChannel]").get(0).selectedIndex == 0){
      $("input[name=5GhzChannelTimer]").prop("disabled", false);
   }      
   else{
      $("input[name=5GhzChannelTimer]").prop("disabled", true);      
   }
}

function wlLoadCountryList_5(OnPageLoad)
{
   $("input[name=wl0RegRev]").val(regrev_5);
   var i = 0;
   if (band_5 == "1") { // 5G  
      <%ejGetWl(wlCountryList_5_newgui,a)%>	  	
   } 

    for (i=0; i< document.forms[11].wl0Country.options.length; i++) {
      if (document.forms[11].wl0Country.options[i].value == country_5) {
         document.forms[11].wl0Country.options[i].selected = true;
         break;
      }
   }

   /* set to all(the last one) if not found */
   if( i == document.forms[11].wl0Country.options.length)
      document.forms[11].wl0Country.options[i-1].selected = true;
   
}