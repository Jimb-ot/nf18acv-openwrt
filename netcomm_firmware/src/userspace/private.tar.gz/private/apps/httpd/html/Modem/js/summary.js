	var index_2 = '<%ejGetWl(switch_index_2)%>';
	var wlStatus_2 = '<%ejGetWl(wlEnbl)%>';
	var wlSsid_2 = '<%ejGetWl(wlSsid)%>';
	var wlChannel_2 = '<%ejGetWl(wlCurrentChannel)%>';
	var wlBandwidth_2 = '<%ejGetWl(wlCurrentBw)%>';
	var wlSecty_2 = '<%ejGetWl(wlAuthMode)%>';
	var wlConnDevs_2 = '<%ejGetWl(wlStationList)%>';


	var index_5 = '<%ejGetWl(switch_index_5)%>';
	var wlStatus_5 = '<%ejGetWl(wlEnbl)%>';
	var wlSsid_5 = '<%ejGetWl(wlSsid)%>';
	var wlChannel_5 = '<%ejGetWl(wlCurrentChannel)%>';
	var wlBandwidth_5 = '<%ejGetWl(wlCurrentBw)%>';
	var wlSecty_5 = '<%ejGetWl(wlAuthMode)%>';
	var wlConnDevs_5 = '<%ejGetWl(wlStationList)%>';

	function	wirelessAppend()
	{
		if(wlStatus_2 == '1')
			$("#wl1Enbl").text("Enabled");
		else
			$("#wl1Enbl").text("Disabled");

		if(wlBandwidth_2 == '1')
			$("#wl1Bandwidth").text("10MHz");
		else if(wlBandwidth_2 == '2')
			$("#wl1Bandwidth").text("20MHz");
		else if(wlBandwidth_2 == '3')
			$("#wl1Bandwidth").text("40MHz");
		else if(wlBandwidth_2 == '4')
			$("#wl1Bandwidth").text("80MHz");

		switch(wlSecty_2)
		{
			case "open":
				$("#wl1Security").text("OPEN");
				break;
			case "shared":
				$("#wl1Security").text("Shared");
				break;
			case "radius":
				$("#wl1Security").text("802.1x");
				break;
			case "wpa2":
				$("#wl1Security").text("WPA2");
				break;
			case "psk2":
				$("#wl1Security").text("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("#wl1Security").text("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("#wl1Security").text("Mixed WPA / WPA2-PSK");
				break;		
		}
			
		$("#wl1Ssid").text(wlSsid_2);
		$("#wl1Channel").text(wlChannel_2);

		var i, devConnArry_2;
		var wlItems_2 = wlConnDevs_2.split('|');

		if(wlItems_2 != '')
		{
			$("#wl2Status").text(wlItems_2.length);
			for(i = 0; i < wlItems_2.length; i++)
			{
				devConnArry_2 = wlItems_2[i].split(',');
				$('#wl24GHzArry tbody').append('<tr><td>' + devConnArry_2[0] + '</td><td>' + devConnArry_2[1] + '</td><td>' + devConnArry_2[2] + '</td><td>' + devConnArry_2[3] + '</td><tr>');
			}
		}
		else
		{
			$("#wl2Status").text("0");
		}


		if(wlStatus_5 == '1')
			$("#wl0Enbl").text("Enabled");
		else
			$("#wl0Enbl").text("Disabled");

		if(wlBandwidth_5 == '1')
			$("#wl0Bandwidth").text("10MHz");
		else if(wlBandwidth_5 == '2')
			$("#wl0Bandwidth").text("20MHz");
		else if(wlBandwidth_5 == '3')
			$("#wl0Bandwidth").text("40MHz");
		else if(wlBandwidth_5 == '4')
			$("#wl0Bandwidth").text("80MHz");

		switch(wlSecty_5)
		{
			case "open":
				$("#wl0Security").text("OPEN");
				break;
			case "shared":
				$("#wl0Security").text("Shared");
				break;
			case "radius":
				$("#wl0Security").text("802.1x");
				break;
			case "wpa2":
				$("#wl0Security").text("WPA2");
				break;
			case "psk2":
				$("#wl0Security").text("WPA2-PSK");
				break;
			case "wpa wpa2":
				$("#wl0Security").text("Mixed WPA / WPA2");
				break;
			case "psk psk2":
				$("#wl0Security").text("Mixed WPA / WPA2-PSK");
				break;		
		}
			
		$("#wl0Ssid").text(wlSsid_5);
		$("#wl0Channel").text(wlChannel_5);

		var devConnArry_5;
		var wlItems_5 = wlConnDevs_5.split('|');
		if(wlItems_5 != '')
		{
			$("#wl5Status").text(wlItems_5.length);		
			for(i = 0; i < wlItems_5.length; i++)
			{
				devConnArry_5 = wlItems_5[i].split(',');
				$('#wl5GHzArry tbody').append('<tr><td>' + devConnArry_5[0] + '</td><td>' + devConnArry_5[1] + '</td><td>' + devConnArry_5[2] + '</td><td>' + devConnArry_5[3] + '</td><tr>');
			}
		}
		else
		{
			$("#wl5Status").text("0");
		}
	}


	function wanInfoStatus()
	{
		var wanParInfo, wanIp, priDns, SecDns, gtwIp;
		var gtwIpAddress = '<%ejGetOther(sysInfo, gtwIpAddress)%>';
		var gtwIpv6Address = '<%ejGetOther(sysInfo, gtwIpv6Address)%>';
		var activeWanIpAddress = '<%ejGetOther(sysInfo, activeWanIpAddress)%>';
		var activeWanIpv6Address = '<%ejGetOther(sysInfo, activeWanIpv6Address)%>';
		var dns1 = '<%ejGetOther(sysInfo, dns1)%>';
		var dns6Pri = '<%ejGetOther(sysInfo, dns6Pri)%>';
		var dns2 = '<%ejGetOther(sysInfo, dns2)%>';
		var dns6Sec = '<%ejGetOther(sysInfo, dns6Sec)%>';

		gtwIp = gtwIpAddress.split('|');
		wanParInfo  = "<tr>";
		wanParInfo += "<td>WAN Gateway IP Address</td>";
		wanParInfo += "<td>" + gtwIp[0] + "</td>";
		wanParInfo += "<td>" + gtwIpv6Address + "</td>";
		wanParInfo += "</tr>";
		wanParInfo += "<tr>";
		wanParInfo += "<td>WAN IP Address</td>";
		wanParInfo += "<td>" + activeWanIpAddress + "</td>";
		wanParInfo += "<td>" + activeWanIpv6Address + "</td>";
		wanParInfo += "</tr>";
		wanParInfo += "<tr>";
		wanParInfo += "<td>Primary DNS Server</td>";
		wanParInfo += "<td>" + dns1 + "</td>";
		wanParInfo += "<td>" + dns6Pri + "</td>";
		wanParInfo += "</tr>";
		wanParInfo += "<tr>";
		wanParInfo += "<td>Secondary DNS Server</td>";
		wanParInfo += "<td>" + dns2 + "</td>";
		wanParInfo += "<td>" + dns6Sec + "</td>";
		wanParInfo += "</tr>";
		
		$("#wanInfo").append(wanParInfo);	

		//show the internet status
		if(gtwIpAddress == "0.0.0.0")
		{
			$("#intStatus").addClass("icon-Cross");
			$("#intStatus").removeClass("icon-Yes");
		}		
		else
		{
			$("#intStatus").addClass("icon-Yes");
			$("#intStatus").removeClass("icon-Cross");
		}	
	}

	function wireDev_voiceInfo()
	{
		var i, tmregstArry, wireDevArry, device, count = 0;
		var tmregst = '<%ejGetVoice(regState)%>';
		var wiredClientList = '<%ejGetOther(wiredClientList)%>';
		
		tmregstArry = tmregst.split(';');

 		for(i = 0; i < tmregstArry.length; i++)
		{
			if(tmregstArry[i].indexOf("Up") > 0 )
			{
				count ++;
			}
		}
		$("#vtpStatus").text(count);

		count = 0;
		wireDevArry = wiredClientList.split('|');
		for(i = 0; i < wiredClientList.length; i++)
		{	
			if(typeof(wireDevArry[i]) != "undefined")
			{
				count ++;
				device = wireDevArry[i].split(',');
				$('#wireDevs tbody').append('<tr><td>' + device[0] + '</td><td>' + device[1] + '</td><td>' + device[2] + '</td></tr>');
			}
		}
		$("#wiredStatus").text(count);
		
	}
