function is_dotted_decimal(address)
{
	var i;

	for(i = 0; i < address.length; i++) {
		if (!((address.charAt(i) == '.')
				|| (address.charAt(i) >= '0' && address.charAt(i) <= '9')))
			return false;
	}
	
	return true;
}

var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function encode(Str)
{
//   alert(Str);	
//   Str = escape(Str);
//   alert(Str);
   var output = "";
   var chr1, chr2, chr3 = "";
   var enc1, enc2, enc3, enc4 = "";
   var i = 0;

   do {
      chr1 = Str.charCodeAt(i++);
      chr2 = Str.charCodeAt(i++);
      chr3 = Str.charCodeAt(i++);
      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;
      if (isNaN(chr2))
      {
         enc3 = enc4 = 64;
      }
      else if (isNaN(chr3))
      {
         enc4 = 64;
      }   
      output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + keyStr.charAt(enc3) + keyStr.charAt(enc4);
      chr1 = chr2 = chr3 = "";
      enc1 = enc2 = enc3 = enc4 = "";
   } while (i < Str.length);
   
   return output;   
}   

//decode
function decode(Str)
{   
   var output = "";
   var chr1, chr2, chr3 = "";
   var enc1, enc2, enc3, enc4 = "";
   var i = 0;
   var base64test = /[^A-Za-z0-9\+\/\=]/g;

   if (base64test.exec(Str)){}

   Str = Str.replace(/[^A-Za-z0-9\+\/\=]/g, "");
   do {
      enc1 = keyStr.indexOf(Str.charAt(i++));
      enc2 = keyStr.indexOf(Str.charAt(i++));
      enc3 = keyStr.indexOf(Str.charAt(i++));
      enc4 = keyStr.indexOf(Str.charAt(i++));
      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;
      output = output + String.fromCharCode(chr1);
      if (enc3 != 64)
      {
         output = output + String.fromCharCode(chr2);
      }
      if (enc4 != 64)
      {
         output = output + String.fromCharCode(chr3);
      }
      chr1 = chr2 = chr3 = "";
      enc1 = enc2 = enc3 = enc4 = "";
   } while (i < Str.length);
//   return unescape(output);
     return output;
}

/* chenlianzhong + : 2009-9-15 */
function isValidNameString( val )
{
	var len = val.length;

    for ( i = 0; i < len; i++ )
    {
        if ( ( val.charAt(i) > '~' )
            || ( val.charAt(i) < '!' ) )
        {
            return false;
        }
    }

    return true;
}

function markDscpToName(mark){
   var i;
   var dscpMarkDesc = new Array ('auto', 'default', 'AF13', 'AF12', 'AF11', 'CS1',
                           'AF23', 'AF22', 'AF21', 'CS2',
                           'AF33', 'AF32', 'AF31', 'CS3',
                           'AF43', 'AF42', 'AF41', 'CS4',
                           'EF', 'CS5', 'CS6', 'CS7', '');
   var dscpMarkValues = new Array(-2, 0x00, 0x38, 0x30, 0x28, 0x20,
                             0x58, 0x50, 0x48, 0x40,
                             0x78, 0x70, 0x68, 0x60,
                             0x98, 0x90, 0x88, 0x80,
                             0xB8, 0xA0, 0xC0, 0xE0);
   if(mark == -1)
   	return '';
   for (i = 0; dscpMarkDesc[i] != ''; i++)
   {
      if (mark == dscpMarkValues[i])
         return dscpMarkDesc[i];
   }
   return dscpMarkDesc[0];
}
   

function isNumber( val )
{
	var len = val.length;
	var sign = 0;

	for( var i = 0; i < len; ++i )
	{
		if( ( val.charAt(i) == '-' ) && ( sign == 0 ) )
		{
			sign = 1;
			continue;
		}

		if( ( val.charAt(i) > '9' )
		    || ( val.charAt(i) < '0' ) )
		{
			return false;
		}
		sign = 1;
	}

	return true;
}
   
function isNum(num)
{
   var i = 0;

   for(i = 0; i < num.length && num.charAt(i) >= '0' && num.charAt(i) <= '9'; i++);
   if (i == num.length)
      return true;
   else
      return false;
}
   
function isHexaDigit(digit) {
   var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                           "A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f");
   var len = hexVals.length;
   var i = 0;
   var ret = false;

   for ( i = 0; i < len; i++ )
      if ( digit == hexVals[i] ) break;

   if ( i < len )
      ret = true;

   return ret;
}

function isDecDigit(digit) {
   var DecVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
   var len = DecVals.length;
   var i = 0;
   var ret = false;

   for ( i = 0; i < len; i++ )
      if ( digit == DecVals[i] ) break;

   if ( i < len )
      ret = true;

   return ret;
}

function isValidDecNum(val) {
   for (var i = 0; i < val.length; i++ )
      if ( isDecDigit(val.charAt(i)) == false )
         return false;

   return true;
}
function isNumber( val )
{
	var len = val.length;
	var sign = 0;

	for( var i = 0; i < len; ++i )
	{
		if( ( val.charAt(i) == '-' ) && ( sign == 0 ) )
		{
			sign = 1;
			continue;
		}

		if( ( val.charAt(i) > '9' )
		    || ( val.charAt(i) < '0' ) )
		{
			return false;
		}
		sign = 1;
	}

	return true;
}

function isValidKey(val, size) {
   var ret = false;
   var len = val.length;
   var dbSize = size * 2;

   if ( len == size )
      ret = true;
   else if ( len == dbSize ) {
      for ( i = 0; i < dbSize; i++ )
         if ( isHexaDigit(val.charAt(i)) == false )
            break;
      if ( i == dbSize )
         ret = true;
   } else
      ret = false;

   return ret;
}

function isValidIpAddress_dhcpDevice(address){
   var i = 0;

   if ( address == '255.255.255.255' )
      return false;

   addrParts = address.split('.');
   if ( addrParts.length != 4 ) return false;
   for (i = 0; i < 4; i++) {
      if (isNaN(addrParts[i]) || addrParts[i] =="")
         return false;
      num = parseInt(addrParts[i]);
      if ( num < 0 || num > 255 )
         return false;
   }
   return true;
}
function isValidDigit(digit) {
   var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
   var len = hexVals.length;
   var i = 0;
   var ret = false;

   for ( i = 0; i < len; i++ )
      if ( digit == hexVals[i] ) break;

   if ( i < len )
      ret = true;

   return ret;
}
function isValidServerPort(val){
   var ret = false;
   var max = 65535;
   var min = 0;
   if((val.length > 1) &&(val.charAt(0) == '0'))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
   	   if (( val <= max) &&( val >= min))
	         ret = true;
	     else
	        ret = false;
   }

   return ret;
}
function isValidServerPortforH248(val){
   var ret = false;
   var max = 65535;
   var min = 0;

    if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' '))||(val.length == 0))
   {
	return false;
   }

   if (( val < max) &&( val > min))  /*1 to 65534, Hw xml need*/
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}

function isValidClientPortforH248(min, max, val)
{
	var ret = false;
	if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' '))||(val.length == 0))
    {
       return false;
	}

	if ((val <= max) && (val >= min))
	{
	   ret = true;
	}
	else{
		ret = false;
	}
	return ret;


}
function isValidValueforH248(val)
{
   var ret = false;
   var min = 0;

    if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' ')))
   {
	return false;
   }

   if (val > min)
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}
function isValidValue2forH248(min,max,val)
{
   var ret = false;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' ')) || (val.length == 0))
   {
	return false;
   }

   if ((val >= min)&&(val <=max))
   {
         ret = true;
   }
   else
   {
         ret = false;
   }
   return ret;
}
function isValidValue(val)
{
   var ret = false;
   var min = 0;
    var i=0;
    if((val.length > 1) &&(val.charAt(0) == '0'))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
        if (val > min)
        {
            ret = true;
        }
        else
        {
            ret = false;
        }
   }
   return ret;
}
function isValidValue0(val)
{
   var ret = false;
   var min = 0;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
        ||(val.length == 0))
   {
	return false;
   }

   if (val >= min)
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}
function isValidValue2(min,max,val)
{
   var ret = false;
   var i=0;

   if(((val.length > 1) &&(val.charAt(0) == '0'))||(val.length==0))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
   	   if (( val <= max) &&( val >= min))
	         ret = true;
	     else
	        ret = false;
   }
   return ret;
}

function isValidSessionTimer(val,mse)
{
   var ret = false;
   var zero = 0;
   var min = 90;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
        ||(val.length == 0))
   {
      return false;
   }

   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }

   if( val == zero)
   {
      ret = true;
   }
   else
   {
      if( eval(val) >= eval(mse) )
      {
         if ( val >= min || val == zero )
         {
            ret = true;
         }
         else
         {
            ret = false;
         }
      }
      else
      {
         ret = false;
      }
   }
   return ret;
}

function isValidMinSessionTimer(val,se)
{
   var ret = false;
   var zero = 0;
   var min = 90;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
         ||(val.length == 0))
   {
      return false;
   }

   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }

   if( se == zero)
   {
       if( val >= min || val == zero )
       {
         ret = true;
       }
	   else
       {
         ret = false;
       }
   }
   else
   {
      if( eval(val) <= eval(se) )
      {
         if( val >= min || val == zero )
         {
            ret = true;
         }
         else
         {
            ret = false;
         }
      }
	  else
	  {
	     ret = false;
	  }
   }
   return ret;
}
function isEqualValue(var1,var2)
{
  if( var1 == var2 )
  {
     return true;
  }
  else
  {
     return false;
  }
}
function isValidLenforH248(max,val)
{
   if((val.length < max)&&(val.length > 0))
   return true;
   else
   return false;
}

function isValidLenforH248TermName(max,val)
{
   if((val.length < max)&&(val.length >= 0))
   return true;
   else
   return false;
}
function isValidforH248RtpName(max, val)
{
   if((val.length < max)&&(val.length > 0))
   {
	if (val.indexOf(" ") != -1)	
	  	return false;
	  else	  	
        return true;
   }
   else
   return false;
}
function isValidLen(max,val)
{
   if(val.length < max)
   return true;
   else
   return false;
}
function isValueNull(val1,val2)
{
	if((val1.length == 0)&&(val2.length == 0))
	return true;
	else
	return false;
}

function MacAddrCompare(mac1, mac2)
{
	mac1a = mac1.split(':');
	mac2a = mac2.split(':');

	for(i=0; i<6; i++) {
		mac1a_n = parseInt(mac1a[i]);
		alert(mac1a_n);
		mac2a_n = parseInt(mac2a[i]);

		if(mac1a_n != mac2a_n) {
			return 1;
		}
	}

	if(i == 6)
		return 0;
}
function isValidLenAndValue(min,max,val)
{
	 var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                           "A", "B", "C", "D", "E", "F","G","H","I","J","K","L","M","N","O","P",
                           "Q","R","S","T","U","V","W","X","Y","Z", "a", "b", "c", "d", "e", "f","g",
                           "h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");

	if((val.length > 1) &&(val.charAt(0) == ' '))
	 {
		return false;
	 }

	var len = hexVals.length;
	var i = 0;
	var j = 0;

	for(j = 0;j < val.length; j++)
	{
		for ( i = 0; i < len; i++ )
			if ( val.charAt(j) == hexVals[i] ) break;

		if(i == len)
		{
			return false;
		}
	}

	if((val.length > max)||(val.length < min))
	{
		return false;
	}
	else
		return true;
}

function isValidMGCAddress(len,address)
{
	var hexVals = new Array("0","1","2","3","4","5","6","7","8","9",".");
	var le = hexVals.length;
	var i,j;
	var ret = true;
	for(j = 0;j < address.length; j++)
	{
		for ( i = 0; i < le; i++ )
			if ( address.charAt(j) == hexVals[i] ) break;

		if(i == le)
		{
			ret = false;
		}
	}

	if(ret == false)
	{
		if(address.length <= len)
			return true;
		else
		{
			return false;
		}
	}
	else
	{
		if ( address == '255.255.255.255' )
		{
			return false;
		}

		addrPartss = address.split('.');
		if ( addrPartss.length != 4 )
			return false;
		for (i = 0; i < 4; i++)
		{
			if (isNaN(addrPartss[i]) || addrPartss[i] =="")
			{
				return false;
			}
			num = parseInt(addrPartss[i]);
			if ( num < 0 || num > 255 )
			{
				return false;
			}
		}
		return true;
	}
}
function isValidJitterBuffer(val){
    var max = 180;
    var min = 0;
    if (val == 'auto'){
      return true; }

    if((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
   {
	return false;
   }

   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }

   if (val > min && val < max ){
        return true;  }
   else if (val == min || val == max){
   	return true;}
   else {
     return false;  }
   }
function isValidDigiMap(val){
    var ret = true;
    var i,j;

    var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                            "A", "B", "C", "D", "#", "|", "*", "T", "[", "]",
                            "+", "-", ".", "x", "X", "t");
    var len = hexVals.length;

    for ( i = 0; i < val.length; i++ )
    {
      for ( j = 0; j < len; j++ )
      {
        if ( val.charAt(i) == hexVals[j] )
            break;
      }

      if ( j == len )
        return false;
    }

    return ret;
}
function isValidDialDigit(val){
    var ret = true;
    var i,j;

    var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                            "A", "B", "C", "D", "#", "*", "|");
    var len = hexVals.length;

    for ( i = 0; i < val.length; i++ )
    {
      for ( j = 0; j < len; j++ )
      {
        if ( val.charAt(i) == hexVals[j] )
            break;
      }

      if ( j == len )
        return false;
    }

    return ret;
}


function isValidHexKey(val, size) {
   var ret = false;
   if (val.length == size) {
      for ( i = 0; i < val.length; i++ ) {
         if ( isHexaDigit(val.charAt(i)) == false ) {
            break;
         }
      }
      if ( i == val.length ) {
         ret = true;
      }
   }

   return ret;
}


function isNameUnsafe(compareChar) {
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.: \t";
	
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}   

function isIncludeInvalidChar(name) {
   var i = 0;

   for ( i = 0; i < name.length; i++ ) {
      if ( isTextUnsafe(name.charAt(i)) == true )
         return true;
   }

   return false;
}

function isTextUnsafe(compareChar){
	var unsafeString = "\"\\`\+\,='\t;";

   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}

function isNameUnsafeII(compareChar)
{
    var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:/*();?! \t";

    if((unsafeString.indexOf(compareChar) == -1)&&
        (compareChar.charCodeAt(0) > 32)&&
        (compareChar.charCodeAt(0) < 123))
        return false;
    else
        return true;
}

function isValidNameII(name)
{
    var i = 0;

    for(i=0; i<name.length; i++) {
        if(isNameUnsafeII(name.charAt(i)) == true)
            return false;
    }

    return true;
}

// Check if a name valid
function isValidName(name) {
   var i = 0;	
   
   for ( i = 0; i < name.length; i++ ) {
      if ( isNameUnsafe(name.charAt(i)) == true )
         return false;
   }

   return true;
}

// same as is isNameUnsafe but allow spaces
function isCharUnsafe(compareChar) {
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";

   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}
function isNameInvalid(compareChar) {
   var unsafeString = " ";
	
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
} 
// Check if a URL valid
//add fields and modify error checks
//check if the name is URL friendly
//Function Name: isValidName(name[,fieldname])
//Description: Check that name contains no unnecessary characters
//Parameters: name, fieldname(optional): show error message when error encountered		
//output: true:no error		false: error
function isValidUrl(name,fieldname) {
   var i = 0;
   for ( i = 0; i < name.length; i++ ) {
	      if ( isNameInvalid(name.charAt(i)) == true )
		  {
			alert (fieldname + " " + name + " contain blank character!");
	              return false;
		  }
	   }
   return true;
}

function isValidNameWSpace(name) {
   var i = 0;

   for ( i = 0; i < name.length; i++ ) {
      if ( isCharUnsafe(name.charAt(i)) == true )
         return false;
   }

   return true;
}

function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {

   var count = 0;

   lan1a = lan1Ip.split('.');
   lan1m = lan1Mask.split('.');
   lan2a = lan2Ip.split('.');
   lan2m = lan2Mask.split('.');

   for (i = 0; i < 4; i++) {
     var  l1a_n = parseInt(lan1a[i],10);
     var  l1m_n = parseInt(lan1m[i],10);
     var  l2a_n = parseInt(lan2a[i],10);
     var  l2m_n = parseInt(lan2m[i],10);
	 
      if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
         count++;
   }
   if (count == 4)
      return true;
   else
      return false;
}

function IpAddrCompare(ip1, ip2)
{
	ip1a = ip1.split('.');
	ip2a = ip2.split('.');

	for(i = 0; i < 4; i++)
	{
		ip1a_n = parseInt(ip1a[i]);
		ip2a_n = parseInt(ip2a[i]);

		if(ip1a_n > ip2a_n)
		{
			return 1;
		}
		else if(ip1a_n < ip2a_n)
		{
			return -1;
		}
		else
		{
			continue;
		}
	}

	if(i == 4)
		return 0;
}

function IpAddrSameByteNums(ip1, ip2)
{
	var	count = 0;

	ip1a = ip1.split('.');
	ip2a = ip2.split('.');

	for(i = 0; i < 4; i++)
	{
		ip1a_n = parseInt(ip1a[i]);
		ip2a_n = parseInt(ip2a[i]);

		if(ip1a_n == ip2a_n)
		{
			count++;
		}
		else
		{
			break;
		}
	}

	return count;
}

function IpSpanIsTooLarge(ip1, ip2, ip3, ip4) {

	var ip1a = ip1.split('.');
	var ip2a = ip2.split('.');
	var ip3a = ip3.split('.');
	var ip4a = ip4.split('.');

	var ip1a_n = parseInt(ip1a[0]) * 255 * 255 * 255 +
		parseInt(ip1a[1]) * 255 * 255 + parseInt(ip1a[2]) * 255 + parseInt(ip1a[3]);
	var ip2a_n = parseInt(ip2a[0]) * 255 * 255 * 255 +
		parseInt(ip2a[1]) * 255 * 255 + parseInt(ip2a[2]) * 255 + parseInt(ip2a[3]);
	var ip3a_n = parseInt(ip3a[0]) * 255 * 255 * 255 +
		parseInt(ip3a[1]) * 255 * 255 + parseInt(ip3a[2]) * 255 + parseInt(ip3a[3]);
	var ip4a_n = parseInt(ip4a[0]) * 255 * 255 * 255 +
		parseInt(ip4a[1]) * 255 * 255 + parseInt(ip4a[2]) * 255 + parseInt(ip4a[3]);

	if(ip2 != "" && ip2a_n - ip1a_n > 100)
		return 1;
	if(ip4 != "" && ip4a_n - ip3a_n > 100)
		return 1;
	if(ip2 != "" && ip4 != "" && (ip2a_n - ip1a_n) *  (ip4a_n - ip3a_n)> 100)
		return 1;

	return 0;
}


// same as is isNameUnsafe but allow spaces
function isCharUnsafe(compareChar) {
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";

   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}

function isValidNameWSpace(name) {
   var i = 0;

   for ( i = 0; i < name.length; i++ ) {
      if ( isCharUnsafe(name.charAt(i)) == true )
         return false;
   }

   return true;
}

function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {

   var count = 0;

   lan1a = lan1Ip.split('.');
   lan1m = lan1Mask.split('.');
   lan2a = lan2Ip.split('.');
   lan2m = lan2Mask.split('.');

   for (i = 0; i < 4; i++) {
     var  l1a_n = parseInt(lan1a[i],10);
     var  l1m_n = parseInt(lan1m[i],10);
     var  l2a_n = parseInt(lan2a[i],10);
     var  l2m_n = parseInt(lan2m[i],10);
	 
      if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
         count++;
   }
   if (count == 4)
      return true;
   else
      return false;
}

function IpAddrCompare(ip1, ip2)
{
	ip1a = ip1.split('.');
	ip2a = ip2.split('.');

	for(i = 0; i < 4; i++)
	{
		ip1a_n = parseInt(ip1a[i]);
		ip2a_n = parseInt(ip2a[i]);

		if(ip1a_n > ip2a_n)
		{
			return 1;
		}
		else if(ip1a_n < ip2a_n)
		{
			return -1;
		}
		else
		{
			continue;
		}
	}

	if(i == 4)
		return 0;
}

function IpAddrSameByteNums(ip1, ip2)
{
	var	count = 0;

	ip1a = ip1.split('.');
	ip2a = ip2.split('.');

	for(i = 0; i < 4; i++)
	{
		ip1a_n = parseInt(ip1a[i]);
		ip2a_n = parseInt(ip2a[i]);

		if(ip1a_n == ip2a_n)
		{
			count++;
		}
		else
		{
			break;
		}
	}

	return count;
}

function IpSpanIsTooLarge(ip1, ip2, ip3, ip4) {

	var ip1a = ip1.split('.');
	var ip2a = ip2.split('.');
	var ip3a = ip3.split('.');
	var ip4a = ip4.split('.');

	var ip1a_n = parseInt(ip1a[0]) * 255 * 255 * 255 +
		parseInt(ip1a[1]) * 255 * 255 + parseInt(ip1a[2]) * 255 + parseInt(ip1a[3]);
	var ip2a_n = parseInt(ip2a[0]) * 255 * 255 * 255 +
		parseInt(ip2a[1]) * 255 * 255 + parseInt(ip2a[2]) * 255 + parseInt(ip2a[3]);
	var ip3a_n = parseInt(ip3a[0]) * 255 * 255 * 255 +
		parseInt(ip3a[1]) * 255 * 255 + parseInt(ip3a[2]) * 255 + parseInt(ip3a[3]);
	var ip4a_n = parseInt(ip4a[0]) * 255 * 255 * 255 +
		parseInt(ip4a[1]) * 255 * 255 + parseInt(ip4a[2]) * 255 + parseInt(ip4a[3]);

	if(ip2 != "" && ip2a_n - ip1a_n > 100)
		return 1;
	if(ip4 != "" && ip4a_n - ip3a_n > 100)
		return 1;
	if(ip2 != "" && ip4 != "" && (ip2a_n - ip1a_n) *  (ip4a_n - ip3a_n)> 100)
		return 1;

	return 0;
}


// same as is isNameUnsafe but allow spaces
function isCharUnsafe(compareChar) {
   var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";
	
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}   

function isValidNameWSpace(name) {
   var i = 0;	
   
   for ( i = 0; i < name.length; i++ ) {
      if ( isCharUnsafe(name.charAt(i)) == true )
         return false;
   }

   return true;
}

function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {

   var count = 0;
   
   lan1a = lan1Ip.split('.');
   lan1m = lan1Mask.split('.');
   lan2a = lan2Ip.split('.');
   lan2m = lan2Mask.split('.');

   for (i = 0; i < 4; i++) {
      l1a_n = parseInt(lan1a[i]);
      l1m_n = parseInt(lan1m[i]);
      l2a_n = parseInt(lan2a[i]);
      l2m_n = parseInt(lan2m[i]);
      if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
         count++;
   }
   if (count == 4)
      return true;
   else
      return false;
}


function isValidIpAddress(address) {    
   ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      num = parseInt(ipParts[1]);
      if (num <= 0 || num > 32)
         return false;
   }

   if (ipParts[0] == '0.0.0.0' ||
       ipParts[0] == '255.255.255.255' )
      return false;

   addrParts = ipParts[0].split('.');
   if ( addrParts.length != 4 ) return false;
   for (kk = 0; kk < 4; kk++) {
      if (isNaN(addrParts[kk]) || addrParts[kk] =="")
         return false;
      num = parseInt(addrParts[kk]);
      if ( num < 0 || num > 255 )
         return false;
   }
   num = parseInt(addrParts[0]);
   if((num < 1)||(num == 127)||(num >223))
   {
        return false;
   }
   var newadd =String(parseInt(addrParts[0])) + '.' + String(parseInt(addrParts[1])) + '.' + 
        String(parseInt(addrParts[2])) + '.' +String(parseInt(addrParts[3]));
   if(newadd != ipParts[0])
   {
        return false;    
   }
   return true;   
}


function isValidIpAddress2(address) {    
   ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      num = parseInt(ipParts[1]);
      if (num <= 0 || num > 32)
         return false;
   }

   if (ipParts[0] == '0.0.0.0' ||
       ipParts[0] == '255.255.255.255' )
      return false;

   addrParts = ipParts[0].split('.');
   if ( addrParts.length != 4 ) return false;
   for (kk = 0; kk < 4; kk++) {
      if (isNaN(addrParts[kk]) || addrParts[kk] =="")
         return false;
      num = parseInt(addrParts[kk]);
      if ( num < 0 || num > 255 )
         return false;
   }
   num = parseInt(addrParts[0]);
   if((num < 1)||(num == 127)||(num >223))
   {
        return false;
   }
   num = parseInt(addrParts[3]);
   if((num == 0) || (num == 255))
   {
        return false;
   }
   var newadd =String(parseInt(addrParts[0])) + '.' + String(parseInt(addrParts[1])) + '.' + 
        String(parseInt(addrParts[2])) + '.' +String(parseInt(addrParts[3]));
   if(newadd != ipParts[0])
   {
        return false;    
   }
   return true;   
}

function isValidIpAddress_all(address) {

   ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      num = parseInt(ipParts[1]);
      if (num <= 0 || num > 32)
         return false;
   }

   if (ipParts[0] == '0.0.0.0' ||
       ipParts[0] == '255.255.255.255' )
      return false;

   addrParts = ipParts[0].split('.');
   if ( addrParts.length != 4 ) return false;
   for (i = 0; i < 4; i++) {
      if (isNaN(addrParts[i]) || addrParts[i] =="")
         return false;
      num = parseInt(addrParts[i]);
      if ( num < 0 || num > 255 )
         return false;
   }
   return true;
}


function IpStrToNum(ipstr)
{
    var ipa =ipstr.split('.');
    var ipnum = (parseInt(ipa[0])<<24) + (parseInt(ipa[1])<<16) + (parseInt(ipa[2])<<8) + (parseInt(ipa[3])<<0);
    return ipnum;
}

function isValidMaskAddress(address) {
   var ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      var num = parseInt(ipParts[1]);
      if (num <= 0 || num > 32)
         return false;
   }

   if (ipParts[0] == '0.0.0.0' ||
       ipParts[0] == '255.255.255.255' )
      return false;

   var addrP = ipParts[0].split('.');
   if ( addrP.length != 4 ) return false;
   
   for (var i = 0; i < 4; i++) {
      if (isNaN(addrP[i]) || addrP[i] =="")
         return false;
      var num = parseInt(addrP[i]);
      if ( num < 0 || num > 255 )
         return false;   
   }
   
   var nmsk = (parseInt(addrP[0])<<24) + (parseInt(addrP[1])<<16) + (parseInt(addrP[2])<<8) + (parseInt(addrP[3])<<0);
    var posb =0;
    var posz =0;
    for(j =1; j <33; j++) 
    {
        if(!(nmsk&1)) 
        {
            posz++;   
        }
        else if(!posb)
        {
            posb =j;
        }
        nmsk >>=1;
    }
    if((posz >= posb)||!posz || !posb)
    {
        return false;
    }
   return true;   
}

function isIpFitMask(ip, mask)
{
    var addrip = ip.split('.');
   	var maskip = mask.split('.');
	var naddr = (parseInt(addrip[0])<<24) + (parseInt(addrip[1])<<16) + (parseInt(addrip[2])<<8) + (parseInt(addrip[3])<<0);
	var nmask = (parseInt(maskip[0])<<24) + (parseInt(maskip[1])<<16) + (parseInt(maskip[2])<<8) + (parseInt(maskip[3])<<0);
	var nsubip = naddr&(~nmask);
	if((nsubip == 0) || (nsubip == ~nmask) || (nsubip == naddr))
	{
	    return false;
	}
	return true;
}

function isValidIpAddressAndIsIpFitMask(address) {    
	var num, addrParts, mskNum;
	var flag = 0;
   var ipParts = address.split('/');
   if (ipParts.length > 2) 
   	{
   	   	alert("11");

		return false;
   	}
   if (ipParts.length == 2) 
	{
		flag = 1;
      mskNum = parseInt(ipParts[1]);
      if (mskNum <= 0 || mskNum > 32)
      	{
      	   	alert("22");

         return false;
      	}
   }

   if (ipParts[0] == '0.0.0.0' || ipParts[0] == '255.255.255.255' )
   	{   	alert("33");

      return false;
   	}

   addrParts = ipParts[0].split('.');
   if ( addrParts.length != 4 ) 
   	{   	alert("44");

		return false;
   	}
   for (var kk = 0; kk < 4; kk++) {
      if (isNaN(addrParts[kk]) || addrParts[kk] =="")
      	{   	alert("55");

         return false;
      	}
      num = parseInt(addrParts[kk]);
      if ( num < 0 || num > 255 )
      	{
      	   	alert("66");

         return false;
      	}
   }
   num = parseInt(addrParts[0]);
   if((num < 1) || (num == 127) || (num >223))
   {
      	   	alert("77");
   
		return false;
   }
   var newadd = String(parseInt(addrParts[0])) + '.' + String(parseInt(addrParts[1])) + '.' + 
        String(parseInt(addrParts[2])) + '.' + String(parseInt(addrParts[3]));
   if(newadd != ipParts[0])
   {
   	alert("88");
		return false;    
   }
	if(flag)
	{
		var addr = 0xffffffff << (32 - parseInt(ipParts[1]));
		var mask1 = (addr >> 24) & 0xff;
		var mask2 = (addr >> 16) & 0xff;
		var mask3 = (addr >> 8) & 0xff;
		var mask4 = addr & 0xff;	
		var naddr = (parseInt(addrParts[0])<<24) + (parseInt(addrParts[1])<<16) + (parseInt(addrParts[2])<<8) + (parseInt(addrParts[3])<<0);
		var nmask = (mask1 << 24) + (mask2 << 16) + (mask3 << 8) + (mask4 << 0);
		var nsubip = naddr&(~nmask);
		if((nsubip == 0) || (nsubip == ~nmask) || (nsubip == naddr))
			{
			alert("mask");
			return false;
			}
	}
   return true;   
}

function isValidPrefixAddress(address) {
   var i = 0, num = 0;
   var space=0;
   addrParts = address.split(':');
   if (addrParts.length < 3 || addrParts.length > 8)
      return false;
   for (i = 0; i < addrParts.length; i++) {
      if ( addrParts[i] != "" && isValidHexKey(addrParts[i],addrParts[i].length) )
         num = parseInt(addrParts[i], 16);
	  else
	   {
		  space++;
		  if(space>1 && (i + 1) != addrParts.length)
		  return false;
		  continue;
	   }
      if ( i == 0 ) {
         if ( (num & 0xf000) == 0xf000 )
            return false;	//can not be link-local, site-local or multicast address
      }
/*      else if ( (i + 1) == addrParts.length) {
         if ( num == 0 || num == 1)
            return false;	//can not be unspecified or loopback address
      }*/
      if ( num > 0xffff || num < 0 )
         return false;
   }
   return true;
}

/*add by hongj on 20071219 for web vality check, bugfree 0003485*/
function isValidServerPort(val){
   var ret = false;
   var max = 65535;
   var min = 0;
/*mod by hongj on 20090216 for prot vality check*/
   var i = 0;
/*
    if((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
   {
	return false;
   }

   if (( val <= max) &&( val >= min))
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
 */
   if((val.length > 1) &&(val.charAt(0) == '0'))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
   	   if (( val <= max) &&( val >= min))
	         ret = true;
	     else
	        ret = false;
   }

   return ret;
   /*mod by hongj end*/
}
/*migrate by LiangJm for migrating H.248 from e8-c,  bugfree: 0012485 */
function isValidServerPortforH248(val){
   var ret = false;
   var max = 65535;
   var min = 0;

    if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' '))||(val.length == 0))
   {
	return false;
   }

   if (( val < max) &&( val > min))  /*1 to 65534, Hw xml need*/
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}

/*add by LiangJm on 20090311 for Hw requirements*/
function isValidClientPortforH248(min, max, val)
{
	var ret = false;
	if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' '))||(val.length == 0))
    {
       return false;
	}

	if ((val <= max) && (val >= min))
	{
	   ret = true;
	}
	else{
		ret = false;
	}
	return ret;


}
/*LiangJm add end*/
function isValidValueforH248(val)
{
   var ret = false;
   var min = 0;

    if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' ')))
   {
	return false;
   }

   if (val > min)
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}
function isValidValue2forH248(min,max,val)
{
   var ret = false;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
		||((val.length == 1)&&(val.charAt(0) == ' ')) || (val.length == 0))
   {
	return false;
   }

   if ((val >= min)&&(val <=max))
   {
         ret = true;
   }
   else
   {
         ret = false;
   }
   return ret;
}
/*LiangJm migrate end*/
/*add by hongj on 20080320*/
function isValidValue(val)
{
   var ret = false;
   var min = 0;
 /*mod by hongj on 20090219 for voip web validity check*/
 /*
   if((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
   {
	return false;
   }

   if (val > min)
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
 */
    var i=0;
    if((val.length > 1) &&(val.charAt(0) == '0'))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
        if (val > min)
        {
            ret = true;
        }
        else
        {
            ret = false;
        }
   }
   return ret;
/*mod by hongj end*/
}
/*add by hongj end*/
/* add by linjl on 20081028 */
function isValidValue0(val)
{
   var ret = false;
   var min = 0;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
        ||(val.length == 0))
   {
	return false;
   }

   if (val >= min)
   	{
         ret = true;
     }
   else{
        ret = false;
   }
   return ret;
}
/* add by linjl end */
function isValidValue2(min,max,val)
{
   var ret = false;
 /*mod by hongj on 20090219 for voip web validity check*/
 /*
    if((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
   {
	return false;
   }

   if ((val >= min)&&(val <=max))
   {
         ret = true;
   }
   else
   {
         ret = false;
   }
   return ret;
   */
   var i=0;

   if(((val.length > 1) &&(val.charAt(0) == '0'))||(val.length==0))
   {
			return false;
   }

   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i == val.length )
   {
       ret = true;
   }

   if(ret == true)
   {
   	   if (( val <= max) &&( val >= min))
	         ret = true;
	     else
	        ret = false;
   }
   return ret;
   /*mod by hongj end*/
}

/* add by linjl on 20081028 */
function isValidSessionTimer(val,mse)
{
   var ret = false;
   var zero = 0;
   var min = 90;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
        ||(val.length == 0))
   {
      return false;
   }

   /*mod by hongj on 20090219 for voip web validity check*/
   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }
   /*mod by hongj end*/

   if( val == zero)
   {
      ret = true;
   }
   else
   {
      if( eval(val) >= eval(mse) )
      {
         if ( val >= min || val == zero )
         {
            ret = true;
         }
         else
         {
            ret = false;
         }
      }
      else
      {
         ret = false;
      }
   }
   return ret;
}

function isValidMinSessionTimer(val,se)
{
   var ret = false;
   var zero = 0;
   var min = 90;

   if(((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
         ||(val.length == 0))
   {
      return false;
   }

   /*mod by hongj on 20090219 for voip web validity check*/
   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }
   /*mod by hongj end*/

   if( se == zero)
   {
       if( val >= min || val == zero )
       {
         ret = true;
       }
	   else
       {
         ret = false;
       }
   }
   else
   {
      if( eval(val) <= eval(se) )
      {
         if( val >= min || val == zero )
         {
            ret = true;
         }
         else
         {
            ret = false;
         }
      }
	  else
	  {
	     ret = false;
	  }
   }
   return ret;
}
/* add by linjl end */
/* add by linjl on 20090210 for vbd redundancy using rfc2198 */
function isEqualValue(var1,var2)
{
  if( var1 == var2 )
  {
     return true;
  }
  else
  {
     return false;
  }
}
/* add by linjl end */
/*migrate by LiangJm for migrating H.248 from e8-c,  bugfree: 0012485 */
function isValidLenforH248(max,val)
{
   if((val.length < max)&&(val.length > 0))
   return true;
   else
   return false;
}

function isValidLenforH248TermName(max,val)
{
   if((val.length < max)&&(val.length >= 0))
   return true;
   else
   return false;
}
/*LiangJm migrate end*/
/*add by LiangJm on 20090330 for Bell SS using more than one rtp name*/
function isValidforH248RtpName(max, val)
{
   if((val.length < max)&&(val.length > 0))
   {
	/*mod by LJm on 20090531 for rtp name may be not include "/"*/
	/*if (val.indexOf("/") == -1 || val.indexOf(" ") != -1)*/
	if (val.indexOf(" ") != -1)	
	/*Ljm mod end*/
	  	return false;
	  else	  	
        return true;
   }
   else
   return false;
}
/*LiangJm add end*/
function isValidLen(max,val)
{
   if(val.length < max)
   return true;
   else
   return false;
}
/*migrate by LiangJm for migrating H.248 from e8-c,  bugfree: 0012485 */
function isValueNull(val1,val2)
{
	if((val1.length == 0)&&(val2.length == 0))
	return true;
	else
	return false;
}

/*LiangJm migrate end*/
function MacAddrCompare(mac1, mac2)
{
	mac1a = mac1.split(':');
	mac2a = mac2.split(':');

	for(i=0; i<6; i++) {
		mac1a_n = parseInt(mac1a[i]);
		alert(mac1a_n);
		mac2a_n = parseInt(mac2a[i]);

		if(mac1a_n != mac2a_n) {
			return 1;
		}
	}

	if(i == 6)
		return 0;
}
/*migrate by LiangJm for migrating H.248 from e8-c,  bugfree: 0012485 */
function isValidLenAndValue(min,max,val)
{
	 var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                           "A", "B", "C", "D", "E", "F","G","H","I","J","K","L","M","N","O","P",
                           "Q","R","S","T","U","V","W","X","Y","Z", "a", "b", "c", "d", "e", "f","g",
                           "h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");

	if((val.length > 1) &&(val.charAt(0) == ' '))
	 {
		return false;
	 }

	var len = hexVals.length;
	var i = 0;
	var j = 0;

	for(j = 0;j < val.length; j++)
	{
		for ( i = 0; i < len; i++ )
			if ( val.charAt(j) == hexVals[i] ) break;

		if(i == len)
		{
			return false;
		}
	}

	if((val.length > max)||(val.length < min))
	{
		return false;
	}
	else
		return true;
}

function isValidMGCAddress(len,address)
{
	var hexVals = new Array("0","1","2","3","4","5","6","7","8","9",".");
	var le = hexVals.length;
	var i,j;
	var ret = true;
	for(j = 0;j < address.length; j++)
	{
		for ( i = 0; i < le; i++ )
			if ( address.charAt(j) == hexVals[i] ) break;

		if(i == le)
		{
			ret = false;
		}
	}

	if(ret == false)
	{
		if(address.length <= len)
			return true;
		else
		{
			return false;
		}
	}
	else
	{
		if ( address == '255.255.255.255' )
		{
			return false;
		}

		addrPartss = address.split('.');
		if ( addrPartss.length != 4 )
			return false;
		for (i = 0; i < 4; i++)
		{
			if (isNaN(addrPartss[i]) || addrPartss[i] =="")
			{
				return false;
			}
			num = parseInt(addrPartss[i]);
			if ( num < 0 || num > 255 )
			{
				return false;
			}
		}
		return true;
	}
}
/*LiangJm migrate end*/
function isValidJitterBuffer(val){
    var max = 180;
    var min = 0;
    if (val == 'auto'){
      return true; }

    if((val.length > 1) &&((val.charAt(0) == ' ')||(val.charAt(0) == '0')))
   {
	return false;
   }

  /*mod by hongj on 20090219 for voip web validity check*/
   var i = 0;
   for(i;i<val.length;i++)
   {
      if ( isValidDigit(val.charAt(i)) == false )
        break;
   }
   if ( i != val.length )
   {
       return false;
   }
   /*mod by hongj end*/

   if (val > min && val < max ){
        return true;  }
   else if (val == min || val == max){
   	return true;}
   else {
     return false;  }
   }
/* add by hongj on 20090302 for web validity check for digimap */
function isValidDigiMap(val){
    var ret = true;
    var i,j;

    var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                            "A", "B", "C", "D", "#", "|", "*", "T", "[", "]",
                            "+", "-", ".", "x", "X", "t");
    var len = hexVals.length;

    for ( i = 0; i < val.length; i++ )
    {
      for ( j = 0; j < len; j++ )
      {
        if ( val.charAt(i) == hexVals[j] )
            break;
      }

      if ( j == len )
        return false;
    }

    return ret;
}
/* add end */
/* add by linjl on 20090908 for dialstring prefix */
function isValidDialDigit(val){
    var ret = true;
    var i,j;

    var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                            "A", "B", "C", "D", "#", "*", "|");
    var len = hexVals.length;

    for ( i = 0; i < val.length; i++ )
    {
      for ( j = 0; j < len; j++ )
      {
        if ( val.charAt(i) == hexVals[j] )
            break;
      }

      if ( j == len )
        return false;
    }

    return ret;
}
/* add by linjl end */

function substr_count (haystack, needle, offset, length)
{
    var pos = 0, cnt = 0;

    haystack += '';
    needle += '';
    if (isNaN(offset)) {offset = 0;}
    if (isNaN(length)) {length = 0;}
    offset--;

    while ((offset = haystack.indexOf(needle, offset+1)) != -1){
        if (length > 0 && (offset+needle.length) > length){
            return false;
        } else{
            cnt++;
        }
    }

    return cnt;
}

function test_ipv6(ip)
{
  // Test for empty address
  if (ip.length<3)
  {
	return ip == "::";
  }

  // Check if part is in IPv4 format
  if (ip.indexOf('.')>0)
  {
        lastcolon = ip.lastIndexOf(':');

        if (!(lastcolon && isValidIpAddress(ip.substr(lastcolon + 1))))
            return false;

        // replace IPv4 part with dummy
        ip = ip.substr(0, lastcolon) + ':0:0';
  } 

  // Check uncompressed
  if (ip.indexOf('::')<0)
  {
    var match = ip.match(/^(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}$/i);
    return match != null;
  }

  // Check colon-count for compressed format
  if (substr_count(ip, ':'))
  {
    var match = ip.match(/^(?::|(?:[a-f0-9]{1,4}:)+):(?:(?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4})?$/i);
    return match != null;
  } 

  // Not a valid IPv6 address
  return false;
}

function isValidIpAddress6(address) {
   ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      num = parseInt(ipParts[1]);
      if (num <= 0 || num > 128)
         return false;
   }

   return test_ipv6(ipParts[0]);
}

/*
//OLD_CODE_406
function isValidIpAddress6(address) {

   ipParts = address.split('/');
   if (ipParts.length > 2) return false;
   if (ipParts.length == 2) {
      num = parseInt(ipParts[1]);
      if (num <= 0 || num > 128)
         return false;
   }

   addrParts = ipParts[0].split(':');
   if (addrParts.length < 3 || addrParts.length > 8)
      return false;
   for (i = 0; i < addrParts.length; i++) {
      if ( addrParts[i] != "" )
         num = parseInt(addrParts[i], 16);
      if ( i == 0 ) {
//         if ( (num & 0xf000) == 0xf000 )
//            return false;	//can not be link-local, site-local or multicast address
      }
      else if ( (i + 1) == addrParts.length) {
         if ( num == 0 || num == 1)
            return false;	//can not be unspecified or loopback address
      }
      if ( num != 0 )
         break;
   }
   return true;
}
*/

function isValidPrefixLength(prefixLen) {
   var num;

   num = parseInt(prefixLen);
   if (num <= 0 || num > 128)
      return false;
   return true;
}

/* check if the object is exist. such as before delete */
function isObjExist(obj) {
   if ((obj==null) || (typeof(obj)=="undefined")) {
	return false;
   }
   else {
   	return true;
   }
}

function areSamePrefix(addr1, addr2) {
   var i, j;
   var a = [0, 0, 0, 0, 0, 0, 0, 0];
   var b = [0, 0, 0, 0, 0, 0, 0, 0];

   addr1Parts = addr1.split(':');
   if (addr1Parts.length < 3 || addr1Parts.length > 8)
      return false;
   addr2Parts = addr2.split(':');
   if (addr2Parts.length < 3 || addr2Parts.length > 8)
      return false;
   j = 0;
   for (i = 0; i < addr1Parts.length; i++) {
      if ( addr1Parts[i] == "" ) {
		 if ((i != 0) && (i+1 != addr1Parts.length)) {
			j = j + (8 - addr1Parts.length + 1);
		 }
		 else {
		    j++;
		 }
	  }
	  else {
         a[j] = parseInt(addr1Parts[i], 16);
		 j++;
	  }
   }
   j = 0;
   for (i = 0; i < addr2Parts.length; i++) {
      if ( addr2Parts[i] == "" ) {
		 if ((i != 0) && (i+1 != addr2Parts.length)) {
			j = j + (8 - addr2Parts.length + 1);
		 }
		 else {
		    j++;
		 }
	  }
	  else {
         b[j] = parseInt(addr2Parts[i], 16);
		 j++;
	  }
   }
   //only compare 64 bit prefix
   for (i = 0; i < 4; i++) {
      if (a[i] != b[i]) {
	     return false;
	  }
   }
   return true;
}

function getLeftMostZeroBitPos(num) {
   var i = 0;
   var numArr = [128, 64, 32, 16, 8, 4, 2, 1];

   for ( i = 0; i < numArr.length; i++ )
      if ( (num & numArr[i]) == 0 )
         return i;

   return numArr.length;
}

function getRightMostOneBitPos(num) {
   var i = 0;
   var numArr = [1, 2, 4, 8, 16, 32, 64, 128];

   for ( i = 0; i < numArr.length; i++ )
      if ( ((num & numArr[i]) >> i) == 1 )
         return (numArr.length - i - 1);

   return -1;
}

function isValidPort(port) {
   var fromport = 0;
   var toport = 100;
   var i=0;
   var j=0;
   var is_all_number=1;
   portrange = port.split(':');
   if ( portrange.length < 1 || portrange.length > 2 ) {
       return false;
   }
   for( i=0; i<portrange.length; i++ ){
   		for( j=0; j<portrange[i].length; j++ ){
   			if( portrange[i].charAt(j) < '0' || portrange[i].charAt(j) > '9' )
   				is_all_number=0;
   		}
   }
   if( is_all_number==0 )
   	   return false;
   if ( isNaN(portrange[0]) )
       return false;
   fromport = parseInt(portrange[0]);
   
   if ( portrange.length > 1 ) {
       if ( isNaN(portrange[1]) )
          return false;
       toport = parseInt(portrange[1]);
       if ( toport <= fromport )
           return false;      
   }
   
   if ( fromport < 1 || fromport > 65535 || toport < 1 || toport > 65535 )
       return false;
   
   return true;
}

function isValidNatPort(port) {
   var fromport = 0;
   var toport = 100;

   portrange = port.split('-');
   if ( portrange.length < 1 || portrange.length > 2 ) {
       return false;
   }
   if ( isNaN(portrange[0]) )
       return false;
   fromport = parseInt(portrange[0]);

   if ( portrange.length > 1 ) {
       if ( isNaN(portrange[1]) )
          return false;
       toport = parseInt(portrange[1]);
       if ( toport <= fromport )
           return false;
   }

   if ( fromport < 1 || fromport > 65535 || toport < 1 || toport > 65535 )
       return false;

   return true;
}

function isValidMacAddress(address) {
   var c = '';
   var num = 0;
   var i = 0, j = 0;
   var zeros = 0;
   var cnt_ff=0;
   addrParts = address.split(':');
   if ( addrParts.length != 6 ) return false;

   for (i = 0; i < 6; i++) {
      if ( addrParts[i] == '' )
         return false;
      for ( j = 0; j < addrParts[i].length; j++ ) {
         c = addrParts[i].toLowerCase().charAt(j);
         if ( (c >= '0' && c <= '9') ||
              (c >= 'a' && c <= 'f') )
            continue;
         else
            return false;
      }

      num = parseInt(addrParts[i], 16);
      if ( num == NaN || num < 0 || num > 255 )
         return false;
      if( num == 255 )
         cnt_ff++;
      if ( num == 0 )
         zeros++;
   }
   if (zeros == 6 || cnt_ff == 6)
      return false;

   return true;
}

function isValidMacMask(mask) {
   var c = '';
   var num = 0;
   var i = 0, j = 0;
   var zeros = 0;
   var zeroBitPos = 0, oneBitPos = 0;
   var zeroBitExisted = false;

   maskParts = mask.split(':');
   if ( maskParts.length != 6 ) return false;

   for (i = 0; i < 6; i++) {
      if ( maskParts[i] == '' )
         return false;
      for ( j = 0; j < maskParts[i].length; j++ ) {
         c = maskParts[i].toLowerCase().charAt(j);
         if ( (c >= '0' && c <= '9') ||
              (c >= 'a' && c <= 'f') )
            continue;
         else
            return false;
      }

      num = parseInt(maskParts[i], 16);
      if ( num == NaN || num < 0 || num > 255 )
         return false;
      if ( zeroBitExisted == true && num != 0 )
         return false;
      if ( num == 0 )
         zeros++;
      zeroBitPos = getLeftMostZeroBitPos(num);
      oneBitPos = getRightMostOneBitPos(num);
      if ( zeroBitPos < oneBitPos )
         return false;
      if ( zeroBitPos < 8 )
         zeroBitExisted = true;
   }
   if (zeros == 6)
      return false;

   return true;
}

var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
              "A", "B", "C", "D", "E", "F");
var unsafeString = "\"<>%\\^[]`\+\$\,'#&";
// deleted these chars from the include list ";", "/", "?", ":", "@", "=", "&" and #
// so that we could analyze actual URLs

function isUnsafe(compareChar)
// this function checks to see if a char is URL unsafe.
// Returns bool result. True = unsafe, False = safe
{
   if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
        && compareChar.charCodeAt(0) < 123 )
      return false; // found no unsafe chars, return false
   else
      return true;
}

function decToHex(num, radix)
// part of the hex-ifying functionality
{
   var hexString = "";
   while ( num >= radix ) {
      temp = num % radix;
      num = Math.floor(num / radix);
      hexString += hexVals[temp];
   }
   hexString += hexVals[num];
   return reversal(hexString);
}

function reversal(s)
// part of the hex-ifying functionality
{
   var len = s.length;
   var trans = "";
   for (i = 0; i < len; i++)
      trans = trans + s.substring(len-i-1, len-i);
   s = trans;
   return s;
}

function convert(val)
// this converts a given char to url hex form
{
   return  "%" + decToHex(val.charCodeAt(0), 16);
}


function hexToAscii(hexstr) 
{
   var hex = hexstr.toString();
   var str = '';
   for ( var i = 0 ; i < hexstr.length; i += 2 )
     str += String.fromCharCode(parseInt(hex.substr(i,2), 16));
   return str;
}

function asciiToHex(asciiStr)
{
   var hexStr = '';
   for ( var i = 0 ; i < asciiStr.length ; i ++ )
      hexStr += Number(asciiStr.charCodeAt(i)).toString(16);

   return hexStr;
}

function transKey(key)
{
   if (key.length == 13 || key.length == 5) // ascii str
      return asciiToHex(key);
   return key;
}

function isAsciiStr(str)
{
   for ( var i = 0 ; i < str.length; i += 2 )
   {
     code = parseInt(str.substr(i,2), 16);
     if (code < 32 || code > 123)
        return false;
   }
   return true;
}

function transKeyView(key)
{
   if (isAsciiStr(key))
      return hexToAscii(key);
   return key;
}

function encodeUrl(val)
{
   var len     = val.length;
   var i       = 0;
   var newStr  = "";
   var original = val;

   for ( i = 0; i < len; i++ ) {
      if ( val.substring(i,i+1).charCodeAt(0) < 255 ) {
         // hack to eliminate the rest of unicode from this
         if (isUnsafe(val.substring(i,i+1)) == false)
            newStr = newStr + val.substring(i,i+1);
         else
            newStr = newStr + convert(val.substring(i,i+1));
      } else {
         // woopsie! restore.
         //alert ("Found a non-ISO-8859-1 character at position: " + (i+1) + ",\nPlease eliminate before continuing.");
		 return "";
         newStr = original;
         // short-circuit the loop and exit
         i = len;
      }
   }

   return newStr;
}

var markStrChars = "\"'";

// Checks to see if a char is used to mark begining and ending of string.
// Returns bool result. True = special, False = not special
function isMarkStrChar(compareChar)
{
   if ( markStrChars.indexOf(compareChar) == -1 )
      return false; // found no marked string chars, return false
   else
      return true;
}

// use backslash in front one of the escape codes to process
// marked string characters.
// Returns new process string
function processMarkStrChars(str) {
   var i = 0;
   var retStr = '';

   for ( i = 0; i < str.length; i++ ) {
      if ( isMarkStrChar(str.charAt(i)) == true )
         retStr += '\\';
      retStr += str.charAt(i);
   }

   return retStr;
}

// Web page manipulation functions
function showhideByJqId(id, sh)
{
	if(sh == 1)
		$("#"+id).prop("hidden", false);
	else if(sh == 0)
		$("#"+id).prop("hidden", true);		
}

function showhide(element, sh)
{
    var status;
    if (sh == 1) {
        status = "";
    }
    else {
        status = "none";
    }
    
	if (document.getElementById)
	{
		// standard
		document.getElementById(element).style.display = status;
	}
	else if (document.all)
	{
		// old IE
		document.all[element].style.display = status;
	}
	else if (document.layers)
	{
		// Netscape 4
		document.layers[element].display = status;
	}
}

// Load / submit functions

function getSelect(item)
{
	var idx;
	if (item.options.length > 0) {
	    idx = item.selectedIndex;
	    return item.options[idx].value;
	}
	else {
		return '';
    }
}

function setSelectbyValue(name, value)
{
	$("select[name="+name+"]").get(0).value = value;
}
function setSelectbyIndex(name, index)
{
	$("select[name="+name+"]").get(0).value = index;
}

function setSelect(item, value)
{
	for (i=0; i<item.options.length; i++) {
        if (item.options[i].value == value) {
        	item.selectedIndex = i;
        	break;
        }
    }
}

function setCheck(item, value)
{
    if ( value == '1' ) {
         item.checked = true;
    } else {
         item.checked = false;
    }
}

function setInnerHtml(item,value) {
	document.getElementById(item).innerHTML=value;
}

function setDisable(item, value)
{
    if ( value == 1 || value == '1' ) {
         item.disabled = true;
    } else {
         item.disabled = false;
    }     
}

function submitText(item)
{
	return '&' + item.name + '=' + item.value;
}

function submitSelect(item)
{
	return '&' + item.name + '=' + getSelect(item);
}


function submitCheck(item)
{
	var val;
	if (item.checked == true) {
		val = 1;
	} 
	else {
		val = 0;
	}
	return '&' + item.name + '=' + val;
}



function numOfRow(valuelist, rowss){ 
	if(typeof(rowss) == 'undefined')
		rowss = '|,|';

	var numR = 0;
	if(valuelist != ''){
		if (rowss != ''){
			var tnodes = valuelist.split(rowss);
		}else{
			var tnodes = valuelist;
		}
		numR = tnodes.length - 2; 
		return numR;
	}

	return numR;
}

function numOfPolicyRoute(valuelist){ 
	var numR = 0;
        var sourceIPAddressArray = getColFromList(valuelist, 'SourceIPAddress');
        var SourceIfNameArray = getColFromList(valuelist, 'X_BROADCOM_COM_SourceIfName');
	var i;
        for(i=0;i<sourceIPAddressArray.length;i++)
        	{
        	     if((sourceIPAddressArray[i]!="")||(SourceIfNameArray[i]!=""))
				numR++;
        	}	
		
           numR=numR-1;                        
		   
       return numR;
 }



function numOfCol(valuelist, rowss, conls){
	if(typeof(rowss) == 'undefined')
		rowss = '|,|';
	if(typeof(conls) == 'undefined')
		conls = '}-{';

	var numC = 0;
	if(valuelist != ''){
		if (rowss != ''){
			var tnodes = valuelist.split(rowss);
		}else{
			var tnodes = valuelist;
		}
		if (tnodes.length > 0){
			if (conls != ''){
				var tdata = tnodes[0].split(conls);
				numC = tdata.length - 1;
			}
		}
		return numC;
	}
	return numC;
}


function getParamNum( valuelist, conlN, rowss, conls ){
	var i;
	if(valuelist != ''){
		if (rowss != ''){
			var tnodes = valuelist.split(rowss);
		}else{
			var tnodes = valuelist;
		}

		var row = numOfRow(valuelist, rowss);
		var names = tnodes[row].split(conls);

		for ( i = 0; i < names.length; i++ ){
			if ( names[i] == conlN ){
				return i;
			}
		}
	}
	return -1;
}

function getValueFromList(valuelist, conlN, rowsN, rowss, conls){ 
	if(typeof(rowss) == 'undefined')
		rowss = '|,|';
	if(typeof(conls) == 'undefined')
		conls = '}-{';
	if(typeof(rowsN) == 'undefined')
		rowsN = 0;

	var n;
	if ( isNaN(conlN) )
		n = getParamNum(valuelist, conlN, rowss, conls);
	else
		n = conlN;

	var mName = new Array();
	if(valuelist != '' && n != -1){
		if (rowss != ''){
			var tnodes = valuelist.split(rowss);
		}else{
			var tnodes = valuelist;
		}

		var tdata = tnodes[rowsN].split(conls);
		(tdata[n]) ? mName = tdata[n]: mName = '';

		return mName;
	}
	return mName;
}

function getColFromList(valuelist, conlN, rowss, conls){
	if(typeof(rowss) == 'undefined')
		rowss = '|,|';
	if(typeof(conls) == 'undefined')
		conls = '}-{';

	var n;
	if ( isNaN(conlN) )
		n = getParamNum(valuelist, conlN, rowss, conls);
	else
		n = conlN;

	var mName = new Array();
	if(valuelist != ''){
		if (rowss != ''){
			var tnodes = valuelist.split(rowss);
		}else{
			var tnodes = valuelist;
		}
		for ( i = 0; i < tnodes.length -1; i++ ){
			var tdata = tnodes[i].split(conls);
			(tdata[n]) ? mName[i] = tdata[n]: mName[i] = '';
		}
		return mName;
	}
	return mName;
}

function getIpMaskBit(mask) {
   var i = 0, num = 0;
   var oneBitPos = 0;

   if ( isValidSubnetMask(mask) == false)
	 return -1;

   maskParts = mask.split('.');
   for (i = 0; i < 4; i++) {
      num = parseInt(maskParts[i]);
      oneBitPos = getRightMostOneBitPos(num);
	if(oneBitPos < 7){
		return i*8 + oneBitPos + 1;
	}
   }
   return 32;
}

function isValidIpAddressRange(startAddr, endAddr){

   if ( !isValidIpAddress(startAddr) || !isValidIpAddress(endAddr) )
      return false;

   var i;
   var startAddrParts = startAddr.split('.');
   var endAddrParts = endAddr.split('.');

   for ( i = 0; i < 4; i++ ){
      if ( parseInt(startAddrParts[i]) < parseInt(endAddrParts[i]) )
         return true;
      else if ( parseInt(startAddrParts[i]) > parseInt(endAddrParts[i]) )
         return false;
   }

   return false;
}

function isValidSubnetMask(mask) {
   var i = 0, num = 0;
   var zeroBitPos = 0, oneBitPos = 0;
   var zeroBitExisted = false;
   var c = '';

   if ( mask == '0.0.0.0' )
      return false;

   for (i = 0; i < mask.length; i++) {
     c = mask.charAt(i);
     if((c>='0'&&c<='9')||(c=='.'))
       continue;
     else
     {
        return false;
      }
   }
/*   if ( mask.indexOf(' ') != -1 )
      return false;*/

   maskParts = mask.split('.');
   if ( maskParts.length != 4 ) return false;

   for (i = 0; i < 4; i++) {
      if ( isNaN(maskParts[i]) || maskParts[i] ==""){
         return false;
      }
      num = parseInt(maskParts[i]);
      if ( num < 0 || num > 255 )
         return false;
      if (maskParts[i].length > 3)
      {
         return false;
	}
      if ( zeroBitExisted == true && num != 0 )
         return false;
      zeroBitPos = getLeftMostZeroBitPos(num);
      oneBitPos = getRightMostOneBitPos(num);
      if ( zeroBitPos < oneBitPos )
         return false;
      if ( zeroBitPos < 8 )
         zeroBitExisted = true;
   }

   return true;
}

function isValidNameString( val )
{
	var len = val.length;

    for ( i = 0; i < len; i++ )
    {
        if ( ( val.charAt(i) > '~' )
            || ( val.charAt(i) < '!' ) )
        {
            return false;
        }
    }

    return true;
}

function getIpMaskBit(mask) {
   var i = 0, num = 0;
   var oneBitPos = 0;
   
   if ( isValidSubnetMask(mask) == false)
	 return -1;

   maskParts = mask.split('.');
   for (i = 0; i < 4; i++) {
      num = parseInt(maskParts[i]);
      oneBitPos = getRightMostOneBitPos(num);
	if(oneBitPos < 7){
		return i*8 + oneBitPos + 1;
	}
   }
   return 32;
}

function isValidRequestListString(val)
{

	 var c = '';
	 
	 c = val.charAt(0);
	 if(c==',')
	 {
		return false;
	 }

	 c = val.charAt(val.length-1);
	 
	 if(c==',')
	 {
		return false;
	 }

	 var newval = val.split(',');
	 var len = val.length;
	 
	 for ( i = 0; i < newval.length; i++ )
    {
			var num;
			if ( newval[i] == '' )
			{
				return false;
			}
			for ( j = 0; j < newval[i].length; j++ ) 
			{
				c = newval[i].toLowerCase().charAt(j);
				if ((c < '0' || c > '9'))
				return false;
			}	
			
			num = parseInt(newval[i]);
			if(num < 1 || num > 255)
			{
         	return false;
			}
    }

	return true;
}

function isValidStringLength(val, min, max){
   if(val.length < max && val.length >= min)
       return true;
   else
       return false;
}

function isValidDTMFNumber(phoneNumber){
    var i = 0;
    for(i = 0; i < phoneNumber.length; ++i){
       if ((phoneNumber.charAt(i) >= '0' && phoneNumber.charAt(i) <= '9')
            || (phoneNumber.charAt(i) >= 'A' && phoneNumber.charAt(i) <= 'D')
            || (phoneNumber.charAt(i) >= 'a' && phoneNumber.charAt(i) <= 'd')
            || phoneNumber.charAt(i) == '*' || phoneNumber.charAt(i) == '#')
            continue;
       else{
            return false;
        }
    }
    return true;
}

function isValidUrgentCallNumber(callNumber)
{
    var i = 0;
    var counts = 0;
    var countLine = 0;

    for(i = 0; i < callNumber.length; ++i)
    {
       if ((callNumber.charAt(i) >= '0' && callNumber.charAt(i) <= '9')
            || (callNumber.charAt(i) >= 'A' && callNumber.charAt(i) <= 'D')
            || (callNumber.charAt(i) >= 'a' && callNumber.charAt(i) <= 'd')
            || callNumber.charAt(i) == '*' || callNumber.charAt(i) == '#')
        {
            counts++;
        }
        else if (callNumber.charAt(i) == '|')
        {
           if (counts > 8)
           {
               return false;
           }
           counts = 0;
           countLine++;
        }
        else
        {
            return false;
        }
    }
    if (counts > 8 || countLine > 8)
    {
        return false;
    }
    else
    {
        return true;
    }
}

function isValidtToneTimer(ToneTimer,Tonekind){

   var num = parseInt(ToneTimer);
   var ret = true;

   switch(Tonekind)
   {
      case 1: /* tonedial */
         if (  num < 10 || num > 20 )
            ret = false;
      break;	
      case 2: /* tonebusy */
      case 4: /* toneoffhookwarning */
      case 5: /* toneringback */
         if (  num < 30 || num > 180 )
            ret = false;
      break;	
      case 3: /* tonereorder */
         if (  num < 1 || num > 5 )
            ret = false;
      break;	

     default:
     break;
   }
   return ret;
}

function isValidminSessExpireTime(minSessExpireTime){

   var timer = parseInt(minSessExpireTime);
   var ret;

   if ( timer < 90 )
   {
      ret = false;
   }
   else
   {
      ret = true;
   }

   return ret;
}

function isValidAddressExpress(address) //chengjianguo modified  for the check of ipaddress 091215
{
	var i = 0;
   	if((address == '0.0.0.0')||(address == '255.255.255.255')) {
    	return false;
	}

	addrParts = address.split('.');
   	if(addrParts.length != 4) {
		return false;
	}

	for(i=0; i<4; i++) {
		if(isNaN(parseInt(addrParts[i]))) {
			return false;
		}
		num = parseInt(addrParts[i]);
		if(i == 0)
		{
			if((num<=0)||(num>=240)) 
        			return false;
		}
		else if(i == 3)
			{
				if((num<=0)||(num>255)) 
        				return false;
			}
		else 
			if((num<0)||(num>255)) {
        		return false;
		}
   	}
   	return true;
}

function IsNotDigit(fData)
{
      var i;

         for (i = 0; i < fData.length; i++) 
               {
                        if (!(fData.charAt(i) >= '0' && fData.charAt(i) <= '9'))
                                 return true;
                           }

            return false;
}

function inttest(s)
{
    var   r   =   /^[0-9]*[1-9][0-9]*$/;
    return r.test(s);
}

function numOfPolicyRoute(valuelist){ 
	var numR = 0;
        var sourceIPAddressArray = getColFromList(valuelist, 'SourceIPAddress');
        var SourceIfNameArray = getColFromList(valuelist, 'X_BROADCOM_COM_SourceIfName');
	var i;
        for(i=0;i<sourceIPAddressArray.length;i++)
        	{
        	     if((sourceIPAddressArray[i]!="")||(SourceIfNameArray[i]!=""))
				numR++;
        	}	
		
           numR=numR-1;                        
		   
       return numR;
 }
function isNotChineseCharacter(val)
{
	var len = val.length;
	for(i=0;i<len;i++)
	{
	    if(val.substring(i,i+1).charCodeAt(0)>255)
	   {
		return false;
	   }
	}
	return true;
}

function isValidHostname(val)
{
   var len = val.length;

   if (len > 255)
      return false;

   for (i = 0; i < len; i++)
   {
      if (((val.charAt(i) >= '0') && (val.charAt(i) <= '9'))
         || ((val.charAt(i) >= 'a') && (val.charAt(i) <= 'z'))
         || ((val.charAt(i) >= 'A') && (val.charAt(i) <= 'Z'))
         || (val.charAt(i) == '-') || (val.charAt(i) == ' ')
         || (val.charAt(i) == '\'') || (val.charAt(i) == '.'))
         continue;
      else
         return false;
   }

   return true;
}


function reboot()
{
	$.get("rebootinfo.cgi");
}
