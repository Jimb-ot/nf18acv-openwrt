(function(){
      function getServerIP() {
            return window.location.hostname
      }

      function getServerURL() {
            var forced = localStorage.serverURL;
            return forced || ("http://" + getServerIP() + ":57337/test/")
      }

      function getFlashServerURL() {
            var forced = localStorage.flashServerURL;
            return forced || (getServerIP() + ":7000")
      }

      var test = new SpeedTest({
            url: getServerURL(),
            flashUrl: getFlashServerURL()
        }),
      testType = "wan";

    window.test = test;

    var WAN_TEST = true;
    var LAN_TEST = true;

    var interval;

    function toTwoPlaces(value) {
        return (Math.round(value*100)/100).toFixed(2);
    }

    function resetValues() {
        var els = document.querySelectorAll('ul > li > div > div');
        for(var i = 0; i < els.length; i++) {
            els[i].innerHTML = "&mdash; ";
        }
    }

    function getPositon(speed) {
        speed = speed/10;

        speed = Math.round(speed*100)/100;

        if(speed <=1) {
            return -120 + 30*speed;
        }
        if(speed <= 5) {
            return -90 + 30*(speed/5);
        }
        if(speed <= 10) {
            return -60 + 30*((speed/5) - 1);
        }
        if(speed <= 20) {
            return -30 + 30* ((speed/10) - 1);
        }
        if(speed <= 40) {
            return 30*((speed/20) - 1);
        }
        if(speed <= 60) {
            return 30 + 30*((speed/20) - 2);
        }
        if(speed <= 80) {
            return 60 + 30*((speed/20) - 3);
        }
        if(speed <= 100) {
            return 90 + 30*((speed/20) - 4);
        }

        return 120;
    }

    function waveHand() {
        return setInterval(function(){
            var el = document.getElementById('Hand');
            var style = el.getAttribute('style');
            var val = style.split('transform: rotate(')[1].split('deg)');
            val = parseInt(val, 10);
            el.setAttribute('style', 'transform: rotate('+ (val - Math.abs(Math.random()))+'deg)')
        }, 120);
    }

    function releaseHand() {
        clearInterval(interval);
        setTimeout(function(){
            interval = waveHand();
        }, 2000);
    }

    var hooks = {
        onStarted: function() {
            console.log('Test started');
            resetValues();
            releaseHand();
        },
        onPing: function(data) {
            console.log('onPing');
            console.log(data);
            if(data.average) {
              document.getElementById('pingValue').innerHTML = data.average;
            }
        },
        onProgress: function(data) {
            console.log(data);
            if(data.current_value && data.event !== 'PROGRESS_PING') {
                document.getElementById("Speed").innerHTML = toTwoPlaces(data.current_value);
                document.getElementById('Hand').setAttribute('style', 'transform: rotate('+ getPositon(data.current_value)+'deg)');
            }
        },
        onDone: function() {
            document.getElementById('Hand').setAttribute('style', 'transform: rotate(-120deg)');
            clearInterval(interval);
            testType = 'wan';
            document.getElementById('TestType').innerHTML = 'DOWNLOAD';
            document.getElementById('Test').innerHTML = 'WAN TEST';
            document.getElementById("Speed").innerHTML = 0;
        },
        onWanDone: function(event) {
            if(!LAN_TEST) {
              document.getElementById('StartButton').style.display = "block";
            }
            releaseHand();
        },
        onWanStarted: function() {
        },
        onDownloadDone: function(event) {

          releaseHand();
          console.log('onDownload Done', event);
          document.getElementById('TestType').innerHTML = 'UPLOAD';

          if(event && event.average) {
            document.getElementById(testType + 'DownloadValue').innerHTML = toTwoPlaces(event.average);
          }

        },

        onUploadDone: function(event) {
            document.getElementById(testType + 'UploadValue').innerHTML = toTwoPlaces(event.average);

        },
        onLanStarted: function() {
            testType = 'lan';
            document.getElementById('TestType').innerHTML = 'DOWNLOAD';
            document.getElementById('Test').innerHTML = 'WAN TEST';
        },
        onLanDone: function() {
            document.getElementById('StartButton').style.display = "block";
        }
    };

    var events = {
        "click #StartButton": function() {
            resetValues();
            test.start({lan: LAN_TEST, wan: WAN_TEST});
            this.style.display = "none";
            //document.getElementById('ProgressSection').style.display = "block";
        }
    };

    for(var i in events) {
        if(events.hasOwnProperty(i)) {
            var parts = i.split(" #");
            document.getElementById(parts[1]).addEventListener(parts[0], events[i]);
        }
    }

    for(var i in hooks) {
        if(hooks.hasOwnProperty(i)) {
            test[i] = hooks[i];
        }
    }
    document.getElementById('Hand').setAttribute('style', 'transform: rotate(-120deg)');
    document.getElementById('Hand').setAttribute("class", "hand");

})();
