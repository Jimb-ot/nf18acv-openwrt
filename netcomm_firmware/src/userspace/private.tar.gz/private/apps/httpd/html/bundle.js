(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function(window, document){
    var hello = require('../drawings/background.svg')(0, 0);
    var hand = require('../drawings/hand.svg')(0, 0);
    var status = require('../drawings/status.svg')(0, 0);
    var captionsDownload = require('../drawings/captions_download.svg')(0, 0);

    var createNode = require('svg-node');

    var svg = document.getElementsByTagName('svg')[0];

    var someLayer = createNode('g');
    var handLayer = createNode('g');
    var statusLayer = createNode('g');
    var captionsDownloadLayer = createNode('g');

    handLayer.appendChild(hand);
    someLayer.appendChild(hello);
    statusLayer.appendChild(status);
    captionsDownloadLayer.appendChild(captionsDownload);

    svg.appendChild(someLayer);
    svg.appendChild(captionsDownloadLayer);
    svg.appendChild(handLayer);
    svg.appendChild(statusLayer);

})(window, document);
},{"../drawings/background.svg":2,"../drawings/captions_download.svg":3,"../drawings/hand.svg":4,"../drawings/status.svg":5,"svg-node":6}],2:[function(require,module,exports){
function format(text) {return function(x, y) {x = (+x|0);y = (+y|0);var el = document.createElement("div");el.innerHTML = "<svg><g><g>" + text + "</g></g></svg>";el = el.childNodes[0].childNodes[0];el.childNodes[0].setAttribute("transform", "translate(" + x + "," + y + ")");return el}}
module.exports = format("\n    <g id=\"Background\">\n        <path fill=\"none\" stroke=\"gray\" stroke-width=\"2\"\n              d=\"M 442.89 382.5 A 165 165 0 1 0 157.11 382.5\"/>\n\n        <path fill=\"none\" stroke=\"gray\" stroke-width=\"1\"\n              d=\"M 133.82 207.89 A 190 190 0 0 0 135.46 395\"/>\n        <path fill=\"none\" stroke=\"gray\" stroke-width=\"1\"\n              d=\"M 296.68 110.03 A 190 190 0 0 0 137.14 202.14\"/>\n        <path fill=\"none\" stroke=\"gray\" stroke-width=\"1\"\n              d=\"M 462.86 202.14 A 190 190 0 0 0 303.32 110.03\"/>\n        <path fill=\"none\" stroke=\"gray\" stroke-width=\"1\"\n              d=\"M 464.54 395 A 190 190 0 0 0 466.18 207.89\"/>\n\n        <circle fill=\"none\" stroke=\"lightgray\" stroke-width=\"0.5\n        \" r=\"7\" cx=\"300\" cy=\"300\"></circle>\n\n        <line x1=\"437.15\" y1=\"382.41\" x2=\"445.72\" y2=\"387.56\" stroke=\"gray\" stroke-width=\"1\"/>\n\n        <line x1=\"140\" y1=\"300\" x2=\"135\" y2=\"300\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"161.44\" y1=\"220\" x2=\"157.11\" y2=\"217.5\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"220\" y1=\"161.44\" x2=\"217.5\" y2=\"157.11\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"300\" y1=\"140\" x2=\"300\" y2=\"135\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"380\" y1=\"161.44\" x2=\"382.5\" y2=\"157.11\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"438.56\" y1=\"220\" x2=\"442.89\" y2=\"217.5\" stroke=\"gray\" stroke-width=\"1\"/>\n        <line x1=\"460\" y1=\"300\" x2=\"465\" y2=\"300\" stroke=\"gray\" stroke-width=\"1\"/>\n\n        <line x1=\"162.85\" y1=\"382.41\" x2=\"154.28\" y2=\"387.56\" stroke=\"gray\" stroke-width=\"1\"/>\n\n        <image xlink:href=\"logo.png\" x=\"204\" y=\"220\" height=\"29\" width=\"186\" opacity=\"0.5\"/>\n    </g>\n")
},{}],3:[function(require,module,exports){
function format(text) {return function(x, y) {x = (+x|0);y = (+y|0);var el = document.createElement("div");el.innerHTML = "<svg><g><g>" + text + "</g></g></svg>";el = el.childNodes[0].childNodes[0];el.childNodes[0].setAttribute("transform", "translate(" + x + "," + y + ")");return el}}
module.exports = format("\n    <g id=\"CaptionsDownload\">\n        <path id=\"DownloadPath\" fill=\"none\" stroke=\"none\" stroke-width=\"1\"\n              d=\"M 154.28 387.56 A 170 170 1 1 1 445.72 387.56\"/>\n\n        <text fill=\"#c0c0c0\" font-family=\"Tahoma\" font-size=\"15\">\n            <textPath spacing=\"auto\" xlink:href=\"#DownloadPath\">\n                <tspan>0</tspan>\n                <tspan dx=\"72\">10</tspan>\n                <tspan dx=\"69\">50</tspan>\n                <tspan dx=\"63\">100</tspan>\n                <tspan dx=\"60\">200</tspan>\n                <tspan dx=\"58\">400</tspan>\n                <tspan dx=\"60\">600</tspan>\n                <tspan dx=\"60\">800</tspan>\n                <tspan dx=\"55\">1G</tspan>\n            </textPath>\n        </text>\n    </g>\n")
},{}],4:[function(require,module,exports){
function format(text) {return function(x, y) {x = (+x|0);y = (+y|0);var el = document.createElement("div");el.innerHTML = "<svg><g><g>" + text + "</g></g></svg>";el = el.childNodes[0].childNodes[0];el.childNodes[0].setAttribute("transform", "translate(" + x + "," + y + ")");return el}}
module.exports = format("\n    <g id=\"Hand\">\n        <circle fill=\"gray\" cx=\"300\" cy=\"300\" r=\"5\"></circle>\n        <polygon fill=\"gray\" points=\"305 300 295 300 300 150\"></polygon>\n        <circle fill=\"#F18194\" cx=\"300\" cy=\"135\" r=\"3\"></circle>\n    </g>\n")
},{}],5:[function(require,module,exports){
function format(text) {return function(x, y) {x = (+x|0);y = (+y|0);var el = document.createElement("div");el.innerHTML = "<svg><g><g>" + text + "</g></g></svg>";el = el.childNodes[0].childNodes[0];el.childNodes[0].setAttribute("transform", "translate(" + x + "," + y + ")");return el}}
module.exports = format("\n    <g id=\"Status\">\n        <!--<g id=\"StartButton\">\n            <rect rx=\"2\" ty=\"2\" fill=\"none\" stroke-width=\"1\" stroke=\"gray\" x=\"250\" y=\"340\" width=\"100\" height=\"40\"></rect>\n            <text font-family=\"Verdana\" fill=\"gray\" text-anchor=\"middle\" x=\"300\" y=\"366\">\n                START\n            </text>\n        </g>-->\n        <g id=\"ProgressSection\">\n            <text font-family=\"Verdana\" fill=\"gray\" text-anchor=\"middle\" x=\"300\" y=\"360\">\n                <tspan id=\"Test\" letter-spacing=\"3\" fill=\"lightgray\" font-size=\"11\" font-weight=\"lighter\" x=\"300\" y=\"342\">WAN TEST</tspan>\n                <tspan x=\"300\" y=\"362\" id=\"TestType\" font-size=\"18\">DOWNLOAD</tspan>\n                <tspan fill=\"#F18194\" font-size=\"35\" x=\"300\" y=\"395\">\n                    <tspan id=\"Speed\">0</tspan><tspan font-size=\"14\" fill=\"#F18194\">mbps</tspan>\n                </tspan>\n            </text>\n        </g>\n    </g>\n")
},{}],6:[function(require,module,exports){
var ns = 'http://www.w3.org/2000/svg'

module.exports = createSVGElement
module.exports.ns = ns

function createSVGElement(name, doc) {
  return (doc || document).createElementNS(ns, name)
}

},{}]},{},[1]);
