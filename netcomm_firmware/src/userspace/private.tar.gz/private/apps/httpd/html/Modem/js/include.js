var ntc = {};
ntc.includeHTML = function(cb) {
  var z, i, elmnt, file, xhttp;
  z = document.getElementsByTagName("*");
  for (i = 0; i < z.length; i++) {
    elmnt = z[i];
    elmntID = elmnt.getAttribute("id")
    file = elmnt.getAttribute("include-html");
    if (file) {
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          elmnt.innerHTML = this.responseText;
          elmnt.removeAttribute("include-html");
          ntc.includeHTML(cb);
        } else {
            var iframe = document.createElement('iframe');
            iframe.setAttribute("src", file);
            document.getElementById(elmntID).appendChild(iframe);
            elmnt.removeAttribute("include-html");
            ntc.includeHTML(cb);
        }
      }      
      xhttp.open("GET", file, true);
      xhttp.send();
      return;
    }
  }
  if (cb) cb();
};