function filterSSIDChange(id) {
   if(id == 1){
      var restrict = $("select[name=24GhzMacSSID]").val();
      var url = "nc_wlmacflt_ssidChange_24.ncwl?wlSsidIdx=" + restrict;

      $.get(url,
      		function(data,status){
            $("#div_24GhzFltMode").empty();
      		$("#div_24GhzFltMode").append(data);
      	});
   }
   else if(id == 0){
      var restrict = $("select[name=5GhzMacSSID]").val();
      var url = "nc_wlmacflt_ssidChange_5.ncwl?wlSsidIdx=" + restrict;

      $.get(url,
      		function(data,status){
            $("#div_5GhzFltMode").empty();
      		$("#div_5GhzFltMode").append(data);
      	});
   }
}


function initWlflt(id){
   if(id == 1){
      $("select[name=24GhzMacSSID]").empty();
      $("select[name=24GhzMacSSID]").append("<option value='0'>" + mainssid_24 + "</option>");
      $("select[name=24GhzMacSSID]").append("<option value='1'>" + guestssid1_24 + "</option>");
      /*$("select[name=24GhzMacSSID]").append("<option value='2'>" + guestssid2_24 + "</option>");
      $("select[name=24GhzMacSSID]").append("<option value='3'>" + guestssid3_24 + "</option>");*/      

      $("select[name=24GhzMacSSID]").get(0).selectedIndex = 0;

      filterSSIDChange(1);        
   }
   else {
      $("select[name=5GhzMacSSID]").empty();
      $("select[name=5GhzMacSSID]").append("<option value='0'>" + mainssid_5 + "</option>");
      $("select[name=5GhzMacSSID]").append("<option value='1'>" + guestssid1_5 + "</option>");
      /*$("select[name=5GhzMacSSID]").append("<option value='2'>" + guestssid2_5 + "</option>");
      $("select[name=5GhzMacSSID]").append("<option value='3'>" + guestssid3_5 + "</option>"); */     

      $("select[name=24GhzMacSSID]").get(0).selectedIndex = 0;

      filterSSIDChange(0);        
   }
}

function modeClick(id) {
   if(id == 1){
      var restrict = $("select[name=24GhzMacSSID]").val();      
      var loc = 'nc_wlmacflt_modeChange_24.ncwl?wlSsidIdx=' + restrict;

      if ( enbl_24 == '0' ) {
         alert("Cannot change MAC filter mode since wireless is currently disabled.");
         return;
      }
      var macMode = $("input[name=24GhzMacRestrictMode]");
      for (i = 0; i < $(macMode).length; i++) {            
         if ( $(macMode[i]).is(':checked') ){
            loc += '&wlFltMacMode=' + $(macMode[i]).val();
            break;
         }
      }
      
      $.get(loc);        
   }
   else{
      var restrict = $("select[name=5GhzMacSSID]").val();      
      var loc = 'nc_wlmacflt_modeChange_5.ncwl?wlSsidIdx=' + restrict;

      if ( enbl_5 == '0' ) {
         alert("Cannot change MAC filter mode since wireless is currently disabled.");
         return;
      }

      var macMode = $("input[name=5GhzMacRestrictMode]");
      for (i = 0; i < $(macMode).length; i++) {            
         if ( $(macMode[i]).is(':checked') ){
            loc += '&wlFltMacMode=' + $(macMode[i]).val();
            break;
         }
      }

      $.get(loc);
   }
}

function deleteRow_24(obj) {
   if ( enbl_24 == '0' ) {
      alert("Cannot remove MAC filter address since wireless is currently disabled.");
      return;
   }

   var index = obj.parentNode.parentNode.rowIndex;
   var table = document.getElementById("24GhzMacAddrList");
   var macFltIfc = $("#24GhzMacAddrList").find("tr").eq(index).find("td").eq(0).html();
   table.deleteRow(index);
   var loc = 'nc_wlmacflt_rmmac_24.ncwl?action=remove&rmLst=' + macFltIfc;

   $.get(loc);
}
function deleteRow_5(obj) {
   if ( enbl_5 == '0' ) {
      alert("Cannot remove MAC filter address since wireless is currently disabled.");
      return;
   }

   var index = obj.parentNode.parentNode.rowIndex;
   var table = document.getElementById("5GhzMacAddrList");
   var macFltIfc = $("#5GhzMacAddrList").find("tr").eq(index).find("td").eq(0).html();
   table.deleteRow(index);
   var loc = 'nc_wlmacflt_rmmac_5.ncwl?action=remove&rmLst=' + macFltIfc;

   $.get(loc);
}

function macFltAdd(id) {
   if(id == 1){      
      var loc = 'nc_wlmacflt_addmac_24.ncwl?action=add';
	
      if ( enbl_24 == '0' ) {
         alert("Cannot apply the change since wireless is currently disabled.");
         return;
      }
      
      if ( isValidMacAddress($("input[name=24GhzMacAddr]").val()) == false ) {
         msg = "MAC address '" + $("input[name=24GhzMacAddr]").val() + "' is invalid MAC address.";
         alert(msg);
         return;
      }

      loc += '&wlFltMacAddr=' + $("input[name=24GhzMacAddr]").val();

      loc += '&wlSyncNvram=1';

      $.get(loc);
      $("#Close_24").trigger("click");
      filterSSIDChange(1);
   }
   else{      
      var loc = 'nc_wlmacflt_addmac_5.ncwl?action=add';

      if ( enbl_5 == '0' ) {
         alert("Cannot apply the change since wireless is currently disabled.");
         return;
      }
      
      if ( isValidMacAddress($("input[name=5GhzMacAddr]").val()) == false ) {
         msg = "MAC address '" + $("input[name=5GhzMacAddr]").val() + "' is invalid MAC address.";
         alert(msg);
         return;
      }

      loc += '&wlFltMacAddr=' + $("input[name=5GhzMacAddr]").val();

      loc += '&wlSyncNvram=1';

      $.get(loc);
      $("#Close_5").trigger("click");
      filterSSIDChange(0);
   }
}
function displayPsk(type){
   if(type == "24Guest"){
      $("#display24MainPskText").empty();
      $("#display24MainPskText").append("<span>" + $("input[name=24GHzGuestNTPSK]").val()+"</span>");
   }
      
}