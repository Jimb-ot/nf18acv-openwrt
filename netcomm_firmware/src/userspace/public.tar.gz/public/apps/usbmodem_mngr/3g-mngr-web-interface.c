/*
	for telerforaci web  function
	this file impliment a state mechine for manger the poping web function
	scb+ 2010-12-23
*/
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
#include <setjmp.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include<sys/wait.h>
#include <sys/ioctl.h>

#include "3g-mngr-include.h"

/*the switch file for outputting debug info*/
#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_web", "WEB", args)

//#define DEBUG

#undef DPRINT
#ifdef DEBUG
#define DPRINT(args...)  printf_3g("", args)
#else
#define DPRINT(args...)  d_printf(args)
#endif

#ifdef TBS
#define BRIDGE	"br1"
#define DNS_CHAINS	"PREROUTING"
#define HTTPD_CHAINS	"PREROUTING"
#else
#define BRIDGE	"br0"
#define DNS_CHAINS	"APPPRE"
#define HTTPD_CHAINS	"PREROUTING"
#endif

#ifdef APPS_GENERAL_CAPTIVAL_PORTAL
#ifdef TBS
#define WEB_PAGE_TBS_PRE \
	"cgi-bin/webproc?getpage=html/index.html&var:page="
	
#define WEB_PAGE_PIN_ENTER WEB_PAGE_TBS_PRE "wan3gpin"

#define WEB_PAGE_PIN_CRRECT WEB_PAGE_TBS_PRE "wan3g_connect_status"

#define  WEB_PAGE_PIN_ERROR WEB_PAGE_TBS_PRE "wan3gview"

#define WEB_PAGE_CONNECTING WEB_PAGE_TBS_PRE "wan3g_connect_status"

/*connected, show for 3s*/
#define WEB_PAGE_CONNECTED WEB_PAGE_TBS_PRE "wan3g_connect_status"

#define WEB_PAGE_DISCONNECTED  	WEB_PAGE_TBS_PRE "wan3g_connect_status"

#define WEB_PAGE_PIN_RERSULT WEB_PAGE_TBS_PRE "wan3gpinresult"

#define WEB_PAGE_CONFIG	WEB_PAGE_TBS_PRE "wan3gcfg"

#endif
#ifdef BRCM

#define WEB_PAGE_PIN_ENTER  	"wanusbmodempincfg.html"

#define WEB_PAGE_PIN_CRRECT  	"wanusbmodem_cfgview.html"

#define  WEB_PAGE_PIN_ERROR  	"wanusbmodem_cfgview.html"

#define WEB_PAGE_CONNECTING  	"wanusbmodem_cfgview.html"

/*connected, show for 3s*/
#define WEB_PAGE_CONNECTED  	"wanusbmodem_cfgview.html"

#define WEB_PAGE_DISCONNECTED  	"wanusbmodemview.html"

#define WEB_PAGE_PIN_RERSULT  "wanusbmodempincfg.html"

#define WEB_PAGE_CONFIG	 	"usbmodemcfg.html"

#endif


#endif

typedef int (*web_page_func_t)(void *__web, int isadd);

#define WEB_URL_LEN 128

typedef struct {
	web_state_t state;
	web_state_t old_state;
	char IPInterfaceIPAddress[80]; /*lan ip address,come from ssk*/
	char IPInterfaceSubnetMask[80];
	web_page_func_t   last_page_func; /*point to type web_page_func_t*/	


	int httpd_port;
	int dns_port;

	char url_pin_enter[WEB_URL_LEN];
	char url_pin_result[WEB_URL_LEN];	
	char url_pin_correct[WEB_URL_LEN];
	char url_pin_error[WEB_URL_LEN];
	char url_connecting[WEB_URL_LEN];
	char url_connected[WEB_URL_LEN];
	char url_disconect[WEB_URL_LEN];	
	char url_configure[WEB_URL_LEN];

	int pin_pop_enable;
	int normal_pop_enable;
		
	struct timer_3g  delay;
} __web_mngr_t;

typedef struct  {
	char event[32] ;
	web_state_t state;
	web_state_t next_state;
	void  (*web_handler)(__web_mngr_t * __web, const char *event);
} state_event_handler_t;

static void web_handler_idle(__web_mngr_t * __web, const char *event);
static void web_handler_needpincode(__web_mngr_t * __web, const char *event);
static void web_handler_pinready(__web_mngr_t * __web, const char *event);
static void web_handler_ready(__web_mngr_t * __web, const char *event);
static void web_handler_dial_req(__web_mngr_t * __web, const char *event);
static void web_handler_dialing(__web_mngr_t * __web, const char *event);
static void web_handler_manual_ready(__web_mngr_t * __web, const char *event);
static void web_handler_dial_success(__web_mngr_t * __web, const char *event);
static void web_handler_dial_fail(__web_mngr_t * __web, const char *event);
static void web_handler_dial_waiting(__web_mngr_t * __web, const char *event);
static void web_handler_connected(__web_mngr_t * __web, const char *event);
static void web_cancel_last_page(__web_mngr_t *__web);

static state_event_handler_t   handler[] = 
{	
	/*any---->WEB_STATE_IDLE*/
	{WEB_EVENT_STOP, WEB_STATE_READY,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_NEED_PIN_CODE, WEB_STATE_IDLE,  web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_PINREADY,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_MANUAL_READY, WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_DIAL_REQ,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_DIALING,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_DIAL_FAIL,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_DIAL_WAITING,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_DIAL_SUCCESS,  WEB_STATE_IDLE, web_handler_idle},
	{WEB_EVENT_STOP, WEB_STATE_CONNECTED, WEB_STATE_IDLE, web_handler_idle},

	/*the start switch, cause by ssk*/
	{WEB_EVENT_READY, WEB_STATE_IDLE,  WEB_STATE_READY, web_handler_ready},

	/*the start switch, cause by ssk*/
	{WEB_EVENT_NEED_PIN_CODE, WEB_STATE_IDLE,  WEB_STATE_NEED_PIN_CODE, web_handler_needpincode},

	{WEB_EVENT_MANUAL_DIAL, WEB_STATE_IDLE,  WEB_STATE_MANUAL_READY, web_handler_manual_ready},

	
	
	{WEB_EVENT_DIAL_ALLOW, WEB_STATE_READY,  WEB_STATE_DIAL_REQ, web_handler_dial_req},


	{WEB_EVENT_DIALING, WEB_STATE_DIAL_REQ,  WEB_STATE_DIALING, web_handler_dialing},
	/*for manual dial*/
	{WEB_EVENT_DIALING, WEB_STATE_MANUAL_READY,  WEB_STATE_DIALING, web_handler_dialing},

	{WEB_EVENT_DIALING, WEB_STATE_PINREADY,  WEB_STATE_DIALING, web_handler_dialing},
	

	{WEB_EVENT_DIAL_FAILE, WEB_STATE_DIALING,  WEB_STATE_DIAL_FAIL, web_handler_dial_fail},
	{WEB_EVENT_DIAL_WAITING, WEB_STATE_DIALING,  WEB_STATE_DIAL_WAITING, web_handler_dial_waiting},
	{WEB_EVENT_DIAL_SUCCESS, WEB_STATE_DIALING,  WEB_STATE_DIAL_SUCCESS, web_handler_dial_success},

	
	{WEB_EVENT_DIALING, WEB_STATE_DIAL_WAITING,  WEB_STATE_DIALING, web_handler_dialing},

	{WEB_EVENT_PIN_ERROR, WEB_STATE_NEED_PIN_CODE,  WEB_STATE_NEED_PIN_CODE, web_handler_needpincode},

	{WEB_EVENT_PIN_READY, WEB_STATE_NEED_PIN_CODE, WEB_STATE_PINREADY, web_handler_pinready},

	{WEB_EVENT_DELAY_TIMEOUT, WEB_STATE_PINREADY,  WEB_STATE_DIAL_REQ, web_handler_dial_req},	

	{WEB_EVENT_CONNECTED_CONFIRM, WEB_STATE_DIAL_SUCCESS,  WEB_STATE_CONNECTED, web_handler_connected},

};
	
	
int web_mngr_init(web_mngr_t *web)
{	
	__web_mngr_t *__web = 0;
	SUB_INIT(web, web_mngr_t, __web_mngr_t);

	__web = GET_PRI(web, __web_mngr_t);

	__web->httpd_port = 80;
	__web->dns_port = 53;

	/*indicate pop whitch web page*/
	__web->pin_pop_enable = 1;
	__web->normal_pop_enable = 1;

#ifdef APPS_GENERAL_CAPTIVAL_PORTAL	
	snprintf(__web->url_pin_enter, WEB_URL_LEN, "%s", 
		WEB_PAGE_PIN_ENTER);
	snprintf(__web->url_pin_correct, WEB_URL_LEN, "%s", 
		WEB_PAGE_PIN_CRRECT);
	snprintf(__web->url_pin_error, WEB_URL_LEN, "%s", 
		WEB_PAGE_PIN_ERROR);
	snprintf(__web->url_pin_result, WEB_URL_LEN, "%s", 
		WEB_PAGE_PIN_RERSULT);
	snprintf(__web->url_connected , WEB_URL_LEN, "%s", 
		WEB_PAGE_CONNECTED);
	snprintf(__web->url_connecting, WEB_URL_LEN, "%s", 
		WEB_PAGE_CONNECTING);
	snprintf(__web->url_disconect, WEB_URL_LEN, "%s", 
		WEB_PAGE_DISCONNECTED);	
	snprintf(__web->url_configure, WEB_URL_LEN, "%s", 
		WEB_PAGE_CONFIG);		
#endif	
		
	
	return 0;	
}

web_mngr_t *web_mngr_new(void *mn)
{
	web_mngr_t *web;

	if ((web = ALLOC_3G(web_mngr_t, __web_mngr_t)) <= 0)
		return 0;

	MN_SET(web, mn);

	web_mngr_init(web);

	return web;
}

int web_mngr_free(web_mngr_t *web)
{
	if (!web)
		return 0;
	
	if (MN(web))
		MN(web)->web = 0;

	free(web);
	web = 0;
	return 0;
}

static const char *state_string(web_state_t s)
{
#define STS_STR(__s) case __s: return #__s;
	
	switch (s) {
		STS_STR(WEB_STATE_IDLE);
		STS_STR(WEB_STATE_READY);
		STS_STR(WEB_STATE_NEED_PIN_CODE);
		STS_STR(WEB_STATE_DIAL_REQ);
		STS_STR(WEB_STATE_DIALING);
		STS_STR(WEB_STATE_DIAL_FAIL);
		STS_STR(WEB_STATE_DIAL_WAITING);
		STS_STR(WEB_STATE_DIAL_SUCCESS);
		STS_STR(WEB_STATE_CONNECTED);
		STS_STR(WEB_STATE_PINREADY);
		STS_STR(WEB_STATE_MANUAL_READY);	
	}

	return "INVALID";

}

void web_mngr_event(web_mngr_t *web, const char *event)
{
	int handler_num = sizeof(handler)/sizeof(handler[0]);
	int i;
	int doflag = 0;
	__web_mngr_t  *__web = GET_PRI(web,  __web_mngr_t);

	DPRINT("event:[%s]    __web_mngr_t info:\n"
			"\t{\n"
			"\t	old_state:%s\n"
			"\t	state:%s\n"
			"\t	IPInterfaceIPAddress:%s\n"
			"\t	IPInterfaceSubnetMask:%s\n"
			"\t	last_page_func:0x%x\n"
			"\t}\n",
			event,
			state_string(__web->old_state),
			state_string(__web->state),
			__web->IPInterfaceIPAddress,
			__web->IPInterfaceSubnetMask,
			(unsigned int)(__web->last_page_func));


	for (i = 0; i < handler_num; i++) {
		if (__web->state == handler[i].state && strcmp(handler[i].event, event) == 0) {
			doflag = 1;
			handler[i].web_handler(__web, event);
			break;
		}
	}

	if (!doflag) {
		d_printf("can not handle such event [%s] at state[%s]\n", 
			event?event:"NONE",
			state_string(__web->state));
		
		return;
	}

	__web->old_state = __web->state;
	__web->state = handler[i].next_state;

	DPRINT("\n"
			"\t			%s\n"
			"\t[%s]------------------------------>[%s]\n"
			"\n",
		event,
		state_string(__web->old_state),
		state_string(__web->state));
}

web_state_t web_mngr_get_state(web_mngr_t *web)
{
	__web_mngr_t  *__web = GET_PRI(web,  __web_mngr_t);

	return __web->state;	
}

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
static void web_page_captival(void * __web_, const char *url, int is_pop)
{
	__web_mngr_t *__web = (__web_mngr_t *)__web_;
	
	if (!is_pop) {
		d_printf("delete captival\n");
		lib3g_fmt_script("%s", "captival del");
		return;
	}

	d_printf("captival portal to %s\n", url);
	lib3g_fmt_script("captival set --url=\"%s\" --intf=%s --host=%s --mask=%s",
		url, BRIDGE,  
		__web->IPInterfaceIPAddress, __web->IPInterfaceSubnetMask);
}

static void web_page_maintain_timer(void *data)
{
	__web_mngr_t *__web = (__web_mngr_t *)data;

	d_printf("Time out. Cancel the last page\n");
	web_cancel_last_page(__web);
}
#endif
/*   
	The following functions for adding rule for pop pages.
	If  adding any rule, need return 1.
	If no adding any rule, or dell all the rule added before, need return 0.
*/
static int web_page_no_need_pin(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

	return 0;
}

static int web_page_pin_ready(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_pin_result, 1);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#endif

	return 0;

}

static int web_page_dial_req(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

	return 0;
}

static int web_page_pin_cfg(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {		
		web_page_captival(__web_, __web->url_pin_enter,1);
		return 1;
	} 

	web_page_captival(__web_, "", 0);
#else
	if (isadd) {
		/*scb+ 2012-7-9, sometime,user not need to pop the pin cfg page*/
		if (!__web->pin_pop_enable) {
			d_printf("User not need pop pin cfg page\n");
			return 0;
		}
		
		if (__web->IPInterfaceIPAddress[0] && 
				__web->IPInterfaceSubnetMask[0]) 
		{
			/* clean all relus first */
			lib3g_fmt_script("iptables -t nat -F REDPRE");
              
			lib3g_fmt_script(
				"iptables -t nat -D %s -i %s -d ! %s -p udp"
				" --dport 53 -j DNAT --to %s:%d",
				DNS_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress,
				__web->IPInterfaceIPAddress, 
				__web->dns_port);
			lib3g_fmt_script("iptables -t nat -D %s -i %s -p tcp -d ! %s/%s "
				"--dport 80 -j DNAT --to %s:%d",
				HTTPD_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress,
				__web->IPInterfaceSubnetMask, 
				__web->IPInterfaceIPAddress,
				__web->httpd_port);
			lib3g_fmt_script("iptables -t nat -A %s -i %s -d ! %s -p udp "
				"--dport 53 -j DNAT --to %s:%d",
				DNS_CHAINS,
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceIPAddress, 
				__web->dns_port);
			lib3g_fmt_script("iptables -t nat -A %s -i %s -p tcp -d ! %s/%s "
				"--dport 80 -j DNAT --to %s:%d",
				HTTPD_CHAINS,
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceSubnetMask, 
				__web->IPInterfaceIPAddress,
				__web->httpd_port);
			lib3g_fmt_script("echo 1 > /var/needpincode");
			lib3g_fmt_script("echo 1 > /var/needredirect");

			return 1;
		}
	}
	else 
	{
	
		if (__web->IPInterfaceIPAddress[0] && 
				__web->IPInterfaceSubnetMask[0]) {
			lib3g_fmt_script("iptables -t nat -D %s -i %s -d ! %s -p udp"
				" --dport 53 -j DNAT --to %s:%d", 
				DNS_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceIPAddress,
				__web->dns_port);
			lib3g_fmt_script("iptables -t nat -D %s -i %s -p tcp -d ! %s/%s "
				"--dport 80 -j DNAT --to %s:%d",
				HTTPD_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceSubnetMask, 
				__web->IPInterfaceIPAddress,
				__web->httpd_port);
			lib3g_fmt_script("rm -f /var/needpincode");
			lib3g_fmt_script("rm -f /var/needredirect");  
			lib3g_fmt_script("rm -f /var/needinform3gup");
         
			return 0;
		}
	}
#endif
	return 0;
}

static int web_page_dial_fail(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_configure, 1);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#endif

	return 0;
}

static int web_page_manual_dial(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_connecting, 1);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#endif

	return 0;
}

static int web_page_connected(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_connected, 1);
		timer_set(5, "web_page_maintain_timer", 
			web_page_maintain_timer,
			__web_);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#else
	/* Pop up a WEB page, tell user connect to internet by 3G WAN */
	if (isadd) {
		if (!__web->normal_pop_enable) {
			d_printf("Connected,the user not need pop notify page\n");
			return 0;
		}

		int needinform3gup = access("/var/needinform3gup", F_OK);

    
		if (needinform3gup == 0 && __web->IPInterfaceIPAddress[0] && 
				__web->IPInterfaceSubnetMask[0]) {
			/* clean all relus first */
			lib3g_fmt_script("iptables -t nat -F REDPRE");
            
			lib3g_fmt_script("iptables -t nat -D %s -i %s -d ! %s -p udp "
				"--dport 53 -j DNAT --to %s:%d",
				DNS_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceIPAddress,
				__web->dns_port);
			lib3g_fmt_script("iptables -t nat -D %s -i %s -p tcp -d ! %s/%s "
				"--dport 80 -j DNAT --to %s:%d",
				HTTPD_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceSubnetMask, 
				__web->IPInterfaceIPAddress,
				__web->httpd_port);	   
			lib3g_fmt_script("iptables -t nat -A %s -i %s -d ! %s -p udp "
				"--dport 53 -j DNAT --to %s:%d",
				DNS_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceIPAddress, 
				__web->dns_port);
			lib3g_fmt_script("iptables -t nat -A %s -i %s -p tcp -d ! %s/%s "
				"--dport 80 -j DNAT --to %s:%d",
				HTTPD_CHAINS, 
				BRIDGE, 
				__web->IPInterfaceIPAddress, 
				__web->IPInterfaceSubnetMask, 
				__web->IPInterfaceIPAddress, 
				__web->httpd_port);
			lib3g_fmt_script("echo 1 > /var/needredirect");

			return 1;
		}
	} else {
         
		return 0;
	}
#endif
	return 0;
}

static int web_page_dialing(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_connecting, 1);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#endif
	return 0;
}

static int web_page_dialwaiting(void * __web_, int isadd)
{
	__web_mngr_t *__web;
	DPRINT("enter: %s\n",isadd?"ADD":"DEL");

	__web = (__web_mngr_t *)__web_;

#if defined(PC)
#if defined(DEBUG)
	return 1;
#else
	return 0;
#endif
#endif

#if defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	if (isadd) {
		web_page_captival(__web_, __web->url_connecting, 1);
		return 1;
	}
	web_page_captival(__web_, "", 0);
#endif

	return 0;	
}


/******************End the rule adding functions********************************/

static void 
web_cancel_last_page(__web_mngr_t *__web)
{
	if (__web->last_page_func)
		__web->last_page_func((void *)__web, 0);

	__web->last_page_func = 0;
}

static void 
web_pop_page(__web_mngr_t *__web, web_page_func_t func)
{
	web_cancel_last_page(__web);

	if (func && func((void *) __web, 1))
		__web->last_page_func = func;
}

static void
web_handler_idle(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");
	
#if !defined(APPS_GENERAL_CAPTIVAL_PORTAL)
	/* clean all regirect settings, when 3G down */
	if (__web->IPInterfaceIPAddress[0] && __web->IPInterfaceSubnetMask[0]) {
		lib3g_fmt_script("iptables -t nat -D %s -i %s -d ! %s -p udp "
			" --dport 53 -j DNAT --to %s:%d", 
			DNS_CHAINS, 
			BRIDGE, 
			__web->IPInterfaceIPAddress, 
			__web->IPInterfaceIPAddress, 
			__web->dns_port);
		lib3g_fmt_script("iptables -t nat -D %s -i %s -p tcp -d ! %s/%s "
			"--dport 80 -j DNAT --to %s:%d",
			HTTPD_CHAINS, 
			BRIDGE,
			__web->IPInterfaceIPAddress,
			__web->IPInterfaceSubnetMask,
			__web->IPInterfaceIPAddress, 
			__web->httpd_port);
		lib3g_fmt_script("rm -f /var/needpincode");
		lib3g_fmt_script("rm -f /var/needredirect");  
		lib3g_fmt_script("rm -f /var/needinform3gup");
	}
   #else
   	timer_del_by_token("web_page_maintain_timer");
   #endif
   
	web_cancel_last_page(__web);

   	memset(&__web->delay, 0, sizeof(struct timer_3g ));
	__web->IPInterfaceIPAddress[0] = 0;
	__web->IPInterfaceSubnetMask[0] = 0;
	__web->last_page_func = 0;
}

static void 
web_handler_needpincode(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_pin_cfg);
}

static void web_handler_delay_timer(void *data)
{
	web_mngr_event(mn->web, WEB_EVENT_DELAY_TIMEOUT);
}

static void 
web_handler_pinready(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_pin_ready);


	__web->delay.data = 0;
	__web->delay.tick= 5;
	__web->delay.handler = web_handler_delay_timer;
	timer_add(&__web->delay);
}

static void 
web_handler_ready(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_no_need_pin);
}

static void 
web_handler_dial_req(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	/*notify ssk to start to dial*/
	lib3g_send_mobile_chage_msg(MNGR_MSG_WEBMSG"=dialreq");

	web_pop_page(__web, web_page_dial_req);
}

static void 
web_handler_dialing(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_dialing);
}

static void 
web_handler_dial_fail(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_dial_fail);	
}

static void
web_handler_manual_ready(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");
	web_pop_page(__web, web_page_manual_dial);	
	
	/*notify ssk to start to dial*/
	lib3g_send_mobile_chage_msg(MNGR_MSG_WEBMSG"=dialreq");		
}

static void 
web_handler_dial_success(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_pop_page(__web, web_page_connected);		

	/*
	__web->delay.data = 0;
	__web->delay.tick= 5;
	__web->delay.handler = web_handler_delay_timer;
	timer_add(&__web->delay);
	*/
}

static void 
web_handler_dial_waiting(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");
	
	web_pop_page(__web, web_page_dialwaiting);		
}

static void 
web_handler_connected(__web_mngr_t * __web, const char *event)
{
	DPRINT("enter\n");

	web_cancel_last_page(__web);
}

static int web_mngr_show(int argc, char *argv[], char *rbuf, int len)
{
	__web_mngr_t *__web = GET_PRI(mn->web, __web_mngr_t);
	char timer_buf[80] = {0};
	
	if (!rbuf || len <= 0)
		return 0;
	
	memset(rbuf, 0, len);
	
	cdmg_fstrncat(rbuf, len-1,
		"\n__web_mngr_t info:\n"
		"\t{\n"
		"\t	old_state:%s\n"
		"\t	state:%s\n"
		"\t	IPInterfaceIPAddress:%s\n"
		"\t	IPInterfaceSubnetMask:%s\n"
		"\t	last_page_func:0x%x\n"
		"\t	timer:%s\n"
		"\t}\n",
		state_string(__web->old_state),
		state_string(__web->state),
		__web->IPInterfaceIPAddress,
		__web->IPInterfaceSubnetMask,
		(unsigned int)(__web->last_page_func),
		timer_3g_show(&__web->delay, timer_buf, 80));
	
	cdmg_fstrncat(rbuf, len-1, 
		"\n"
		"httpd port is:%d\n"
		"dns port is:%d\n"
		"url_pin_enter:%s\n"
		"url_pin_result:%s\n"	
		"url_pin_correct:%s\n"
		"url_pin_error:%s\n"
		"url_connecting:%s\n"
		"url_connected:%s\n"
		"url_disconect:%s\n"
		"url_configure:%s\n",		
		__web->httpd_port, 
		__web->dns_port,
		__web->url_pin_enter,
		__web->url_pin_result,
		__web->url_pin_correct,
		__web->url_pin_error,
		__web->url_connecting,
		__web->url_connected,
		__web->url_disconect,
		__web->url_configure);

	cdmg_fstrncat(rbuf, len-1,
		"pin_pop_enable:%d\n"
		"normal_pop_enable:%d\n",
		__web->pin_pop_enable,
		__web->normal_pop_enable);
	
	return strlen(rbuf) + 1;	
}
__CDMG_SETUP_GET(web_mngr_show, 1, web_mngr_show, 0, 0, "");

CDMG_FUNC(webctl, 1, 0, 0, 0, 0, 0,
		      "control the web page pop function.\n"
                   "exam: 3g-mngr webctl --show | "
                   "--event=xxxx --lan=xxx --lanmsk=xxx |\n"
                   "\t --httpd_port=80 --dns_port=53 \n"
                   "\t --url_pin_enter=xxx\n"
                   "\t --url_pin_correct=xxx\n"
                   "\t --url_pin_error=xxx\n"
                   "\t --url_pin_result=xxx\n"
                   "\t --url_connected=xxx\n"
                   "\t --url_connecting=xxx\n"
                   "\t --url_disconnect=xxx\n"
                   "\t --url_configure=xxx\n"
                   "\t --pin_pop_enable=0|1\n"
                   "\t --normal_pop_enable=0|1\n")
{
	char show[4] = {0};
	char *buf = 0;
	char pin_pop_enable[4] = {0};
	char normal_pop_enable[4] = {0};

	d_printf("enter\n");
	/*At daemon, this code segment do not be called*/
	if (!cdmg_is_on_daemon() && CDMG_GET_ARG("show", show)) 
	{
		/*Get info from diald*/
		CDMG_SEND_AND_GET(buf, 1000000, web_mngr_show,"%s", "");		
		if (buf) {		
			printf(buf);
			free(buf);
		}		
		return 0;
	}	

	/*Let  diald to do the following action*/
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;	

	d_printf("enter\n");

	__web_mngr_t *__web = GET_PRI(mn->web, __web_mngr_t);

	char httpd_port[12] = {0};
	char dns_port[12] = {0};
	
	CDMG_GET_ARG("httpd_port", httpd_port);
	CDMG_GET_ARG("dns_port", dns_port);
	if (httpd_port[0])
		__web->httpd_port= strtoul(httpd_port, 0, 10);
	if (dns_port[0])
		__web->dns_port= strtoul(dns_port, 0, 10);

	if (CDMG_GET_ARG("pin_pop_enable", pin_pop_enable)) {
		if (pin_pop_enable[0] == '0')
			__web->pin_pop_enable = 0;
		if (pin_pop_enable[0] == '1')
			__web->pin_pop_enable = 1;			
	}

	if (CDMG_GET_ARG("normal_pop_enable", normal_pop_enable)) {
		if (normal_pop_enable[0] == '0')
			__web->normal_pop_enable= 0;
		if (normal_pop_enable[0] == '1')
			__web->normal_pop_enable = 1;			
	}	

	/*set url*/
	char url_pin_enter[WEB_URL_LEN];
	char url_pin_result[WEB_URL_LEN];	
	char url_pin_correct[WEB_URL_LEN];
	char url_pin_error[WEB_URL_LEN];
	char url_connecting[WEB_URL_LEN];
	char url_connected[WEB_URL_LEN];
	char url_disconect[WEB_URL_LEN];	
	char url_configure[WEB_URL_LEN];

#define WEBCTL_SET_URL(n, v, e) \
	if (CDMG_GET_ARG(n, v))	\
		snprintf(e, WEB_URL_LEN, "%s", v)
	
	WEBCTL_SET_URL("url_pin_enter", url_pin_enter, __web->url_pin_enter);
	WEBCTL_SET_URL("url_pin_correct", url_pin_correct, __web->url_pin_correct);
	WEBCTL_SET_URL("url_pin_error", url_pin_error, __web->url_pin_error);
	WEBCTL_SET_URL("url_pin_result", url_pin_result, __web->url_pin_result);
	WEBCTL_SET_URL("url_connecting", url_connecting, __web->url_connecting);
	WEBCTL_SET_URL("url_connected", url_connected, __web->url_connected);
	WEBCTL_SET_URL("url_disconect", url_disconect, __web->url_disconect);
	WEBCTL_SET_URL("url_configure", url_configure, __web->url_configure);
	

	char event[32] = {0};
	char ipaddr[80] = {0};
	char mask[80] = {0};		

	/*web event*/
	CDMG_GET_ARG("event", event);
	if (event[0]) {		
		__web = GET_PRI(mn->web, __web_mngr_t);

		if (strcmp(event, WEB_EVENT_READY) == 0 || 
				    strcmp(event, WEB_EVENT_NEED_PIN_CODE) == 0 ||
				    strcmp(event, WEB_EVENT_MANUAL_DIAL) == 0) {
			CDMG_GET_ARG("lan", ipaddr);
			CDMG_GET_ARG("lanmsk", mask);

			if (ipaddr[0])
			strncpy(__web->IPInterfaceIPAddress, ipaddr, sizeof(ipaddr));

			if (mask[0])
			strncpy(__web->IPInterfaceSubnetMask, mask, sizeof(mask));
		}
		web_mngr_event(mn->web, event);
	}

	return 0;
}

#undef DPRINT
#endif
