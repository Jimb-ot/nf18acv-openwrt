#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

//#include "lib/3g-lib.h"
#include "3g-mngr-include.h"

/*the switch file for outputting debug info*/
#undef DIAL_DEBUG_LOCAL_TAG_FILE
#define DIAL_DEBUG_LOCAL_TAG_FILE "/var/3g_debug_pin"

int pin_mngr_init(pin_mngr_t *pin)
{
	SUB_INIT(pin, pin_mngr_t, 0);
	return 0;	
}

pin_mngr_t *pin_mngr_new(void *mn)
{
	pin_mngr_t *pin = 0;

	if ((pin = ALLOC_3G(pin_mngr_t, 0)) <= 0)
		return 0;

	MN_SET(pin, mn);
	
	pin_mngr_init(pin);
	
	return pin;
	
}

int pin_mngr_free(pin_mngr_t *pin)
{
	if (!pin)
		return 0;

	if (MN(pin))
		MN(pin)->pin = 0;
	
	free(pin);
	pin = 0;
	return 0;
}

/************************************/
static void pin_mngr_show_remain_setting_time(pin_mngr_t *pin_mr, const char *type)
{
	int retry = -1;

	if (!pin_mr)
		return;	
    
	if (strstr(type, "pin"))
		retry = modem_set_pin_retry_t(MN(pin_mr)->mdm);
	else if (strstr(type, "cpin"))
		retry = modem_chg_pin_retry_t(MN(pin_mr)->mdm);
	else if (strstr(type, "puk"))
		retry = modem_set_puk_retry_t(MN(pin_mr)->mdm);
	else if (strstr(type, "lock")) 
		retry = modem_set_lock_retry_t(MN(pin_mr)->mdm);

	printf("%d", retry);
}

static int pin_mngr_need_to_set_lock(pin_mngr_t *pin_mr)
{
	char *info = 0;
	char lock[10] = {0};
	char pin[12] = {0};

	if (!pin_mr)
		return 1;	

	modem_get_lock_info(MN(pin_mr)->mdm, &info);
	param_get_item(MN(pin_mr)->par, "pin", pin);
	param_get_item(MN(pin_mr)->par, "lock", lock);

	if (!lock[0]) {		
		printf(info);
		return 0;
      }	

	if (strstr(info, LOCK_INFO_LOCK) && lock[0] == '1') {
		printf("OK");
		return 0;
	}

	if (strstr(info, LOCK_INFO_UNLOCK) && lock[0] == '0') {
		printf("OK");
		return 0;
	}
	
	if (lock[0] == '1' && !pin[0]) {
		printf("NO  PIN CODE!");
		return 0;
	}
	
	if (lock[0] == '0' &&  !pin[0]) {
		printf("NO  PIN CODE!");
		return 0;
	}

	return 1;
}

static int pin_mngr_lock_setting_is_no_ok(pin_mngr_t *pin_mr)
{
	char *info;
	char lock[10] = {0};

	if (!pin_mr)
		return 1;	
    
	modem_get_pin_info(MN(pin_mr)->mdm, &info);

	if (strstr(info, PIN_INFO_PUK)) {
		printf(PIN_CODE_RET_PUK_ERR":you must enter puk code!");
		return 0;
	}
	
	modem_get_lock_info(MN(pin_mr)->mdm, &info);
	param_get_item(MN(pin_mr)->par, "lock", lock);
	
	if (strstr(info, LOCK_INFO_LOCK) && lock[0] == '1') {
		printf("OK");
		return 0;
	}	

	if (strstr(info, LOCK_INFO_UNLOCK) && lock[0] == '0') {
		printf("OK");
		return 0;
	}

	return 1;
}

int pin_mngr_lock(pin_mngr_t *pin_mr, int argc, char *argv[])
{	
	char type[10] = {0};
	char *info = 0;
	int retry = 0;
	param_t *par = 0;
    int count = 2;

	if (!pin_mr)
		return 0;	

	par = MN(pin_mr)->par;

	if (modem_search(MN(pin_mr)->mdm) != 0) {
		printf(STATUS_NO_USB);
		return 0;
	}

	if (cdmg_get_arg(argv, "time", 0, 0)) {
		cdmg_get_arg(argv, "type", type, 10);
		if (!type[0]) {
			strcpy(type, "pin");
		}
		pin_mngr_show_remain_setting_time(pin_mr, type);	
		return 0;
	}

	modem_get_pin_info(MN(pin_mr)->mdm, &info);

	if (!strstr(info, PIN_INFO_READY)) {
		printf(info);
		return 0;
	}

	param_init(MN(pin_mr)->par);
	param_get_from_user(MN(pin_mr)->par, argc, argv);

	if (!pin_mngr_need_to_set_lock(pin_mr))
		return 0;

	modem_set_lock(MN(pin_mr)->mdm);

    while(--count >= 0)
    {
        /* ��ʱ���һ�β�ѯ��ʧ�ܣ��������ﳢ������*/
        sleep(3);
    	if (!pin_mngr_lock_setting_is_no_ok(pin_mr))
        {  
    		return 0;
        }        
    }
	
	retry = modem_set_lock_retry_t(MN(pin_mr)->mdm);	
	
	if (retry == -1)
		printf(AT_CMD_ERR);
	else if (retry == 3)    /* ���óɹ��ˣ���ѯȴʧ�ܣ�Ҳ��Ϊ�ǳɹ������������dongle�ϱ����ݵ��´���*/
        printf("OK");
    else
		printf(PIN_CODE_RET_PIN_ERR":you have %d chages(s) to retry!", retry);

	return 0;		
}


static int pin_mngr_needs_set_pin(pin_mngr_t *pin_mr)
{
	char *info;

	if (!pin_mr)
		return -1;
    
	modem_get_pin_info(MN(pin_mr)->mdm, &info);

	if (strstr(info, PIN_INFO_READY)) {
		printf("%s:needn't enter pin code!", info);
		return 0;
	}
	if (strstr(info, PIN_INFO_PUK)) {
		printf("%s:please enter puk code!\n", info);
		return 0;
	}

	if (strstr(info, PIN_INFO_INVALID)) {
		printf("%s\n", info);
		return 0;
	}

	return 1;
}

int pin_mngr_set_pin(pin_mngr_t *pin_mr, int argc, char *argv[])
{
	char pin[10] = {0};
	char *info = 0;
	int retry;

	if (!pin_mr)
		return -1;

	if (modem_search(MN(pin_mr)->mdm) != 0)
		return -1;
	
	
	if (!pin_mngr_needs_set_pin(pin_mr))
		return 0;
		
	cdmg_get_arg(argv, "code", pin, 10);
	if (!pin[0]) {
		printf("NO CODE!");
		return 0;
	}

	param_get_from_user(MN(pin_mr)->par, argc, argv);

	modem_set_pin(MN(pin_mr)->mdm);

	for (retry = 0; retry < 4; retry++) {
		int ret = 0;
		
		sleep(5);
		ret = modem_get_pin_info(MN(pin_mr)->mdm, &info);
		if (ret == -14) {
			d_printf("sim busy, again\n");
			continue;
		}
		break;
	}

	retry = 0;

	if (!strstr(info, PIN_INFO_PIN) && !strstr(info, PIN_INFO_INVALID)  &&
			!strstr(info, PIN_INFO_PUK) ) {
		if (!strstr(info, PIN_INFO_READY))
			d_printf("pin not ready, %s\n", info);
		CDMG_SEND_MSG(pinready, "%s", "");
		printf("OK");
		return 0;
	} else if (strstr(info, PIN_INFO_PUK)) {
		printf(PIN_INFO_PUK);
		return 0;
	}	

	retry = modem_set_pin_retry_t(MN(pin_mr)->mdm);

    if (retry == 3)
    {
        modem_set_pin_info(MN(pin_mr)->mdm, PIN_INFO_READY);
		CDMG_SEND_MSG(pinready, "%s", "");
		printf("OK");
		return 0;        
    }
	printf(PIN_CODE_RET_PIN_ERR":%s you have %d chage(s) to retry!", info, retry);

	return 0;	
}

int pin_mngr_set_puk(pin_mngr_t *pin_mr, int argc, char *argv[])
{
	char *info = 0;
	char pin[12] = {0};
	char puk[12] = {0};
	int retry = 0;

	if (!pin_mr)
		return -1;
    
	if (modem_search(MN(pin_mr)->mdm) != 0)
		return -1;
	
	modem_get_pin_info(MN(pin_mr)->mdm, &info);
	
	if (strstr(info, PIN_INFO_INVALID)) {
		printf("%s\n", info);
		return 0;
	}	

	if (!strstr(info, PIN_INFO_PUK)) {
		printf("%s:do not allow enter puk!\n", info);
		return 0;
	}

	param_get_from_user(MN(pin_mr)->par, argc, argv);	
	param_get_item(MN(pin_mr)->par, "pin", pin);
	param_get_item(MN(pin_mr)->par, "puk", puk);

	if (!pin[0]) {
		printf("no pin code!");
		return 0;
	}

	if (!puk[0]) {
		printf("no puk code!");
		return 0;
	}

	modem_set_puk(MN(pin_mr)->mdm);

	sleep(5);

	modem_get_pin_info(MN(pin_mr)->mdm, &info);
	
	if (strstr(info, PIN_INFO_READY)) {
		lib3g_send_mobile_msg(MSG_UNIX_DAEMON_PATH, "pukready");   
		printf("OK");
		return 0;
	} 	

	retry = modem_set_puk_retry_t(MN(pin_mr)->mdm);	
	
	printf(PIN_CODE_RET_PUK_ERR": you have %d chage(s) to retry!", retry);

	return 0;	
}

int pin_mngr_chg_pin(pin_mngr_t *pin_mr, int argc, char *argv[])
{
	char pin[12] = {0};
	char newpin[12] = {0};
	char *info = 0;
	int retry = 0;
	int ret = 0;

	if (!pin_mr)
		return -1;

	if (modem_search(MN(pin_mr)->mdm) != 0)
		return -1;

	modem_get_pin_info(MN(pin_mr)->mdm, &info);
	
	if (strstr(info, PIN_INFO_INVALID)) {
		printf("%s\n", info);
		return 0;
	}	

	if (strstr(info, PIN_INFO_PUK)) {
		printf("%s:need enter puk code!\n", info);
		return 0;
	}

	param_get_from_user(MN(pin_mr)->par, argc, argv);	
	param_get_item(MN(pin_mr)->par, "pin", pin);
	param_get_item(MN(pin_mr)->par, "newpin", newpin);
		
	if (!pin[0]) {
		printf("no pin code!");
		return 0;
	}

	if (!newpin[0]) {
		printf("no new pin  code!");
		return 0;
	}	
	

	ret = modem_chg_pin(MN(pin_mr)->mdm);
	sleep(5);
	modem_get_pin_info(MN(pin_mr)->mdm, &info);

	if (strstr(info, PIN_INFO_PUK)) {
		printf("%s:you need enter puk code!\n", info);
		return 0;
	}

	retry = modem_chg_pin_retry_t(MN(pin_mr)->mdm);

	if (retry == 3 && ret == 0) {
		printf("OK");
		return 0;
	}	
	printf(PIN_CODE_RET_PIN_ERR": you have %d chage(s) to retry!", retry);
	return 0;	
}

/*****************************************************************/
FUNC(lock, "enable or disable the pin code\n"
		    "example1: lock\n"
		    "example2: lock --time  --type=pin[|cpin|lock|puk]\n"
		    "example3: lock --enable=0/1 --pin=xxx\n")
{	
	mngr_start(&mn, MNGR_START_CREATE_AT|MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_PAR|MNGR_START_CREATE_PIN);

	pin_mngr_lock(mn->pin, argc, argv);
	
	return 0;	
}

FUNC(pin, "enter the pin  code\n"
			"example: 3g-mngr pin --code=xxx")
{
	mngr_start(&mn, MNGR_START_CREATE_AT|MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_PAR|MNGR_START_CREATE_PIN);

	pin_mngr_set_pin(mn->pin, argc, argv);
	
	return 0;	
}

FUNC(puk, "enter the puk  code\n"
			"example: 3g-mngr puk --pin=1234 --puk=11111111")
{
	mngr_start(&mn, MNGR_START_CREATE_AT|MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_PAR|MNGR_START_CREATE_PIN);

	pin_mngr_set_puk(mn->pin, argc, argv);
	
	return 0;	
}

FUNC(cpin, "change the pin code\n"
			"example: 3g-mngr cpin --pin=1234 --newpin=1111")
{
	mngr_start(&mn, MNGR_START_CREATE_AT|MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_PAR|MNGR_START_CREATE_PIN);

	pin_mngr_chg_pin(mn->pin, argc, argv);
	
	return 0;	
}

