#ifndef __3G_MNGR_PARAMETER_H_
#define __3G_MNGR_PARAMETER_H_

#define	__PAR_MAP_SIZE 35

typedef struct {
	void *mngr;
	char nt[32];	
	DEF_PRI;
} param_t;

struct par {
	char name[32];
	char *value;
};

typedef struct{
	struct par par_map[__PAR_MAP_SIZE];
	
	char apn[80];
	char number[80];	
	char idle_t[32];//disconnecting when no flow for idle_t. the unit is second.	
	char username[80];
	char password[80];
    char authmethod[20];
	char mru[10];
	char mtu[10];

	/*for pin set */
	char time[10];
	char type[10];
	char pin[10];
	char newpin[10];
	char puk[10];
	char lock[3];

	char demand[10];
	char dialdelay[32];
} __param_t;
param_t *param_new(void *mn); 
int param_init(param_t *par);
int param_free(param_t *par);
int param_get(param_t *par);
int param_get_item(param_t *par, const char *name, char *rbuf);
int param_show_default(param_t *par,  char *rbuf, int rlen);
int param_get_from_user(param_t *par, int argc, char *argv[]);
int param_product_pppd_cfg(param_t *par, int chat_at_pppd);
int param_get_default(param_t *par);
void param_show(param_t *param);
int param_replace_var(param_t *param, char *at_str, int len);
void param_write_par(param_t *par);
void param_read_par(param_t *par);
void param_for_hotplug_notify(int is_hotplug);

#endif

