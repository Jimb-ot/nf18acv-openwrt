#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>

#include "3g-lib.h"
/***  a timer  implement***************************************************/

static struct timer_3g	*timer_list;

static struct timeval timeout;

#define timer_printf(tr, args...)	\
	do{	\
		char __buf1__[80] = {0};	\
		char __buf2__[80] = {0};	\
				\
		snprintf(__buf1__, sizeof(__buf1__), 	##args);	\
		timer_3g_show((tr), __buf2__, sizeof(__buf2__));	\
		d_printf("%s%s\n", __buf1__, __buf2__);	\
	}while(0);

	
struct timeval *  timer_handler()
{	
	time_t curr;
	struct timer_3g  *tr;

	time(&curr);
	
	while (timer_list) {
		timer_printf(timer_list, "Checkint timer,for timer:\n");

		if (timer_list->expire > curr)
			break;

		/*get rid of the head*/
		tr = timer_list;
		timer_list = timer_list->next;
		
		timer_printf(tr,"Time Out:");
		
		if (tr->handler) {
			d_printf("do the handler 0x%x\n", (unsigned int)tr->handler);
			tr->handler(tr->data);
		}  

		free(tr);
	}

	if (timer_list) {
		timer_printf(timer_list, "The next expired timer:\n");
		timeout.tv_sec = timer_list->expire - curr;
		timeout.tv_usec = 0;
		return &timeout;
	} else
		return 0;

}

void timer_add(struct timer_3g *tm)
{
	time_t curr = 0;
	
	time(&curr);
	tm->expire = curr + tm->tick;
	timer_printf(tm, "ADD timer:%s\n", tm->token);

	CDMG_LIST_ADD_IN_ORDER(struct timer_3g, timer_list, tm, expire, 1);
}

void timer_del(struct timer_3g *tm)
{
	d_printf("Try to Delate timer:[%s]\n", tm->token);

	CDMG_LIST_DEL(struct timer_3g, timer_list, tm);
}

void timer_del_by_token(const char *token)
{
	struct timer_3g  *tr = 0;
	struct timer_3g  *prv_tr = 0;
	struct timer_3g  *tmp = 0;

	//d_printf("enter\n");
	
	if (!token || !token[0])
		return;
	
	prv_tr = timer_list;
	tr = timer_list;
	while(tr) {
		if (strcmp(tr->token, token) == 0) {
			tmp = tr;
			if (prv_tr == tr) {
				/*first node*/
				d_printf("first node\n");
				timer_list = tr->next;
				tr = timer_list;
				prv_tr = tr;
			}
			else {
				d_printf("not first node\n");
				tr = tr->next;
				prv_tr->next = tr;
			}

			timer_printf(tmp, "DELETE  timer by token:%s\n", token);

			free(tmp);
			
			continue;			
		}
		
		prv_tr = tr;
		tr = tr->next;
	}
}

void timer_del_all()
{
	struct timer_3g  *tr;

	while (timer_list) {
		tr = timer_list;
		timer_list = timer_list->next;
		timer_printf(tr, "DELETE  timer:\n");
		free(tr);
	}
}

struct timer_3g *timer_get(const char *token)
{
	struct timer_3g  *tr = 0;

	d_printf("enter\n");
	
	tr = timer_list;
	while (tr) {
		if (strncmp(tr->token, token, sizeof(tr->token)) == 0) {
			timer_printf(tr, "Get Timer");
			return tr;
		}
		tr = tr->next;
	}

	return 0;
	
}



static int timer_diald_dump(int argc, char *argv[], char *rbuf, int len)
{
	int num = 0;
	time_t curr;
	struct timer_3g  *tr = 0;

	if (!rbuf || len <= 0)
		return 0;

	rbuf[0] = 0;
	
	/*get current time*/
	time(&curr);

	cdmg_fstrncat(rbuf, len, "current time:%d, the timer list:\n", (unsigned int)curr);
	
	for (tr = timer_list; tr; tr = tr->next) {
		cdmg_fstrncat(rbuf, len, 
			"%d:[0x%x token:%s,tick:%d,expire:%d func:0x%x]\n",
			num++,
			(unsigned int)tr,tr->token, tr->tick, 
			(int)tr->expire, (unsigned int)tr->handler);
	}

	return (strlen(rbuf) + 1);
	
}

CDMG_SETUP_GET(timerdump, timer_diald_dump, 0, 0, "display the current timer\n");


struct timer_3g  * 
timer_set(int tick, const char *token, void (*func)(void *), void *data)
{
	struct timer_3g  *tr = 0;

	d_printf("enter tick=%d token=%s func=0x%x\n",
		tick, token, (unsigned int )func);

	if (tick == 0) {
		d_printf("delete timer %s\n", token);
		timer_del_by_token(token);
		return 0;
	}

	if ((tr = (struct timer_3g  *)malloc(sizeof(struct timer_3g))) <= 0) {
		perror("can not malloc\n");
		return 0;
	}
	memset(tr, 0, sizeof(struct timer_3g));

	snprintf(tr->token, sizeof(tr->token), "%s", token);
	
	if (data == 0)
		tr->data = (void *)tr;
	else
		tr->data = data;

	tr->handler = func;
	
	tr->tick = tick;

	timer_add(tr);

	return tr;
}

static void timer_send_token(void *data)
{
	struct timer_3g  *tr = (struct timer_3g  *)data;

	d_printf("send to token [%s]\n", tr->token);
	lib3g_send_mobile_msg(MSG_UNIX_DAEMON_PATH,tr->token);
	lib3g_send_mobile_chage_msg(tr->token);
}

void timer_token_set(int tick, const char *token)
{
	d_printf("enter\n");
	
	timer_del_by_token(token);
	timer_set(tick, token, timer_send_token, 0);
}


char  *timer_3g_show(struct timer_3g *tr, char *buf, int len)
{
	time_t curr;

	if (!buf || len <= 0)
		return 0;

	time(&curr);
	
	memset(buf, 0, len);
	snprintf(buf, len, "[TIMER:0x%x Tn:<%s> Tk:%d Ep:%d Ct:%d Rmt:%d Fn:0x%x]",
		(unsigned int)tr,
		tr->token, 
		tr->tick, 
		(unsigned int)(tr->expire), 
		(unsigned int)curr,
		(unsigned int)(tr->expire - curr),
		(unsigned int)tr->handler);
	
	return buf;
}

CDMG_FUNC(timer, 1, 0, 0, 0, 0, 0,
					"wait some time, then send a string to external software\n"
					"exam1:3g-mngr timer --token=xxx --time=xx\n")
{
	char token[32] = {0};
	char time[12] = {0};

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	cdmg_get_arg(argv, "time", time, 12);
	cdmg_get_arg(argv, "token", token, 32);

	d_printf("time=%s, token=%s\n", time, token);

	timer_token_set(strtoul(time, 0, 10), token);

	return 0;		
}

