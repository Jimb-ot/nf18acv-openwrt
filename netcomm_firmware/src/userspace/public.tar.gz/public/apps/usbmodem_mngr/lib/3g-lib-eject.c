#include <linux/unistd.h>
#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <sys/time.h>
#include <ctype.h>
#include <linux/fs.h>
#include "3g-lib.h"

/* various defines swiped from linux/cdrom.h */
#define CDROMCLOSETRAY            0x5319  /* pendant of CDROMEJECT  */
#define CDROMEJECT                0x5309  /* Ejects the cdrom media */
#define CDROM_DRIVE_STATUS        0x5326  /* Get tray position, etc. */
/* drive status possibilities returned by CDROM_DRIVE_STATUS ioctl */
#define CDS_TRAY_OPEN        2


/* Code taken from the original eject (http://eject.sourceforge.net/),
 * refactored it a bit for busybox (ne-bb@nicoerfurth.de) */

#include <scsi/sg.h>
#include <scsi/scsi.h>

int lib3g_scsi_sg_set_cmd(int fd, int num, uint8_t *cmd)
{
	unsigned char sense_b[128] = {0};
	struct sg_io_hdr io_hdr;
	
	memset(&io_hdr, 0, sizeof(struct sg_io_hdr));
	io_hdr.interface_id = 'S';
	io_hdr.cmd_len = num;
	io_hdr.mx_sb_len = sizeof(sense_b);
	io_hdr.dxfer_direction = SG_DXFER_NONE;
	io_hdr.cmdp = cmd;
	io_hdr.sbp = sense_b;
	io_hdr.timeout = 30000;

	if (is_debug()) {
		int i = 0;
		printf("Send cmd:[");
		for(i = 0; i < num; i++)
			printf("0x%02x ", (uint8_t)cmd[i]);
		printf("]\n");
	}

	if (ioctl(fd, SG_IO, &io_hdr) < 0) {
		perror("SG_IO error:");
		return -1;
	}
	else {
		return 0;
	}
}

static void eject_scsi(int dev_fd)
{
	int i = 0;
	int ver = 0;	
	uint8_t sg_commands[3][6] = {
		{ ALLOW_MEDIUM_REMOVAL, 0, 0, 0, 0, 0 },
		{ START_STOP, 0, 0, 0, 1, 0 },
		{ START_STOP, 0, 0, 0, 2, 0 }
	};

	if ((ioctl(dev_fd, SG_GET_VERSION_NUM, &ver) < 0) || (ver < 30000))
		d_printf("not a sg device or old sg driver");

	for (i = 0; i < 3; i++) {
		if (lib3g_scsi_sg_set_cmd(dev_fd, 6, sg_commands[i]) < 0) {
			d_printf("do SG_IO error\n");
			return;
		}
	}

	/* force kernel to reread partition table when new disc is inserted */	
	ioctl(dev_fd, BLKRRPART);
}

#define FLAG_CLOSE  1
#define FLAG_SMART  2
#define FLAG_SCSI   4

static void eject_cdrom(unsigned flags, int dev_fd)
{
	int cmd = CDROMEJECT;

	if (flags & FLAG_CLOSE	 || 
		(flags & FLAG_SMART && 
		ioctl(dev_fd, CDROM_DRIVE_STATUS) == CDS_TRAY_OPEN)) {
			cmd = CDROMCLOSETRAY;
	}

	if (ioctl(dev_fd, cmd,NULL) < 0)
		d_perror("do CDROM cmd %d :", cmd);
}


int lib3g_eject(const char *device, int do_flags)
{
	int dev_fd = -1;
	
	if (access(CDROM_DEV, F_OK) != 0) {
		/*the device number of sr SCSI cdrom is 11:0*/
		if (lib3g_fmt_script("mknod -m 777 %s b %d  %d", CDROM_DEV, 11, 0) < 0) {
			d_perror("do mknod failse");
			return -1;
		}
	}

	if ( (dev_fd = open(device, O_RDONLY|O_NONBLOCK)) < 0) {
		d_perror("open[%s]", device);
		return -1;
	}


	if (do_flags & FLAG_SCSI)
		eject_scsi(dev_fd);
	else
		eject_cdrom(do_flags, dev_fd);

	close(dev_fd);

	return 0;
}



CDMG_FUNC(sg_set, 0, 0, 0, 0, 0, 0, "send cmd to sg\n"
			"\t exap: --dev=xxx --cmd=0xab,0xcd,0xef,... [--update_partion]\n")
{
	int ver = 0;
	int cmd_num = 0;
	char *psave = 0;
	char *param = 0;
	char cmdstr[32] = {0};
	char dev_path[128] = {0};
	uint8_t	cmds[16] = {0};

	if (CDMG_GET_ARG("cmd", cmdstr)) {	
		for (param = strtok_r(cmdstr, ",", &psave);
				param;
				param = strtok_r(NULL, ",", &psave)) {
			cmds[cmd_num++] = (uint8_t)strtoul(param, 0, 16);
		}
		/*				
		if (cmd_num != 6 && cmd_num != 10 && cmd_num != 12 &&
				cmd_num != 16) {
			printf("The sg cmd num must be 6, 10,12 or 16\n");
			return -1;
		}
		*/
	}
	
	if (!CDMG_GET_ARG("dev", dev_path)) {
		snprintf(dev_path, sizeof(dev_path), "/dev/sg1");	
	}	

	int fd = 0;
	int ret = 0;
	CDMG_OPEN(fd, open, O_RDWR|O_NONBLOCK,dev_path, return -1);
	if ((ioctl(fd, SG_GET_VERSION_NUM, &ver) < 0) || (ver < 30000)) {
		d_printf("not a sg device or old sg driver");
		close(fd);
		return -1;
	}
	
	if (cmd_num > 0)
		ret = lib3g_scsi_sg_set_cmd(fd, cmd_num, cmds);

	if (cdmg_get_arg(argv, "update_partion", 0, 0) && ret == 0) {
		d_printf("update the partion table\n");
		ret = ioctl(fd, BLKRRPART);
	}
	
	if (fd > 0)
		close(fd);
	
	if (ret == 0) {
		printf("OK\n");
		return 0;
	}

	return -1;
}
