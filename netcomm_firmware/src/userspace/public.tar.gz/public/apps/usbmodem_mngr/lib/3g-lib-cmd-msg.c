/**
* scb+ 2011-8-31
* impliment the command and message mechine
* The interface:
*	int fork_do_daemon(int need_return, int is_syn, void *ret_bug, int ret_len)
*   		return 0 at non daemon, return 1 at daemon.
*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <limits.h>
#include <stdlib.h>
#include <sys/un.h>
#include <sys/param.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include<sys/wait.h>
#include <sys/ioctl.h>

#include "3g-lib-cmd-msg.h"


/*timer function point, set by the user at cdmg_int()*/
/*create a timer, and return the timer's address*/
static void*  (*s_cdmg_timer_set)(int tick, const char *name, 
				void (*func)(void *), void *data);

/*delete a timer*/
static void   (*s_cdmg_timer_del)(void *timer);

/*do the timeout timer, and return the next expired time*/
static struct timeval *   (*s_cdmg_timer_handler)();





/*the first command description*/
static __cdmg_cmd_t 	*s_cdmg_cmd_start = 0;

/*the last command description*/
static __cdmg_cmd_t 	*s_cdmg_cmd_end = 0;

/*The flag for indicating is if running at daemon*/
static int s_cdmg_is_daemon = 0;

/*Control the staring if the action for recieving message*/
static int s_cdmg_stop = 0;

char    g_cdmg_daemon_addr[128] = CDMG_DAEMON_ADDR;
/*used by help function*/
char    g_cdmg_buf[CDMG_MSG_LEN+1];
char * g_cdmg_argv[CDMG_ARGS_NUM];
int      g_cdmg_argc;




static void cdmg_do_get_handler(__cdmg_cmd_t *cmd,
				const char *spath, int argc, 
				char *argv[], 	char *rbuf, int rlen, int *r_len);

/*fork function, the sub will wait
**
**	@ sub_pid   return the sub task's pid
*/
cdmg_pid_t *cdmg_fork_wait( pid_t *sub_pid)
{
	int len = 0;
	char buf[8] = {0};
	cdmg_pid_t *cdmg_pid;

	/*malloc abuffer*/
	CDMG_MALLOC(sizeof(cdmg_pid_t), cdmg_pid, return (cdmg_pid_t *)-1);

	/*create  a pipe for asynch*/
	if (pipe(cdmg_pid->p_fd) != 0) {
		free(cdmg_pid);
		return (cdmg_pid_t *)-1;
	}
	
	cdmg_pid->pid = fork();

	/*return*/
	if (cdmg_pid->pid > 0)  {
		/*father*/
		close(cdmg_pid->p_fd[0]);
		if (sub_pid)
			*sub_pid = cdmg_pid->pid;			
		return cdmg_pid;
	} else if (cdmg_pid->pid == 0) {
		/*sun task*/
		close(cdmg_pid->p_fd[1]);
		cdmg_debug("Sub task is start\n");

		/*let the sub wait*/
		len = read(cdmg_pid->p_fd[0], buf, sizeof(buf)-1);
		if (len == -1)
			perror("read");
		else
			cdmg_debug("Read %d byte(s). sub task is:%s\n", len, buf);
		if (sub_pid)
			*sub_pid = strtoul(buf, 0, 10);
		
		close(cdmg_pid->p_fd[0]);
		free(cdmg_pid);
		return 0;
	} else {
		free(cdmg_pid);
		return (cdmg_pid_t *)-1;		
	}	
}

/*let the sub to start, call by the father task*/
void cdmg_start_sub(cdmg_pid_t *pid)
{
	int len = 0;
	char buf[8] = {0};
	
	if (!pid)
		return;

	snprintf(buf, 8, "%d", pid->pid);

	/*Start sun task, and tell it it's pid*/
	len = write(pid->p_fd[1], buf, strlen(buf));
	if (len == -1)
		perror("Write");
	else
		cdmg_debug("Write %d bytes to let %s start\n", len, buf);

	close(pid->p_fd[1]);
	
	free(pid);
}

/*
* filter the args.
*/
static int cdmg_arg_match(const char *arg, const char *index)
{
	char tmp[1024] = {0};

	snprintf(tmp, sizeof(tmp) -1, "--%s", index);
	if (arg && strcmp(arg, tmp) == 0)
		return 1;

	snprintf(tmp, sizeof(tmp) -1,"--%s=", index);
	if (arg && strstr(arg, tmp))
		return 1;

	snprintf(tmp, sizeof(tmp) -1,"-%s", index);
	if (arg && !arg[2] && strcmp(arg, tmp) == 0)
		return 1;

	return 0;	
}

/*get an arg from the argv list*/
int cdmg_get_arg(char *argv[],  char *name, char *r_buf, int r_len)
{
	int i = 0, j = 0, k = 0;
	int quotation = 0;
	int is_end = 0;
	int have_opt = 0;
	char *par = 0;

	if (r_buf && r_len > 0)
		memset(r_buf, 0, r_len);
	
	for(i = 0; argv[i] && argv[i][0] && 
			argv[i][0] != '\n' && argv[i][0] != ' ';
			i++) 
	{
		cdmg_debug("argv[%d]=[%s]\n", i, argv[i]);
		
		/*
		** scb changed at 2011-11-29 for such conditon:
		**	--par1="abc def" --par2=ghi ...
		** the "abc def" is ONE parameter.
		*/		
		if (!quotation) {
			if (!cdmg_arg_match(argv[i], name))
				continue;
			else {
				have_opt = 1;
				
				/*only check if is there the options*/
				if (!r_buf)
					return 1;
					
				if ((par = strchr(argv[i], '=')) > 0)
					par++;
				else
					return 1;/*not needs content*/
			}
		} else {
			/*second argv*/
			par = argv[i];
			r_buf[j++] = ' ';
		}
		
		
		/*get content */
		for (k = 0;; k++) {
			/*if r_len == 0, ignore this condition*/
			if (r_len > 0 && j >= r_len - 1) {
				is_end = 1;
				break;
			}
			if (!quotation && par[k] == '\"') {
				quotation = 1;
				continue;
			}
			if (!quotation && !par[k]) {
				is_end = 1;
				break;
			}
			if (quotation && par[k] == '\"') {
				is_end = 1;
				break;
			}
			if (quotation && !par[k])
				break;
			r_buf[j++] = par[k];
		}

		if (is_end) {
			r_buf[j] = 0;
			break;
		}
	}

	if (have_opt)
		return 1;
	else
		return 0;
}
		

/*******************************************************
  *
  *         The unix socket rcvd and send process 
  *
  *******************************************************/

static const char *cdmg_create_self_unix_addr()
{
	static char addr[128] = {0};

	snprintf(addr, sizeof(addr), "/var/cdmg_send_sock.%d", getpid());
	return addr;
}

static  void  cdmg_rm_self_unix_addr()
{
	unlink(cdmg_create_self_unix_addr());
}

const struct sockaddr  *cdmg_create_unix_addr(const char *path)
{
	static struct sockaddr_un addr;

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	strncpy(addr.sun_path, path, sizeof(addr.sun_path) - 1);

	return (struct sockaddr  *)&addr;
}

/*
* send socket msg
*/
int cdmg_send_msg_fd(int fd, const struct sockaddr *dst, int len,
				const char *msg, int size)
{
 	int now = 1;
	int ret =0;
    int ret_count = 0;

retry:
	if (!dst)
		ret = send(fd, msg, size, 0);
	else
		ret = sendto(fd, msg, size, 0, dst, len);
 	if (ret == -1) {
		if (errno == EINTR) {
			cdmg_debug("sent is fail by INTERUPT, try again\n");
			/* sleep now seconds and retry (with now * 2) */
			sleep(now);
			now *= 2;
			goto retry;
		}
        /* 3g daemon���̻�û�г�ʼ����ɵ�ʱ�򣬷�����Ϣ�ᶪ��
         * �����ᵼ����Ҫdaemon����ִ�е�����û�б�ִ�С�����:
         * ϵͳ����������ȡwan����������Ϣ��3g-mngr��ʱ�򣬾Ϳ���
         * ����ֶ�ȡ����������������ӳ�һ���ٴη���
         */
        else if(dst && (errno == ENOENT) && (ret_count < 2) && (access("/var/3gppp/unix_socket_3g_msg_daemon", F_OK)  != 0))
        {
            ret_count++;
            cdmg_debug("3g-mngr daemon is not ready, sleep 4s\n");
            sleep(4);
            goto retry;
        }      
        else
        {
			//perror("send error");
			cdmg_debug("sent error:%s\n", strerror(errno));	
		}
	}
	
	if (ret >= 0)
		cdmg_debug("send %d bytes to socket:%d\n", ret, fd); 
	else
		cdmg_debug("sent  error\n");

	return ret;
}

int cdmg_send_unix_msg(const char *dst_path, int protocol, 
				const char *msg, int size)
{
	int fd = 0;
	int ret = 0;
	const struct sockaddr  *dst_addr = 0;

	if ((fd = cdmg_create_unix_socket(cdmg_create_self_unix_addr(), 
			protocol)) < 0) {
		cdmg_printf("Can not create socket, fd = %d\n", fd);
		return -1;
	}

	dst_addr = cdmg_create_unix_addr(dst_path);
	
	if (protocol == SOCK_STREAM) {
		cdmg_debug("Do connect\n");
		if (connect(fd, dst_addr, sizeof(struct sockaddr_un)) != 0) {
			cdmg_printf("Do connect error");;
			perror("connect");
			close(fd);
			cdmg_rm_self_unix_addr();
			return -1;
		}
		ret = cdmg_send_msg_fd(fd, 0, 0, msg, size);
	}
	else
		ret = cdmg_send_msg_fd(fd, dst_addr, 
				sizeof(struct sockaddr_un), msg, size);

	cdmg_rm_self_unix_addr();
	close(fd);

	return ret;
}

/*send the msg to daemon*/
int cdmg_send_msg_to_daemon(const char *msg, int len)
{
	return cdmg_send_unix_msg(g_cdmg_daemon_addr, SOCK_DGRAM, msg, len);
}
	
/**
* Create and init an unix soecket to rcvd message.
*/
int cdmg_create_unix_socket(const char *path, int protocol)
{
	int sock_fd;
	int len;
	char lfile[80] = {0};
	char buf[80] = {0};
	char *p;
	struct sockaddr_un sunx;

   	/*make path for address*/
	sprintf(buf, "mkdir -p  %s", path);
	if ((p = strrchr(buf, '/')))
		*p = 0;   
	system(buf);
	unlink (path);
	if (realpath (path, lfile) != NULL) {
		unlink (lfile);
		return -1;
	}
	
	memcpy(&sunx, cdmg_create_unix_addr(path), sizeof(sunx));

	/*create the socket*/
	if ((sock_fd = socket(AF_UNIX, protocol, 0)) < 0) {
		perror("can not create socket:");
		return -1;
	}

	fcntl(sock_fd, F_SETFD, FD_CLOEXEC);

	/*bind the address*/
	len = sizeof(sunx.sun_family) + strlen(sunx.sun_path);
	if (bind(sock_fd, (struct sockaddr *) &sunx, len) < 0) {
		close(sock_fd);       
		perror("client: bind");

		return -1;
	} 
	cdmg_debug("unix socket create ok\n");
	return sock_fd;
}

/**
* receive socket msg
*/
int  cdmg_rcvd_msg_fd(int fd, char *rbuf, int len, struct timeval *tv)
{
	fd_set fds;	
	int i = 0;
	int ret = 0;
	char *buf = 0;

	/*malloc a buffer*/
	CDMG_MALLOC(CDMG_MSG_LEN+1, buf, return -1);
	
	FD_ZERO(&fds);
	FD_SET(fd, &fds);

	/*do select*/
	if ((ret = select(fd + 1, &fds, NULL, NULL, tv)) > 0) {		
		if (FD_ISSET(fd, &fds)) {			
			//memset(buf, 0, CDMG_MSG_LEN);

do_try:
			/*receive*/
			if ((i = recv(fd, buf, CDMG_MSG_LEN, 0)) == -1) {
				if (i == EINTR) {
					cdmg_debug("INTERRUPT when do recv, do again\n");
					sleep(1);
					goto do_try;
				} else {
					cdmg_printf("recv error\n");
					perror("recv");
				}
			} else
				cdmg_debug("RCVD: %d bytes\n", i);
			
			if (rbuf && i > 0) {
				rbuf[0] = 0;
				i = (len > 0 && i > len) ? len : i;	
				memcpy(rbuf, buf, i);		
			}
		}/* FD_ISSET() */
	}
	
	if (ret == 0) {
		/*
		if (rbuf && (len == 0 || len > strlen("timeout")))
			strcpy(rbuf, "timeout");
		*/
		free(buf);
		return 0;
	}

	free(buf);
	return i;	
}

void cdmg_msg_process_loop(const char *unix_sok_path, 
		int usleep_v, const char *token, 
		void (*handler)(char *msg), 
		struct timeval * (*timeout_func)())
{
	int s, i, r;
	fd_set fds;
	char *buf = 0;
	struct timeval *timeout;

	cdmg_debug("enter\n");

	/*malloc a buffer*/
	CDMG_MALLOC(CDMG_MSG_LEN+1, buf, return );

	/*create a receive socket*/
	if ((s = cdmg_create_unix_socket(unix_sok_path, SOCK_DGRAM)) 
			< 0) {
		cdmg_debug("can not init unix socket %s\n", unix_sok_path);
		free(buf);
		return ;
	}

	/*doing select loop*/
	for (;;) {
		FD_ZERO(&fds);
		FD_SET(s, &fds);

		if (timeout_func)
			timeout = timeout_func();
		else
			timeout = NULL;

		r = select(s + 1, &fds, NULL, NULL, timeout) ;

		if (r == 0)
			continue;

		if (r < 0) {
			cdmg_perror("select error");
			continue;
		}


		if (FD_ISSET(s, &fds)) {
			memset(buf, 0, CDMG_MSG_LEN+1);
do_again:			
			if ((i = recv(s, buf, CDMG_MSG_LEN, MSG_DONTWAIT/*0*/)) > 0) 
			{
				char debugbuf[16] = {0};

				if (cdmg_is_debug()) {	
					char *p;
					
					memset(debugbuf, 0, 16);
					strncpy(debugbuf, buf, 15);
					for (p = debugbuf; *p && *p == ' '; p++);
					if (*p && (p = strchr(debugbuf, ' ')))
						*p = 0;					
				}
				
				cdmg_debug("<MSG-%s RCVD>:[%s]\n", 
					token ? token : "NONE", 
					buf);

				/*handle the message*/
				handler(buf);

				cdmg_debug("<MSG-%s RCVD>: [%s] Process end!\n", 
					token ? token : "NONE", 
					debugbuf);		

				if (usleep_v)
					usleep(usleep_v);
			
			} 
			else 
			{
				if (i == EINTR) {
					cdmg_debug("Interrupt do again\n");
					usleep(100000);
					goto do_again;
				} else {
					cdmg_debug("recv error\n");
					perror("UNIX socket error");
					if (usleep_v)
						usleep(usleep_v);
				}
			}
		}/* FD_ISSET() */
	}
	free(buf);
}

/**
* @len    the len of msg
* @rbuf   must be free by the caller
* @rlen   the len of the receive message
* 
* Return:
* 	-1 error
*	>0 the rcvd msg's len
*/
static int __cdmg_send_and_get(const char *rcvd_addr, const char *dst_addr, 
			int protocol, const char *msg, int msg_len,
			char **rbuf, int rlen, int usec)
{
	int rrlen = 0, slen = 0;
	int try_rlen = 0;
	int fd = 0;
	char *p = 0;
	struct timeval time_out;

	if (rbuf)
		*rbuf = 0;

	fd = cdmg_create_unix_socket(rcvd_addr, protocol);
	if (fd < 0) {
		cdmg_printf("Can not create rcvd socket\n");
		return -1;
	}
	cdmg_debug("create socket:%d \n", fd);
 		
	
	/*Send to daemon to let the daemon do this function*/
	cdmg_debug("Send\n");
	if (access(dst_addr, F_OK) != 0) {
		cdmg_debug("No dst path\n");
        close(fd);
		return -1;
	}
	if (protocol == SOCK_STREAM) {
		cdmg_debug("Do connect\n");
		if (connect(fd, cdmg_create_unix_addr(dst_addr), 
				sizeof(struct sockaddr_un)) != 0) {
			cdmg_printf("connect to %s error\n", dst_addr);
			perror("connect");
			close(fd);
			return -1;
		}
		slen = cdmg_send_msg_fd(fd, 0, 0, msg, msg_len);
	} else
		slen = cdmg_send_msg_fd(fd, cdmg_create_unix_addr(dst_addr), 
			sizeof(struct sockaddr_un), msg, msg_len);
	if (slen <= 0) {
		cdmg_printf("send error: ret=%d\n", slen);
		close(fd);
		unlink(rcvd_addr);
		return -1;
	}

	cdmg_debug("Send %d byte(s)\n", slen);

	if (rlen <= 0 || rlen > CDMG_MSG_LEN)
		try_rlen = CDMG_MSG_LEN;
	else
		try_rlen = rlen;
	
	/*to get the result from the daemon*/
	if (rbuf) {
		CDMG_MALLOC(rlen+1, *rbuf, return -1);
		p = *rbuf;
	} else {
		CDMG_MALLOC(rlen+1, p, return -1);
	}

	time_out.tv_sec = usec/1000000;
	time_out.tv_usec = usec % 1000000;
	
	cdmg_debug("RCVD timeout:tv_sec=%d, tv_usec=%d\n",
		(int)time_out.tv_sec, (int)time_out.tv_usec);
	
	/*receive*/
	cdmg_debug("Star to rcvd\n");
	rrlen = cdmg_rcvd_msg_fd(fd, p, try_rlen, &time_out);
	cdmg_debug("Rcvd %d byte(s), from %s by %s\n", rrlen, 
			dst_addr, rcvd_addr);

	/*the call not used the output,so here free the buf*/
	if (!rbuf && p)
		free(p);

	close(fd);

	return rrlen;
}

int cdmg_send_and_get_unix_msg(const char *dst_path, int protocol, 
			const char *msg, int msg_len, char **rbuf, int rlen, int usec)
{
	int ret = 0;

	ret = __cdmg_send_and_get(cdmg_create_self_unix_addr(), dst_path, 
			protocol, msg, msg_len, rbuf, rlen, usec);
	cdmg_rm_self_unix_addr();
	return ret;
}

/*******************************************************
  *
  *         The  socket rcvd and send process End
  *
  *******************************************************/

/*get a line from str s*/
static const char *cdmg_sgets(const char *s, char *rbuf, int rlen)
{
	int i = 0;
	const char *p = s;

	if (!rbuf)
		return 0;

	memset(rbuf, 0, rlen);

	if (!s)
		return 0;

	/*scan the string*/
	while(*p && *p != '\n' && *p != '\r' && i < rlen) {
		rbuf[i] = *p;
		p++;
		i++;
	}

	/*Go to  the start of the next line*/
	if (*p && (*p == '\n' || *p == '\r')) {
		if ((*p == '\n' && *(p+1) == '\r') || 
				(*p == '\r' && *(p+1) == '\n'))
			p += 2;
		else 
			p++;
	}

	/*return the next start line*/
	if (*p)
		return p;
	else
		return 0;

}

/*
* the output format:
* dial
*	dial function
*		args: --apn=x 
* undial
*	undial function
* ...
*/	
static void cdmg_get_help_info(__cdmg_cmd_t *cmd, int show_all, 
									char *rbuf, int rlen)
{
#define __CDMG_START_STR	"   "
	int len;
	char buf[160] = {0};
	const char *s = cmd->help;	

	if (!rbuf)
		return;

	memset(rbuf, 0, rlen);
	
	/*output the func name*/
	snprintf(rbuf, rlen, "%s", cmd->name);

	/*show the details*/
	if (show_all) {
		if (cmd->is_inner)
			cdmg_fstrncat(rbuf, rlen, "  inner");
		
		if (cmd->is_daemon)
			cdmg_fstrncat(rbuf, rlen, "  run_at_daemon");

		if (cmd->is_unshow)
			cdmg_fstrncat(rbuf, rlen, "  un_show");		
		
		if (cmd->is_get_action) {
			cdmg_fstrncat(rbuf, rlen, "  is_get");
			if (cmd->is_asynch) {
				cdmg_fstrncat(rbuf, rlen, "  is_asynch");
				cdmg_fstrncat(rbuf, rlen, "  timeout: %d", cmd->timeout);
			}
		}
	}
	rbuf[strlen(rbuf)] = '\n';	

	/*get a line*/
	while( strlen(rbuf) -2 < rlen && ((s = cdmg_sgets(s, buf, sizeof(buf)-2)) || 
				buf[0])) {
		len = strlen(buf);	
		if (buf[len-1] != '\n') {
			
			/*the line not end*/
			if (len == sizeof(buf)-2) {
				if (buf[len-1] != ' ') {
					cdmg_fstrncat(rbuf, rlen, __CDMG_START_STR"%s-\n", buf);
				} else
					cdmg_fstrncat(rbuf, rlen, __CDMG_START_STR"%s\n", buf);
			} else
				cdmg_fstrncat(rbuf, rlen, __CDMG_START_STR"%s\n", buf);
			
		}
		else		
			cdmg_fstrncat(rbuf, rlen, __CDMG_START_STR"%s", buf);
		
		memset(buf, 0, sizeof(buf));
	}

	len = strlen(rbuf);
	if (rbuf[len-1] != '\n') {
		rbuf[len] = '\n';
		rbuf[len+1] = 0;
	}
}

int cdmg_is_on_daemon()
{
	return s_cdmg_is_daemon;
}

int  cdmg_is_stop(void)
{
	return s_cdmg_stop;
}

void cdmg_set_daemon()
{
	s_cdmg_is_daemon = 1;
}

void  cdmg_start(void)
{
	s_cdmg_stop = 0;
}

void  cdmg_stop(void)
{
	s_cdmg_stop = 1;
}

/**
* Translate the command line  to  'argv' mode.
* exmaple:
*   command line: '3g-mngr setdelay --hotplug=1'
*   argv mode:     argc=3 argv[0]=3g-mngr argv[1]=setdelay argv[2]=--hotplug=1
**/
void cdmg_cmd_to_argv(char *msg, int *argc, char **__argv)
{
	int __argc = 0;
	int quotation = 0;
	char *p;

	cdmg_debug("Changed msg to argv for[%s]\n", msg);

	/*the format:
	* 	dial --delay=0 --idle=0 --apn=Unicom --number=*99# \
	*	--nettype=xx --user=xx 
	*/
	memset(__argv, 0, sizeof(__argv));
	__argc = 0;
	p = msg;
	while(1) {

		/*skip the blank*/
	    	for (; p && *p && *p == ' ';p++);

		if (!p || !*p)
			break;
		
	    	__argv[__argc] = p;

		/*to next word*/
		quotation = 0;
		for(;;p++) {
			if (!p || !*p || *p == '\n')
				break;

			if (*p == '\"') {
				if (quotation)
					quotation = 0;
				else
					quotation = 1;
				continue;
			}

			if (!quotation && (*p == ' ' || *p == '\t'))
				break;
		}
		
		/*for (; p && *p && *p != ' ' && *p != '	' && *p != '\n';p++);*/

		if (!p) {
			cdmg_printf("The string no end\n");
			p--;
			*p = 0;
			__argc++;
			break;
		} else if( *p == ' ') {
			*p = 0;
			p++;
			__argc++;
			continue;
		} else if (*p == '\n') {
			*p = 0;
			__argc++;
			break;
		} else {
			/*the last arg */
         	    	__argc++;
			break;
		}		
	}
	*argc = __argc;
	__argv[__argc] = 0;
}

/**
* Translate the  'argv' mode to command line mode
* example: argv[0] = 3g-mngr, argv[1] = setdelay argc[2] = --show=1
* the trans result:
*	'3g-mngr setdelay --show=1'
*/
void cdmg_argv_to_cmd(int argc, char **argv, 
				char *rbuf, int rlen)
{
	int i;

	if (!rbuf)
		return;
	
	memset(rbuf, 0, rlen);

	for (i = 0; argv && argv[i] && i < argc; i++) {		
		if (strcmp(argv[i], "-s") == 0) {
			continue;
		}
		if (strcmp(argv[i], "-d") == 0) {
			continue;
		}
		cdmg_fstrncat(rbuf, rlen, "  %s", argv[i]);
	}

	rbuf[rlen-1] = 0;

	cdmg_debug("the cmd:[%s]\n", rbuf);
}

/*search next cmd desc*/
static __cdmg_cmd_t *cdmg_find_next(__cdmg_cmd_t *curr, int forword)
{
	int delt_size = 4;
	int total_size = 2*sizeof(__cdmg_cmd_t);
	int scan_size = 0;
	char *p = (char *)curr;

	/*step*/
	if (forword) {
		p += delt_size;
	}
	else {
		p -= delt_size;
	}
	scan_size += delt_size;
	
	for(;;) {
		/*check*/
		if (!strncmp(p, __CDMG_MAGIC, strlen(__CDMG_MAGIC))) {			
			return (__cdmg_cmd_t *)p;
		}

		/*step*/
		if (forword) {
			p += delt_size;			
		}
		else {
			p -= delt_size;
		}
		scan_size += delt_size;

		if (scan_size >= total_size) {
			cdmg_debug("can not find, maybe scan to the end\n");
			return 0;
		}		
	}	
}

/**
* Find a cmd struct by the index of nane
*/
static __cdmg_cmd_t *cdmg_find_cmd(const char *name, int is_get_action)
{
	__cdmg_cmd_t *cmd = 0;

	cdmg_debug("To find cmd:%s\n", name);
	if (!name)
		return 0;
#define CDMG_FIND_IS_CMD(n) !strncmp(str, n, strlen(n)) 
	if (s_cdmg_stop) {
		char const  *str = name;
		for (; str && *str && (*str == ' ' || *str == '\t'); str++);
        if (!str)
        {
			cdmg_printf("Error name!\n");
			return 0;            
        }
		cdmg_debug("cmd:[%s]\n", str ? str : "NONE");
		if (!CDMG_FIND_IS_CMD("start") &&
		    !CDMG_FIND_IS_CMD("stop") &&						
		    !CDMG_FIND_IS_CMD("daemon_is_stop") &&
		    !CDMG_FIND_IS_CMD("__cdmg_get_daemon_info") &&
		    !CDMG_FIND_IS_CMD("daemon_is_start"))
		{
			cdmg_printf("Stop!\n");
			return 0;
		}
		cdmg_debug("Daemon has stop!\n");
	}
	
	
	for (cmd = s_cdmg_cmd_start; cmd && cmd <= s_cdmg_cmd_end ; 
				cmd = cmd->next) 
	{
		cdmg_debug("scan cmd:%s\n", cmd->name);
		
		/**
		* The daemon command is the cmd for 'message', 
		* is not show to the user 
		*/
		if (!cdmg_is_on_daemon() && cmd->is_inner)
			continue;

		if (is_get_action && !cmd->is_get_action)
			continue;
		
		if (!strcmp(name, cmd->name)) 
		{
			cdmg_debug("Find out!\n");
			return cmd;
		}
	}

	cdmg_printf("No cmd:%s\n", name);
	return 0;
}
	
/**
* Call a function:
* The args will be '3g-mngr setdelay --hotplug=1',
* the '3g-mngr' will be ignore
*/
int cdmg_call_cmd(int argc, char *argv[])
{
	__cdmg_cmd_t *cmd = 0;
	
	cdmg_debug("Try to do cmd:%s\n", argv[0]);
	

	if (argc >= 1 ) 
	{
		if ((cmd = cdmg_find_cmd(argv[0], 0))) 
		{	
			cdmg_debug("do:%s\n", cmd->name);
			return cmd->func(argc, argv, 0, 0, 0);
		}
	}

	printf("'%s' is not the supported sub command!\n", argv[0]);
	return -1;
}

/*The daemon's message proccess function*/
void cdmg_process_cmd_msg(char *msg_cmds)
{
	int     __argc;
	char *__argv[CDMG_ARGS_NUM];
	char  argbuf[CDMG_CMD_LINE_LEN+1] = {0};
	
	cdmg_debug("enter\n");
	
	if (!msg_cmds || !msg_cmds[0]) {
		cdmg_printf("cmds is zero\n");
		return ;
	}	

	/*let the cmd run on diald process*/
	cdmg_debug("try to call the func at daemon\n");

	strncpy(argbuf, msg_cmds, CDMG_CMD_LINE_LEN);

	cdmg_cmd_to_argv(argbuf, &__argc, __argv);

	cdmg_debug("call cmd[%s]\n", __argv[0]);
	if (cdmg_call_cmd(__argc, __argv) >= 0)
		return;
	
	cdmg_printf("Can not handler diald msg:[%s]\n", msg_cmds);	
}


/**
* when the get action is ended,
* do this function to notify the user caller
*/
static int cdmg_get_is_end(int argc, char *argv[])
{
	__cdmg_cmd_t *cmd = 0;
	char buf[80] = {0};
	pid_t do_process = 0;
	int fd;
	int done = 0;

	cdmg_debug("end get handler:[%s]\n", argv[0]);

	/*get who is end*/
	CDMG_GET_ARG("pid", buf);
	
	cdmg_debug("Pid:[%s]\n", buf);

	do_process = strtoul(buf, 0, 10);

	/*find the corresponding cmd desc for this get action*/
	for (cmd = s_cdmg_cmd_start;
			cmd <= s_cdmg_cmd_end;
			cmd++)
	{
		if (cmd->do_process == do_process) {
			cdmg_debug("find:%s\n", cmd->name);
			break;
		}
	}

	if (cmd > s_cdmg_cmd_end) {
		cdmg_printf("Can not find cmd desc for pid: %d\n", do_process);
		return -1;
	}
	

	/*delete the timer*/
	if (cmd->timeout_timer) {
		s_cdmg_timer_del(cmd->timeout_timer);
		cmd->timeout_timer = (void *)0;
	}

	cdmg_debug("%s end rlen=%d\n", cmd->name, cmd->rlen);

	if (!cmd->rlen)
		cdmg_send_unix_msg(cmd->rspath, SOCK_DGRAM, "", 0);

	if (cmd->rlen > 0) {
		if ((fd = open(CDMG_GET_ACT_TMP_FILE, O_RDONLY)) >= 0) {
			char *rbuf;
			int len;

			/*get the doing result from a tmp file*/
			if ((rbuf = malloc(cmd->rlen+1))) {
				memset(rbuf, 0, cmd->rlen+1);
				len = read(fd, rbuf, cmd->rlen);
				cdmg_debug("read %d byte(s)\n", len);
				
				cdmg_send_unix_msg(cmd->rspath, SOCK_DGRAM, rbuf, len);

				done = 1;
				free(rbuf);
			}
			close(fd);
			unlink(CDMG_GET_ACT_TMP_FILE);
		} else
			perror("Open" CDMG_GET_ACT_TMP_FILE);
	}

	if (!done) {
		cdmg_printf("asyn msg action [%s], no return val\n", cmd->name);
		cdmg_send_unix_msg(cmd->rspath, SOCK_DGRAM, " ", 1);
	}

	memset(cmd->rspath, 0, CDMG_CMD_LINE_LEN+1);
	cmd->rlen = 0;
	cmd->do_process = 0;	

	return 0;
}
__CDMG_SETUP_MSG(cdmg_get_is_end, 0, 1, cdmg_get_is_end, "");

/**
  * This function is for getting some infomation from the deamon process
  * @ argv[0]: --rpath=xxx	    indicate the caller's unix socke address, the info is
  *						    sent to that.
  * @ argv[1]: --rlen=xxx        indicate the receive buffer len of the caller can reveceied
  * @ argv[2]: --asynch=0[1]    indicats the caller is if need to wait the action is finished
  * @ argv[3]: --action=xxx       shows what is the info  
  * @ argv[x]: the other args is desided by the info type
  */
static int   __cdmg_get_daemon_info(int argc, char *argv[])
{
	char *rpath = 0, *action = 0;
	char *rbuf = 0;
	char  str_rlen[8] = {0};
	int    ret = -1;
	int    rlen = 0;
	int    rrb_len = 0;
	__cdmg_cmd_t *cmd;

	/*malloc buffer*/
	CDMG_MALLOC(CDMG_CMD_LINE_LEN+1, rpath, return -1);
	CDMG_MALLOC(CDMG_NAME_LEN+1, action, goto end);
	
	/*Get the standard argments*/
	CDMG_GET_ARG_L("rpath", rpath, CDMG_CMD_LINE_LEN);	
	CDMG_GET_ARG_L("action", action, CDMG_NAME_LEN);
	

	CDMG_GET_ARG_L("rlen", str_rlen, sizeof(str_rlen)-1);
	
	/*deside the rlen*/
	rlen = strtoul(str_rlen, 0, 10);
	if ( rlen <= 0 || rlen > CDMG_MSG_LEN + 1)
		rlen = CDMG_MSG_LEN + 1;
	
	/*malloc buffer*/
	CDMG_MALLOC(rlen, rbuf, goto end);

	/*Find the get info action by name*/
	cdmg_debug("search action:%s\n", action);
	cmd = cdmg_find_cmd(action, 1); 

	/*No action */
	if (!cmd) {
		cdmg_printf("No action:%s\n", action);
		goto end;		
	}

	cdmg_debug("Start to do... rlen=%d\n", rlen-1);
	cdmg_do_get_handler(cmd, rpath, argc-2, &argv[2], rbuf, rlen-1, &rrb_len);
	cdmg_debug("Done!\n");

	/*Send the result to the caller*/
	if (!cmd->is_asynch) {
		cdmg_debug(" RCVD %d byte(s).Get action is not asyn, "
				"send msg to let the user caller return\n", rrb_len);
		cdmg_send_unix_msg(rpath, SOCK_DGRAM, rbuf, rrb_len);
	}

	ret = 0;
	
end:
	if (rpath)
		free(rpath);
	if (rbuf)
		free(rbuf);
	if (action)
		free(action);
	
	return ret;
}
__CDMG_SETUP_MSG(__cdmg_get_daemon_info, 0, 1, __cdmg_get_daemon_info, "");

int cdmg_create_get_msg(int argc, char *argv[], int get_len, 
			int is_asynch, char *cmdline, int cmdlen)
{
	char path[80] = {0};
	char *cmdline1= 0;
	pid_t pid = 0;

	if (cdmg_is_on_daemon()) {
		cdmg_printf("Can not called at daemon\n");
		return -1;
	}

	pid = getpid();

	/*malloc a buffer*/
	CDMG_MALLOC(CDMG_CMD_LINE_LEN+1,cmdline1 , return -1);
	
	/**
	* Product the command line:
	* __cdmg_get_daemon_info  --rpath=xxx --rlen=x --asynch=x\
	*	--action=xxx  .....
	*/

	/*the caller, product the command line and send to daemon*/
	snprintf(path, sizeof(path)-1,
		CDMG_WORK_PATH"cdmg_get_info_act_%d", pid);
	snprintf(cmdline, cmdlen, 
			"__cdmg_get_daemon_info "
			"--rpath=%s "
			"--rlen=%d "
			"--action=%s ",
			path, get_len, argv[1]);
	/*ignore the module name*/
	cdmg_argv_to_cmd(argc-2, &argv[2], cmdline1, CDMG_CMD_LINE_LEN);
	
	cdmg_fstrncat(cmdline, cmdlen, "%s", cmdline1);
	cdmg_debug("Get cmd:[%s]\n", cmdline);

	free(cmdline1);

	return 0;
}

/**
* timer procces.
* when the get action is running at synch mode,
* if timeout, need to kill it
*/
static void cdmg_do_get_timeout(void *data)
{
	__cdmg_cmd_t *cmd = data;

	cdmg_debug("%s pid=%d timeout\n", cmd->name, cmd->do_process);

	/*maybe the end have be done*/
	if (cmd->rspath[0]) {
		cdmg_debug("The get action have be ended\n");
		return;
	}

	cdmg_send_unix_msg(cmd->rspath, SOCK_DGRAM, " ", 1);

	kill(cmd->do_process, SIGKILL);
	
	memset(cmd->rspath, 0, CDMG_CMD_LINE_LEN+1);
	cmd->timeout_timer = (void *)0;
	cmd->rlen = 0;
	cmd->do_process = 0;
}

/**
* process the get command at asyan mode
*/
static void cdmg_do_get_handler(__cdmg_cmd_t *cmd,
				const char *spath, int argc, 
				char *argv[], 	char *rbuf, int rlen, int *r_len)
{
	int len = 0;
	cdmg_pid_t *pid;/*for synchn fork*/
	pid_t sub_pid = 0;
	
	cdmg_debug("process action %s asyn=%d\n", cmd->name, cmd->is_asynch);

	/*for none asynch mode, doing action at daemon envirenment*/
	if (!cmd->is_asynch) {
		/*here  MUST set the __is_get to 1. */
		len = cmd->func(argc, argv, rbuf, rlen, 1);
		
		if (r_len)
			*r_len = len;

		return;
	}
	
	/*if the action is done, return*/
	if (cmd->do_process) {
		cdmg_debug("%s being done at task:%d\n", cmd->name, 
			cmd->do_process);
		cdmg_send_unix_msg(spath, SOCK_DGRAM, " ", 1);
		return ;
	}

	/*save the action info*/
	cmd->rlen = rlen;
	snprintf(cmd->rspath, CDMG_CMD_LINE_LEN, "%s", spath);

	/*fork a sub task to handler the action*/
	if ((pid = cdmg_fork_wait(&sub_pid)) == -1) {
		/*create sub task fail*/
		cdmg_printf("can not fork to handler %s\n", cmd->name);
		cmd->do_process = 0;
		cmd->rlen = 0;
		cmd->timeout_timer = (void *)0;		
		cdmg_send_unix_msg(cmd->rspath, SOCK_DGRAM, " ", 1);
		memset(cmd->rspath, 0, 80);
		return;		
	} else if (pid == 0) { 
		/*the sub task to do the get action*/
		int fd;
		char msg[80] = {0};

		/*Start to do*/
		cdmg_debug("Fork %d  to handler:%s\n", sub_pid, cmd->name);	

		/*here  MUST set the __is_get to 1. */
		len = cmd->func(argc, argv, rbuf, rlen, 1);
		cdmg_debug("%d end! return %d byte(s)\n", sub_pid, len);

		/*write the output to an tmp file*/
		if (len > 0) {			
			if ((fd = open(CDMG_GET_ACT_TMP_FILE, 	
						O_CREAT|O_WRONLY|O_TRUNC)) >= 0) {
				write(fd, rbuf, len);
				close(fd);
			} else
				cdmg_printf("Write %s error\n", CDMG_GET_ACT_TMP_FILE);
		}

		snprintf(msg, 80, "cdmg_get_is_end --pid=%d", sub_pid);
		cdmg_send_unix_msg(g_cdmg_daemon_addr, SOCK_DGRAM, msg, strlen(msg));
		
		exit(0);						
	} 


	cmd->do_process = sub_pid;
		
	/*teh default timeout is 5*/
	int to = cmd->timeout ? cmd->timeout : CDMG_GET_DEF_TIMEOUT;
	
	/*set the timer*/
	char name[32] = {0};
	
	snprintf(name, sizeof(name)-1, "cdmg_get_timeout_%s", cmd->name);

	cdmg_debug("Set time out timer: %d\n", to);
	cmd->timeout_timer = s_cdmg_timer_set(to, name, 
			cdmg_do_get_timeout, (void *)cmd);

	cdmg_debug("fork %d to handler %s let sub start\n", cmd->do_process, 
		cmd->name);

	/*let the sub task to do*/
	cdmg_start_sub(pid);
}

/**
* this func is called at none daemon
*
* @rbuf   must be free by the caller
*/
int  cdmg_get_act(int argc, char *argv[], int get_len, char **rbuf, 
					struct timeval *time_out)
{
	char   rcvd_path[80] = {0};
	char *cmdline =0;
	char *cmdline1 = 0;
	int     len = 0;
	int     rrlen = 0;			
	pid_t  pid = getpid();
			
	/**
	* Product the command line:
	* __cdmg_get_daemon_info  --rpath=xxx --rlen=x \
	*	--action=xxx  .....
	*/

	CDMG_MALLOC(CDMG_CMD_LINE_LEN+1, cmdline, return -1);
	CDMG_MALLOC(CDMG_CMD_LINE_LEN+1, cmdline1, free(cmdline); return -1);

	if (get_len == 0 || get_len > CDMG_MSG_LEN)
		len = CDMG_MSG_LEN;
	else
		len = get_len;
	
	/*the caller, product the command line and send to daemon*/
	snprintf(rcvd_path, sizeof(rcvd_path)-1, CDMG_GET_PATH_PRE"%d", pid);
	snprintf(cmdline, CDMG_CMD_LINE_LEN, 
			"__cdmg_get_daemon_info "
			"--rpath=%s "
			"--rlen=%d "
			"--action=%s ",
			rcvd_path, len, argv[0]);
	/*ignore the action name*/
	cdmg_argv_to_cmd(argc-1, &argv[1], cmdline1, CDMG_CMD_LINE_LEN);
	
	cdmg_fstrncat(cmdline, CDMG_CMD_LINE_LEN, "%s", cmdline1);
	cdmg_debug("Get cmd:[%s]\n", cmdline);

	/*send get msg to daemon*/
	cdmg_debug("Send get msg to daemon\n");
	rrlen = __cdmg_send_and_get(rcvd_path, g_cdmg_daemon_addr, 
				SOCK_DGRAM,
				cmdline, strlen(cmdline), 
				rbuf, len, 
				(time_out->tv_sec * 1000000 + time_out->tv_usec));

	free(cmdline);
	free(cmdline1);
	if (!cdmg_is_debug())
		unlink(rcvd_path);

	return rrlen;
}


/**
* There serveral path, is like the fork function.
*
* This function is not used by the user direct, 
* it can be used by the macro 'CDMG_FORK()' .
*
* @rbuf   will be free by the caller, the function will do malloc
* @is_do_get   set by the daemon
*
* return:
*	CDMG_ENV_DAEMON  run at daemon by cdmg_process_cmd_msg()
*  	CDMG_ENV_DAEMON_GET      run at deamon by cdmg_do_get_handler()
*	CDMG_ENV_USER_SENT run at user's shell, have send the command 
*			to the daemon, then the cdmg_process_cmd_msg() or cdmg_do_get_handler()
*			will call this function again later at daemon, so the user caller need do nothing.
*	CDMG_ENV_USER   run at user's shell, caller need to do the realy action
*     CDMG_ENV_USER_GET  send the get command to daemon and return, then
*                   need to show the result.
*/	
cdmg_env_t  __cdmg_fork(int argc, char *argv[], int get_len,
					char **rbuf, int *rlen, int is_do_get)
{	
	__cdmg_cmd_t *cmd = 0;
	int rrlen = 0;
	struct timeval tv;
		
	if (cdmg_is_on_daemon()) 
	{
		/*deamon*/
		if (!is_do_get) {
			cdmg_debug("%s at daemon\n", argv[0]);
			return CDMG_ENV_DAEMON;/*normal done at daemon*/
		}
		else {
			cdmg_debug("%s at get action\n", argv[0]);
			return CDMG_ENV_DAEMON_GET; /*call at func 'cdmg_do_get_handler()'*/
		}
	} 
	else 
	{
		/*user*/	
		cdmg_debug("User do action:%s\n", argv[0]);
		cmd = cdmg_find_cmd(argv[0], 0);
		if (!cmd) {
			cdmg_printf("Not find!\n");
			return -1;
		}

		/*the cmd is not get info*/
		if (!cmd->is_get_action) 
		{
			char *cmdline = 0; 
			int     do_at_daemon = cmd->is_daemon;

			/*check the user if is set to do at daemon*/
			if (!do_at_daemon && CDMG_HAVE_DN_ARGS())
					do_at_daemon = 1;

			if (do_at_daemon) 
			{

				/*malloc a buffer*/
				CDMG_MALLOC(CDMG_CMD_LINE_LEN+1, cmdline, return CDMG_ENV_USER);

				cdmg_argv_to_cmd(argc, argv, cmdline, CDMG_CMD_LINE_LEN);
				
				/*Send to daemon to let the daemon do this function*/
				cdmg_debug("Send to daemon to let the daemon do this function\n");
				cdmg_send_unix_msg(g_cdmg_daemon_addr, SOCK_DGRAM, cmdline, strlen(cmdline));
				
				free(cmdline);
				
				if (rbuf)
					*rbuf = 0;
				if (rlen)
					*rlen = 0;
				
				return CDMG_ENV_USER_SENT;
			} 
			else
			{
				cdmg_debug("do this function at user evn\n");
				return CDMG_ENV_USER;
			}
		} 
		else
		{
			/*The cmd is get info action*/
			tv.tv_sec   = cmd->timeout ? cmd->timeout : CDMG_GET_DEF_TIMEOUT;

			/*add some time to wait*/
			tv.tv_usec = 500000;

			/*check the daemon is exist*/
			char *is_stop = 0;	
			CDMG_SEND_AND_GET(is_stop, 100000, daemon_is_stop, "%s", "");
			if (!is_stop || is_stop[0] == '1') {
				cdmg_debug("daemon is stop or not exist\n");
				free(is_stop);	
				if (rbuf && ((*rbuf = malloc(8)) != NULL)) {
					snprintf(*rbuf, 8, "stop");
					if (rlen)
						*rlen = 0;		
				}
				else {				
					if (rlen)
						*rlen = 0;
				}				
				return CDMG_ENV_USER_GET;	
			}

			/*to let the daemon to do get action*/
			cdmg_debug("Try to let the daemon to do get action:%s\n", argv[0]);
			rrlen = cdmg_get_act(argc, argv, get_len, rbuf, &tv);
			if (rlen)
				*rlen = rrlen;

			return CDMG_ENV_USER_GET;
		}		
	}	
}

/*
* the help function
*/
static int cdmg_user_help(int argc, char *argv[])
{
	char *rbuf = 0;
	int  show_all = CDMG_GET_ARG("all", 0);
	__cdmg_cmd_t *cmd = 0;

	/*malloc a buffer*/
	CDMG_MALLOC(1024, rbuf, return -1);

	printf("\n"
 		   "Support the following commands:\n"
 		   "Name\tinfo\n"
 		   "----------------------------------------------------------\n"
 		   );
	
	for (cmd = s_cdmg_cmd_start;
			cmd <= s_cdmg_cmd_end;
			cmd++)
	{
		/*if not demand, not show the daemon function*/
		if (!show_all && cmd->is_inner)
			continue;

		if (!show_all && cmd->is_unshow)
			continue;		
		
		cdmg_get_help_info(cmd, show_all, rbuf, 1023);
		if (rbuf[0])
			printf(rbuf);
	}	
	free(rbuf);

	printf("----------------------------------------------------------\n");

	return 0;
}
CDMG_SETUP_CMD(help, cdmg_user_help, "args: --all  show all the handler\n");

/*init the s_cdmg_cmd_start and s_cdmg_cmd_end*/
void cdmg_init(void * (*timer_set)(int tick, const char *name, 
						void (*)(void *), void *data),
			void (*timer_del)(void *timer),
			struct timeval * (*timer_handler)(void *data),
			const char *daemon_addr)
{
	__cdmg_cmd_t *cmd = 0, *cmd_n;

	/*'__cdmg__desc_help' is define at 
	* CDMG_FUNC(help, 0, 1, 0, "This is the help\n")
	*/
	cdmg_debug("%s:enter\n", __func__);
	cmd = &__cdmg__desc_help;
	cmd_n = cdmg_find_next(cmd, 0);
	for (;;) {
		if (!cmd_n) {
			s_cdmg_cmd_start = cmd;
			break;
		}

		/*link*/
		if (cmd_n)
			cmd_n->next = cmd;		
		
		cmd = cmd_n;
		cmd_n = cdmg_find_next(cmd, 0);
	}		

	/*decide the s_cdmg_cmd_end*/
	cmd = &__cdmg__desc_help;
	cmd_n = cdmg_find_next(cmd, 1);	
	for (;;) {
		/*link*/
		if (cmd)
			cmd->next = cmd_n;
	
		if (!cmd_n) {
			s_cdmg_cmd_end = cmd;
			break;
		}
		
		cmd = cmd_n;
		cmd_n = cdmg_find_next(cmd, 1);
	}
	
	cdmg_debug("Cmd start at:[%s], end at:[%s]\n", s_cdmg_cmd_start->name,
			s_cdmg_cmd_end->name);
	
	/*set the timer function*/
	s_cdmg_timer_set = timer_set;
	s_cdmg_timer_del = timer_del;
	s_cdmg_timer_handler = timer_handler;

	/*set daemon addr*/
	if (daemon_addr) {
		snprintf(g_cdmg_daemon_addr, sizeof(g_cdmg_daemon_addr)-1,
			"%s", daemon_addr);
	} 
}

/*
* the shell interface
*/
void  cdmg_shell(int argc, char *argv[])
{
	char *buf = 0;
	__cdmg_cmd_t *cmd = 0;

	s_cdmg_is_daemon = 0;

	/*check the args, there are must 2 args such as: '3g-mngr help'*/
	if (argc <= 1 || !argv || !argv[0] || !argv[0])
		goto help;
	
	if (!strcmp(argv[0], "--help") || !strcmp(argv[0], "-h"))
		goto help;
	
	/*the argv[0] is the program's name, such as '3g-mngr'*/
	if (CDMG_GET_ARG("help", 0)) 
		goto help_one;

	/*ignore the program's name */
	if (cdmg_call_cmd(argc-1, &argv[1]) == CDMG_FAIL)
		goto help_one;
	else
		return;


help_one:
	cmd = cdmg_find_cmd(argv[1], 0);
	if (cmd) {
		CDMG_MALLOC(1024, buf, goto help);

		/*get the help string and print to user*/
		cdmg_get_help_info(cmd, 0, buf, 1023);
		printf(buf);

		free(buf);
	}

	return;

help:
	CDMG_DO_FUNC(help, "%s", "");
}


/*
* the daemon interface
*/
void  cdmg_daemon(int usleep_v, const char * token, 
		void (*init)(void *date), void *date)
{
	/*set this flag to indicate this is running at daemon*/
	s_cdmg_is_daemon = 1;

	if (init)
		init(date);

	cdmg_msg_process_loop(g_cdmg_daemon_addr, 
		usleep_v, token, cdmg_process_cmd_msg,  
		s_cdmg_timer_handler);
}

static int cdmg_stop_check(int argc, char *argv[], char *rbuf, int rlen)
{
	if (cdmg_is_stop())
		snprintf(rbuf, rlen, "1");
	else
		snprintf(rbuf, rlen, "0");
	
	return strlen(rbuf)+1;
}
__CDMG_SETUP_GET(daemon_is_stop, 1, cdmg_stop_check, 0, 1, 
	"Check the daemon is stop or not\n");

static int cdmg_daemon_start_check(int argc, char *argv[], 
				char *rbuf, int rlen)
{
	snprintf(rbuf, rlen, "OK");
	return strlen(rbuf)+1;
}
__CDMG_SETUP_GET(daemon_is_start, 1, cdmg_daemon_start_check, 0, 1, 
	"Check the daemon is start or not\n");

/*the product a deamon command*/
CDMG_FUNC(daemon, 0, 0, 0, 0, 0, 0, "start the daemon\n"
							     "\targs: --token=xx\n")
{
	char *is_start = 0;
	char token[32] = {0};

	if (cdmg_is_on_daemon())
		return 0;

	if (!s_cdmg_timer_set  || ! s_cdmg_timer_del || 
			!s_cdmg_timer_handler) {
		printf("Not set timer, can not start the daemon\n");
		return 0;
	}

	CDMG_SEND_AND_GET(is_start, 100000, daemon_is_start, "%s","");
	if (is_start) {
		printf("Daemon is started\n");
		free(is_start);
		return 0;
	}

	CDMG_GET_ARG("token", token);
	cdmg_daemon(0, token, 0, 0);

	return 0;
}

CDMG_FUNC(start,  1, 0, 0, 0, 0, 0, "start the deamon's message process!\n")
{
	if (CDMG_FORK(0,0,0) == CDMG_ENV_DAEMON)
		s_cdmg_stop = 0;
	
	return 0;
}

CDMG_FUNC(stop,  1, 0, 0, 0, 0, 0, "start the deamon's message process!\n"
								     " args: --asynch   only stop the asynch action\n")
{
	__cdmg_cmd_t *cmd;
	
	if (CDMG_FORK(0,0,0) != CDMG_ENV_DAEMON)
		return 0;

	/*not stop the msg process*/
	if (!CDMG_GET_ARG("asynch", 0)) 
		s_cdmg_stop = 1;

	/*kill the asyn task*/
	for (cmd = s_cdmg_cmd_start; cmd && cmd <= s_cdmg_cmd_end ; 
				cmd = cmd->next) 
	{
		if (!cmd->is_get_action ||  !cmd->do_process)
			continue;
		
		cdmg_debug("Kill %s\n", cmd->name);
		kill(SIGKILL, cmd->do_process);
		cmd->do_process = 0;

		/*stop the timer*/
		if (cmd->timeout_timer) {
			s_cdmg_timer_del(cmd->timeout_timer);
			cmd->timeout_timer = 0;
		}
	}

	
	return 0;
}

/*this cmd for test the get function*/
static int cdmg_test_get(int argc, char *argv[], char *rbuf, int rlen)
{	
	/*
	* called by func 'cdmg_do_get_handler()' at daemon's 
	* sub task
	*/
	char str_sleep[10] = {0};
	int n_sleep = 0;

	CDMG_GET_ARG("sleep", str_sleep);
	n_sleep = strtoul(str_sleep, 0, 10);

	cdmg_printf("do testget to sleep:%d\n", n_sleep);
	sleep(n_sleep);

	snprintf(rbuf, rlen, "OK! sleeping for %d seconds\n", n_sleep);

	return strlen(rbuf)+1;
}

/*Setup this function*/
__CDMG_SETUP_GET(testget, 1, cdmg_test_get, 1, 5,
	"Test the get function for asynch mode\n\targs:--sleep=x");

/*Setup this function*/
__CDMG_SETUP_GET(testget1, 1, cdmg_test_get, 0, 0,
	"Test the get function for none asynch mode\n\targs:--sleep=x");





#if 0
/*implement a timer*/

/*create a timer, and return the timer's address*/
void  *cdmg_test_timer_set(int tick, const char *name, 
				void (*func)(void *), void *data)
{
	pid_t timer = 0;

	if ((timer = fork()) == 0) {
		sleep(tick);
		
		func(data);/*do the timer handler*/
		
		exit(0);
	}

	cdmg_debug("For %d for timer\n", timer);
	
	return (void *)timer;
}


/*delete a timer*/
void   cdmg_test_timer_del(void *timer)
{
	pid_t pid = (pid_t)timer;
	
	cdmg_debug("kill %d\n", pid);
	kill(pid, SIGKILL);
}


/*do the timeout timer, and return the next expired time*/
struct timeval *   cdmg_test_timer_handler(void *date)
{
	return 0;		
}

/*The last part of modem_wait_search_nt()*/
CDMG_FUNC(msgtest, 1, 0, 0, 0, 0, 0, 
		"for test the function of sending message\n"
		"\teampl: --show=xxx")
{
	char show[80] = {0};
	
	if (!cdmg_is_on_daemon()) {		
		CDMG_GET_ARG("show", show);
		printf("<USER> the show string is:[%s]\n", show);
		
		CDMG_SEND_MSG(msgtest, "--string=\"%s\"", show);
		return 0;
	} 

	if (cdmg_is_on_daemon()) {	
		CDMG_GET_ARG("string", show);
		printf("<DAEMON> the rcvd string is:[%s]\n", show);
		return 0;
	}
}

/*test main*/
int main(int argc, char *argv[])
{
	/*set signal*/
	signal(SIGCHLD, SIG_IGN);

	/*set timer*/
	cdmg_init(cdmg_test_timer_set, cdmg_test_timer_del, 
		cdmg_test_timer_handler, 0);

	/*do the shell*/
	cdmg_shell(argc, argv);
	
	return 0;
}
#endif
