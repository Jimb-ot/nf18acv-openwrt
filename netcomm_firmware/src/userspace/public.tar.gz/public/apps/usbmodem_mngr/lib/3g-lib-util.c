#include <linux/unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <regex.h>
#include <ctype.h>
#include <sys/wait.h>
#include <setjmp.h>
#include <time.h>
#include <sys/sysinfo.h>
#include <sys/file.h>
#include "3g-lib.h"

#define  DEBUG_REG_TAG_FILE "/var/3g_debug_reg"


/*scb+ 2012-4-9 for debug*/
int is_3g_debug_local(const char *token1, const char *token2, 
		const char *file, const char *func)
{
	int ret = 0;
	char str[80] = {0};
	
	if (ret == 0 && token1 && 
			access(token1, F_OK) == 0) {
		ret = 1;
	}
	if (ret == 0 && token2 && 
			access(token2, F_OK) == 0) {
		ret = 1;
	}
	if (ret == 0 && file && file[0]){
		snprintf(str, sizeof(str), 
			"/var/%s", file);
 		if (access(str, F_OK) == 0)
			ret = 1;
	}
	if (ret == 0 && func && func[0]){
		snprintf(str, sizeof(str), 
			"/var/%s", func);
 		if (access(str, F_OK) == 0)
			ret = 1;
	}	
	
	return ret;		
}

void lib3g_at_ret_print(char *src)
{
      int i = 0;
	  
      printf("[");
      for (	 i = 0; src && src[i]; i++) {
                if ( src[i] == '\r')
                        printf("\\r");
                else if (src[i] == '\n')
                        printf("\\n");
                else if (src[i] == '\t')
                        printf("\\t");
                else
                        printf("%c", src[i]);
      	}
       printf("]\n");

}

#ifdef FIND_TTY_PORT_BY_INT_EP
//#define EP_DEBUG(args...)	\
//	do{	\
//		if (is_3g_debug_local(0, 0, 0, __FUNCTION__))\
//			printf_3g("EP", args);\
//	}while(0)
#define EP_DEBUG(args...) d_printf(args)	
int lib3g_have_int_ep(const char *tty)
{
	char buf1[512] = {0};
	char buf2[128] = {0};
	char buf3[12] = {0};
	char *usbtty = 0, *p = 0, *q = 0;
	int kernel_sublevel = 0;
    int kernel_ver = 0;
	DIR *d = 0;
	struct dirent *dent = 0;

	EP_DEBUG("Check:[%s] if exist interrupt ep\n", tty);
		
	/*  format: '/var/dev/ttyUSB0'    */
	if (!(usbtty = strrchr(tty, '/'))) {
		d_printf("tty name error:%s\n", tty);
		return 0;
	}

	usbtty++;/*get 'ttyUSB0'*/
	
	lib3g_get_kernel_ver(&kernel_ver, 0, 	&kernel_sublevel, 0, 0);

    d_printf("kernel_ver = %d\n", kernel_ver);
	if (kernel_sublevel > 21 || kernel_ver >= 3) {
		snprintf(buf1, sizeof(buf1), 
			"ls -l %s/%s >/var/.tmpfile 2>/dev/null", 
			USB_S_DEV_PATH, 
			usbtty);
	} else {
		/*
		  *the link path is:
		  * /sys//class/tty/ttyUSB0/device ->\
		  * ../../../devices/platform/rtl8672-ohci.0/usb2/2-2/2-2:1.0/ttyUSB0
		  */
		snprintf(buf1, sizeof(buf1), 
			"ls -l %s/%s/device >/var/.tmpfile 2>/dev/null", 
			USB_S_DEV_PATH, 
			usbtty);	
	}

	EP_DEBUG("Do cmd:[%s]\n", buf1);
	
	system(buf1);
	buf1[0] = 0;
	if (lib3g_read_file("/var/.tmpfile", buf1,sizeof(buf1) - 1) != 0) {
		d_printf("read /var/.tmpfile error\n");
		unlink("/var/.tmpfile");
		return 0;
	}
	
	unlink("/var/.tmpfile");
	EP_DEBUG("cmd result[%s]\n", buf1);

	/*
	  * result:lrwxrwxrwx 1 root root 0 2011-04-12 07:33 /sys/class/tty/ttyUSB0 ->\
	  * ../../devices/pci0000:00/0000:00:1d.0/usb2/2-2/2-2:1.0/ttyUSB0/tty/ttyUSB0
	  */
	if (!(p = strstr(buf1, "->"))) {
		d_printf("format error\n");
		return 0;
	}

	p = strchr(p, '.');
    if (!p)
    {
		d_printf("format error\n");
		return 0;
    }
	if ((q = strchr(p, '\n')) != NULL)
		*q = 0;
	if ((q = strchr(p, '\r')) != NULL)
		*q = 0;	
	
	EP_DEBUG("The link is:[%s]\n", p);
	if (kernel_ver >= 3)
    {
		snprintf(buf2, sizeof(buf2), 
			"%s/%s/../../../", 
			USB_S_DEV_PATH, 
			p);    
    }
	else if (kernel_sublevel > 21) {
		snprintf(buf2, sizeof(buf2), 
			"%s/%s/../../../usb_endpoint", 
			USB_S_DEV_PATH, 
			p);
	} else {
		/*
		  *for 2.6.19, the endpion can find at dir:
		  * /sys/devices/platform/rtl8672-ohci.0/usb2/2-2/2-2\:1.0/ttyUSB0/..
		  *At this dir the file for endpiod is character link file,such as:
		  *   usb_endpoint:usbdev2.3_ep02
          *   usb_endpoint:usbdev2.3_ep81
          *   usb_endpoint:usbdev2.3_ep82
		  */
		p = strstr(p, "devices");		  
		snprintf(buf2, sizeof(buf2) - 1, 
			"/sys/%s/..", 
			p);		
	}

	if (is_3g_debug_local(DAIL_DEBUF_CONTR_FILE,
			0, __FILE__, __FUNCTION__))
		printf_3g("","To Find ep at dir:[%s]\n", buf2);
	
	if ((d = opendir(buf2)) <= 0) {
		lib3g_send_mobile_msg(MSG_UNIX_DAEMON_PATH, 
			"hotunplug");
		printf_3g("", "open %s failse, maybe 3g dongle is bad, "
			"send hotunplug to diald\n", 
			buf2);
		return 0;
	}

	EP_DEBUG("after open dir dir addr=%d\n", (unsigned int)d);
		
	while( (dent = readdir(d))) {
		if ( !strcmp(dent->d_name, ".") || 
				!strcmp(dent->d_name, ".."))
			continue;

		if (kernel_sublevel <= 21 && kernel_ver < 3 &&
				!strstr(dent->d_name, "usb_endpoint:")) {
			continue;				
		}

        if (kernel_ver >= 3 &&
            !strstr(dent->d_name, "ep_"))
            continue;
        
		buf1[0] = 0;
		
		snprintf(buf1, sizeof(buf1), 
			"%s/%s/type", 
			buf2, 
			dent->d_name);

		
		buf3[0] = 0;
		
		EP_DEBUG("read ep file:[%s]\n", buf1);
		if (lib3g_read_file(buf1, buf3, sizeof(buf3) - 1) == 0) {
			EP_DEBUG("result:[%s]\n", buf3);
			if (strstr(buf3, "Interrupt")) {
				closedir(d);
				if (is_3g_debug_local(DAIL_DEBUF_CONTR_FILE,
						0, __FILE__, __FUNCTION__))
					printf_3g("","[%s] have  interrupt ep\n", tty);
				return 1;
			}
		}
	}
	closedir(d);
	if (is_3g_debug_local(DAIL_DEBUF_CONTR_FILE,
			0, __FILE__, __FUNCTION__))	
		printf_3g("","[%s] have no interrupt ep\n", tty);
	return 0;	
}
#endif

char *lib3g_strncpy(char *dest, int dlen, 
			const char *src, int slen)
{
	char *ret = 0;
	int len = 0;
	int len1 = 0;

	if (!dest)
		return 0;

	if (slen == 0)
		len1 = strlen(src);
	else
		len1 = slen;

	if (dlen == 0)
		len = len1;
	else
		len = (dlen - 1) > len1 ? len1 : (dlen - 1);

	if (dlen)
		memset(dest, 0, dlen);
	
	ret = strncpy(dest, src, len);

	if (dlen)
		dest[dlen - 1] = 0;

	return ret;
}

void lib3g_strl2u(char *s)
{
	int i;
	int del;

	del = 'A' - 'a';
	for (i = 0; s[i] ; i++)
		if (s[i] >= 'a' && s[i] <= 'z')
			s[i] += del;
}

void lib3g_strdelblank(char *s)
{
	int i;
	int j;
	int k;

	for (i = 0; s[i]; i++) {
		if (s[i] == ' ' || s[i] == '\t') {
			for(j = i; s[j] && (s[j] == ' ' || s[j] == '\t'); j++);
			for (k = 0; s[j+k]; k++)
				s[i+k] = s[j+k];
			s[i+k] = 0;
		}
		if (!s[i])
			break;
	}
}

void lib3g_strdelCR(char *s)
{
	int i;
	int j;
	int k;

	for (i = 0; s[i]; i++) {
		if (s[i] == '\r' || s[i] == '\n') {
			for(j = i; s[j] && (s[j] == '\r' || s[j] == '\n'); j++);
			for (k = 0; s[j+k]; k++)
				s[i+k] = s[j+k];
			s[i+k] = 0;
		}
		if (!s[i])
			break;
	}
}	

int lib3g_at_is_end(const char *buf, int byte)
{		
	int i = 0;
	int n = 0;
	char local_buf[BUFSIZE] = {0};
	char *at_end_str[] = {
		"OK", 
		"ERROR", 
		"NO CARRIER", 
		"NO ANSWER"
	};

	n = byte > (BUFSIZE - 1) ? (BUFSIZE - 1) : byte;
	memcpy(local_buf, buf, n);

	for (i = 0; i < sizeof(at_end_str)/sizeof(at_end_str[0]); i++) {
		if (strstr(local_buf, at_end_str[i]))
			return 1;
	}

	return 0;
}

int lib3g_getridof_invalidstr(char *recv_buf, int recv_len)
{
    char *match_point = NULL;
    char *last_match_point = NULL;
    int ret = 0;
    
    if (!recv_buf || recv_len <= 2)
    {
        return recv_len;
    }

    last_match_point = recv_buf;
    while ( (last_match_point != NULL) &&
            ((match_point = strstr(last_match_point, "\r\n")) != NULL))
    {
        last_match_point = match_point + 2;
    }

    if (last_match_point)
    {
        ret = recv_len - (last_match_point - recv_buf);
        strcpy(recv_buf, last_match_point);
    }
    else
    {
        recv_buf[0] = '\0';
    }
    
    return ret;
}
int lib3g_at_is_success(const char *buf, int byte)
{
	char local_buf[BUFSIZE] = {0};
	int n = byte > (BUFSIZE - 1) ? (BUFSIZE - 1) : byte;

	memcpy(local_buf, buf, n);

	if (strstr(local_buf, "OK") || strstr(local_buf, "READY") || 
			strstr(local_buf, "ok"))
		return 1;
	else
		return 0;
}

void lib3g_serial_attr_change_for_dongle(int fd, int is_restore)
{
	static struct termios saved_tio;
	struct termios  newtio;

	if (is_restore) {
		tcsetattr(fd,TCSANOW,&saved_tio);
		return;
	}

	memset(&saved_tio, 0, sizeof(saved_tio));
	memset(&newtio, 0, sizeof(newtio));
	
	tcgetattr(fd,&saved_tio);
	newtio = saved_tio;
	
	tcflush(fd, TCIFLUSH);
	
	newtio.c_iflag     |= IGNBRK | ISTRIP | IGNPAR;
	newtio.c_oflag      = 0;
	newtio.c_lflag      = 0;
	newtio.c_cc[VERASE] = 0;
	newtio.c_cc[VKILL]  = 0;
	newtio.c_cc[VMIN]   = 1;
	newtio.c_cc[VTIME]  = 0;	
	
	tcsetattr(fd,TCSANOW,&newtio);	
}

/*serial io*/
int __lib3g_serial_send_recv(int fd, int not_change_attr, 
			char *send, int send_len, 
                       char *recv_buf, int recv_len, 
                       int timeout_s, int timeout_us, 
                       int wait_s, int wait_us, 
    int exit_func(char *r_buf, int r_len, void *, char *o_buf, int *io_len), void *exit_data)
{
#if 1
#define DP(fmt, args...) d_printf(fmt, ##args)
#else
#define DP(fmt, args...) 
#endif
	int ret = 0;
	int nread = 0;
	int nwrite = 0;
	int total = 0;
	int delsec = 0;
	int delusec = 0;
	fd_set rfds;
	char buf[BUFSIZE] = {0};
	char tmp[BUFSIZE] = {0};
	struct timeval tv;
	struct timeval tv1;
	struct timeval tv2;

	if (!not_change_attr)
		lib3g_serial_attr_change_for_dongle(fd, 0);
    if (flock(fd, LOCK_EX) == 0)
        d_printf("%s:set tty lock, pid= %d\n", __func__, getpid());

	if (send) {
		nwrite = write(fd, send, send_len);

		if(nwrite < 0)
		{
			d_perror("AT cmd %s", send);
			ret =  -1;
			goto end;
		}

		DP("wite %d bytes\n", nwrite);
	} else {
		DP("no write, only read\n");
	}

	memset(&tv1, 0, sizeof(tv1));
	gettimeofday(&tv1, 0);

	if (wait_s > 0 || wait_us > 0) 
		usleep(wait_s * 1000000 + wait_us);
	
	if (!recv_buf) {
		DP("NOT to receive\n");
		ret = nwrite;
		goto end;
	}
		
	total = 0;
	
	while(1) {
		FD_ZERO(&rfds);
		FD_SET(fd,&rfds);	

		/*calculate the timeout interval*/
		if (timeout_us < delusec)  {
			tv.tv_usec = 1000000 + timeout_us - delusec;
			tv.tv_sec = timeout_s - delsec -1;			
		} else {
			tv.tv_usec = timeout_us - delusec;
			tv.tv_sec = timeout_s - delsec;
		}

		DP("time out:[%ds %dus], remaind:[%ds %dus]\n", 
			(int)timeout_s, (int)timeout_us, 
			(int)tv.tv_sec, (int)tv.tv_usec);
			
		if ((ret = select(1+fd, &rfds, NULL, NULL, &tv)) > 0)
		{
			if(FD_ISSET(fd,&rfds))
			{ 
				memset(tmp, 0, BUFSIZE);	
				nread = read(fd, tmp, BUFSIZE-1);
						

				if(nread < 0) 
					d_perror("serial read");

				d_printf("read %d byte(s) :[%s]\n", nread, tmp);
				
				if (nread > 0) {
					int n_free = BUFSIZE - total - 1;
					DP("the free space is %d, the read is:[%s](%dbyte(s))\n", 
						n_free, tmp, nread);
					if (n_free <= 0) {
						d_printf("buf is full\n");
						goto end;
					}

					/*for debug*/
					memset(&tv2, 0, sizeof(tv2));
					gettimeofday(&tv2, 0);					
					DP("orig time[%ds %dus] current [%ds %dus]\n", 
						(int)tv1.tv_sec, 
						(int)tv1.tv_usec, 
						(int)tv2.tv_sec, 
						(int)tv2.tv_usec);
					
					int n_copy = nread > n_free ? n_free  : nread;
					DP("copy %d byte(s) to buf\n", n_copy);
					memcpy(buf + total, tmp, n_copy);
					total += n_copy;
                    /*
					if (total >= recv_len) {
						DP("The receive buf is full\n");
						goto end;
					}
					*/

                    /* ����Ҳ���ܻ�������ؽ������ʧ�������������ATָ��ִ��ʧ�� */
					if (lib3g_at_is_end(buf, total)) {
						ret = nread;
						goto end;
					}

					/* Ϊ�˷�ֹ�����ķ��ؽ�������º����rbuf�Ų��¶���ʧ��Ҫ��
                     * �����������ȡ������Ҫ���ַ�����������Ҫ������˵���յ�
                     * ����rbuf���ȴ�С������أ�����Ҫ�ķ��ؾ��ڳ����Ļ�����
                     * ����ͻ�������������
                     */
                    if (exit_func && exit_func(buf, total, exit_data, buf, &total)) {
						d_printf("According the user's exit condition\n");
						ret = total;
						goto end;
					}
                    /* ������Ϊ���ܻ��������˾��˳���3g modem�ϱ���Ϣ��ʱ��
                     * �����׾ͷ����˻�������������������ջ��������ˣ�����
                     * ���ò���������Ҫ���ַ���������һ��'\r\n'��ȡ�ַ���
                     */
					if (total >= recv_len) {
                        total = lib3g_getridof_invalidstr(buf, total);

                        /* ���㳬ʱ�������ʱ���˳�������������� */
                        memset(&tv2, 0, sizeof(tv2));
                        gettimeofday(&tv2, 0);
                        
                        DP("orig time[%ds %dus] current [%ds %dus]\n", 
                            (int)tv1.tv_sec, 
                            (int)tv1.tv_usec, 
                            (int)tv2.tv_sec, 
                            (int)tv2.tv_usec);
                        
                        if (tv2.tv_usec < tv1.tv_usec) {
                            delusec = tv2.tv_usec + 1000000 - tv1.tv_usec;
                            delsec = tv2.tv_sec - tv1.tv_sec - 1;
                        } else {
                            delsec = tv2.tv_sec - tv1.tv_sec;
                            delusec = tv2.tv_usec - tv1.tv_usec;
                        }
                        
                        DP("lost time[%ds %dus] \n", delsec, delusec);
                                               
                        if ((delsec == timeout_s && delusec >= timeout_us) ||
                                delsec > timeout_s)
                        {
                            //printf("%s[%d]:Time Out\n", __func__, __LINE__);
                            ret = 0;
                            break;
                        }
                        continue;
					}
				}
			}
		}
		else if (ret == 0)
		{
			d_printf("timer out\n");
		}
		else
		{
			perror("Select");
		}

		memset(&tv2, 0, sizeof(tv2));
		gettimeofday(&tv2, 0);

		DP("orig time[%ds %dus] current [%ds %dus]\n", 
			(int)tv1.tv_sec, 
			(int)tv1.tv_usec, 
			(int)tv2.tv_sec, 
			(int)tv2.tv_usec);

		if (tv2.tv_usec < tv1.tv_usec) {
			delusec = tv2.tv_usec + 1000000 - tv1.tv_usec;
			delsec = tv2.tv_sec - tv1.tv_sec - 1;
		} else {
			delsec = tv2.tv_sec - tv1.tv_sec;
			delusec = tv2.tv_usec - tv1.tv_usec;
		}

		DP("lost time[%ds %dus] \n", delsec, delusec);
		
		
		if ((delsec == timeout_s && delusec >= timeout_us) ||
				delsec > timeout_s)
		{
			d_printf("Time Out\n");
			ret = 0;
			break;
		}
	}
	
end:	
	
	if (recv_buf) {
		DP("read total %d byte(s)\n", total); 
		total = total > recv_len ? recv_len : total;
		memcpy(recv_buf, buf, total);
	}
#ifdef LTE_CS_CALL
    lib3g_send_voip_echo_msg(buf);
#endif
	if (!not_change_attr)				
		lib3g_serial_attr_change_for_dongle(fd, 1);
	
    flock(fd, LOCK_UN);
	return ret;

#undef DP
}

int lib3g_serial_send_recv(const char *dev, char *send, int send_len,
		char *recv_buf, int recv_len, int timeout_s,
	       int timeout_us, int wait_s, int wait_us,
           int exit_func(char *r_buf, int r_len, void *, char *o_buf, int *io_len), void *exit_data)
{
	int fd = 0;
	int ret = 0;
	time_t lastTime = time(NULL);

	record_3g("use dev(%s) to excute AT command\r\n", dev);

	if ( (fd = open(dev, O_RDWR | O_NOCTTY | O_NONBLOCK )) < 0) {
	        perror("Open dev[%s]", dev);
	        return -1;
	}

    //some console dev spend so many time to open/write/read, so here we optimize code to end it fastly.
    if (send!=NULL && 
        send_len==(sizeof(AT_TEST_INSTRUCTION)-1) && 
        !strncmp(send, AT_TEST_INSTRUCTION, send_len)){
        if ((time(NULL)-lastTime) > AT_TEST_INSTRUCTION_MAX_RESPONSE_TIME){
            ret = AT_TEST_TIMEOUT_RET;
            record_3g("open dev(%s) timeout(>%d), return %d\r\n",
            dev, AT_TEST_INSTRUCTION_MAX_RESPONSE_TIME, AT_TEST_TIMEOUT_RET);
            goto closeFD;
        }
    }

	
	ret = __lib3g_serial_send_recv(fd, 0,
			send, send_len, 
			recv_buf, recv_len, 
			timeout_s, timeout_us, 
			wait_s, wait_us, exit_func, exit_data);

closeFD:    
	close(fd);

	return ret;
}

int lib3g_is_support_at_cmd(char *tty_dev)
{
	char at_buf[256] = {0};	
	int i = 0;
	int ret = 0;

	for (i = 0; i <= 2; i++) {
		memset(at_buf, 0 , sizeof(at_buf));
		ret = lib3g_serial_send_recv(tty_dev, AT_TEST_INSTRUCTION, sizeof(AT_TEST_INSTRUCTION)-1, 
			at_buf, 256, 0, 10000, 0, 0, 0, 0);
		if (ret == AT_TEST_TIMEOUT_RET)
			return 0;
		if ( strstr(at_buf, "AT") || strstr(at_buf, "OK"))
			return 1;		
		usleep(1000);
	}
	return 0;
}

/******end serial io************************/




/***Chat function support ******************************/

#if 0
#define DP(fmt, args...) d_printf(fmt, ##args)
#else
#define DP(fmt, args...) 
#endif


#define LIB3G_CHAT_BUF_LEN 512
#define LIB3G_CHAT_RCVD_LEN 256

/*
* @ retrun the len of the token
*/
static int lib3g_chat_get_string(const char *buf, 	char *rtoken1, 
			int rtoken1_l, char *rtoken2, int rtoken2_l)
{	
	const char *p = 0;
	int i =0;
	int token1_start = 0;
	int token1_end = 0;
	int token2_start = 0;
	int token2_end = 0;
	int commom_c = 0;
	int switch_c = 0;

	/*get the  token*/
	p = buf;
	do
	{
		/*the '\' char*/
		if (*p == '\\' && !switch_c) {
			switch_c = 1;
			continue;
		} else
			switch_c = 0;

		/*teh ' or '' char*/
		if ((*p == '\'' || *p == '\'') && !switch_c) 
		{
			if (commom_c)  
			{
				/*count the '\'' again*/
				commom_c = 0;
				if (token1_start && !token1_end) 
				{
					token1_end = 1;
					if (rtoken1 && i < rtoken1_l)
						rtoken1[i] = 0;
				} 
				else if (token1_end && (token2_start && !token2_end)) 
				{
					token2_end = 1;
					if (rtoken2 && i < rtoken2_l)
						rtoken2[i] = 0;
				}	
			}
			else
			{
				commom_c = 1;
				
				/*first count the " ' "*/
				if (!token1_start) {
					token1_start = 1;
					i = 0;
				}
				
				if (token1_end && !token2_start) {
					token2_start = 1;
					i= 0;
				}
			}
			
			continue;
		}

		/*blank char*/
		if ((*p == ' ' || *p == '\t') && !switch_c) {
			if (!commom_c && token1_start && !token1_end) {
				/*token 1 end*/
				token1_end = 1;
				if (rtoken1 && i < rtoken1_l)
					rtoken1[i] = 0;
				continue;
			}

			if (!commom_c && token1_end && 
					(token2_start && !token2_end)) {
				token2_end = 1;
				if (rtoken2 && i < rtoken2_l)
					rtoken2[i] = 0;
			}				
		}

		/*normal char*/
		if (*p && *p != ' ' && *p != '\t' && *p != '\'' && 
			*p != '\"' && *p != '\\')
		{
			/*start to get the 1st token*/
			if (!token1_start) {
				token1_start = 1;
				i = 0;
			}

			/*start to get the 1st token*/
			if (token1_end && !token2_start) {
				token2_start = 1;
				i = 0;
			}				
		}

		/*set  token1's value */
		if (token1_start && !token1_end) {			
			if (rtoken1 && i < rtoken1_l)
				rtoken1[i] = *p;
			i++;
		}

		/*set  token2's value */
		if (token2_start && !token2_end) {
			if (rtoken2 && i < rtoken2_l)
				rtoken2[i] = *p;
			i++;
		}
	}   while(*(++p) && *p != '\n' && *p != '\r');

	if (rtoken1 && rtoken1_l > 0)
		rtoken1[rtoken1_l -1] = 0;
	
	if (rtoken2 && rtoken2_l > 0)
		rtoken2[rtoken2_l -1] = 0;

	return 0;	
}

/*
*
* get the abort string and the time out from chat script
* the abort sting format is:
* 	ERROR,BUSY
* return :		
*	find ctrl token 1, else 0.
*/
static int lib3g_chat_get_crtl(const char *buf, char *abort, int abortlen, int *to)
{
	char token1[80] = {0};
	char token2[80] = {0};

	lib3g_chat_get_string(buf, token1, sizeof(token1)-1,
		token2, sizeof(token2)-1);

	DP("chat line:first:%s, second:%s\n", token1, token2);

	if (!token1[0] || (!strstr(token1, "ABORT") &&
			!strstr(token1, "TIMEOUT") && !strstr(token1, "ECHO") &&
			!strstr(token1, "EOT") && !strstr(token1, "SAY")))
		return 0;			
	
	if (abort && token1[0] && !strcmp(token1, "ABORT")) {
		if (abort[0] && token2[0])
			cdmg_fstrncat(abort, abortlen, ",%s", token2);
		else if (token2[0])
			cdmg_fstrncat(abort, abortlen, "%s", token2);
	}

	if (to && token1[0] && !strcmp(token1, "TIMEOUT")) {
		if (token2[0])
			*to = strtoul(token2, 0, 10);
	}

	return 1;	
}

/*
* check the chat receive string is if abort string
*/
static int  lib3g_chat_check_rcvd(const char *buf, const char *abort)
{
	char *tmp = 0;
	char *saveptr = 0;
	char *s = 0;
	int len = strlen(abort) + 1;

	/*malloc a buf*/
	CDMG_MALLOC(len, tmp, return -1);
	snprintf(tmp, len, "%s", abort);

	/*check*/
	s = strtok_r(tmp, ",", &saveptr);
    if (!s)
    {
        free(tmp);
        return -1;
    }
	do {
		if (strstr(buf, s)) {
			DP("return %s, abort\n", s);
			free(tmp);
			return -1;
		}
	}while((s = strtok_r(NULL, ",", &saveptr)));

	free(tmp);
	return 0;
}

static int lib3g_chat_exit_condition(char *buf, int len, void *data, char *o_buf, int *io_len)
{
	char rbuf[LIB3G_CHAT_RCVD_LEN] = {0};
	char user_reg_exp[LIB3G_CHAT_RCVD_LEN] = {0};
	char express[] = "/([ \t]*CONNECT.*[0-9]+)|([ \t]*connect.*[0-9]+)/";

	/*check the user's data*/
	lib3g_reg_exec(buf, express, rbuf, LIB3G_CHAT_RCVD_LEN-1);
	if (rbuf[0]) {
		d_printf("Read: [%s]\n", rbuf);
        if (o_buf && io_len)
        {
            strncpy(o_buf, rbuf, *io_len - 1);
            *io_len = strlen(o_buf);
        }
		return 1;
	}

	/*check the connected data*/
	if (data) {
		rbuf[0] = 0;
		snprintf(user_reg_exp, LIB3G_CHAT_RCVD_LEN, "/%s/", (char *)data);
		lib3g_reg_exec(buf, user_reg_exp, rbuf, LIB3G_CHAT_RCVD_LEN-1);
		if (rbuf[0]) {
			d_printf("Read the user's point out string:[%s]\n", rbuf);
			return 1;
		}
	}

	return 0;	
}

int lib3g_chat_file(const char *file, const char *tty, const char *log_file)
{	
	FILE *fp =0, *log_fp = 0;
	int io_ret = 0, fd = -1, ret = 0, chat_timeout = 5, rate = 0, times = 1;
	char *send = 0, *rcvd = 0, *abort = 0, *expect = 0;
	char *buf = 0, *p = 0, *tmp_express = 0;
	time_t curr;
	
	d_printf("Chat script:%s, tty:%s, log:%s\n",
		file, tty, log_file);
	
	CDMG_OPEN(fd, open, O_RDWR | O_NOCTTY | O_NONBLOCK, 
		tty, ret = -1; goto end;);

	lib3g_serial_attr_change_for_dongle(fd, 0);

	/*open log file*/
	if (log_file)
		CDMG_FOPEN(log_fp, fopen, "w", log_file, ret = -1; goto end;);

	/*open chat script file*/
	CDMG_FOPEN(fp, fopen, "r", file, ret = -1; goto end; ); 

	/*malloc a buf to read file*/
	CDMG_MALLOC(LIB3G_CHAT_BUF_LEN, buf, ret = -1; goto end;);

	/*malooc a buf to receive from tty*/
	CDMG_MALLOC(LIB3G_CHAT_RCVD_LEN, rcvd, ret = -1; goto end;);

	/*malooc a buf to receive expect*/
	CDMG_MALLOC(LIB3G_CHAT_BUF_LEN, expect, ret = -1; goto end;);

	/*malooc a buf to receive sendcontent*/
	CDMG_MALLOC(LIB3G_CHAT_BUF_LEN, send, ret = -1; goto end;);	

	/*malooc a buf to receive abort strings*/
	CDMG_MALLOC(LIB3G_CHAT_BUF_LEN, abort, ret = -1; goto end;);	

	/*malooc a buf to receive abort strings*/
	CDMG_MALLOC(LIB3G_CHAT_BUF_LEN, tmp_express, ret = -1; goto end;);	
	
	
	while(fgets(buf, LIB3G_CHAT_BUF_LEN-1, fp)) 
	{
		DP("%s\n", buf);

		/*skip the blank char*/
		for (p = buf; 
			*p && (*p == '\n'  || *p == '\r' || *p == ' ' || *p == '\t'); 
			p++);

		/*skip the blank line*/
		if (!*p)
			continue;


		/*the line is ctrl, get the abort string, then to read the next line*/
		if (lib3g_chat_get_crtl(buf, abort, LIB3G_CHAT_BUF_LEN, 
				&chat_timeout) > 0) {
			memset(buf, 0, LIB3G_CHAT_BUF_LEN);
			continue;
		}
		
		memset(expect, 0, LIB3G_CHAT_BUF_LEN);
		memset(send, 0, LIB3G_CHAT_BUF_LEN);
		lib3g_chat_get_string(buf, expect, LIB3G_CHAT_BUF_LEN, 
			send, LIB3G_CHAT_BUF_LEN);		
		
		if (expect[0]) 
		{
			d_printf("Get expect string:[%s], to read...\n", expect);
			snprintf(tmp_express, LIB3G_CHAT_BUF_LEN, "/%s/", expect);
			
			memset(rcvd, 0, LIB3G_CHAT_RCVD_LEN);
			
			io_ret = __lib3g_serial_send_recv(fd, 1, 0, 0, 
				rcvd, LIB3G_CHAT_RCVD_LEN - 1,
				chat_timeout, 0,
				0, 300000,
				lib3g_chat_exit_condition, (void *)expect);
			if (io_ret <= 0) {
				printf_3g("", "TimeOut\n");
				ret = -1;
				goto end;	
			}
			if (!rcvd[0]) {
				printf_3g("", "No content to read when read the expect\n");
				ret = -1;
				goto end;
			}
			
			lib3g_reg_exec(rcvd, 
				"/[\n\r][^\n\r]{1,}[\n\r]/, /[^\n\r]{1,}/", 
				rcvd, LIB3G_CHAT_RCVD_LEN-1);
			
			/*output log*/
			if (log_fp) {
				time(&curr);
				fprintf(log_fp, "\n\n%-12d %-4s : %-20s\n\n",
					(unsigned int)curr,
					"==>R",
					rcvd);
			}

			/*get the connect rate*/
			if ((p = strstr(rcvd, "CONNECT")) || (p = strstr(rcvd, "connect"))) 
			{
				/*skip the none digital*/
				for (; *p && !isdigit(*p); p++);

				if (p) 
				{
					rate = strtoul(p, 0, 10);
					DP("the raw rate:%d\n", rate);
					
					/*skip the digital*/
					for (; *p && isdigit(*p); p++);
					
					if (*p) 
					{
						DP("the rate unit:%c\n", *p);
						if (*p == 'm' || *p == 'M')
							times = 1000000;
						if (*p == 'k' || *p == 'K')
							times = 1000;
						if (*p == 'g' || *p == 'G')
							times = 1000000000;

						rate = rate * times;
					}
				}			
				
			}

			/*check the abort*/
			if (lib3g_chat_check_rcvd(rcvd, abort) != 0) {
				d_printf("Read the abort string!\n");
				ret = -1;
				goto end;
			}				
		}/*end processing the string expect */

		if (send[0]) 
		{
			d_printf("Get send string:[%s]\n", send);

			/*out put send string*/
			if (log_fp) {
				time(&curr);
				fprintf(log_fp, "\n\n%-12d %-4s : %-20s\n\n",
					(unsigned int)curr,
					"==>S",
					send);
			}
			
			if (!strstr(send, "\r"))
				cdmg_fstrncat(send, LIB3G_CHAT_BUF_LEN - 1, 
					"%s", "\r\n");			
			__lib3g_serial_send_recv(fd, 1, send, strlen(send), 
				0, 0, 0, 0, 0, 0, 0, 0);			
		}		
	}
	
end:

	if (ret == -1 && log_fp)
		fprintf(log_fp, "Failed\n");
	else if (ret == 0 && log_fp)
		fprintf(log_fp, "Chat Success!\n");
	
	if (fp)
		fclose(fp);
	if (log_fp)
		fclose(log_fp);
	if (fd >= 0) {
		lib3g_serial_attr_change_for_dongle(fd, 1);
		close(fd);
	}
		

	if (buf)
		free(buf);
	if (rcvd)
		free(rcvd);
	if (expect)
		free(expect);
	if (send)
		free(send);
	if (abort)
		free(abort);
	if (tmp_express)
		free(tmp_express);	
	
	if (ret == 0)
		return rate;
	else
		return ret;
}

#undef DP

/*****Chat function support end**********************/


/****regular express ******/
typedef enum {
	REG_CMD_MATCH,
	REG_CMD_REPLACE
} reg_cmd_t;

static int __reg_match(const char *str, const char *regstr, 
			char **start, char **end)
{
#if 0
#define DP(fmt, args...) d_printf(fmt, ##args)
#else
#define DP(fmt, args...) 
#endif
        regex_t reg;
        regmatch_t  match_result[5];
        char errbuf[128] = {0};
        int ret = 0;

        if (start)
                *start = (char *)str;
        if (end)
                *end = (char *)str;

	 memset(&reg, 0, sizeof(regex_t));
	 memset(&match_result, 0, sizeof(match_result));
	 
        if ((ret = regcomp(&reg, regstr, REG_EXTENDED)) != 0) {
            regerror(ret, &reg, errbuf, sizeof(errbuf));
            DP("%s: %s regcom('%s')\n", errbuf, str, regstr);
            return -1;
        }
		
        if ( (ret = regexec(&reg, str, 5, match_result, 0)) != 0) {
            regerror(ret, &reg, errbuf, sizeof(errbuf));
            DP("%s: %s regcom('%s')\n", errbuf, str, regstr);
            regfree(&reg);
            return 0;
        }
		
        regfree(&reg);

        if (match_result[0].rm_so == -1 || match_result[0].rm_eo == -1 ) 
                return 0;
		
        if (start)
                *start = (char *)(str + match_result[0].rm_so);
        if (end)
                *end = (char *)(str + match_result[0].rm_eo);
		
        return(match_result[0].rm_eo - match_result[0].rm_so);
		
#undef DP
}

/*@ regstr : /reg1/,/reg2/,s/reg3/replace_str/...*/
static int __reg_get(char *reg_strs, char *reg, reg_cmd_t *reg_act, 
					char *rpl_string, char **next)
{
        int i = 0;
        int j = 0;
	 int 	find = 0;
        char *p;
	 enum {
	 	REG_SCAN_START,
	 	REG_SCAN_CMD,
		REG_SCAN_REG_START,
		REG_SCAN_REG_END,
		REG_SCAN_RPL_START,
		REG_SCAN_RPL_END
	 } s;

	 s = REG_SCAN_START;
        if (!reg_strs) {
		*next = 0;	
		return 0;
        }

        p = reg_strs;
        for (i = 0; p[i] != 0; i++) {
		  switch(s) {
		  	case REG_SCAN_START:
				 /* there 3 format: 
				  *	 1.	s/../../
                             *    2.	m/.../
                             *    3.	/.../
                             */
				if (p[i] == 's') {
					*reg_act = REG_CMD_REPLACE;
					s = REG_SCAN_CMD;
				} else if (p[i] == 'm') {
					*reg_act = REG_CMD_MATCH;
					s = REG_SCAN_CMD;	
				} else if (p[i] == '/') {
					*reg_act = REG_CMD_MATCH;
					j = 0;
					s = REG_SCAN_REG_START;
				} else if	(p[i] != ' ' && p[i] != '\t')
					goto reg_err;
				break;
				
			case	REG_SCAN_CMD:
				if (p[i] == '/') {
					j = 0;
					s =REG_SCAN_REG_START;
				} else
					goto reg_err;
				
				break;
				
			case	REG_SCAN_REG_START:
				if (p[i] == '/') {
					reg[j] = 0;
					if (p[i+1] == 0) {
						*next = 0;
						if (*reg_act == REG_CMD_MATCH) {
							/* /abc/ */
							find = 1;
							goto reg_ok;
						} else 
							goto reg_err;
					}
					s = REG_SCAN_REG_END;
					j = 0;
				} else
					reg[j++] = p[i]; 
				break;
				
			case	REG_SCAN_REG_END:
				if (*reg_act == REG_CMD_MATCH) {
					if ( p[i] == ',') {
						if (p[i+1] == 0)
							*next = 0;
						else 
							*next = p+i+1;
						find = 1;
						goto reg_ok;

					} else if ((p[i] == ' ' || p[i] == '\t') && 
							p[i+1] == 0) {
						/* "/abc/ " */
						*next = 0;
						find = 1;
						goto reg_ok;
					} else if (p[i] != ' ' && p[i] != '	')						
						goto reg_err;
				} else if (*reg_act == REG_CMD_REPLACE) {
					if (p[i] == '/') {
						/* s/abc// */
						rpl_string[0] = 0;
						if ( p[i+1] == 0) {
							*next = 0;
							find = 1;
							goto reg_ok;
						}
						s = REG_SCAN_RPL_END;
					} else {
						j = 0;
						rpl_string[j++] = p[i];
						s = REG_SCAN_RPL_START;
					}
				} else {
					*next = 0;
					goto reg_err;
				}
				break;				

			case REG_SCAN_RPL_START:
				if (p[i] == '/') {
					rpl_string[j] = 0;
					if (p[i+1] == 0) {
						*next = 0;
						find =1;
						goto reg_ok;
					}
					s =REG_SCAN_RPL_END;
				} else
					rpl_string[j++] = p[i];
				break;
				
			case REG_SCAN_RPL_END:
				if (p[i] == ',') {
					if (p[i+1] == 0) 
						*next = 0;
					else 
						*next = p+i+1;
					find = 1;
					goto reg_ok;
				} else if ((p[i] == ' ' || p[i] == '\t') &&
						p[i+1] == 0) {
					*next = 0;
					find = 1;
					goto reg_ok;
				} else if (p[i] != ' ' && p[i] != '\t')
					goto reg_err;				
				break;						

		  	default:
				goto reg_err;
		}
       }

	/*scan to the end of the regstring*/
reg_err:
	*next = 0;
	*reg = 0;
	*rpl_string = 0;
	d_printf("reg format err:[%s]\n", reg_strs);
	return 0;
reg_ok:	
	return find;	

}

/*@ regstr:
*    /reg1/,/reg2/,..
*    start: the first char of the matched .
*    end : the first char following the matched.
*/
int lib3g_reg_exec(char *str, char *regstr, char *rbuf, int r_len)
{
	int ret = 0;
	reg_cmd_t regact = REG_CMD_MATCH;
	char regbuf[REG_EXPR_BUF_SIZE] = {0};
	char __str[REG_STR_BUF_SIZE] = {0};
	char __regstr[REG_STR_BUF_SIZE] = {0};
	char rpl_str[REG_STR_BUF_SIZE] = {0};		
	char rpl_tmp[REG_STR_BUF_SIZE] = {0};	
	char *regstr_tmp = 0;
	char *str_tmp;		
	char *result_start;
	char *result_end;

	strncpy(__str, str, REG_STR_BUF_SIZE-1);	
	strncpy(__regstr, regstr, REG_STR_BUF_SIZE-1); 
	
	str_tmp = __str;
	regstr_tmp = regstr;

	while((ret = __reg_get(regstr_tmp, regbuf, &regact, 
					rpl_str, &regstr_tmp))) {
#ifndef EXTERN_USE_3G_MNGR_H		
		if (IS_MNGR_DEBUG(DEBUG_REG_TAG_FILE)) {			
			printf("\n\nTo  %s the following string:\n", 
				regact==0 ? 
				"match":"replace");
			lib3g_at_ret_print(str_tmp);
			printf("by the  following pattern:\n");
			lib3g_at_ret_print(regbuf);
		}
#endif		
		result_start = 0;
		result_end = 0;
		
		if ((ret = __reg_match(str_tmp, regbuf, 
					&result_start, &result_end)) == -1) {
			printf_3g("", "reg expression error:[%s]\n", regbuf);
			return -1;
		}
		
#ifndef EXTERN_USE_3G_MNGR_H
		if (IS_MNGR_DEBUG(DEBUG_REG_TAG_FILE)) {
			char tmp[128] = {0};
			char *p;
			int i;
			
			memset(tmp, 0, 128);

			for (p = result_start, i = 0; i < 128 && 
						p < result_end; p++, i++)
				tmp[i] = *p;
			
			printf("The result:\n");
			lib3g_at_ret_print(tmp);
			printf("\n\n");
		}			
#endif
			
		if (ret == 0) {
			/*no match*/
			if ( regact == REG_CMD_MATCH)
				return 0;
			
			if ( regact == REG_CMD_REPLACE)
				continue;
		}
		
		if ( regact == REG_CMD_MATCH) {
			str_tmp = result_start;
			if (result_end)
				*result_end = 0;
		} else if (regact == REG_CMD_REPLACE) {
			/*replace*/
			*result_start = 0;
			*rpl_tmp = 0;

			lib3g_fstrncat(rpl_tmp, 
				REG_STR_BUF_SIZE, 
				"%s%s%s", 
				str_tmp, rpl_str, result_end);
			snprintf(str_tmp, 
				REG_STR_BUF_SIZE, 
				"%s", rpl_tmp);
			
		} 
	}
	
	//if (rbuf && r_len <= 0)
	//	strcpy(rbuf, str_tmp);

	if (rbuf && r_len > 0)
		strncpy(rbuf, str_tmp, r_len);
	
	return 0;
}

/***************************regex end********************************************/



/*****************************************************************************/

int lib3g_read_file(const char *file, char *buf, int buf_l)
{
	FILE *fp;

	if (!(fp = fopen(file, "r"))) {
		d_printf("can not open file:%s\n", file);
		return -1;
	}

	if ( !fread(buf, 1, buf_l, fp)) 
		d_printf("read nothing from file:%s\n", file);
	fclose(fp);
	return 0;
}

int lib3g_write_file0(const char *file, char *buf, int len)
{
	FILE *fp;
	size_t rlen = 0;

	if (!(fp = fopen(file, "w+"))) {
		d_printf("can not open file:%s\n", file);
		return -1;
	}

	rlen = fwrite(buf, 1, len, fp);
	fclose(fp);
	
	return rlen;
}

int lib3g_write_file(const char *file, char *buf)
{
	return lib3g_write_file0(file, buf, 8192);
}


/************************************************************/
int lib3g_set_dns(const char * dns1, const char *dns2, FILE *fp)
{
   int f = 0;
   
   if (!fp ) {
      if ((fp = fopen(RESOLV_CONF_PATH, "w+"))) 
         f =1;
      else {
         perror("open err;");
         return -1;
      }
   }
   if (dns1 && dns1[0])
   	fprintf(fp, "nameserver %s\n", dns1);
   if (dns2 && dns2[0])
   	fprintf(fp, "nameserver %s\n", dns2);
   fprintf(fp, "domain Home\n");

   if ( f)
      fclose(fp);
   return 0;
}

extern char **environ;

static sigset_t signals_handled;
static sigjmp_buf  jmpbuf;
static struct sigaction sa, oldsa;
static volatile sig_atomic_t canjump;

static void sig_handle_sigterm(int sig)
{
	d_printf("receve SIGTERM\n");
	
	if (canjump) 
		siglongjmp(jmpbuf, sig);	
}

static void sig_set_kill_sub()
{
	canjump = 1;
	
	memset(&sa, 0, sizeof(sa));
	memset(&oldsa, 0, sizeof(oldsa));
	
	sigemptyset(&signals_handled);
	sigaddset(&signals_handled, SIGTERM);   
	sa.sa_mask = signals_handled;
	sa.sa_handler = sig_handle_sigterm;
	sigaction(SIGTERM, &sa, &oldsa);	
}

static void sig_restore_kill_sub()
{
	canjump = 0;

	memset(&sa, 0, sizeof(sa));
	memset(&oldsa, 0, sizeof(oldsa));	
}
	

int lib3g_system (char *command, int is_wait)
{
	int pid = 0, status = 0;


	if ( command == 0 )
		return 1;


	pid = fork();
	
	if ( pid == -1 )
		return -1;

	if ( pid == 0 ) {
		char *argv[4];
		argv[0] = "sh";
		argv[1] = "-c";
		argv[2] = command;
		argv[3] = 0;
		d_printf("app: %s\r\n", command);

		execve("/bin/sh", argv, environ);
		exit(127);
	}

	if (!is_wait)
		return pid;
	
	sig_set_kill_sub();

	if (sigsetjmp(jmpbuf, 1) == pid) {
		int i;
		
		d_printf("terminal %d\n", pid);
		kill(pid, SIGTERM);

		for (i = 0; i <= 60; i++) {
			if (kill(pid, 0) != 0)
				return 0;
			sleep(1);
		}
		kill(pid, SIGKILL);

		return 0;
	} 

	/* wait for child process return */
	do {
		if (waitpid(pid, &status, 0) == -1 ) {
			if ( errno != EINTR ) {
				sig_restore_kill_sub(pid);
				return -1;
			}
		} else {
			sig_restore_kill_sub(pid);
			return status;
		}
	} while ( 1 );

	sig_restore_kill_sub();	
	return status;
}

char lib3g_script_cmd[SCRIPT_CMD_SIZE+1] = {0};
int __lib3g_script_and_get_ret(char *script, char *buf, int len)
{
	FILE *fp = 0;
	int ret;
	char cmd[SCRIPT_CMD_SIZE+1] = {0};

	if (!script || strlen(script) > 
			(SCRIPT_CMD_SIZE - (strlen(" 2>/dev/null") + 10))) {
		printf_3g("", "script name too long or zero:%s\n", 
			script ? script : "NULL");
		return -1;
	}

	snprintf(cmd, SCRIPT_CMD_SIZE, "%s 2>/dev/null", script);
	if ((fp = popen(cmd, "r")) != NULL) {

		if (len > 0 && buf > 0) {
			ret = fread(buf, 1, len, fp);			
			pclose(fp);
			return ret;
		} else if (len == 0 || buf == 0) {
			pclose(fp);
			return 0;
		} else {
			d_perror("can not read");
			pclose(fp);
			return -1;
		}
	} else {
		d_perror("%s", cmd);
		return -1;
	}
}

int lib3g_script_and_get_ret(char *script, char *buf)
{
	return __lib3g_script_and_get_ret(script, buf, 8192);
}

void cmd_3g(const char *cmd, char *rbuf, int len)
{
		char buf[1024] = {0};
		
		snprintf(buf, MNGR_LEN(buf), 
			"3g-mngr  %s 2>/dev/null", 
			cmd);
		
		if ( rbuf && len > 0) {
			__lib3g_script_and_get_ret(buf, 
				rbuf, len);
		}
		else
			system(buf);
}

/**********************************************************/
int lib3g_file_copy(const char *f1, const char *f2)
{
	FILE *fp1 = 0;
	FILE *fp2 = 0;
	size_t s = 0;
	char *buf = 0;

	if (!f2 || !f1)
		return 0;

	if (strcmp(f1, f2) == 0)
		return 0;

	if ((fp1 = fopen(f1, "w")) == NULL)
		return -1;

	if ((fp2 = fopen(f2, "r")) == NULL) {
		fclose(fp1);
		return -1;
	}

	if ((buf = malloc(8192)) == NULL) {
		fclose(fp1);
		fclose(fp2);
		return -1;
	}

	memset(buf, 0, 8192);

	s = fread(buf, 1, 8192, fp2);
	if (s > 0)
		s = fwrite(buf, 1, s, fp1);

	free(buf);
	fclose(fp1);
	fclose(fp2);
	
	return s;
}

static void remove_delimitor( char *s)
{
   char *p1, *p2;

   p1 = p2 = s;
   while ( *p1 != '\0' || *(p1+1) != '\0') 
   {
      if (*p1 != '\0') 
      {
         *p2 = *p1;
         p2++;
      }
      p1++;
   }
   *p2='\0';
}

pid_t* lib3g_find_pid_by_name( char* pid_name)
{
	int i = 0;
	FILE *fp = 0;
	DIR *dir;	
	pid_t* pidList = 0;
	struct dirent *next;
	
	char buffer[READ_BUF_SIZE+1] = {0};
	char filename[READ_BUF_SIZE+1] = {0};	
	char name_buf[MNGR_LEN_CMD+1] = {0};

	strncpy(name_buf, pid_name, MNGR_LEN(name_buf));

	dir = opendir("/proc");
	if (!dir) {
		ERR("cfm:Cannot open /proc");
		return NULL;
	}

	while ((next = readdir(dir)) != NULL) {
		/* re-initialize buffers */
		memset(filename, 0, sizeof(filename));
		memset(buffer, 0, sizeof(buffer));  

		/* Must skip ".." since that is outside /proc */
		if (strcmp(next->d_name, "..") == 0)
			continue;

		/* If it isn't a number, we don't want it */
		if (!isdigit(next->d_name[0]))
			continue;

		/* sprintf(filename, "/proc/%s/status", next->d_name); */
		/* read /porc/<pid>/cmdline instead to get full cmd line */
		snprintf(filename, MNGR_LEN(filename), "/proc/%s/cmdline", 
			next->d_name);
		
		if (!(fp = fopen(filename, "r"))) {
			continue;
		}
		if (fgets(buffer, MNGR_LEN(buffer), fp) == 0) {
			fclose(fp);
			continue;
		}
		
		fclose(fp);

		/* Buffer should contain a string like "Name:   binary_name" */
		/*sscanf(buffer, "%*s %s", name);*/
		/* buffer contains full commandline params separted by '\0' */
		remove_delimitor(buffer);
		
		lib3g_strdelblank(buffer);
		lib3g_strdelblank(name_buf);

		if (strstr(buffer, name_buf) != 0) {
			pidList = realloc( pidList, sizeof(pid_t) * (i+2));
			if (!pidList) {
				ERR("find_pid_by_name: Out of memeory!\n");
				closedir(dir);
				return 0;
			}
			pidList[i++] = strtol(next->d_name, NULL, 0);
		}
	}
	closedir(dir);

	if (pidList)
		pidList[i] = 0;
	else if ( strcmp(pid_name, "init") == 0) {
		/* If we found nothing and they were trying to kill "init",
		* guess PID 1 and call it good...  Perhaps we should simply
		* exit if /proc isn't mounted, but this will do for now. */
		pidList = realloc( pidList, sizeof(pid_t));
		if (!pidList) {
			ERR("cfm: Out of memeory!\n");
			return NULL;
		}
		pidList[0] = 1;
	} else {
		pidList = realloc( pidList, sizeof(pid_t));
		if (!pidList) {
			ERR("Out of memeory!\n");
			return NULL;
		}
		pidList[0] = -1;
	}
	
	return pidList;
}

/*call chat script, when the script is success return 1,else return 0*/
int lib3g_run_script(const char *pragram, int infd, int outfd, int errfd)
{
	int status = -1;
	int pid;
	sigset_t sigset;
	
	sigemptyset(&sigset);
	sigaddset(&sigset, SIGCHLD);
	sigprocmask(SIG_BLOCK, &sigset, 0);
	
	pid = fork();
	if (pid < 0) {
		perror("Can not create sub process");
		return -1;
	}
	
	if (pid > 0) {
		sig_set_kill_sub(pid);
		
		d_printf("chat script proccess's pid=%d\n", pid); 
		while (waitpid(pid, &status, 0) < 0 && errno != ECHILD) {
			if (errno == EINTR)
				continue;
			ERR("error waiting for process: %d\n", pid);
		}

		if (errno == ECHILD)
			d_printf("No child processes\n");

		sigprocmask(SIG_UNBLOCK, &sigset, 0);

		sig_restore_kill_sub(pid);
		return (status == 0 ? 0 : -1);

	}

	/*sub proccess*/
	sigprocmask(SIG_UNBLOCK, &sigset, 0);
	
	/* make sure infd, outfd and errfd won't get tromped on below */
	if (infd == 1 || infd == 2)
		infd = dup(infd);
	if (outfd == 0 || outfd == 2)
		outfd = dup(outfd);
	if (errfd == 0 || errfd == 1)
		errfd = dup(errfd);

	/* dup the in, out, err fds to 0, 1, 2 */
	if (infd != 0)
		dup2(infd, 0);
	if (outfd != 1)
		dup2(outfd, 1);
	if (errfd != 2)
		dup2(errfd, 2);

	execl("/bin/sh", "sh", "-c", pragram, (char *)0);
	perror("could not exec /bin/sh");
	exit(99);	
	
}

void lib3g_get_kernel_ver(int *version, int *patchlevel, int *sublevel, 
			char *total_ver, int total_ver_len)
{
	char buf[128] = {0};
	char *p = 0;
	char *q = 0;

	if (lib3g_read_file("/proc/version", buf, 128 - 1) != 0) {
		d_printf("can not open /proc/version\n");
		return;
	}

	if (!buf[0])
		return;

	/*the format:
	* Linux version 2.6.30 (root@localhost.localdomain) \
	* (gcc version 4.4.2 (Buildroot 2010.02-git) ) #2 \
	* Thu Nov 11 06:24:16 CST 2010
	*
	* or:
	* Linux version 2.6.19 (root@localhost.localdomain) \
	* (gcc version 3.4.6-1.3.6) #331 \
	* Sun Jul 17 14:04:01 CST 2011
	*/
	  
	for (p = buf;  *p && !isdigit(*p); p++);

    if (!p)
        return;
    
	q = strchr(p, ' ');
	if (q) {
		*q = 0;
		q++;
	}
	if (total_ver)
		lib3g_strncpy(total_ver, total_ver_len, p, 0);

	q = strchr(p, '.');
	if (q) {
		*q = 0;
		q++;
	}
	
	if (version)
		*version = strtoul(p, 0, 10);

	p = q;
    if (!p)
        return;
	q = strchr(p, '.');
	if (q) {
		*q = 0;
		q++;
	}

	if (patchlevel)
		*patchlevel = strtoul(p, 0, 10);

	p = q;
    if (!p)
        return;
	q = strchr(p, ' ');
	if (q) {
		*q = 0;
		q++;
	}

	if (sublevel)
		*sublevel = strtoul(p, 0, 10);
}

void lib3g_install_modules()
{
	char version[80] = {0};

    //insmod conflict between 3g and voip, move it to bcm-base-driver.sh
#if 0
	lib3g_get_kernel_ver(0, 0, 0, version, 79);

    lib3g_fmt_script("insmod  /lib/modules/privat_module/cdc-wdm.ko 2>/dev/null");
	lib3g_fmt_script("insmod /lib/modules/privat_module/fg_ether.ko 2>/dev/null");
    lib3g_fmt_script("insmod  /lib/modules/privat_module/qmi_wwan.ko 2>/dev/null");
    //lib3g_fmt_script("insmod  /lib/modules/privat_module/cdc_ncm.ko 2>/dev/null");
	lib3g_fmt_script("insmod "
		"/lib/modules/%s/kernel/drivers/net/usb/cdc_ncm.ko "
		"2>/dev/null",
		version);

	lib3g_fmt_script("insmod "
		"/lib/modules/%s/kernel/drivers/usb/serial/usbserial.ko "
		"2>/dev/null",
		version);
	lib3g_fmt_script("insmod "MODULE_FILE " 2>/dev/null");
#endif
}

void lib3g_mkttynod(const char * name, char *dev_path, int *maj, int *min)
{
	char tty[80] = {0};
	char path[160] = {0};
	char buf[80] = {0};
	char *p_maj, *p_min;
	int major;
	int minor;
	int kernel_ver = 2;
	int kernel_patchlevel = 6;
	int kernel_sublevel = 30;
	FILE *fp;

	snprintf(tty, sizeof(tty), DEV_DIR"/%s", name);
	snprintf(path, sizeof(path), "rm -rf %s", tty);
	system(path);	

	/*get dev number from sysfs */
	lib3g_get_kernel_ver(&kernel_ver, &kernel_patchlevel, &kernel_sublevel, 
		0, 0);

#if 0
	if (kernel_sublevel <= 21)
		snprintf(path, sizeof(path),  USB_S_DEV_PATH"/%s/tty:%s/dev", 
			name, name);		
	else
		snprintf(path, sizeof(path), USB_S_DEV_PATH"/%s/tty/%s/dev", 
			name, name);
#else
	snprintf(path, sizeof(path), USB_S_DEV_PATH"/%s/dev", name);
#endif
	
	if ( (fp = fopen(path, "r")) == 0) {
		perror("open %s", path);
		return;
	}

	if (fgets(buf, sizeof(buf), fp) == 0) {
		printf_3g("", "can not read %s\n", path);
		fclose(fp);
		return;
	}
	fclose(fp);
	
	p_maj = buf;
	p_min = strchr(buf, ':');
    if (!p_min)
    {
        perror("strchr can not find :\n");
        fclose(fp);
        return;
    }
	*p_min = 0;
	p_min++;
	major = strtoul(p_maj, 0, 0);
	minor = strtoul(p_min, 0, 0);
	if (maj)
		*maj = major;
	if (min)
		*min = minor;
	if (dev_path)
		strcpy(dev_path, tty);
	
	if ( access(tty, F_OK) == 0) {
		strcpy(dev_path, tty);
		return;
	}
	
	snprintf(path, sizeof(path), 
		"mknod -m 777 %s c %d  %d", 
		tty, major, minor);
	d_printf("cmd:%s\n", path);
	system(path);
	return;	
	
}

char *lib3g_at_strerror(const char *err_raw_info, int *r_errorn)
{
	/*changr the error output to standar format*/
	struct __at_error {
		int number;
		char name[80];
	} ;
	
	static struct __at_error unspecial_err = {999, "unknown error"};
	static struct __at_error	at_error[] = 
	{
		{0, "phone failure"},
		{1, "no connection to phone"},
		{2, "phone-adaptor link reserved"},
		{3, "operation not allowed"},
		{4, "operation not supported"},
		{5, "PH-SIM PIN required"},
		{6, "PH-FSIM PIN required"},
		{7, "PH-FSIM PUK required"},
		{10, "SIM not inserted"},
		{11, "SIM PIN required"},
		{12, "SIM PUK required"},
		{13, "SIM failure"},
		{14, "SIM busy"},
		{15, "SIM wrong"},
		{16, "incorrect password"},
		{17, "SIM PIN2 required"},
		{18, "SIM PUK2 required"},
		{20, "memory full"},
		{21, "invalid index"},
		{22, "not found"},
		{23, "memory failure"},
		{24, "text string too long"},
		{25, "invalid characters in text string"},
		{26, "dial string too long"},
		{27, "invalid characters in dial string"},
		{30, "no network service"},
		{31, "network timeout"},
		{32, "network not allowed - emergency calls only"},
		{40, "network personalisation PIN required"},
		{41, "network personalisation PUK required"},
		{42, "network subset personalisation PIN required"},
		{43, "mnetwork subset personalisation PUK required"},
		{44, "service provider personalisation PIN required"},
		/*
		ETSI
		ETSI TS 100 916 V7.3.0 (1999-07) 90 (GSM 07.07 version 7.3.0 Release 1998)
		*/
		{45, "service provider personalisation PUK required"},
		{46, "corporate personalisation PIN required"},
		{47, "corporate personalisation PUK required"},
		{100, "unknown"},
		{103, "Illegal MS (#3)"},
		{106, "Illegal ME (#6)"},
		{107, "GPRS services not allowed (#7)"},
		{111, "PLMN not allowed (#11)"},
		{112, "Location area not allowed (#12)"},
		{113, "Roaming not allowed in this location area (#13)"},
		/*
		(Values in parentheses are GSM 04.08 cause codes.)
		ETSI
		ETSI TS 100 916 V7.3.0 (1999-07) 91 (GSM 07.07 version 7.3.0 Release 1998)
		9.2.2.2 Errors related to a failure to Activate a Context
		Numeric Text
		*/
		{132, "service option not supported (#32)"},
		{133, "requested service option not subscribed (#33)"},
		{134, "service option temporarily out of order (#34)"},
		{149, "PDP authentication failure"},
		/*
		(Values in parentheses are GSM 04.08 cause codes.)
		9.2.2.3 Other GPRS errors
		Numeric Text
		*/
		{150, "invalid mobile class"},
		{148, "unspecified GPRS error"},
	};

	char errstr1[80] = {0};
	char errstr2[80] = {0};
	char *p = 0;
	char *ret_str= 0;
	int ret = -1;
	int err_no = 0;
	int i = 0;

	if (!err_raw_info)
		goto end;
		

	strncpy(errstr1, err_raw_info, sizeof(errstr1) - 1);
	
	if ((p = strstr(errstr1, "ERROR:"))) {
		p = strchr(p, ':');
		p++;
	} else
		p = errstr1;

	err_no  = strtoul(p, 0, 10);

	if (err_no != 0) {
		for (; i < sizeof(at_error)/sizeof(at_error[0]); i++) {
			if (err_no == at_error[i].number) {
				ret = err_no;
				ret_str = at_error[i].name;		
				goto end;
			}
		}
		ret = unspecial_err.number;
		ret_str = unspecial_err.name;
		goto end;
	}

	/*the result is string*/
	strcpy(errstr1, p);
	lib3g_strdelblank(errstr1);
	lib3g_strl2u(errstr1);
	lib3g_strdelCR(errstr1);
	
	for (; i < sizeof(at_error)/sizeof(at_error[0]); i++) {
		strcpy(errstr2, at_error[i].name);		
		lib3g_strdelblank(errstr2);
		lib3g_strl2u(errstr2);
		lib3g_strdelCR(errstr2);

		if (strcmp(errstr2, errstr1) == 0) {
			ret = at_error[i].number;
			ret_str = at_error[i].name;
			goto end;
		}		
	}

	ret = unspecial_err.number;
	ret_str = unspecial_err.name;	

	
end:
	if (r_errorn)
		*r_errorn = ret;
	
	return 	ret_str;
}

wan_status_t	lib3g_change_wan_status(void *special_status, int solusion)
{
	int i, num;
	struct  linkStatusMap {
		wan_status_t status;
		char *specialStatus;
	}  linkStatusMap[] = 
	{
		{WAN_S_DISCONNECTED,  "Disconnected"},
		{WAN_S_CONNECTED,	"Connected"},
		{WAN_S_CONNECTING, "Connecting"},
		{WAN_S_DISCONNECTING, "Disconnecting"},
	};

	num = sizeof(linkStatusMap)/sizeof(linkStatusMap[0]);

	for (i = 0; i < num; i++) {
		if (strcmp(linkStatusMap[i].specialStatus, (char *)special_status) == 
				0) {
			return linkStatusMap[i].status;
		}
	}

	return WAN_S_INVALID;	
}


void lib3g_change_string(struct dec_map *map, int isEncode, char *content)
{
        char *to = 0;
        char *from = 0;
        int fromlen = 0;
        int tolen = 0;
        int deltlen = 0;
        int v_deltlen = 0;
        int len = 0;
        int i = 0;
        int j = 0;
        int m =0;
        int step = 1;

        for (i = 0; content && content[i];)
        {
                step = 1;
                for (j = 0; map[j].org[0]; j++)
                {
                        to = isEncode?map[j].code : map[j].org;
                        from = isEncode?map[j].org : map[j].code;
                        fromlen = strlen(from);
                        tolen = strlen(to);
                        deltlen = fromlen - tolen;

                        if (strncmp(from, content+i, fromlen) == 0)
                        {
                                if (deltlen > 0)
                                {
						/*shift direct <--, from 'i+fromlen',
						*shitf deltlen positions 
						*/
                                        for (m = 0; 
							content[i + fromlen + m]; 
							m++)
                                        {
                                                content[i + deltlen+m] = 
								content[i + fromlen + m];
                                        }
                                        content[i + deltlen+m +1] = 0;
                                }
                                else if (deltlen < 0)
                                {
                                		/*shift direct -->, form 'i+fromlen', 
                                		* all the charictor shift 'deltlen' 
                                		*position 
                                		*/
                                        len = strlen(content+i);
                                        v_deltlen = -deltlen;
                                        for (m = len; m >= fromlen; m--)
                                        {
                                                content[i + m + v_deltlen] = 
								content[i + m];
                                        }
                                }

                                for (m = 0; m < tolen; m++)
                                        content[i + m] = to[m];

                                step = tolen;
                                break;
                        }
                }
                i += step;
        }
}

/*
* scb+ 2012-2-22
* check the given network interface if is the default gate way.
*/
int lib3g_is_def_gw(const char *ifname)
{
	  char *p = 0;
	  char route_entry[80] = {0};
	  int def_gw_ok = -1;
	  FILE *fp = 0;

	  d_printf("enter\n");
	  if (ifname && ifname[0] && (fp = fopen("/proc/net/route" , "r")) != NULL) 
	  {
	  		d_printf("Check %s if is the gw\n", ifname);
			while((memset(route_entry, 0, sizeof(route_entry)), 
					fgets(route_entry, sizeof(route_entry)-1, fp)) )
			{
				d_printf("Entery:%s\n", route_entry);
				if(!strncmp(route_entry, ifname,
						strlen(ifname)))
				{
					/*
					* the format is:
					* eth1    00000000        011010AC        0003    0       0       0       00000000        0       0       0 
					*/
					d_printf("Get Entry:%s\n", route_entry);
					p = route_entry + strlen(ifname);
					d_printf("Entery:[%s]\n", p);

					/*delete the blank*/
					for (;*p && (*p == ' ' || *p == '\t'); p++);
					d_printf("Entery:[%s]\n", p);
					if (*p && !strncmp(p, "00000000", strlen("00000000")))
						def_gw_ok = 1;
					else
						def_gw_ok = 0;
				}
			}
			fclose(fp);
	  }

	  return def_gw_ok;
}

time_t my_time(time_t *t)
{
    /*
    FILE *fp = NULL;
    char buf[128] = {0};
    char *endpos = NULL;
    unsigned int uptime = 0;
    
    if((fp = popen("cat /proc/uptime 2>/dev/null", "r")) != NULL)
    {
        if (fread(buf, 1, 128, fp) > 0)
        {
            if ((endpos = strchr(buf, '.')) != NULL)
            {
                *endpos = '\0';
            }
            uptime = (unsigned int)strtoul(buf, NULL, 10);
        }

        pclose(fp);
    }
    
    *t = (time_t)uptime;

    printf("get uptime=%d\n", uptime);
    */
    struct sysinfo info;

    if (sysinfo(&info) < 0)
    {
        printf("%s:sysinfo error, errno = %d\n", __func__, errno);
    }
    if(t){*t = (time_t)info.uptime;}
    
    return ((time_t)info.uptime);
}


