#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <limits.h>
#include <stdlib.h>
#include <sys/un.h>
#include <sys/param.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include "3g-lib.h"

int lib3g_send_mobile_msg(const char *path, const char *msg)
{
	int len = 0;
	int bytes = 0;

	len = strlen(msg);

	bytes = cdmg_send_unix_msg(path, SOCK_DGRAM, msg, len);

	if (bytes > 0)
		d_printf("send[%s] to socket %s\n", msg, path);

	return bytes;
}

int lib3g_send_mobile_chage_msg(const char *msg)
{
	int bytes = 0;
	
	d_printf("Send msg to ssk:[%s]\n", msg);
	bytes = lib3g_send_mobile_msg(MSG_UNIX_SEND_PATH, msg);
	if (bytes <= 0) {
		d_printf("can not send msg:[%s]\n", msg);
	}
	return bytes;
}

#ifdef LTE_CS_CALL
int lib3g_send_voip_echo_msg(const char *msg)
{
    char *voip_token_arr[] = {
        "RING",
        "CALLER:",
        "CHUP",
        "END",
        //"OK",
        "CALL CONNECT",
        "+CLCC:"
    };

	int bytes = 0;
    int count = sizeof(voip_token_arr)/sizeof(char *);
    int found = 0;
    int i;

    for (i = 0; i < count; i++)
    {
        if ((strstr(msg, voip_token_arr[i]) != NULL) &&
             (strlen(msg) < 1024))
        {
            found = 1;
            break;
        }
    }
    if (0 == strcmp(msg,"\n\nOK\n\n") || 0 == strcmp(msg,"OK\n"))
    {
        found = 1;
    }
    if (!found)
        return 0;
    
	d_printf("Send msg to voip:%s\n", msg);
	bytes = lib3g_send_mobile_msg(MSG_UNIX_REPORT_PATH, msg);
	if (bytes <= 0) {
		d_printf("can not send msg:[%s]\n", msg);
	}
	return bytes;
}
#endif
void lib3g_msg_process_loop(const char *unix_sok_path, 
		int usleep_v, const char *token, 
		void (*handler)(char *msg), 
		struct timeval * (*timeout_func)(void))
{
	/*call the cdmg lib's function*/
	cdmg_msg_process_loop(unix_sok_path, usleep_v, token, 
			handler, timeout_func);
}	

/*init a socket*/
int 	lib3g_init_mobile_msg_recever_socket(const char *path)
{
	return cdmg_create_unix_socket(path, SOCK_DGRAM);
}

/*
** This function is used by the external pragram to
** learn some infomation about the daemon
**
*/
int lib3g_get_modem_info(struct modem_3g_info *info)
{
	struct modem_3g_info *p_info = NULL;
	char *rbuf = NULL;
    struct timeval tv = {0,0};
	
	if (!info)
		return -1;

	/*Can not run at daemon*/
	if (cdmg_is_on_daemon()) {
		d_printf("this func can not run at daemon\n");
		return -1;
	}

	tv.tv_sec = 6;
	tv.tv_usec = 0;

	/*getmodeminfo defined at 3g-mngr-msg.c*/
	if (CDMG_SEND_AND_GET(rbuf, 5000000, getmodeminfo,
			"%s", "") <= 0 ||  !rbuf)
	{
			d_printf("can not rcvd content from diald\n");
			return -1;
	};

	p_info = (struct modem_3g_info *)rbuf;

	/*check the magic is right or not*/
	if (p_info->magic[0] != 'a' || p_info->magic[1] != 'b' ||
		p_info->magic[2] != 'c') {
			d_printf("the msg from diald is error\n");
			free(rbuf);
			return -1;
	}
	
	memcpy(info, p_info, sizeof(struct modem_3g_info));

	/*p_info is malloc at cdmg_send_and_get()*/
	free(rbuf);

	return 0;
}
