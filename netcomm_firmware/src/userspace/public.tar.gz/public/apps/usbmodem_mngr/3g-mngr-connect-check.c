/**********************************************************************

 Copyright (c), 1991-2011, T&W ELECTRONICS(SHENTHEN) Co., Ltd.

filename: 3g-mngr-connect-check.c

note	: Create by shen chang ban      
              
**********************************************************************/
#ifdef SUPPORT_IP_CONNECT_CHECK
#include <setjmp.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_arp.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <errno.h>

#include "3g-mngr-include.h"

#define PING_CHECKING_UNIX_SOCKET_PATH WORK_PATH"unix_socket_3g_ping_checking"
#define PING_RESULT_SUCCESS_TOKEN "1 packets transmitted, 1 packets received, 0% packet loss"
#define PING_STATUS_SUCCESS "pingsuccess"
#define PING_STATUS_FAIL "pingfail"

typedef struct{
	pid_t ping_pid;	
} __conn_mngr_t;

int conn_mngr_init(conn_mngr_t *cnn)
{	
	SUB_INIT(cnn, conn_mngr_t, __conn_mngr_t);
	return 0;	
}

conn_mngr_t *conn_mngr_new(void *mn)
{
	conn_mngr_t *cnn;

	if ((cnn = ALLOC_3G(conn_mngr_t, __conn_mngr_t)) <= 0)
		return 0;

	MN_SET(cnn, mn);

	conn_mngr_init(cnn);

	return cnn;
}

int conn_mngr_free(conn_mngr_t *cnn)
{
	if (!cnn)
		return 0;
	
	if (MN(cnn))
		MN(cnn)->cnn = 0;

	free(cnn);
	cnn = 0;
	return 0;
}

/***************************************************
function: do checking
args	: 
return:none
note: 
**************************************************/	
/*this function is run on sub task*/
static void conn_mngr_ping_check(conn_mngr_t *cnn)
{
	int ret = 0;
	
	d_printf("enter,check for:[%s]\n", 
		cnn->check_type == 0 ? "CHECK_TYPE_INVALID" : 
		cnn->check_type == 1 ? "CHECK_TYPE_SUCCESS":"CHECK_TYPE_FAIL");

	/*running untill the user kill me*/
	while (1) {
		d_printf("Start connection check for %s by %s %s ...\n", 
			cnn->ipaddr, cnn->intf, 		
			cnn->check_type == 0 ? "" : 
			cnn->check_type == 1 ? "for sucess":"for fail");

		/*running ping command*/
		ret = CDMG_DO_FUNC(ping, 
			"--timeout=%d --times=%d"
			" --period=%d --intf=%s --addr=%s --nexthop=%s ",
			cnn->timeout, cnn->tolerance, 
			cnn->period, cnn->intf, cnn->ipaddr,cnn->nexthop);

		/*do something according the ping result*/
		if (ret == 0) {
			d_printf("ping success\n");
			if (cnn->check_type == CHECK_TYPE_INVALID || 
					cnn->check_type == CHECK_TYPE_SUCCESS)
				lib3g_send_mobile_msg(MSG_UNIX_DAEMON_PATH, 
					IP_CONN_CHECK_MSG" -1");
			/*If OK, ping return right now, so  needs sleep here*/
			sleep(cnn->period);
		} else {
			d_printf("ping fail\n");
			if (cnn->check_type == CHECK_TYPE_INVALID || 
					cnn->check_type == CHECK_TYPE_FAIL)
				lib3g_send_mobile_msg(MSG_UNIX_DAEMON_PATH,
					IP_CONN_CHECK_MSG" -0");
			/*If ret == -1, do not need to sleep,pls see  FUNC(ping)*/
			if (ret == -2)
				sleep(cnn->period);
		}
	}
}

void conn_mngr_set(conn_mngr_t *cnn)
{
	__conn_mngr_t *__cnn = 0;

	d_printf("enter\n");
    
    if (!cnn)
    {
        printf_3g("", "at is null\n");
        return;
    }

	if (cnn->enable == 0)
		return;

	__cnn = GET_PRI(cnn, __conn_mngr_t);

	if (__cnn->ping_pid > 0) {
		if (kill(__cnn->ping_pid, SIGKILL/*SIGTERM*/) == 0) 
			d_printf("ping task %d exist kill it\n", __cnn->ping_pid);
	}

	if (!wan_mngr_cond_check(
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK|
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_3G_CONN_EXIST)) {
		d_printf("3g not valid\n");
		return;	
	}
	
	if ((__cnn->ping_pid = fork_3g()) > 0) {
		d_printf("create task %d to checking\n", __cnn->ping_pid );
		return;
	} else if (__cnn->ping_pid < 0) {
		d_printf("can not create task to checking\n");
		return;
	}

	/*sub task*/
	setsid();
	pin_mngr_free(MN(cnn)->pin);
	dial_mngr_free(MN(cnn)->dial);
	switch_mngr_free(MN(cnn)->sw);
	at_free(MN(cnn)->at);
	modem_free(MN(cnn)->mdm);	

	conn_mngr_ping_check(cnn);
	exit(0);
}

int conn_mngr_is_start(conn_mngr_t *cnn)
{
	__conn_mngr_t *__cnn = 0;
	
	__cnn = GET_PRI(cnn, __conn_mngr_t);
	if (__cnn->ping_pid > 0)
		return 1;
	else
		return 0;		
}

void conn_mngr_cancel(conn_mngr_t *cnn)
{
	__conn_mngr_t *__cnn;

	__cnn = GET_PRI(cnn, __conn_mngr_t );
	
	if (__cnn->ping_pid > 0)
    {
		kill(__cnn->ping_pid, SIGKILL/*SIGTERM*/);
    }

	__cnn->ping_pid = -1;
}

FUNC(ipconn, "ip connecting checking function\n"
			   "example1: 3g-mngr ipconn -s --action=start --chtype=success|fail"
			   " --intf=ppp0 --addr=80.58.61.250 --period=10\n"
			   "\t\t --timeout=10 --Tolerance=3 --nexthop = 10.10.10.1\n"
			   "example2: 3g-mngr ipconn -s --action=stop\n")
{
	int tl = 0;
	int to = 0;	
	int period = 0;	
	
	char __period[12] = {0};
	char __to[12] = {0};
	char __tl[12] = {0};
	char __action[12] = {0};
	char __ipaddr[32] = {0};
	char __intf[32] = {0};
	char __chtype[12] = {0};
	char __nexthop[CDMG_IPV4_ADDR_LEN] = {0};

	if (CDMG_FORK(0, 0, 0) == CDMG_ENV_USER_SENT)
		return 0;

	mngr_start(&mn, MNGR_START_CREATE_CNN);

	if (!mn->run_on_diald)
		printf_3g("", "This function must run in diald ,"
			"please add -s option when start\n");	

	MNGR_GET_ARG("action", __action);

	if (strcmp(__action, "stop") == 0) {
		d_printf("stop ip ping\n");
		mn->cnn->enable = 0;
		conn_mngr_cancel(mn->cnn);
		return 0;
	}

	MNGR_GET_ARG("period", __period);
	MNGR_GET_ARG("timeout", __to);
	MNGR_GET_ARG("Tolerance", __tl);
	MNGR_GET_ARG("intf", __intf);
	MNGR_GET_ARG("addr", __ipaddr);
	MNGR_GET_ARG("chtype", __chtype);
	MNGR_GET_ARG("nexthop", __nexthop);

	if (__period[0]) {
		period = strtoul(__period, 0, 10);
		mn->cnn->period = period;
	}
	if (__to[0]) {
		to = strtoul(__to, 0, 10);
		mn->cnn->timeout = to;
	}
	if (__tl[0]) {
		tl = strtoul(__tl, 0, 10);
		mn->cnn->tolerance = tl;
	}
	if (__intf[0]) {
		strcpy(mn->cnn->intf, __intf);
	}
    if (__nexthop[0]) {
		strcpy(mn->cnn->nexthop, __nexthop);
	}
	
	if (__ipaddr[0]) {
		strcpy(mn->cnn->ipaddr, __ipaddr);
	}
	if (__chtype[0]) {
		if (strcmp(__chtype, "success") == 0)
			mn->cnn->check_type = CHECK_TYPE_SUCCESS;
		else
			mn->cnn->check_type = CHECK_TYPE_FAIL;
	}

	mn->cnn->enable = 1;

	d_printf("try to start ip ping\n");
	conn_mngr_set(mn->cnn);
	
	return 0;
}




/*
*********************************************************
*														*
*		The folowing  is an implement of ping tools			*
*
*													       *
*********************************************************
*/
#define UL_MAX (~0UL)

#define PING_DATE_LEN 56
#define ICMP_MINLEN 8
#define MAXIPLEN 60
#define MAXICMPLEN  76
#define MAXPACKET  65468
#define	MAX_DUP_CHK	(8 * 128)
#define  MAX_DUP_CHK	(8 * 128)
#define  MAXWAIT  10
#define  PINGINTERVAL  1


#define O_QUIET         (1 << 0)
#define O_LOG           2
#define PING_PID_FILE   "/var/pingPid"
#define	A(bit)		rcvd_tbl[(bit)>>3]	/* identify byte in array */
#define	B(bit)		(1 << ((bit) & 0x07))	/* identify bit in byte */
#define	SET(bit)	(A(bit) |= B(bit))
#define	CLR(bit)	(A(bit) &= (~B(bit)))
#define	TST(bit)	(A(bit) & B(bit))
#define PING_IN_PROGRESS  0
#define PING_FINISHED      1
#define PING_ERROR        2  /* ping process exits on error */
#define PING_UNKNOWN_HOST 3  /* ping unable to resolve host name */

static int verbo = 0;
static long ntransmitted = 0, nreceived = 0, nrepeats = 0;
static unsigned long tmin = UL_MAX, tmax = 0, tsum = 0;
static char rcvd_tbl[MAX_DUP_CHK / 8];

/*macro for printing the ping result*/
#define verbo_printf(args...)	\
	do {	\
		if (is_debug() || verbo)	\
			printf(args);	\
	}while(0)


/***************************************************
function: calculate the check sum of the icmp package
args	: 
return:
note: 
**************************************************/	
static int in_cksum(unsigned short *buf, int sz)
{
	int nleft = sz;
	int sum = 0;
	unsigned short *w = buf;
	unsigned short ans = 0;

	while (nleft > 1) {
		sum += *w++;
		nleft -= 2;
	}

	if (nleft == 1) {
		*(unsigned char *) (&ans) = *(unsigned char *) w;
		sum += ans;
	}

	sum = (sum >> 16) + (sum & 0xFFFF);
	sum += (sum >> 16);
	ans = ~sum;
	return (ans);
}

/*
* scb+ 2012-5-18
*
* there 2 ping methods.
* the first can not work at MER interface.
*
* the second not through the IP layer of the kernel,
* so the iptable rule can not drop the ping package.
* this  will result in more difficut for test,
* so if need test the ping check function, we can use the first one.
*/
#if 0
static int myid = 0;

/*************************************************************************
function: create an raw socket whitch is used for sending icmp package

args	:     

return:

note: 
**************************************************************************/		
static int create_icmp_socket(const char *intf)
{	
	int sock;
	int sockopt;
	struct protoent *proto;

	proto = getprotobyname("icmp");
	/* if getprotobyname failed, just silently force
	 * proto->p_proto to have the correct value for "icmp" */
	if ((sock = socket(AF_INET, SOCK_RAW,
			(proto ? proto->p_proto : 1))) < 0) {/* 1 == ICMP */
		if (errno == EPERM)
			printf_3g("", "Not allow to create socket\n");
		else
			d_perror("Create icmp socket:");

		return -1;
	}

	/*bind the socket to an interface, then
	  * let the package output from that inteface,ignore the defauklt
	  *gate way
	  */
	if (intf && intf[0]) {
		if (setsockopt	(sock, SOL_SOCKET, SO_BINDTODEVICE, intf,
			 	strlen(intf) + 1) == -1) {
			d_perror("Bind interface:");
			return -1;
		}
	}

	/* drop root privs if running setuid */
	setuid(getuid());

	/* enable broadcast pings */
	sockopt = 1;
	setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *) &sockopt,
			   sizeof(sockopt));

	/* set recv buf for broadcast pings */
	sockopt = 48 * 1024;
	setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char *) &sockopt,
			   sizeof(sockopt));

	return sock;
}

/***************************************************
function: send an icmp package
args	: sock ---the send socket 
	pingaddr---the dst address
return:
note: 
**************************************************/	
static int  sendping(int sock, struct sockaddr_in *pingaddr)
{
	int i;
	struct icmp *pkt;	
	char packet[PING_DATE_LEN + 8];

	pkt = (struct icmp *) packet;

	/*set value of the icmp pakage*/
	pkt->icmp_type = ICMP_ECHO;
	pkt->icmp_code = 0;
	pkt->icmp_cksum = 0;
	pkt->icmp_seq = ntransmitted++;
	pkt->icmp_id = myid;
	CLR(pkt->icmp_seq % MAX_DUP_CHK);

	/*set the seding time*/
	gettimeofday((struct timeval *) &packet[8], NULL);
	/*calulate the check sum*/
	pkt->icmp_cksum = in_cksum((unsigned short *) pkt, sizeof(packet));

	/*send the package*/
	i = sendto(sock, packet, sizeof(packet), 0,
			   (struct sockaddr *)pingaddr, sizeof(struct sockaddr_in));
	
	/*proccess the result*/
	if (i > 0) {
		d_printf("send %d byte(s)\n", i);
		return 0;
	} else {
		d_perror("sendto");
		return -1;
	}
	
}

/***************************************************
function: check the received package is right or not
args	: 
return:OK return 0, error return -1
note: 
**************************************************/	
static int check_result(char *buf, int sz, struct sockaddr_in *from)
{
	struct icmp *icmppkt;
	struct iphdr *iphdr;
	struct timeval tv, *tp;
	int hlen, dupflag;
	unsigned long triptime;

	gettimeofday(&tv, NULL);

	/* check IP header */
	iphdr = (struct iphdr *) buf;
	hlen = iphdr->ihl << 2;
	/* discard if too short */
	if (sz < (PING_DATE_LEN + ICMP_MINLEN))	
		return -1;

	sz -= hlen;
	icmppkt = (struct icmp *) (buf + hlen);

	/*check the id*/
	if (icmppkt->icmp_id != myid)
	    return -1;/* not our ping */

	/*the package type is reply*/
	if (icmppkt->icmp_type == ICMP_ECHOREPLY) {
	    ++nreceived;
		tp = (struct timeval *) icmppkt->icmp_data;

		if ((tv.tv_usec -= tp->tv_usec) < 0) {
			--tv.tv_sec;
			tv.tv_usec += 1000000;
		}
		tv.tv_sec -= tp->tv_sec;

		triptime = tv.tv_sec * 10000 + (tv.tv_usec / 100);
		tsum += triptime;
		if (triptime < tmin)
			tmin = triptime;
		if (triptime > tmax)
			tmax = triptime;

		if (TST(icmppkt->icmp_seq % MAX_DUP_CHK)) {
			++nrepeats;
			--nreceived;
			dupflag = 1;
		} else {
			SET(icmppkt->icmp_seq % MAX_DUP_CHK);
			dupflag = 0;
		}

		/*print the result*/
		verbo_printf("%d data bytes from %s: icmp_seq=%u", (sz-ICMP_MINLEN),
			inet_ntoa(*(struct in_addr *) &from->sin_addr.s_addr),
			icmppkt->icmp_seq);
		verbo_printf(" ttl=%d", iphdr->ttl);
		verbo_printf(" time=%lu.%lu ms", triptime / 10, triptime % 10);
		if (dupflag)
			printf(" (DUP!)");
		verbo_printf("\n");
		
		return 0;
	}
	
	d_printf("Warning: Got ICMP %d ", icmppkt->icmp_type);
	return -1;
}

/***************************************************
function: the interface function
args	: 
return:0 OK, -1 ping fail, -2 other fial not start ping
note: 
**************************************************/	
FUNC(ping, "Ping tools for checking nenection is OK or not.\n"  
			"\temax: 3g-mngr ping --addr=xx "
			"[--timeout=x --times=x --period=x --intf=xx --nexthop=x  -v]\n")
{
	int timeout = 1;
	int times = 3;
	int period = 1;
	int sock = 0;
	int delt_t, nsleep, i;
	time_t t0 = 0, t1 = 0;
	char str_verbo[4] = {0};
	char str_timeout[4] = {0};
	char str_times[4] = {0};
	char str_period[4] = {0};
	char str_addr[32] = {0};
	char str_intf[32] = {0};
	char str_nexthop[CDMG_IPV4_ADDR_LEN] = {0};
	char packet[PING_DATE_LEN + 8];
	struct sockaddr_in pingaddr = {0};
	
	/*get addrees from the command line*/
	if (MNGR_GET_ARG("addr", str_addr) <= 0) {
		printf("No address\n");
		return -2;
	}
	
	/*check the address*/
	if (inet_pton(AF_INET, str_addr, (void  *)&pingaddr.sin_addr ) != 1) {
		printf("Addr Error\n");
		return -2;
	}
	pingaddr.sin_family = AF_INET;

	/*get check parameter*/
	MNGR_GET_ARG("timeout", str_timeout);
	MNGR_GET_ARG("times", str_times);
	MNGR_GET_ARG("period", str_period);
	MNGR_GET_ARG("intf", str_intf);
	MNGR_GET_ARG("nexthop", str_nexthop);

	if (MNGR_GET_ARG("v", str_verbo))
		verbo = 1;

	d_printf("[ping]: addr=%s, to=%s,times=%s,period=%s,intf=%s,nexthop=%s\n",
		str_addr, str_timeout, str_times, str_period, str_intf,str_nexthop);

	/*create socket*/
	sock = create_icmp_socket(str_intf);
	if (sock == -1) {
		printf("Can not create  socket");
		return -2;
	}

	/*modify some check parameter*/
	if (str_timeout[0]) {
		timeout 	= strtoul(str_timeout, 0, 10);
		timeout   = timeout <= 0 ?  1 : timeout; 
	}
	if (str_times[0]) {
		times    	= strtoul(str_times, 0, 10);
		times	= times <= 0 ? 1 : times;
	}
	if (str_period[0]) {
		period	= strtoul(str_period, 0, 10);
		period	= period <= 0 ? 1: period;
	}
	
	/*icmp package id*/
	myid = getpid() & 0xFFFF;

	/*scb+ 2011-11-19 only for test, need to change another method*/
	if(str_intf != NULL && strstr(str_intf,"ppp")==NULL)
	{
		lib3g_fmt_script ("route add -net %s netmask 255.255.255.255 "
			"dev %s gw %s 2>/dev/null 1>&2",
			str_addr,str_intf,str_nexthop);
	}
	
	/*start to do checking*/
	for (i = 0; i < times; i++) {
		int ret = 0;
		fd_set  fdreads;
		struct timeval to;

		t0 = time(0);
		verbo_printf("Start at:%d for No.%d\n", (int)t0, i);

		/*send ping*/
		if (sendping(sock, &pingaddr) < 0) {
			d_printf("Send error\n");
			goto do_again;/*error, do the second check*/
		}

		memset(&to, 0, sizeof(to));	
		to.tv_sec = timeout;
		to.tv_usec = 0;
		
		memset(&fdreads, 0, sizeof(fdreads));
		FD_SET(sock, &fdreads);

		/*wait for receiving package*/
		ret = select(sock + 1, &fdreads, 0, 0, &to);
		if (ret == 0) {
			d_printf("time out\n");
			goto do_again;
		}
		if (ret < 0) {
			perror("select:");
			goto do_again;
		}
		if (!FD_ISSET(sock, &fdreads)) {
			printf("Error\n");
			goto do_again;
		}

		/*read*/
		struct sockaddr_in from;
		socklen_t fromlen = (socklen_t) sizeof(from);
		int needread = 1;
		int c;
		
		while (1) {
			if ((c = recvfrom(sock, packet, sizeof(packet), 0,
						(struct sockaddr *) &from, &fromlen)) < 0) {
				if (errno == EINTR)
					continue;
				
				d_printf("No content\n");
				needread = 0;
				break;
			}
			break;
		}

		if (!needread)
			goto do_again;

		/*check the result*/
		if (check_result(packet, c, &from) == 0) {	
			if (!mn || !mn->run_on_diald)
				printf("OK at  No.%d time\n", i);
			close(sock);

			/*scb+ 2011-11-19 only for test, need to change another method*/
			if(str_intf != NULL && strstr(str_intf,"ppp")==NULL)
			{
				lib3g_fmt_script("route delete -net %s netmask 255.255.255.255 "
					"dev %s gw %s 2>/dev/null 1>&2",
					str_addr,str_intf,str_nexthop);
			}
			
			return 0;
		}
		
do_again:
		t1 = time(0);
		delt_t = t1 >= t0 ? t1 - t0 : ((UL_MAX - t0) + t1);
		nsleep = period >= delt_t ? period - delt_t : 0;

		verbo_printf("End at %d, pass:%d, need to sleep:%d\n",
			(int)t1, (int)delt_t, nsleep);

		/*sleep some time, then do again*/
		if (nsleep)
			sleep(nsleep);
	}

	if (!mn || !mn->run_on_diald)
		printf("Fail try %d time(s)\n", times);
	close(sock);

	/*scb+ 2011-11-19 only for test, need to change another method*/
	if(str_intf != NULL && strstr(str_intf,"ppp")==NULL)
	{
		lib3g_fmt_script("route delete -net %s netmask 255.255.255.255 dev %s"
			" gw %s 2>/dev/null 1>&2",
			str_addr,str_intf,str_nexthop);
	}
	
	return -1;	
}

#else

/*
* scb+ 2012-5-17.
* the following codes to implement the ping function for supportting ethnet.
*
* if point out interface, and the interface is not the default gateway.
* the old ping can not handler,because it can not get the right MAC addr
* of the next hop.
*/
typedef enum{
	PING_S_INIT = 0,
	PING_S_NEED_ARP,
	PING_S_SEND_ARP,
	PING_S_ARP_OK,
	PING_S_SEND_ICMP,
	PING_S_ICMP_OK,
	PING_S_ERROR,
} ping_net_s_t;

struct net_param {	
	char 		ifname[32];
	int 		ifindex;
	uint16_t	haddr_type;
	uint8_t		shaddr[6];
	uint8_t		thaddr[6];

	in_addr_t 	ip_saddr;/*bigendian*/
	in_addr_t	ip_daddr;/*bigendian*/
	in_addr_t	ip_nhop;/*bigendian*/

	uint16_t	ip_id;
	
	uint16_t	echo_seq;
	uint16_t	echo_id;
	
	int 		sock;

	unsigned long timeout;
	
	ping_net_s_t status;
	int	 r_len;
	char buf[128];
};
static struct net_param  s_net_param;

/*get current time*/
static char *curr_time()
{
	struct timeval	val;
	static char timestr[32];

	memset(&val, 0, sizeof(val));
	gettimeofday(&val, NULL);

	snprintf(timestr, sizeof(timestr), 
		"%d.%d", (int)val.tv_sec, (int)val.tv_usec);
	return timestr;
}

/*change the ip and mac address to string*/
static char *ping_mac_str(in_addr_t ip, uint8_t *mac)
{
	static char buf[32] = {0};
	char *p = 0;

	memset(buf, 0, sizeof(buf));
	if (ip != 0) {
		inet_ntop(AF_INET, (void *)&ip, buf, sizeof(buf));
		strcat(buf, "-");
	}
	p = buf + strlen(buf);
	snprintf(p, sizeof(buf)-strlen(buf),
		"%02x:%02x:%02x:%02x:%02x:%02x",
		mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	return buf;
}

/*
* create a package sockete the send the arp
*/
static int ping_net_init(const char *ifn, 
				in_addr_t daddr,/*bigend*/
				in_addr_t nhop, /*bigend*/
				int timeout)
{
	int sock = 0, sockopt = 0;
	struct ifreq ifr;	
	struct arpreq arp_r;
	struct sockaddr_ll sll;
	struct sockaddr_in *ip_addr = 0;

	memset(&s_net_param, 0, sizeof(s_net_param));

	/*set daddr and nhop addr*/
	s_net_param.ip_daddr 	= daddr;
	if (nhop)
		s_net_param.ip_nhop	= nhop;
	else
		s_net_param.ip_nhop	= daddr;
	s_net_param.timeout = timeout;	
	strncpy(s_net_param.ifname, ifn, sizeof(s_net_param.ifname)-1);
	
	/*create socket*/
	if ((sock = socket(PF_PACKET, SOCK_DGRAM, htons(ETH_P_ALL))) < 0) {
		if (is_debug())
			printf_3g("", "Create PF_PACKET socket:%s\n", strerror(errno));
		return -1;
	}
	s_net_param.sock = sock;
	

	
	/*get interface index by dev name*/
	d_printf("To get ifindex\n");
	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_ifrn.ifrn_name, ifn, IFNAMSIZ-1);
	if (ioctl(sock, SIOCGIFINDEX, &ifr, sizeof(ifr)) < 0) {
		if (is_debug())
			printf_3g("", "Get ifindex error:%s\n", strerror(errno));
		goto error;
	}
	s_net_param.ifindex = ifr.ifr_ifru.ifru_ivalue;
	d_printf("If index:%d\n", s_net_param.ifindex);

	/*get the MAC addr and the hard type*/
	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_ifrn.ifrn_name, ifn, IFNAMSIZ-1);
	if (ioctl(sock, SIOCGIFHWADDR, &ifr, sizeof(ifr)) < 0) {
		if (is_debug())
			printf_3g("", "Get SIOCGIFHWADDR error:%s\n", strerror(errno));
		goto error;
	}
	s_net_param.haddr_type = ifr.ifr_hwaddr.sa_family;
	if (ARPHRD_PPP == s_net_param.haddr_type) {
		d_printf("Dev is PPP not need arp.\n");
		s_net_param.status	= PING_S_ARP_OK;
		s_net_param.ip_nhop 	= s_net_param.ip_daddr;
	} else {
		memcpy(s_net_param.shaddr, ifr.ifr_hwaddr.sa_data, 
			sizeof(s_net_param.shaddr));
		d_printf("MAC:<%s>,type:%d\n",
			ping_mac_str(0, s_net_param.shaddr),
			s_net_param.ifindex);
	}

	/*Get src addr from the inteface name*/
	memset(&ifr, 0, sizeof(ifr));
	memcpy(&ifr.ifr_ifrn.ifrn_name, s_net_param.ifname, IFNAMSIZ-1);
	if (ioctl(sock, SIOCGIFADDR, &ifr, sizeof(ifr)) < 0) {
		if (is_debug())
			printf_3g("", "Get SIOCGIFADDR error:%s\n", strerror(errno));
		goto error;
	}
	ip_addr = (struct sockaddr_in *)&ifr.ifr_ifru.ifru_addr;
	s_net_param.ip_saddr = ip_addr->sin_addr.s_addr;
	d_printf("Get saddr:%s\n", inet_ntoa(ip_addr->sin_addr));

	/*Get arp form kernel arp table*/
	if (s_net_param.haddr_type != ARPHRD_PPP) {
		d_printf(
			"Get arp from kernel for:dev:%s,ip:%s\n",
			s_net_param.ifname, 
			inet_ntoa(*(struct in_addr *)&s_net_param.ip_nhop));
		memset(&arp_r, 0, sizeof(arp_r));
		memcpy(&arp_r.arp_dev, s_net_param.ifname, 15);
		arp_r.arp_pa.sa_family = AF_INET;
		ip_addr = (struct sockaddr_in *)&arp_r.arp_pa;
		ip_addr->sin_addr.s_addr = s_net_param.ip_nhop;
		if (ioctl(sock, SIOCGARP, &arp_r, sizeof(arp_r)) < 0) {
			if (is_debug())
				printf_3g("", "Do SIOCGARP error:%s\n", strerror(errno));
			s_net_param.status = PING_S_NEED_ARP;
		} else {
			memcpy(s_net_param.thaddr, arp_r.arp_ha.sa_data, 6);	
			d_printf("Got ARP entry<%s dev:%s flag:0x%1x HW-type:0x%1x>\n",				
				ping_mac_str(s_net_param.ip_nhop,s_net_param.thaddr),
				arp_r.arp_dev,
				arp_r.arp_flags,
				arp_r.arp_ha.sa_family);
			s_net_param.status = PING_S_ARP_OK;
		}
	}

	/*bind the socket to the interface*/
	d_printf("Bind to if:%s, ifindex:%d\n", ifn, s_net_param.ifindex);
	memset(&sll, 0, sizeof(sll));
	sll.sll_family 	= AF_PACKET;
	sll.sll_ifindex = s_net_param.ifindex;
	sll.sll_protocol = htons(ETH_P_ALL);
	if (bind(sock, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		if (is_debug())
			printf_3g("", "Bind socket error:%s\n", strerror(errno));
		goto error;
	}
	d_printf("Bind OK\n");
	
	/* set recv buf for broadcast pings */
	sockopt = 48 * 1024;
	setsockopt(s_net_param.sock, SOL_SOCKET, SO_RCVBUF, 
		(char *) &sockopt, sizeof(sockopt));

	return 0;

error:
	if (s_net_param.sock)
		close(s_net_param.sock);
	memset(&s_net_param, 0, sizeof(s_net_param));
	close(sock);
	return -1;
}

struct eth_arphdr{
	uint16_t		ar_hrd;		/* format of hardware address	*/
	uint16_t		ar_pro;		/* format of protocol address	*/
	uint8_t			ar_hln;		/* length of hardware address	*/
	uint8_t			ar_pln;		/* length of protocol address	*/
	uint16_t		ar_op;		/* ARP opcode (command)		*/
	/*
	*	 Ethernet looks like this : This bit is variable sized however...
	*/
	uint8_t		ar_sha[6];	/* sender hardware address	*/
	in_addr_t	ar_sip;		/* sender IP address		*/
	uint8_t		ar_tha[6];	/* target hardware address	*/
	in_addr_t	ar_tip;		/* target IP address		*/	
} __attribute__ ((packed));

/*send the arp request*/
static ssize_t ping_arp_send()
{
	struct eth_arphdr  *arp;
	char *package = 0;
	int len = 0;
	ssize_t ret = 0;
	ssize_t i = 0;
	struct sockaddr_ll daddr;

	len = (sizeof(*arp) + 32)&(~0x11);
	CDMG_MALLOC(len, package, return -1;);
	arp	= (struct eth_arphdr *)package;

	arp->ar_hrd = htons(s_net_param.haddr_type);
	arp->ar_pro = htons(0x0800);/*ip addr*/
	arp->ar_op	= htons(0x0001);/*arp request*/
	arp->ar_hln = 6;
	arp->ar_pln = 4;
	memcpy(arp->ar_sha, s_net_param.shaddr, 6);
	arp->ar_sip = s_net_param.ip_saddr;
	arp->ar_tip = s_net_param.ip_nhop;
	memset(arp->ar_tha, 0, 6);

	/*set the bcast mac addr*/
	daddr.sll_ifindex		= s_net_param.ifindex;
	daddr.sll_halen			= 6;
	daddr.sll_hatype		= s_net_param.haddr_type;
	daddr.sll_protocol		= htons(ETH_P_ARP);
	daddr.sll_pkttype		= PACKET_BROADCAST;
	memset(daddr.sll_addr, 0xff, 6);

	char sip[32] = {0}, dip[32] = {0};
	inet_ntop(AF_INET, &arp->ar_sip, sip, sizeof(sip)-1);
	inet_ntop(AF_INET, &arp->ar_tip, dip, sizeof(dip)-1);
	d_printf("Send arp:who has %s, tell %s\n", dip, sip);

	if ((i = sendto(s_net_param.sock, 
			package, len, 0, 
			(struct sockaddr *)&daddr, 
			sizeof(daddr))) < 0) {
		if (is_debug())			
			printf_3g("", "send error:%s\n", strerror(errno));
		ret = -1;
		goto end;			
	}
	d_printf("%s:SEND %d byte(s)\n", curr_time(), i);
	s_net_param.status = PING_S_SEND_ARP;
	
end:
	free(package);
	return ret;
}

/*Resovle the arp respond to get the MAC addr*/
static int ping_arp_resolve()
{
	struct eth_arphdr *arp = (struct eth_arphdr *)s_net_param.buf;

	if (s_net_param.r_len < sizeof(*arp)) {
		d_printf("ARP too small\n");
		return -1;
	}
	if (arp	->ar_op != htons(0x0002)) {
		d_printf("Not arp respond\n");
		return -1;
	}
	if (arp	->ar_pro != htons(0x0800)) {
		d_printf("Not ip protocol\n");
		return -1;
	}
	if (arp	->ar_sip != s_net_param.ip_nhop) {
		d_printf("Not the dest ip:%s\n",
			inet_ntoa(*(struct in_addr *)&arp	->ar_sip));
		return -1;
	}
	if (arp	->ar_tip != s_net_param.ip_saddr) {
		d_printf("Not the src ip:%s\n",
			inet_ntoa(*(struct in_addr *)&arp	->ar_tip));
		return -1;
	}
	d_printf("ARP got:<%s>\n", ping_mac_str(arp->ar_sip, arp->ar_sha));
	memcpy(s_net_param.thaddr, arp->ar_sha, 6);

	struct arpreq req;
	struct sockaddr_in	*saddr = 0;

	/*set the arp entry to kernel*/
	d_printf("Set the arp to kernel\n");
	memset(&req, 0, sizeof(req));
	strncpy(req.arp_dev, s_net_param.ifname, 15);
	memcpy(req.arp_ha.sa_data, s_net_param.thaddr, 6);
	saddr = (struct sockaddr_in	*)&req.arp_pa;
	saddr->sin_family = AF_INET;
	saddr->sin_addr.s_addr = s_net_param.ip_nhop;
	req.arp_flags = ATF_COM;
	if (ioctl(s_net_param.sock, SIOCSARP, &req, sizeof(req)) < 0) {
		if (is_debug())
			printf_3g("", "Set arp to kernel error:%s\n", strerror(errno));	
	} else
		d_printf("Arp set OK\n");

	s_net_param.status = PING_S_ARP_OK;
	return 0;	
}


static int ping_icmp_send()
{
	int i = 0, ret = 0, len = 0;
	char *buf = 0;
	struct iphdr *ip = 0;
	struct icmphdr *icmp = 0;
	struct sockaddr_ll	sll = {0};	

	d_printf("Send icmp echo\n");
	len = (sizeof(*ip) + sizeof(*icmp) + PING_DATE_LEN);
	CDMG_MALLOC(len, buf, return -1;);

	ip		= (struct iphdr *)buf;
	icmp	= (struct icmphdr *)(buf + sizeof(struct iphdr));

	/*set ip hdr*/
	ip->version 	= 0x04;
	ip->ihl			= 0x05;
	ip->tos 		= 0;
	ip->frag_off	= htons(0x4000);/*do not frag*/
	ip->protocol	= 0x01;/*icmp*/
	ip->ttl			= 255;
	ip->id			= 0;
	ip->saddr	= s_net_param.ip_saddr;
	ip->daddr	= s_net_param.ip_daddr;
	

	s_net_param.echo_id	= (uint16_t)getpid();
	s_net_param.echo_seq	= ntransmitted++;
	
	/*set value of the icmp pakage*/
	icmp->type = ICMP_ECHO;/*echo*/
	icmp->code = 0;
	icmp->checksum = 0;
	icmp->un.echo.sequence = htons(s_net_param.echo_seq);
	icmp->un.echo.id = htons(s_net_param.echo_id);
	CLR(s_net_param.echo_seq % MAX_DUP_CHK);

	/*set the seding time*/
	gettimeofday((struct timeval *) &buf[sizeof(*ip)+sizeof(*icmp)], NULL);
	/*calulate the check sum*/
	icmp->checksum = in_cksum((unsigned short *) icmp, len - sizeof(*ip));
	

	/*set len and check sum of ip hdr*/
	ip->tot_len	= htons(len - sizeof(*ip));
	ip->check	= in_cksum((uint16_t *)ip, sizeof(*ip));

	/*set the mac addr*/
	sll.sll_ifindex		= s_net_param.ifindex;
	sll.sll_halen		= 6;
	sll.sll_hatype		= s_net_param.haddr_type;
	sll.sll_protocol	= htons(ETH_P_IP);
	sll.sll_pkttype		= PACKET_OUTGOING;
	memcpy(sll.sll_addr, s_net_param.thaddr, 6);

	if ((i = sendto(s_net_param.sock,
			buf, len, 0,
			(struct sockaddr *)&sll, 
			sizeof(sll))) < 0) {
		if (is_debug())
			printf_3g("", "send error:%s\n", strerror(errno));
		ret = -1;
		goto end;
	}
	d_printf("%s:SEND %d byte(s)\n", curr_time(), i);
	s_net_param.status = PING_S_SEND_ICMP;

end:
	free(buf);
	return ret;
}

static int ping_icmp_resolve()
{
	int sz = 0;
	struct icmp *icmppkt;
	struct iphdr *iphdr;
	struct timeval tv, *tp;
	int hlen, dupflag;
	unsigned long triptime;

	d_printf("Resolve icmp:\n");
	gettimeofday(&tv, NULL);

	/* check IP header */
	iphdr = (struct iphdr *) s_net_param.buf;
	hlen = iphdr->ihl << 2;
	/* discard if too short */
	if (s_net_param.r_len < PING_DATE_LEN)	 {
		d_printf("Package too short\n");
		return -1;
	}

	/* discard if dst ip addr is not me */
	if (iphdr->daddr !=s_net_param.ip_saddr) {
		char ip_dst[32] = {0}, ip_me[32] = {0};		
		in_addr_t me = s_net_param.ip_saddr;
		inet_ntop(AF_INET, &iphdr->daddr, ip_dst, sizeof(ip_dst)-1);
		inet_ntop(AF_INET, &me, ip_me, sizeof(ip_me)-1);
		d_printf("Dst ip:%s is not me:%s\n", ip_dst, ip_me);
		return -1;
	}

	sz = s_net_param.r_len - hlen;
	icmppkt = (struct icmp *) (s_net_param.buf + hlen);

	/*check the id*/
	if (icmppkt->icmp_id != htons(s_net_param.echo_id)) {
		d_printf("Id not match:his is 0x%04x,me is 0x%04x\n",
			ntohs(icmppkt->icmp_id), s_net_param.echo_id);
		return -1;/* not our ping */
	}

	/*check the id*/
	if (icmppkt->icmp_seq != htons(s_net_param.echo_seq)) {
		d_printf("Seq not match:his is 0x%04x,me is 0x%04x\n",
			ntohs(icmppkt->icmp_seq), s_net_param.echo_seq);
		return -1;/* not our ping */
	}
	
	if (icmppkt->icmp_type != ICMP_ECHOREPLY) {
		d_printf("Not the reply:0x%02x\n", icmppkt->icmp_type);
		return -1;
	}
	
	/*the package type is reply*/
    ++nreceived;
	tp = (struct timeval *) icmppkt->icmp_data;

	if ((tv.tv_usec -= tp->tv_usec) < 0) {
		--tv.tv_sec;
		tv.tv_usec += 1000000;
	}
	tv.tv_sec -= tp->tv_sec;

	triptime = tv.tv_sec * 10000 + (tv.tv_usec / 100);
	tsum += triptime;
	if (triptime < tmin)
		tmin = triptime;
	if (triptime > tmax)
		tmax = triptime;

	if (TST(ntohs(icmppkt->icmp_seq) % MAX_DUP_CHK)) {
		++nrepeats;
		--nreceived;
		dupflag = 1;
	} else {
		SET(ntohs(icmppkt->icmp_seq) % MAX_DUP_CHK);
		dupflag = 0;
	}

	/*print the result*/
	verbo_printf("%d data bytes from %s: icmp_seq=%u", 
		(sz - sizeof(*icmppkt)),
		inet_ntoa(*(struct in_addr*)&iphdr->saddr),
		ntohs(icmppkt->icmp_seq));
	verbo_printf(" ttl=%d", iphdr->ttl);
	verbo_printf(" time=%lu.%lu ms", triptime / 10, triptime % 10);
	if (dupflag)
		printf(" (DUP!)");
	verbo_printf("\n");

	s_net_param.status = PING_S_ICMP_OK;	
	return 0;
}

static int ping_wait_input()
{
	int ret = 0;
	fd_set	reads;

	d_printf("Wait input\n");
	for (;;) {
		FD_ZERO(&reads);
		FD_SET(s_net_param.sock, &reads);

	again:
		ret = select(s_net_param.sock + 1, &reads, 0, 0, NULL);
		if (ret <= 0)
			goto again;

		d_printf("Data come\n");
		if (FD_ISSET(s_net_param.sock , &reads)) {
			d_printf("Get some data\n");
			return 0;
		} else {
			d_printf("Not data come select again\n");
			goto again;
		}
	}
}

/*receive the package from ther socket*/
static void ping_recv()
{
	int i = 0;	

	d_printf("Rcvd data\n");
	memset(s_net_param.buf, 0, sizeof(s_net_param.buf));
	
again:
	i = recv(s_net_param.sock, 
			s_net_param.buf, 
			sizeof(s_net_param.buf)-1, 0);
	
	if (i < 0 && errno == EINTR)
		goto again;/*interrupt*/
	else if (i < 0 && errno != EINTR) {
		d_printf("Rcvd error\n");
		goto again;/*interrupt*/
	} else {/*OK*/
		s_net_param.r_len = i;
		d_printf("%s:RCVD %d byte(s)\n", curr_time(), i);
	}
}

static int ping_resolve()
{
	d_printf("Resove the income package,s_net_param.status=%d\n", 
		s_net_param.status );
	
	if (s_net_param.status == PING_S_SEND_ARP)
		ping_arp_resolve();
	else if (s_net_param.status == PING_S_SEND_ICMP)
		ping_icmp_resolve();

	return 0;
}


static sigjmp_buf ping_jmp;

static void sig_alarm(int sig)
{
	siglongjmp(ping_jmp, 1);
}

static void sig_alarm_block()
{
	sigset_t sigmsk;

	sigemptyset(&sigmsk);
	sigaddset(&sigmsk, SIGALRM);
	sigprocmask(SIG_BLOCK, &sigmsk, 0);
}

static void sig_alarm_unblock()
{
	sigset_t sigmsk;

	sigemptyset(&sigmsk);
	sigaddset(&sigmsk, SIGALRM);
	sigprocmask(SIG_UNBLOCK, &sigmsk, 0);
}

/*
* process the arp and icmp
* @dst  --bigendian
* @nhop --bigendian
*/
static int ping_check_do(in_addr_t dst, in_addr_t nhop,
		const char *intf, int time_out)
{
	int ret = -1, set_timer = 0;
	struct sigaction sigact;
	struct sigaction old_sigact;

	sig_alarm_block();

	if (ping_net_init(intf, dst, nhop, time_out) != 0)
		goto end;

	d_printf("status:%d\n",s_net_param.status);

	memset(&sigact, 0, sizeof(sigact));
	memset(&old_sigact, 0, sizeof(old_sigact));
	sigact.sa_handler = sig_alarm;	
	sigaction(SIGALRM, &sigact, &old_sigact);

	/*if timeout jmp to here*/
	if (sigsetjmp(ping_jmp, 1) == 1) {
		if (is_debug())
			d_printf("%s:timeout\n", curr_time());
		else
			verbo_printf("timeout\n");
		ret = -1;
		goto end;
	}	

	/*the main loop, running untill timeout or get the ping reply*/
	for(;;) {
		switch(s_net_param.status) {
			case PING_S_ICMP_OK:
				ret = 0;/*rcvd the icmp reply*/
				goto end;/*exit*/
			case PING_S_NEED_ARP:
				ping_arp_send();
				break;
			case PING_S_ARP_OK:
				ping_icmp_send();
				break;
			case PING_S_SEND_ARP:
			case PING_S_SEND_ICMP:
				if (!set_timer) {
					d_printf("Set alarm\n");
					alarm(s_net_param.timeout);/*set time out*/
					set_timer = 1;
				}
				sig_alarm_unblock();
				ping_wait_input();
				sig_alarm_block();
				ping_recv();
				ping_resolve();
				break;
			default:
				verbo_printf("Error\n");
				goto end;
		}
	}

end:
		if (s_net_param.sock)
			close(s_net_param.sock);
		
		/*cancel the timer*/
		if (set_timer)
			alarm(0);
		
		/*restore sig setting*/
		sigaction(SIGALRM, &old_sigact, 0);
		return ret;			
}

/***************************************************
function: the interface function
args	: 
return:0 OK, -1 ping fail, -2 other fial not start ping
note: 
**************************************************/	
FUNC(ping, "Ping tools for checking nenection is OK or not.\n"
			   "For debug, create file /var/3g_ping, can control the ping result:\n"
			   " the conten of the file: 0---fail, 1--sucess\n"
			   "\temax: 3g-mngr ping --addr=xx "
			   "[--timeout=x --times=x --period=x --intf=xx --nexthop=x  -v]\n")
{
	char str_verbo[4] = {0};
	char str_timeout[4] = {0};
	char str_times[4] = {0};
	char str_period[4] = {0};
	char str_addr[32] = {0};
	char str_intf[32] = {0};
	char str_nexthop[CDMG_IPV4_ADDR_LEN] = {0};
	in_addr_t daddr, nhop;
	struct sockaddr_in pingaddr = {0};
	int i = 0, timeout = 1, times = 3, period = 1;
	
	/*get addrees from the command line*/
	if (MNGR_GET_ARG("addr", str_addr) <= 0) {
		printf("No address\n");
		return -2;
	}
	
	/*check the address*/
	if (inet_pton(AF_INET, str_addr, (void  *)&pingaddr.sin_addr ) != 1) {
		printf("Addr Error\n");
		return -2;
	}

	/*get check parameter*/
	MNGR_GET_ARG("timeout", str_timeout);
	MNGR_GET_ARG("times", str_times);
	MNGR_GET_ARG("period", str_period);
	MNGR_GET_ARG("intf", str_intf);
	MNGR_GET_ARG("nexthop", str_nexthop);

	if (MNGR_GET_ARG("v", str_verbo))
		verbo = 1;

	d_printf("[ping]: addr=%s, to=%s,times=%s,period=%s,intf=%s,nexthop=%s\n",
		str_addr, str_timeout, str_times, str_period, str_intf,str_nexthop);

	/*this func be sure  the daddr is bigend*/
	inet_pton(AF_INET, str_addr, &daddr);
	
	/*this func be sure  the daddr is bigend*/
	if (str_nexthop[0])
		inet_pton(AF_INET, str_nexthop, &nhop);
	else
		nhop = 0;
	
	if (str_timeout[0])
		timeout = strtoul(str_timeout, 0, 10);
	if (str_times[0])
		times = strtoul(str_times, 0, 10);	
	if (str_period[0])
		period = strtoul(str_period, 0, 10);
	
	for (i = 0; i <times; i++) {
		const char *debug_file = "/var/3g_ping";
		char ping_result[4] = {0};

		d_printf("Ping check No:%d\n", i);
		ping_result[0] = 0;

		/*
		* for debug:
		* if the content of file:/var/3g_ping is 0 let the ping fail
		* if the content of file:/var/3g_ping is 1 let the ping sucess
		*/		
		if (access(debug_file, F_OK) == 0 &&
				lib3g_read_file(debug_file,
				ping_result,sizeof(ping_result)-1) == 0) {
			if (ping_result[0] == '0') 
				continue;
			if (ping_result[0] == '1') {
				if (!mn || !mn->run_on_diald)
					printf("OK at  No.%d time\n", i);
				return 0;
			}			
		} 

		/*the really check action*/
		if (ping_check_do(daddr, nhop, str_intf, timeout) == 0) {
			if (!mn || !mn->run_on_diald)
				printf("OK at  No.%d time\n", i);
			return 0;
		}
		sleep(period);
	}

	if (!mn || !mn->run_on_diald)
		printf("Fail try %d time(s)\n", times);
	return -1;	
}
#endif
#endif

