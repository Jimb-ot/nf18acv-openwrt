#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "3g-mngr-include.h"

#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_modem", "MODEM", args)

typedef struct{
	char tty_cache[16][MNGR_MODEM_LEN_TTY_PATH+1];
	char dev_path[MNGR_MODEM_LEN_DEV_PATH+1];	
	char ctrl_tty[MNGR_MODEM_LEN_TTY_PATH+1];
	char ip_tty[MNGR_MODEM_LEN_TTY_PATH+1];	
	int major;
	int minor;
	char manufacturer[128];
	char product[128];
	char nt[32];
	char provider_code[32];
	char identify[32];
	char serialno[80];
	char imei[80];/*imei*/
	char imsi[16];/*imsi*/
	char charge[12]; /*Advice of Charge, the value  is in hexadecimal format */

	struct csq  csq;
	char reginfo[80];
	char pininfo[80];
	char lockinfo[32];

	char lac[8];/*location area code n hexadecimal format*/
	char cellid[8];/*cell ID in hexadecimal format*/

	/*showing the down and up stream rate*/
	char down_stream_rate[32];
	char up_stream_rate[32];
	
    int act;
	time_t update_time_info;

	int pin_retry_time;
	int puk_retry_time;
	int pin_chg_retry_time;
	int lock_chg_retry_time;

	int do_at_hangup;
} __modem_t;


typedef struct {
    char *vid;
    char *pid;
    char *driver;
}VPDinfo;
#define FORMAT_PATH_OF_MODULE "/lib/modules/privat_module/%s.ko"
VPDinfo VPDinfos[] = {
    {"1c9e", "9b3c", "GobiNet_LS"},
    {"1c9e", "9b05", "GobiNet_LS"},
    {"2df3", "9b3e", "GobiNet_LS"},
    {"2DEE", "4D01", "GobiNet_MG"},
    {"2DEE", "4D02", "GobiNet_MG"},
    {"05c6", "C04D", "GobiNet_MG"},
    {"05c6", "f601", "GobiNet_MG"},
    {"05c6", "9025", "GobiNet_MG"}
};
#define VPDinfosSize(VPDinfos) ((sizeof(VPDinfos)/sizeof(VPDinfo)))

UBOOL8 attachedLTEDriver(const char *moduleName){
    #define PROC_FILE_ALL_INSMODED_MODULES "/proc/modules"
    UBOOL8 ret = 0;
    FILE *in = NULL;
    char modsBuf[1024];

    if ((moduleName==NULL) || (strlen(moduleName)==0)) {
        d_printf("parameter is Empty\n");
		goto end;
    }

    memset(modsBuf, 0, sizeof(modsBuf));
    
    if ((in = fopen(PROC_FILE_ALL_INSMODED_MODULES, "r")) == NULL) {
		d_printf("can not open %s\n", 
			PROC_FILE_ALL_INSMODED_MODULES);
		goto end;
	}
    
	if (fread(modsBuf, 1, sizeof(modsBuf)-1, in) <= 0) {
		d_printf("can not read %s\n", 
			PROC_FILE_ALL_INSMODED_MODULES);
		goto end;
	}else{
	    fclose(in);
        in = NULL;
	}

    if (strstr(modsBuf, moduleName)) {
        ret = 1;
    }

end:
    if (in){
        fclose(in);
    }
    
    return ret;
}


#define PROC_FILE_LTEDriverName "/var/LTEDriverName"
UBOOL8 setLTEDriverName(const char *moduleName){
    UBOOL8 ret = 0;
    FILE *in = NULL;
    int ilen = 0;

    if ((moduleName==NULL) || ((ilen=strlen(moduleName))==0)) {
        d_printf("parameter is Empty\n");
		goto end;
    }

    if ((in = fopen(PROC_FILE_LTEDriverName, "w+")) == NULL) {
		d_printf("can not open %s\n", 
			PROC_FILE_LTEDriverName);
		goto end;
	}

    if ((fwrite(moduleName, 1, ilen, in) <= 0)) {
		d_printf("can not write %s\n", PROC_FILE_LTEDriverName);
		goto end;
	}else{
	    ret = 1;
	}

end:
    if (in){
        fclose(in);
    }

    return ret;
}

UBOOL8 getLTEDriverName(const char *moduleName, int ilen, UBOOL8 bUnlink){
    UBOOL8 ret = 0;
    FILE *in = NULL;

    if ((moduleName==NULL) || (ilen==0)) {
        d_printf("parameter is Empty\n");
		goto end;
    }

    if ((in = fopen(PROC_FILE_LTEDriverName, "r")) == NULL) {
		d_printf("can not open %s\n", 
			PROC_FILE_LTEDriverName);
		goto end;
	}

    if ((fread(moduleName, 1, ilen-1, in) <= 0)) {
		d_printf("can not read %s\n", PROC_FILE_LTEDriverName);
		goto end;
	}else{
	    ret = 1;
	}

end:
    if (in){
        fclose(in);
    }

    if (bUnlink){
        unlink(PROC_FILE_LTEDriverName);
    }

    return ret;
}

void attachLTEDriver(const char *pVid, const char *pPid){
    if(pVid!=NULL && pPid!=NULL){
        int i = 0;
        int found = 0;
        for(i=0; !found && i<VPDinfosSize(VPDinfos); i++){
            if(!strcasecmp(VPDinfos[i].vid, pVid) 
                && !strcasecmp(VPDinfos[i].pid, pPid)){
                char strCmd[128];
                found = 1;
                record_3g("match well VPDinfos[%d](%s, %s)\r\n", i, VPDinfos[i].vid, VPDinfos[i].pid);
                if(VPDinfos[i].driver){
                    if (!attachedLTEDriver(VPDinfos[i].driver)){
                        record_3g("have a special LTEDriver(%s), insmod it now\r\n", VPDinfos[i].driver);
                        snprintf(strCmd, sizeof(strCmd)-1, "insmod " FORMAT_PATH_OF_MODULE " 2>/dev/null", VPDinfos[i].driver);
                        lib3g_fmt_script(strCmd);
                        sleep(3);
                        setLTEDriverName(VPDinfos[i].driver);
                    }
                }
                break;
            }
        }
    }
}


void dettachLTEDriver(){
    char moduleName[64];

    memset(moduleName, 0, sizeof(moduleName));
    getLTEDriverName(&moduleName[0], sizeof(moduleName), 1);

    if (moduleName[0]){
        char strCmd[128];
        
        record_3g("have a special LTEDriver(%s), rmmod it now\r\n", moduleName);
        snprintf(strCmd, sizeof(strCmd)-1, "rmmod %s 2>/dev/null", moduleName);
        sleep(3);
        lib3g_fmt_script(strCmd);
    }
}


static int modem_proccess_at_error(modem_t *mdm, const char *err_str);

int modem_valid_check(modem_t *mdm)
{
	int ret = 0;
	
	if (!mdm)
		return -1;

	if (!MN(mdm)->at) {
		d_printf("modem no at\n");
		ret = -1;
	}

	if (!MN(mdm)->par) {
		d_printf("modem no param\n");
		ret = -1;
	}

	if (!mdm->mngr) {
		d_printf("no mngr\n");
		ret = -1;
	}

	return ret;
}

modem_t  *modem_new(void *mn)
{
	modem_t *m;

	if ((m = ALLOC_3G(modem_t, __modem_t) ) <= 0) {
		printf_3g("", "can not malloc modem\n");
		return 0;
	}


	MN_SET(m, mn);
	
	modem_init(m);

	return m;
}

int modem_init(modem_t *mdm)
{
	SUB_INIT(mdm, modem_t, __modem_t);
	
	return 0;
}

int modem_free(modem_t *mdm)
{
	if (!mdm)
		return 0;

	if (MN(mdm))
		MN(mdm)->mdm = 0;

	free(mdm);

	mdm = 0;

	return 0;
}

/*Get the  path of dir witch have manufacturer file.
*1. decide the link path
*2. find the really path of the link path
*3. travel from right to left to find a path of dir which have manufacturer file.
*/
static int modem_get_attr_dir(const char *d_name, char *rbuf, int rbuflen)
{
	DIR *dir = 0;
	struct dirent *dent = 0;
	int kernel_ver = 2;
	int kernel_patchlevel = 6;
	int kernel_sublevel = 30;
	char *p = 0, *q = 0;
	char buf[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	char tty_path[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	
	d_printf("enter d_name:[%s]\n", d_name);
	
	if (!d_name) {
		printf_3g("", "param error\n");
		return -1;
	}

	if (!rbuf || rbuflen <=0) {
		printf_3g("", "param error\n");
		return -1;
	}
	
	memset(rbuf, 0, rbuflen);
	
	lib3g_get_kernel_ver(&kernel_ver, &kernel_patchlevel, 
		&kernel_sublevel, 0, 0);
	d_printf("start to search modem... for Linux kernel %d.%d.%d\n",
		kernel_ver,
		kernel_patchlevel,
		kernel_sublevel);
	
	/*1. decide the link path*/
    d_printf("kernel_ver = %d\n", kernel_ver);
	if (kernel_sublevel > 21 || kernel_ver >= 3) {
		snprintf(tty_path, sizeof(tty_path), 
			"%s/%s", 
			USB_S_DEV_PATH, 
			d_name);
	} else {
		/*/sys/class/sys/ttyUSBx/device is the character link*/
		snprintf(tty_path, sizeof(tty_path), 
			"%s/%s/device", 
			USB_S_DEV_PATH, 
			d_name);
	}
	d_printf("the link path:[%s]\n", tty_path);

	/*2. find the really path of the link path*/
	if (readlink(tty_path, buf, 
			MNGR_MODEM_LEN_TTY_PATH) <= 0) {
		perror("readlink %s", tty_path);
		return -1;
	}
	d_printf("read dev path:[%s]\n", buf);
	
	p = strstr(buf, "devices");
	if (!p)
		return -1;
	snprintf(tty_path, MNGR_MODEM_LEN_TTY_PATH,
		"/sys/%s", p);
	d_printf("really dev path:[%s]\n", tty_path);

	/*
	* 3. travel from right to left to find a path of dir which have manufacturer file.
	*the format:
	*../../../devices/pci0000:00/0000:00:1f.2/usb1/1-1/1-1:1.0/ttyUSB0
	* /sys/class/tty/../../devices/pci0000:00/0000:00:0a.0/usb1/1-1/1-1.4/1-1.4:1.1/ttyUSB1/tty/ttyUSB1
	* /sys/class/tty/../../devices/pci0000:00/0000:00:0a.0/usb1/1-1/1-1.4/1-1.4:1.3/tty/ttyACM1 ;have hub
	* /sys/class/tty/../../devices/pci0000:00/0000:00:0a.0/usb1/1-1/1-1:1.1/tty/ttyACM1   ;no hub
	* /sys/class/tty../../devices/platform/rtl8672-ohci.0/usb2/2-2/2-2:1.2/ttyUSB2 ;For TBS linux2.6.19
	* /sys/class/tty/../../devices/platform/rtl8672-ehci.0/usb1/1-2/1-2:1.3 ;For TBS linux2.6.19 ACM
	*/
	q = strstr(tty_path, "devices");
	q += strlen("devices");
	while (1) {
		d_printf("search dir:[%s] for if exist file:idProduct\n", tty_path);
		if ((dir = opendir(tty_path)) > 0) {
			while( (dent = readdir(dir))) {
				if (!strcmp(dent->d_name, "idProduct")) {
					d_printf("OK, find!\n");
					snprintf(rbuf, rbuflen, "%s", tty_path);
					closedir(dir);
					return 0;
				}
			}
			closedir(dir);	
		} else
			d_perror("can not open [%s]:", tty_path);

		if (!(p = strrchr(tty_path, '/'))) {
			d_printf("%s not '\'\n", tty_path);
			return -1;
		}

		if (p <= q) {
			d_printf("end, not find\n");
			return -1;
		}
		
		*p = 0;
	}
}


/*
* scb+ 2012-1-12 this is a assistant function for fix the ctrl tty and ip tty
* return: 0  no item, 1 has item
*/
static int get_tty_by_at(modem_t *mdm, at_cmd_t item, char *result, int rlen)
{
	int i = 0;
	int ttyindex = 0;
	char tty[AT_CMD_LEN] = {0};
	__modem_t *__mdm = NULL;
    
    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }
    
    __mdm = GET_PRI(mdm, __modem_t);
    
	at_get_item(MN(mdm)->at, item, tty, AT_CMD_LEN);
	

	if (!tty[0])
		return 0;
	
	if (!strstr(tty, "ttyUSB") && !strstr(tty, "ttyACM")) {
		/*point out the tty by number*/
		ttyindex = strtoul(tty, 0, 10);
		if (!__mdm->tty_cache[ttyindex][0]) {			
			printf_3g("", 
				"***ERROR:No. %d tty no exist, the tty index too larger\n",
				ttyindex);
			return 0;			
		} else {	
			snprintf(result, rlen, "%s", __mdm->tty_cache[ttyindex]);
			d_printf("The %s  is:%s\n", 
				(item == AT_IP_TTY ? "AT_IP_TTY":"AT_CTL_TTY"),
				result);
			return 1;
		}
	} else {
		/*point out the tty by name such as ;AT_IP_TTY="ttyUSB2"*/
		for (i = 0; __mdm->tty_cache[i][0]; i++) {
			if (strstr(__mdm->tty_cache[i], tty)) {
				snprintf(result, rlen, "%s", __mdm->tty_cache[i]);
				d_printf("The %s  is:%s\n", 
					(item == AT_IP_TTY ? "AT_IP_TTY":"AT_CTL_TTY"),
					result);
				return 1;
			}
		}
		printf_3g("", "***WARNNING:the point out tty %s is not valid, "
			"it can not support AT\n",
			tty);
		if (item == AT_IP_TTY) {
			snprintf(result, rlen, "/var/dev/%s", tty);
			return 1;
		}
	}

	printf_3g("", "Get %s, No result\n", 
		(item == AT_IP_TTY ? "AT_IP_TTY":"AT_CTL_TTY"));
	
	return 0;	
}

/*
* scb+ 2012-1-12 fix the control tty from the config
* for some dongle, must send the AT to the special port.
* So must point out the control port at the config file.
*/
static int get_ctrl_tty_by_at(modem_t *mdm)
{
	char tty[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
    __modem_t *__mdm = NULL;

    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }
    
	__mdm =GET_PRI(mdm, __modem_t);


	if (get_tty_by_at(mdm, AT_CTL_TTY, tty, MNGR_MODEM_LEN_TTY_PATH) <= 0) {
		d_printf("Not find valid AT_CTL_TTY at config file\n");
		return 0;
	}

	d_printf("Change ctrl tty:%s-->%s\n", __mdm->ctrl_tty, tty);
	snprintf(__mdm->ctrl_tty, MNGR_MODEM_LEN_TTY_PATH, "%s", tty);
	at_set_tty(MN(mdm)->at, __mdm->ctrl_tty);

	return 1;
}

/*scb+ 2012-1-12 select a tty for  the ctrl tty*/
static int  modem_select_ctrl_tty(modem_t *mdm)
{
	int ret = 0;
    __modem_t *__mdm = NULL;
    
    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }    
	__mdm = GET_PRI(mdm, __modem_t);

	d_printf("Select control tty\n");		
	if (get_ctrl_tty_by_at(mdm) > 0) {
		d_printf("point out ctrl tty %s at configure file\n", __mdm->ctrl_tty);
		ret =  1;
		goto end;
	}
	
	d_printf("not point out ctrl tty  at configure file\n");
#ifdef FIND_TTY_PORT_BY_INT_EP
	int i;

	/*selet the first interfacer without  interrupt endpoint as the ctrl tty*/
	for ( i = 0; __mdm->tty_cache[i][0]; i++) {
		if (!lib3g_have_int_ep(__mdm->tty_cache[i])) {
			d_printf("%s no interrupt endpoid, select it as the ctrl tty\n",
				__mdm->tty_cache[i]);
			strcpy(__mdm->ctrl_tty, __mdm->tty_cache[i]);
			modem_set_ctrl_port(mdm, __mdm->tty_cache[i]);
			ret =  1;
			goto end;
		}
	}
#endif


end:

	if (ret != 1)
		printf_3g("", "can not get ctrl tty\n");
	
	return ret;
}

/*scb+ 2012-2-17 ar start, need to do some function for init the dongle*/
int modem_phone_init(modem_t *mdm)
{
    
    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }
    
	at_do_cmd(MN(mdm)->at, AT_PHONE_INIT, 0, AT_NONE, 0, 0);
	/*sleep(3);*/
	return 0;
}
			
int modem_search(modem_t *mdm)
{
	DIR *d = 0;
	char *p = 0;
	char tty_path[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	char buf[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	char idProduct[MNGR_MODEM_LEN_ID_LEN+1] = {0};
	char idVendor[MNGR_MODEM_LEN_ID_LEN+1] = {0};	
	int major = 0, minor = 0;
	int ret = -1;
	int tty_cache_n = 0;
	int have_done = 0;
	__modem_t  *__mdm;
	struct dirent *dent = 0;

    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }	

	d_printf("mdm->status =%d\n", mdm->status );
	if (mdm->status == SEARCH_FINISHED)
		return 0;

	__mdm = GET_PRI(mdm, __modem_t);
	
	if (( d = opendir(USB_S_DEV_PATH))) {
		have_done = 1;
			
		while( (dent = readdir(d))) {
			if ( !strcmp(dent->d_name, ".") || 
					!strcmp(dent->d_name, ".."))
				continue;

			if ( !strstr(dent->d_name, "USB") && 
					!strstr(dent->d_name, "ACM"))
				continue;			
			
			memset(tty_path, 0, sizeof(tty_path));

			record_3g("%s mkttynod\n", 
					tty_path);
			
			lib3g_mkttynod(dent->d_name, tty_path, 
				&major, &minor);

			record_3g("%s test AT\n", 
					tty_path);
			
			if (!lib3g_is_support_at_cmd(tty_path)) {
				d_printf("%s not support AT\n", 
					tty_path);
				record_3g("%s not support AT\n", 
					tty_path);
				continue;
			}

			d_printf("find %s support AT\n", tty_path);			
			record_3g("find %s support AT\n", tty_path);

			ret = 0;
			strncpy(__mdm->tty_cache[tty_cache_n], 
				tty_path,
				MNGR_MODEM_LEN_TTY_PATH);
			tty_cache_n++;
			
			if (tty_cache_n > 1)
				continue;


			/*when tty_cache_n == 1, only do one time*/
			 
			strcpy(__mdm->ctrl_tty, tty_path);
			d_printf("set default ctrl tty is[%s]\n", __mdm->ctrl_tty);
			
			__mdm->major = major;
			__mdm->minor = minor;

			ret = modem_get_attr_dir(dent->d_name, __mdm->dev_path, 
					sizeof(__mdm->dev_path)-1);

			if (ret == -1) {
				d_printf("error\n");
				break;
			}

			d_printf("Attr Dir is:[%s]\n", __mdm->dev_path);
			
			snprintf(buf, sizeof(buf), "%s/manufacturer",
				__mdm->dev_path);
			if (lib3g_read_file(buf, __mdm->manufacturer, 
					sizeof(__mdm->manufacturer) - 1) != 0)
				d_printf("read dev manufacturer error path:%s\n", 
					__mdm->dev_path);
			
			p = 0;
			if ((p = strchr(__mdm->manufacturer, '\n')))
				*p = 0;

			snprintf(buf, sizeof(buf), "%s/product", 
				__mdm->dev_path);				
			if (lib3g_read_file(buf, __mdm->product, 
					sizeof(__mdm->product) - 1) != 0)
				d_printf("read dev product error path:%s\n",
					__mdm->dev_path);
			
			p = 0;
			if ((p = strchr(__mdm->product, '\n')))
				*p = 0;

			idProduct[0] = '0';
			idProduct[1] = 'x';
			snprintf(buf, sizeof(buf),
				"%s/idProduct", 
				__mdm->dev_path);		
			if (lib3g_read_file(buf, idProduct+2, 
					sizeof(idProduct) -2) != 0) {
				d_printf("read dev idProduct error path:%s\n",
					__mdm->dev_path);
			}
			mdm->idProduct = strtoul(idProduct, 0, 16);

			idVendor[0] = '0';
			idVendor[1] = 'x';	
			snprintf(buf, sizeof(buf), 
				"%s/idVendor", 
				__mdm->dev_path);
			
			if (lib3g_read_file(buf, idVendor+2, 
					sizeof(idVendor) -2) != 0) {
				d_printf("read dev idVendor error path:%s\n",
					__mdm->dev_path);
			}
			mdm->idVendor = strtoul(idVendor, 0, 16);

		}
		
		closedir(d);
	}

	if (have_done == 0)
		d_printf("Is the modem usb_serial.ko not install? Can not open %s\n", 
			USB_S_DEV_PATH);
	
	if (ret == 0 && mdm->idVendor && mdm->idProduct ) {
		/*
		* scb+ 2012-1-18 filter function, 
		* only support some dongle or some network
		*/
		char id_vendor[8] = {0};
		char id_product[8] = {0};
		snprintf(id_vendor, sizeof(id_vendor), "%04x", mdm->idVendor);
		snprintf(id_product, sizeof(id_product), "%04x", mdm->idProduct);
		d_printf("FILTER:Try to check if is support for:(%s,%s)\n",
			id_vendor, id_product);	
		if (!modem_filter_is_allow(id_vendor, id_product)) {
			d_printf("We do not support this dongle:(%s,%s)\n", 
				id_vendor, id_product);
			ret = -1;
			modem_init(mdm);
		} else {
			d_printf("modem init ok\n");
			record_3g("modem init ok (%s:%s)\r\n", id_vendor, id_product);
            
			mdm->status = SEARCH_FINISHED;

			/*scb+ 2012-1-12 select the control tty */
			modem_select_ctrl_tty(mdm);
			if (MN(mdm)->at)
				at_set_tty(MN(mdm)->at, __mdm->ctrl_tty);

			/*scb+ 2012-2-17 ar start, need to do some function for init the dongle*/
			d_printf("Do AT command init...\n");
			modem_phone_init(mdm);
            //here try to attach LTE dirver
            attachLTEDriver(id_vendor, id_product);
		}
	} else {
		ret = -1;
		d_printf("modem init fail, reset modem info\n");
		modem_init(mdm);
	}
	return ret;
}

int modem_is_exist_tty(modem_t *mdm)
{	
	int i = 0;
	char *tty;
	char tty_path[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);

	d_printf("enter\n");
	
	while((tty = strstr(__mdm->tty_cache[i], "tty"))) {
		snprintf(tty_path, sizeof(tty_path) - 1, 
			"%s/%s",
			USB_S_DEV_PATH,
			tty);
		
		d_printf("check %s is if exist!\n", tty_path);
		if (access(tty_path, F_OK) == 0) {
			d_printf("%s exist,check it is if support AT\n", 
				tty_path);
			
			if (lib3g_is_support_at_cmd(__mdm->tty_cache[i])) {
				d_printf("%s  support AT\n", 
					__mdm->tty_cache[i]);
				return 1;
			} else {
				d_printf("%s  not support AT, it is bad\n", 
					__mdm->tty_cache[i]);
			}
		}
		i++;		
	}
	return 0;	
}

/**********************************************************************/
static provider_t providers[] = {//provider_code, idVendor, idProduct,  nt, name, apn, number,username,password
		/*confirmed*/
		{"46001", -1, -1, -1, "WCDMA",   "China Unicom",   "3gnet",               "*99#",    "any",                       "any" },
		{"46001", 7, -1, -1, "LTE",   "China Unicom",   "wonet",               "*99#",    "any",                       "any" },

		/*confirmed*/
		{"46003", -1, -1, -1, "EVDO",      "China Telecom",  "any",                  "#777",   "ctnet@mycdma.cn",    "vnet.mobi" },	
		{"46011", -1, -1, -1, "LTE",      "China Telecom",  "ctnet",                  "#777",   "any",    "any" }, 

		/*confirmed*/
        {"46000", 7, -1, -1, "LTE",      	   "China Mobile",  "cmnet",                  "*99***1#",   "any",    "any" },		
		{"46000", 0, -1, -1, "GSM",      	   "China Mobile",  "cmnet",                  "*99***1#",   "any",    "any" },
		{"46007", -1, -1, -1, "TD-SCDMA",      "China Mobile",  "cmnet",                  "*99***1#",   "any",    "any" },
		{"46002", -1, -1, -1, "TD-SCDMA",      "China Mobile",  "cmnet",                  "*99***1#",   "any",    "any" },
		
		/*spanish*/

		/*given by Telerforica's Antonio, but in the internet, 21401 is the code of  Vodafone*/
		{"21401", -1, -1, -1, "WCDMA",   "Vodafone",          "movistar.es", "*99#",    "movistar",               "movistar" },

		{"21403", -1, -1, -1, "WCDMA",   "Orange",           "internet",            "*99#",   "",         "" },
		{"21406", -1, -1, -1, "WCDMA",   "Vodafone",        "ac.vodafone.es",  "*99#",   "vodafone",                 "vodafone" },

		/*confirmed*/
		{"21407", -1, -1, -1, "WCDMA",   "Vodafone",        "movistar.es",        "*99#",   "MOVISTAR",               "MOVISTAR" },

		{"21409", -1, -1, -1, "WCDMA",	  "Orange ES",	     "internet",	"*99#", "CLIENTE", "AMENA"},
		{"21404", -1, -1, -1, "WCDMA",    "YOIGO ES", "Internet", "*99#", "user", "pass"},
		{"21408", -1, -1, -1, "WCDMA",    "Euskaltel ES", "internet.euskaltel.mobi", "*99#", "CLIENTE", "EUSKALTEL"},
		{"21416", -1, -1, -1, "WCDMA",    "Telecable ES", "internet.telecable.es", "*99#", "telecable", "telecable"},
		{"21417", -1, -1, -1, "WCDMA",    "mundo", "internet.mundo-r.com", "*99#", "user", "pass"},
		{"21418", -1, -1, -1, "WCDMA",    "Ono ES", "internet.ono.com", "*99#", "user", "pass"},
		{"21419", -1, -1, -1, "WCDMA",    "Simyo ES", "gprs-service.com", "*99#", "user", "pass"},



		{"20201", -1, -1, -1, "WCDMA",    "GR COSMOTE", "internet", "*99#", "user", "pass"},
		{"20205", -1, -1, -1, "WCDMA",    "VODAFONE GR", "internet.vodafone.gr", "*99#", "user", "pass"},
		{"20209", -1, -1, -1, "WCDMA",    "WIND GR", "gint.b-online.gr", "*99#", "web", "web"},
		{"20210", -1, -1, -1, "WCDMA",    "WIND GR", "gint.b-online.gr", "*99***1#",  "web", "web"},





		/*confirmed 2011-3-23*/
		/*Chile teleforica*/
		{"73001", -1, -1, -1, "WCDMA",    "Entel", "imovil.entelpcs.cl", "*99#", "entelpcs", "entelpcs"},
		{"73002", -1, -1, -1, "WCDMA",    "Telefonica", "web.tmovil.cl", "*99#", "web", "web"},
		{"73003", -1, -1, -1, "WCDMA",    "Claro", "bam.clarochile.cl", "*99#", "clarochile", "clarochile"},




		
		/*Brazil*/
		{"72405", -1, -1, -1, "WCDMA",    "Claro", "bandalarga.claro.com.br", "*99***1#",  "claro", "claro"},

		{"72407", -1, -1, -1, "WCDMA",    "CTBC", "ctbc.br", "*99#",  "ctbc", "1212"},
		{"72432", -1, -1, -1, "WCDMA",    "CTBC", "ctbc.br", "*99#",  "ctbc", "1212"},
		{"72433", -1, -1, -1, "WCDMA",    "CTBC", "ctbc.br", "*99#",  "ctbc", "1212"},
		{"72434", -1, -1, -1, "WCDMA",    "CTBC", "ctbc.br", "*99#",  "ctbc", "1212"},

		{"72402", -1, -1, -1, "WCDMA",    "TIM", "tim.br", "*99#",  "tim", "tim"},
		{"72403", -1, -1, -1, "WCDMA",    "TIM", "tim.br", "*99#",  "tim", "tim"},
		{"72404", -1, -1, -1, "WCDMA",    "TIM", "tim.br", "*99#",  "tim", "tim"},
		{"72408", -1, -1, -1, "WCDMA",    "TIM", "tim.br", "*99#",  "tim", "tim"},

		{"72431", 0, -1, -1, "GSM",    "Oi", "gprs.oi.com.br", "*99#",  "", ""},

		{"72406", -1, -1, -1, "WCDMA",    "Vivo", "zap.vivo.com.br", "*99#",  "vivo", "vivo"},
		{"72410", -1, -1, -1, "WCDMA",    "Vivo", "zap.vivo.com.br", "*99#",  "vivo", "vivo"},
		{"72411", -1, -1, -1, "WCDMA",    "Vivo", "zap.vivo.com.br", "*99#",  "vivo", "vivo"},
		{"72423", -1, -1, -1, "WCDMA",    "Vivo", "zap.vivo.com.br", "*99#",  "vivo", "vivo"},

		{"72415", -1, -1, -1, "WCDMA",    "Sercomtel", "sercomtel.com.br", "*99#",  "sercomtel", "sercomtel"},		


		/**Russion, confirmed*/
		{"25001", -1, -1, -1, "WCDMA",    "mts", "internet.mts.ru", "*99#",  "mts", "mts"},		

		/*scb+ 2012-2-24  confirmed at Pakistan*/
		{"41051", -1, -1, -1, "EVDO",    "41051", "any", "#777",  "vwireless@ptcl.com", "ptcl"},
};

static provider_t prv_default = {"default", -1, 0, 0, "Auto", "default",   "internet","*99#", "", ""};

int modem_search_provider(modem_t *mdm, provider_t **prd)
{
	int i = 0, j = 0;

	__modem_t *__mdm = 0;

	d_printf("enter\n");

	__mdm = GET_PRI(mdm, __modem_t);

	//if (!__mdm->provider_code[0])
	//	modem_get_prd(mdm, 0);

	j = sizeof(providers)/sizeof(providers[0]);

	/*provider_code, id match */
	for (i = 0; i < j; i++) {
		if ( !strcmp(__mdm->provider_code, providers[i].provider_code) 
			&& (mdm->idProduct == providers[i].idProduct 
				&& mdm->idVendor== providers[i].idVendor) ) {			
				*prd = &providers[i];
				return 0;
		}				
	}
	
	/*provider_code, act match*/
	for (i = 0; i < j; i++) {		
		if ( !strcmp(__mdm->provider_code, providers[i].provider_code)
            && (__mdm->act == providers[i].act)) {         
				*prd = &providers[i];
				return 0;
		}				
	}

	/*provider_code match*/
	for (i = 0; i < j; i++) {		
		if ( !strcmp(__mdm->provider_code, providers[i].provider_code) ) {			
				*prd = &providers[i];
				return 0;
		}				
	}	

	/*id  match*/
	for (i = 0; i < j; i++) {		
		if (mdm->idProduct == providers[i].idProduct
			&& mdm->idVendor== providers[i].idVendor) {			
				*prd = &providers[i];
				return 0;
		}				
	}	
	
	d_printf("Use the default provide's param\n");
	*prd  = &prv_default;
	return -1;
}

int modem_get_tty_port(modem_t *mdm, char **ports)
{
	if (mdm->status != SEARCH_FINISHED) {		
		*ports = 0;
		return -1;
	}

	*ports = GET_PRI(mdm, __modem_t)->ctrl_tty;
	return 0;		
}

static void chang_ctrl_tty(modem_t *mdm)
{
	int i;
	char tty[MNGR_MODEM_LEN_TTY_PATH+1] = {0};
	__modem_t *__mdm;

    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return 0;
    }

	__mdm = GET_PRI(mdm, __modem_t);

	if (!__mdm->ip_tty[0]) 
		return;

	if (strcmp(__mdm->ip_tty, __mdm->ctrl_tty) != 0) {
		d_printf("The crtl tty is not the same as the ip tty, "
			" need not been changed\n");
		return;
	}

	d_printf("The crtl tty is the same as the ip tty,"
		"check if is needed to changed\n");

	/*check the ctrl tty if is the poin out one*/
	if (get_tty_by_at(mdm, AT_CTL_TTY, tty, MNGR_MODEM_LEN_TTY_PATH) > 0 &&
			strcmp(tty, __mdm->ctrl_tty) == 0) {
		d_printf("The ctrl tty is point out by config file, "
			"can not been changed\n");
		return;
	}
	
	/*ctrl_tty and ip_tty is the same*/
	for (i = 0; __mdm->tty_cache[i][0]; i++) {
		if (strcmp(__mdm->ip_tty, __mdm->tty_cache[i]) != 0) {
			if (at_set_tty(MN(mdm)->at, __mdm->tty_cache[i]) == 0) {
				strcpy(__mdm->ctrl_tty, __mdm->tty_cache[i]);
				d_printf("ctrl_tty chage to %s\n", __mdm->ctrl_tty);
				return;
			} else 
				d_printf("ERROR at set ctrl tty!!! %s\n", __mdm->tty_cache[i]);
		}
	}

	/*only one tty*/
	d_printf("only one tty, let the ctrl and data tty as the same %s\n", __mdm->ctrl_tty);
	at_set_tty(MN(mdm)->at, __mdm->ctrl_tty);
	
}

int modem_set_ip_port(modem_t *mdm, char *port)
{
	int i;
	int find = 0;
	__modem_t *__mdm;


	if (!port)
		return -1;

	__mdm = GET_PRI(mdm, __modem_t);	

	for (i = 0; port && __mdm->tty_cache[i][0]; i++) {
		if (strcmp(port, __mdm->tty_cache[i]) == 0) {
			find = 1;
			break;
		}
	}

	if (!find ) {
		d_printf("port is not the tty belong to modem\n");
		return -1;
	}

	strcpy(__mdm->ip_tty, port);

	chang_ctrl_tty(mdm);

	
	return 0;	
}

static int get_ip_port_by_at(modem_t *mdm)
{
#if 1
	char tty[MNGR_MODEM_LEN_TTY_PATH+1] = {0};	
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);


	if (get_tty_by_at(mdm, AT_IP_TTY, tty, MNGR_MODEM_LEN_TTY_PATH) <= 0) {
		d_printf("Not find valid AT_IP_TTY at config file\n");
		return 0;
	}
	snprintf(__mdm->ip_tty, MNGR_MODEM_LEN_TTY_PATH, "%s", tty);
	
	chang_ctrl_tty(mdm);
	
	if (access(__mdm->ip_tty, F_OK) != 0)
		printf_3g("", "***ERROR:tty %s not exist\n", __mdm->ip_tty);
	
	return 1;
#else	
	int i = 0;
	int ttyindex = 0;
	char iptty[AT_CMD_LEN] = {0};
	__modem_t *__mdm;

	__mdm = GET_PRI(mdm, __modem_t);

	at_get_item(MN(mdm)->at, AT_IP_TTY, iptty, AT_CMD_LEN);
	

	if (!iptty[0])
		return 0;

	if (!strstr(iptty, "ttyUSB") && !strstr(iptty, "ttyACM")) {
		
		ttyindex = strtoul(iptty, 0, 10);

		if (!__mdm->tty_cache[ttyindex][0]) {
			
			printf_3g("", "***ERROR:No. %d tty no exist, the tty index too larger\n",   ttyindex);
			return 0;
			
		} else		
			snprintf(iptty, sizeof(iptty), "%s", __mdm->tty_cache[ttyindex]);
		
	}


	
	for (i = 0; __mdm->tty_cache[i][0]; i++) {
		if (strstr(__mdm->tty_cache[i], iptty)) {
			strcpy(__mdm->ip_tty, __mdm->tty_cache[i]);
			chang_ctrl_tty(mdm);
			return 1;
		}
	}

	printf_3g("", "***WARNNING:the point out tty %s is not valid, it can not support AT\n",
		iptty);

	snprintf(__mdm->ip_tty, sizeof(__mdm->ip_tty), "/var/dev/%s",  iptty);

	if (access(__mdm->ip_tty, F_OK) != 0)
		printf_3g("", "***ERROR:tty %s not exist\n", __mdm->ip_tty);
	
	return 1;	
#endif	
}

int modem_get_ip_port(modem_t *mdm, char **port)
{
	int ret = 0;
	__modem_t *__mdm;

	__mdm = GET_PRI(mdm, __modem_t);
	
	if (__mdm->ip_tty[0]) {
		d_printf("ip tty have been select\n");
		ret =  1;
		goto end;
	}
		
	if (get_ip_port_by_at(mdm) > 0) {
		d_printf("point out ip tty %s at configure file\n", __mdm->ip_tty);
		ret =  1;
		goto end;
	}
	
	d_printf("not point out ip tty  at configure file\n");
#ifdef FIND_TTY_PORT_BY_INT_EP
	int i;
	for ( i = 0; __mdm->tty_cache[i][0]; i++) {
		if (lib3g_have_int_ep(__mdm->tty_cache[i])) {
			strcpy(__mdm->ip_tty, __mdm->tty_cache[i]);
			chang_ctrl_tty(mdm);
			ret =  1;
			goto end;
		}
	}
#endif


end:

	if (port)
		*port = __mdm->ip_tty;

	if (ret != 1)
		d_printf("can not get ip tty\n");
	
	return ret;
	
}

int modem_set_ctrl_port(modem_t *mdm, char *port)
{
	if (!mdm || !port) {
		d_printf("parameter error\n");
		return -1;
	}

	if (!MN(mdm)->at) {
		d_printf("not set at\n");
		return -1;
	}

	strcpy(GET_PRI(mdm, __modem_t)->ctrl_tty, port);
	
	return at_set_tty(MN(mdm)->at, port);	
}

int modem_get_ctrl_port(modem_t *mdm, char **port)
{
	if (!mdm || !port) {
		d_printf("parameter error\n");
		return -1;
	}

	*port = GET_PRI(mdm, __modem_t)->ctrl_tty;

	return 0;
}

int modem_clr_reg_info(modem_t *mdm)
{
	d_printf("enter\n");
	
	GET_PRI(mdm, __modem_t)->reginfo[0] = 0;
	return 0;
}

int modem_set_reg_info(modem_t *mdm, const char *reginfo)
{
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);

	strncpy(__mdm->reginfo,  reginfo, sizeof(__mdm->reginfo) - 1);
	d_printf("set reginfo to %s\n", __mdm->reginfo);

	return 0;
}

int modem_set_pin_info(modem_t *mdm, const char *pininfo)
{
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);

	strncpy(__mdm->pininfo,  pininfo, sizeof(__mdm->pininfo) - 1);
	d_printf("set pininfo to %s\n", __mdm->pininfo);

	return 0;
}

/**********access at ***********************************/
int modem_get_reg_info(modem_t *mdm, char **info)
{
	char s[4] = {0};
	__modem_t *__mdm = 0;
    int is_lte_reged = 0;

    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return -1;
    }

	__mdm = GET_PRI(mdm, __modem_t);

	if (mdm->status != SEARCH_FINISHED) {
		d_printf("modem not init\n");
		return -1;
	}

    if (at_item_get_and_check_exist(MN(mdm)->at, AT_GET_REG_LTE, 0, 0) &&
        (at_do_cmd(MN(mdm)->at, AT_GET_REG_LTE, 1, AT_GET_REG_PATTN, s, sizeof(s) - 1) != -1))
    {
        d_printf("lte reg = %s\n", s);
        record_3g("lte reg = %s\n", s);
        if ((*s == '1') ||(*s == '5') || (*s == '6'))
        {
            d_printf("lte reg ok\n");
            is_lte_reged = 1;
        }
    }

    if (!is_lte_reged)
    {
	if (!at_item_get_and_check_exist(MN(mdm)->at, AT_GET_REG, 0, 0)) {
		d_printf("No AT_GET_REG cmd,ignore to get the reg info\n");
		strcpy(__mdm->reginfo, REG_INFO_INGNORE);
		goto end;
	}

	if (at_do_cmd(MN(mdm)->at, AT_GET_REG, 1, AT_GET_REG_PATTN, s, sizeof(s) - 1) == -1) {
		d_printf("AT_GET_REG_PATTN failure!\n");
		modem_proccess_at_error(mdm, s);
		return -1;
	}
	record_3g("2g/3g reg = %s\n", s);
	}

	/* the result:
	0 not registered, ME is not currently searching a new operator to register to
	1 registered, home network
	2 not registered, but ME is currently searching a new operator to register to
	3 registration denied
	4 unknown
	5 registered, roaming
	*/

	switch(*s) {
		case '0':
		{
			strcpy(__mdm->reginfo, REG_INFO_NOT_REG); 
			lib3g_send_mobile_chage_msg(REG_INFO_NOT_REG);
			break;
		}
		case  '1':
        {
			strcpy(__mdm->reginfo, REG_INFO_REG_LOCAL);
            lib3g_send_mobile_chage_msg(REG_INFO_REG_LOCAL);	
            break;
        }
		case  '2':
		{
			strcpy(__mdm->reginfo, REG_INFO_SEARCH );
			lib3g_send_mobile_chage_msg(REG_INFO_SEARCH);
			break;
		}
		case  '3':
		{
			strcpy(__mdm->reginfo, REG_INFO_REG_DENY);
			lib3g_send_mobile_chage_msg(REG_INFO_REG_DENY);				
			break;
		}
		case  '4':
		{
			strcpy(__mdm->reginfo, REG_INFO_UNKOWN); 
//			lib3g_send_mobile_chage_msg(REG_INFO_UNKOWN);				
			break;
		}
		case  '5':
        {
			strcpy(__mdm->reginfo, REG_INFO_REG_ROAM);
            lib3g_send_mobile_chage_msg(REG_INFO_REG_ROAM);	
            break;
        }
		default:break;
	}

end:
	d_printf("REG:[%s]\n", __mdm->reginfo);

	if (info)
		*info = __mdm->reginfo;
	
	return 0;

}

static int modem_proccess_at_error(modem_t *mdm, const char *s)
{
    int err_no = 0;
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);
	d_printf("s = %s\n", s);
	if (strstr(s, "SIM PIN"))
		strcpy(__mdm->pininfo, PIN_INFO_PIN);
	else if (strstr(s, "SIM PUK"))
		strcpy(__mdm->pininfo, PIN_INFO_PUK);
	/*ignore this pin style*/
	else if (strstr(s, "failure"))
		strcpy(__mdm->pininfo, PIN_INFO_INVALID);
	else if (strtoul(s, 0, 10) > 0) {
		char *err_str;

		err_str = lib3g_at_strerror(s, &err_no);

		d_printf("result=[%s], err_str=[%s], err_no=%d\n", s, err_str, err_no);

		if (err_no == 10 || (err_no >= 13 && err_no <=18))
			strcpy(__mdm->pininfo, PIN_INFO_INVALID);
		else if (err_no == 11)
			strcpy(__mdm->pininfo, PIN_INFO_PIN);
		else if (err_no == 12)
			strcpy(__mdm->pininfo, PIN_INFO_PUK);	
	}

    return err_no;
}

int modem_set_cmee_to_numeric(modem_t *mdm)
{
    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return -1;
    }

	return at_do_cmd(MN(mdm)->at, AT_SET_CMEE_TO_NUM_MODE , 
		0, AT_NONE, 0, 0);
}

int modem_get_pin_info(modem_t *mdm, char **info)
{
	char s[80] = {0};
	__modem_t *__mdm = NULL;
	int err_no = 0;

    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return -1;
    }
    
    __mdm = GET_PRI(mdm, __modem_t);

	if (at_do_cmd(MN(mdm)->at, AT_GET_PIN, 3, 
				AT_GET_PIN_PATTN, s, sizeof(s) - 1) != 0)  {
		d_printf("Can not get pin info\n");
		strcpy(__mdm->pininfo, PIN_INFO_INVALID);
		
		if (info)
			*info = __mdm->pininfo;
		
		return -1;
	}
	
	/* the result:
		READY ME is not pending for any password
		SIM PIN ME is waiting SIM PIN to be given
		SIM PUK ME is waiting SIM PUK to be given
		PH-SIM PIN ME is waiting phone-to-SIM card password to be given
		PH-FSIM PIN ME is waiting phone-to-very first SIM card password to be given
		PH-FSIM PUK ME is waiting phone-to-very first SIM card unblocking password to be given
		SIM PIN2 ME is waiting SIM PIN2 to be given (this <code> is recommended to be returned only when the
		last executed command resulted in PIN2 authentication failure (i.e. +CME ERROR: 17); if PIN2
		is not entered right after the failure, it is recommended that ME does not block its operation)
		SIM PUK2 ME is waiting SIM PUK2 to be given (this <code> is recommended to be returned only when the
		last executed command resulted in PUK2 authentication failure (i.e. +CME ERROR: 18); if
		PUK2 and new PIN2 are not entered right after the failure, it is recommended that ME does not
		block its operation)
		PH-NET PIN ME is waiting network personalisation password to be given
		PH-NET PUK ME is waiting network personalisation unblocking password to be given
		PH-NETSUB PIN ME is waiting network subset personalisation password to be given
		PH-NETSUB PUK ME is waiting network subset personalisation unblocking password to be given
		PH-SP PIN ME is waiting service provider personalisation password to be given
		PH-SP PUK ME is waiting service provider personalisation unblocking password to be given
	*/

	d_printf("pin info, result:%s\n", s);

	if (strstr(s, "READY"))
		strcpy(__mdm->pininfo, PIN_INFO_READY);
	else 
		err_no = modem_proccess_at_error(mdm, s);

	if (info)
		*info = __mdm->pininfo;

	if (err_no == 14) {
		d_printf("sim busy\n");
		return -14;
	} else	
		return 0;
}

/**
* scb+ 2012-3-10 for get pin retry times
* @type: 
*	pin,puk,pin_change,lock_change
*/
int modem_get_lock_retry_time(modem_t *mdm, const char *type, 
							int need_up_date)
{
	__modem_t *__mdm = 0;
	if (!mdm)
		return -1;
	
	__mdm = GET_PRI(mdm, __modem_t);

	if (need_up_date) {		
		__mdm->pin_retry_time = modem_set_pin_retry_t(mdm);
		d_printf("pin retry time:%d\n", __mdm->pin_retry_time);

		__mdm->puk_retry_time = modem_set_puk_retry_t(mdm);
		d_printf("pukretry time:%d\n", __mdm->pin_retry_time);

		__mdm->pin_chg_retry_time = modem_chg_pin_retry_t(mdm);	
		d_printf("chang pin  retry time:%d\n", __mdm->pin_chg_retry_time);

		__mdm->lock_chg_retry_time = modem_set_lock_retry_t(mdm);
		d_printf("enable/disable lock  retry time:%d\n", 
			__mdm->lock_chg_retry_time);		
	}

	if (type && strcmp(type, "pin") == 0)
		return __mdm->pin_retry_time;
	if (type && strcmp(type, "puk") == 0)
		return __mdm->puk_retry_time;
	if (type && strcmp(type, "pin_change") == 0)
		return __mdm->pin_chg_retry_time;
	if (type && strcmp(type, "lock_change") == 0)
		return __mdm->lock_chg_retry_time;

	return -1;	
}

int modem_get_lock_info(modem_t *mdm, char **info)
{
	char s[4] = {0};
	__modem_t *__mdm = 0;

	if (!mdm)
		return -1;

	__mdm = GET_PRI(mdm, __modem_t);

	if (at_do_cmd(MN(mdm)->at, AT_GET_LOCK, 1, 
			AT_GET_LOCK_PATTN, s, sizeof(s) - 1) != 0) {
		d_printf("AT_GET_LOCK_PATTN failure!");
		return -1;	
	}
	
	if (s[0] == '0')
		strncpy(__mdm->lockinfo, LOCK_INFO_UNLOCK, sizeof(__mdm->lockinfo));
	else if (s[0] == '1')
		strncpy(__mdm->lockinfo, LOCK_INFO_LOCK, sizeof(__mdm->lockinfo));

	if (info)
		*info = __mdm->lockinfo;
	
	return 0;	
}

/*pin mngr */
int modem_set_pin(modem_t *mdm)
{
	char pin[12] = {0};
    
	if (!mdm)
		return -1;

	param_get_item(MN(mdm)->par, "pin", pin);
	if (pin[0])
		at_do_cmd(MN(mdm)->at, AT_SET_PIN, 0, AT_NONE, 0, 0);
	else
		d_printf("no pin code");

	return 0;
}

/*get the remain times for setting pin code */
int modem_set_pin_retry_t(modem_t *mdm)
{		
	char rb[10] = {0};
    
	if (!mdm)
		return -1;	
	at_do_cmd(MN(mdm)->at, AT_SET_PIN_RETRY_T, 1, 
		AT_SET_PIN_RETRY_T_PATTN, rb, sizeof(rb) - 1);
	return strtoul(rb, 0, 10);	
}

int modem_set_puk(modem_t *mdm)
{
	char pin[12] = {0};
	char puk[12] = {0};

	if (!mdm)
		return -1;	
    
	param_get_item(MN(mdm)->par, "pin", pin);
	param_get_item(MN(mdm)->par, "puk", puk);
	
	if (puk[0] && pin[0])
		at_do_cmd(MN(mdm)->at, AT_SET_PUK, 0, AT_NONE, 0, 0);
	else
		d_printf("no puk code or no pin\n");

	return 0;
}

int modem_set_puk_retry_t(modem_t *mdm)
{
	char rb[10] = {0};

	if (!mdm)
		return -1;	
    
	at_do_cmd(MN(mdm)->at, AT_SET_PUK_RETRY_T, 1, 
		AT_SET_PUK_RETRY_T_PATTN, rb, sizeof(rb) - 1);
	return strtoul(rb, 0, 10);	
}
	

int modem_set_lock(modem_t *mdm)
{
	char lock[12] = {0};
	char pin[12] = {0};
    
	if (!mdm)
		return -1;	

	param_get_item(MN(mdm)->par, "pin", pin);
	param_get_item(MN(mdm)->par, "lock", lock);
	
	if (!(lock[0] == '0') && !(lock[0] == '1')) {
		d_printf("param error:lock=%s\n", lock);
		return 0;
	}

	if (!pin[0]) {
		d_printf("no pin code\n");
		return 0;
	}

	return at_do_cmd(MN(mdm)->at, AT_SET_LOCK, 0, AT_NONE, 0, 0);
}

int modem_set_lock_retry_t(modem_t *mdm)
{
	char rb[10] = {0};

	if (!mdm)
		return -1;	
    
	at_do_cmd(MN(mdm)->at, AT_SET_LOCK_RETRY_T, 1, 
		AT_SET_LOCK_RETRY_T_PATTN, rb, sizeof(rb) - 1);
	return strtoul(rb, 0, 10);
}

int modem_chg_pin(modem_t *mdm)
{
	char pin[12] = {0};
	char newpin[12] = {0};

	if (!mdm)
		return -1;	
    
	param_get_item(MN(mdm)->par, "pin", pin);
	param_get_item(MN(mdm)->par, "newpin", newpin);
	
	if (!pin[0] || !newpin[0]) {
		d_printf("param error:pin=%s, newpin=%s", pin, newpin);
		return 0;
	}
	
	return at_do_cmd(MN(mdm)->at, AT_CHG_PIN, 0, AT_NONE, 0, 0) ;
}

int modem_chg_pin_retry_t(modem_t *mdm)
{
	char rb[10] = {0};
    
	if (!mdm)
		return -1;	
    
	at_do_cmd(MN(mdm)->at, AT_CHG_RETRY_T, 1, 
		AT_CHG_RETRY_T_PATTN, rb, sizeof(rb) - 1);
	return strtoul(rb, 0, 10);
}
/*end pin mngr port*/

static void modem_init_nt(__modem_t *__mdm)
{
	int i;
	
	if (!__mdm->nt[0]) {
		for (i = 0; i < sizeof(providers)/sizeof(providers[0]); i++) {
			if (strstr(providers[i].provider_code, __mdm->provider_code)) {
				strncpy(__mdm->nt, providers[i].nt, sizeof(__mdm->nt));
				break;
			}
		}
	}
}

int modem_get_prd(modem_t *mdm, char **prd)
{
	int ret = 0;
	__modem_t *__mdm;
    char rbuf[128] = {0};
    char act[12] = {0};

	d_printf("To Get provider\n");

	if (!mdm)
		return -1;	

	__mdm = GET_PRI(mdm, __modem_t);
	
	if (modem_reg_is_ready(mdm)) {
		if (!__mdm->provider_code[0])
			if ((ret = at_do_cmd(MN(mdm)->at, 	AT_GET_PRVDR, 1, 
					0, rbuf,
					sizeof(rbuf) - 1)) == 0) 
			{
	            at_parse(MN(mdm)->at, AT_GET_PRVDR_PATTN, 
                            rbuf, __mdm->provider_code, sizeof(__mdm->provider_code) - 1);
	            at_parse(MN(mdm)->at, AT_GET_ACT_PATTN, rbuf, act, sizeof(act) - 1);
                d_printf("act = %s\n", act);
                if (act[0])
                {
                    __mdm->act = atoi(act);
                }   			
				modem_init_nt(__mdm);
			}

		if (!__mdm->provider_code[0]) {
			modem_get_imsi(mdm, 0);
			if (__mdm->imsi[0]) {
				strncpy(__mdm->provider_code, __mdm->imsi, 5);
				__mdm->provider_code[5] = 0;
				/*twsh wanghaitao add*/
				memset(__mdm->nt, 0, sizeof(__mdm->nt));
				modem_init_nt(__mdm);
				/*twsh wanghaitao add end*/ 
				
			}
		}
	}

	/**
	* scb+ 2012-2-18 set the invalid provider code
	* to prohibit doing this action
	**/
	if (!__mdm->provider_code[0]) {
		printf_3g("", "Can not get provider code\n");
		__mdm->provider_code[0] = 9;
		__mdm->provider_code[1] = 9;
	}

	d_printf("The provider coder:[%s], act[%d]\n", __mdm->provider_code, __mdm->act);
		
	if (prd)
		*prd = __mdm->provider_code;
	
	return ret;		
}

int modem_get_csq(modem_t *mdm, struct csq  **csq)
{
	int ssi = 0;
	char rbuf[128] = {0};	
	char rbuf1[128] = {0};	
	char rssi[80] = {0}, ber[32] = {0};
	__modem_t *__mdm;	

	d_printf("start to do 	cdma_at_get_csq\n");	

	if (!mdm)
		return -1;	

	__mdm = GET_PRI(mdm, __modem_t);		

		
	if (at_do_cmd(MN(mdm)->at, AT_GET_CSQ, 0, 0, rbuf, sizeof(rbuf) - 1) != 0) {
		d_printf("do AT_GET_CSQ failure!\n");
		return -1;
	}

	strcpy(rbuf1, rbuf);

	/*the resul:[at+csq\r\r\r+CSQ: 17,99\r\r\r\rOK\r\r] */

	at_parse(MN(mdm)->at, AT_GET_CSQ_RSSI_PATTN, rbuf, rssi, sizeof(rssi) - 1);

	at_parse(MN(mdm)->at, AT_GET_CSQ_BER_PATTN, rbuf, ber, sizeof(ber) - 1);

	d_printf("rssi=%s, ber=%s\n", rssi, ber);
	if (!rssi[0] || !ber[0]) {
		d_printf("error\n");
		return 0;
	}

	ssi = strtoul(rssi, 0, 0);
	if (ssi == 99)
		snprintf(__mdm->csq.rssi, sizeof(__mdm->csq.rssi), "unknown");
	else
		snprintf(__mdm->csq.rssi, sizeof(__mdm->csq.rssi),"%ddBm", -(113-ssi*2));
	if (strtoul(ber, 0, 0) != 99)
		snprintf(__mdm->csq.ber, sizeof(__mdm->csq.ber), "%d", (int)strtoul(ber, 0, 0));
	else 
		snprintf(__mdm->csq.ber,sizeof(__mdm->csq.ber),  "unknown");

	if (csq)
		*csq = &(__mdm->csq);
	
	return 0;
}
int modem_get_csq_for_check(modem_t *mdm, int *csq)
{
	char rbuf[128] = {0};	
	char rssi[80] = {0};
    char *pnegative = NULL;
    char tmp[80] = {0};

	d_printf("start to do 	cdma_at_get_csq\n");			

	if (!mdm)
		return -1;	
		
	if (at_do_cmd(MN(mdm)->at, AT_GET_CSQ, 0, 0, rbuf, sizeof(rbuf) - 1) != 0) {
		d_printf("do AT_GET_CSQ failure!\n");
		return -1;
	}
    //strcpy(rbuf, "\n\r+csq: -98,100\n\rOK\n\r");
    pnegative = strstr(rbuf, "-");  /* ����lte��˵���ź�û��ת�����Ǹ��� */
	/*the resul:[at+csq\r\r\r+CSQ: 17,99\r\r\r\rOK\r\r] */

	at_parse(MN(mdm)->at, AT_GET_CSQ_RSSI_PATTN, rbuf, rssi, sizeof(rssi) - 1);

	d_printf("rssi=%s\n", rssi);
	if (!rssi[0]) {
		d_printf("error\n");
		return -1;
	}

    if (pnegative)
    {
        sprintf(tmp, "-%s", rssi);
	    *csq = atoi(tmp);
    }
    else
        *csq = atoi(rssi);
    d_printf("%s:rssi = %s, csq = %d\n", __func__, tmp, *csq);
    if (*csq < 0)
    {
        if (*csq < -123)
            *csq = 99;
        else if ((*csq >= -123) && (*csq < -118))
            *csq = 3;
        else if ((*csq >= -118) && (*csq < -114))
            *csq = 9;
        else if ((*csq >= -114) && (*csq < -107))
            *csq = 12;
        else if (*csq >= -107)
            *csq = 18;
    }
    if (*csq > 99)
        *csq = 99;
	
	return 0;
}

int modem_get_reg_for_check(modem_t *mdm)
{
	char s[4] = {0};
	__modem_t *__mdm = 0;
    int is_lte_reged = 0;

	if (!mdm)
		return -1;	

	__mdm = GET_PRI(mdm, __modem_t);

	if (mdm->status != SEARCH_FINISHED) {
		d_printf("modem not init\n");
		return -1;
	}

    if (at_item_get_and_check_exist(MN(mdm)->at, AT_GET_REG_LTE, 0, 0) &&
        (at_do_cmd(MN(mdm)->at, AT_GET_REG_LTE, 1, AT_GET_REG_PATTN, s, sizeof(s) - 1) != -1))
    {
        d_printf("lte reg = %s\n", s);
        if ((*s == '1') ||(*s == '5'))
        {
            d_printf("lte reg ok\n");
            is_lte_reged = 1;
        }
    }

    if (!is_lte_reged)
    {
    	if (!at_item_get_and_check_exist(MN(mdm)->at, AT_GET_REG, 0, 0)) {
    		d_printf("No AT_GET_REG cmd,ignore to get the reg info\n");
            return 0;
    	}

    	if (at_do_cmd(MN(mdm)->at, AT_GET_REG, 1, AT_GET_REG_PATTN, s, sizeof(s) - 1) == -1) {
    		d_printf("AT_GET_REG_PATTN failure!\n");
    		return -1;
    	}
    }

	/* the result:
	0 not registered, ME is not currently searching a new operator to register to
	1 registered, home network
	2 not registered, but ME is currently searching a new operator to register to
	3 registration denied
	4 unknown
	5 registered, roaming
	*/

	switch(*s) {
		case  '1':
		case  '5':
			return (*s - '0');
		default:break;
	}
    
	return -1;
}

#define MODEM_GET_INFO(cmd, pattn, t, r, mdm, mdm_item)	\
	({	int ret = 0;	\
			\
		ret= at_do_cmd(MN(mdm)->at, cmd, \
				t, pattn, 				\
				mdm_item, 				\
				sizeof(mdm_item) - 1);		\
		if (r)			\
			*(r) = (mdm_item);		\
		ret;	\
	})

int modem_get_imsi(modem_t *mdm, char **imsi)
{
	return MODEM_GET_INFO(AT_GET_IMSI, AT_GET_IMSI_PATTN, 1,
				imsi,
				mdm,
				GET_PRI(mdm, __modem_t)->imsi);
}
	
int modem_get_imei(modem_t *mdm, char **imei)
{
	return MODEM_GET_INFO(AT_GET_IMEI, AT_GET_IMEI_PATTN,0,
				imei,
				mdm,
				GET_PRI(mdm, __modem_t)->imei);	
}
	
int modem_get_id(modem_t *mdm, char **identify)
{
	return MODEM_GET_INFO(AT_GET_ID, AT_GET_ID_PATTN, 1,
				identify,
				mdm,
				GET_PRI(mdm, __modem_t)->identify);
}

/*scb+ 2012-5-11 for getting cell id*/
int modem_get_ci(modem_t *mdm, char **ci)
{
	return MODEM_GET_INFO(AT_GET_CELLID, AT_GET_CELLID_PATTN, 1,
				ci,
				mdm,
				GET_PRI(mdm, __modem_t)->cellid);
}

/*scb+ 2012-5-11 for getting  location area code in hexadecimal format*/
int modem_get_lac(modem_t *mdm, char **lac)
{
	return MODEM_GET_INFO(AT_GET_LAC, AT_GET_LAC_PATTN, 1,
				lac,
				mdm,
				GET_PRI(mdm, __modem_t)->lac);
}

int modem_get_charge(modem_t *mdm, char **charge)
{
	return MODEM_GET_INFO(AT_GET_CHARGE, AT_GET_CHARGE_PATTN, 0,
				charge,
				mdm,
				GET_PRI(mdm, __modem_t)->charge);
}

int modem_hangup(modem_t *mdm)
{
	/*FIX me:some time, need to re-open the tty,otherwise write will failse*/
	if (!mdm)
		return -1;	

    if (strncmp(g_usb_dongle_ifname, "ppp" , sizeof("ppp")-1)){
        set_ndis_interface(0);
    }
	at_set_tty(MN(mdm)->at, GET_PRI(mdm, __modem_t)->ctrl_tty);
	
	return at_do_cmd(MN(mdm)->at, AT_HANGUP , 1, AT_NONE, 0, 0);
}

CDMG_FUNC(asyn_modem_hangup_end, 1, 1, 1, 0, 0, 0, 
		"The last part of modem_show_status()")
{
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;
	
	modem_t *mdm = mn->mdm;
	__modem_t *__mdm = GET_PRI(mdm, __modem_t);

	__mdm->do_at_hangup = 0;
	d_printf("hangup end\n");

	return 0;
}

void asyn_modem_hangup(modem_t *mdm)
{
	__modem_t *__mdm;	

	__mdm = GET_PRI(mdm, __modem_t);

	if (!mn || !mn->run_on_diald)
		return;

	if (__mdm->do_at_hangup)
		return;

	__mdm->do_at_hangup = 1;

	if (fork_3g() == 0) {
		modem_hangup(mdm);
		CDMG_SEND_MSG(asyn_modem_hangup_end, "%s", "");
		exit(0);
	}	
}

int modem_get_serial_id(modem_t *mdm, int *vid, int *pid)
{
	if (!mdm) 
		return -1;

	if (mdm->status != SEARCH_FINISHED)
		modem_search(mdm);

	if (vid)
		*vid = mdm->idVendor;
	if (pid)
		*pid = mdm->idProduct;

	return 0;		
}

/*****************************************************/


int modem_get_nt(modem_t *mdm, char **nt)
{
	if (nt)
		*nt = GET_PRI(mdm, __modem_t)->nt;

	return 0;	
}

/****************chat**********************/
static int  tty_chat(const char *tty)
{
#if 0
	int fd;
	int fd_out;
	int logfd;
	int ret = 0;

	/*open chat output file*/
	d_printf("create chat output file\n");
	CDMG_OPEN(logfd, open, O_RDWR|O_CREAT|O_TRUNC,
		MODEM_MNGR_CHAT_OUT_FILE, return -1;);

	CDMG_OPEN(fd, open, O_RDWR|O_CREAT|O_TRUNC, 
		tty, close(fd_out); return -1;);
	
	d_printf("try to chat %s\n", tty);

	if (is_debug()) {
		ret= lib3g_run_script("chat -f "CHAT_SCRIPT_PATH" -v -s", fd, fd, logfd);
	} else {
		logfd = open("/dev/null", O_RDWR);
		ret= lib3g_run_script("chat -f "CHAT_SCRIPT_PATH, fd, fd, logfd);
	}

	close(fd);
	close(logfd);

	/*output the log*/
#if defined(PC)
	fd_out 	= open("/proc/self/fd/1", O_RDWR);
#else
	fd_out 	= open("/dev/console", O_RDWR);
#endif
	if (fd_out >= 0) {
		logfd 	= open(MODEM_MNGR_CHAT_OUT_FILE, O_RDONLY);
		if (logfd >= 0) {
			char *buf = 0;

			/*maloc a buf*/
			CDMG_MALLOC(512, buf, buf = 0);

			/*output to user*/
			if (buf > 0) {
				read (logfd, buf, 511);
				write(fd_out, buf, strlen(buf));
				free(buf);
			}
			close(logfd);
		}

		close(fd_out);
	}
#else

	int ret = 0;
	pid_t *pids = 0;

	d_printf("try chat base on:%s\n", tty);

	if (is_3g_debug_local("/var/3g_debug_dial",DAIL_DEBUF_CONTR_FILE, 0, 0)) {
		ret = CDMG_DO_FUNC(chat, " --file=%s --tty=%s --log=%s ",  
			CHAT_SCRIPT_PATH,
			tty, 
			"/proc/self/fd/1");

	}
	else
		ret = CDMG_DO_FUNC(chat, " --file=%s --tty=%s --log=/var/3gppp/chat_log", 
				CHAT_SCRIPT_PATH,
				tty); 

	/*update the down stream rate*/
	if (mn && mn->mdm) {
		__modem_t *__mdm = GET_PRI(mn->mdm, __modem_t);
		if (ret >= 0)
			sprintf(__mdm->down_stream_rate, "%d", ret);
		else
			sprintf(__mdm->down_stream_rate, "unkown");
	}
	
#endif


	if (ret >= 0) {
		d_printf("chat success!\n");
		if ((pids = lib3g_find_pid_by_name("3g-mngr diald"))) {
			d_printf("tell diald chat success\n");
			CDMG_SEND_MSG(tty_chat_result, " --result=%d",  ret);
			free(pids);
		}
		return 0;
	}
	
	printf_3g("", "chat failse!\n");
	if ((pids = lib3g_find_pid_by_name("3g-mngr diald"))) {
		d_printf("tell diald chat fail\n");
		CDMG_SEND_MSG(tty_chat_result, " %s", " --result=-1");
		free(pids);
	}
	return -1;
}

/*
* receive the 'tty_chat' msg to upodate the downstream rate and 
* up stream rate
*/
static int modem_process_chat_result(int argc, char *argv[])
{
	char result[12] = {0};
	__modem_t  *__mdm = GET_PRI(mn->mdm, __modem_t);

	CDMG_GET_ARG("result", result);

	if (strstr(result, "-1")) {
		__mdm->down_stream_rate[0] = 0;
		d_printf("chat fail\n");
	}
	else {
		strcpy(__mdm->down_stream_rate, result);
		d_printf("chat success:%s\n", result);
	}
	
	return 0;	
}
__CDMG_SETUP_MSG(tty_chat_result, 0, 1, modem_process_chat_result, "");

/*
* used by pppd, if do lcp session, pppd send this msg to diald
* to chat.
* Why do so, is to get the down stream rate
* the 
*/
static int modem_ext_chat(int argc, char *argv[], char *rbuf, int rlen)
{
	char tty[80] = {0};

	CDMG_GET_ARG("tty", tty);
	d_printf("try to chat by %s\n", tty);

	tty_chat(tty);
	
	rbuf[0] = ' ';
	rbuf[1] = 0;

	return 2;
} 
__CDMG_SETUP_GET(connect_ext_chat, 1, modem_ext_chat, 1, 60, 
	"exmapl: connect_ext_chat  --tty=xxx")

int modem_try_chat(modem_t *mdm)
{
	int i = 0;
	__modem_t  *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);


	if (__mdm->ip_tty[0]  && !lib3g_is_support_at_cmd(__mdm->ip_tty)) {
		d_printf("%s  not support at, it is for ip!\n", __mdm->ip_tty);
		return 0;
	}

	if (__mdm->ip_tty[0]) 
		return tty_chat(__mdm->ip_tty);
	else {	
		for (i = 0; __mdm->tty_cache[i] && __mdm->tty_cache[i][0]; i++) {
			if (tty_chat(__mdm->tty_cache[i]) >= 0)
				return 0;
		}
	}

	d_printf("no tty can chat success.\n");
	
	return -1;
}

/*after connectted the tty for data will can not support AT cmd, so we find out such tty*/
static void modem_decide_data_tty(modem_t *mdm)
{
	int i;
	__modem_t *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);

	if (__mdm->ip_tty[0]) {
		
		d_printf("ip tty have been select %s\n", __mdm->ip_tty);		
		return;
		
	}

	for(i = 0; __mdm->tty_cache[i] && __mdm->tty_cache[i][0]; i++) {
		
		if (!lib3g_is_support_at_cmd(__mdm->tty_cache[i])) {		

			d_printf("IP PORT:%s not support AT, select it as IP port\n",
				__mdm->ip_tty);
			strcpy(__mdm->ip_tty, __mdm->tty_cache[i]);
			chang_ctrl_tty(mdm);	
			return;
			
		}
		
	}

	d_printf("can not find the tty for ip\n");
}

int modem_do_chat(modem_t *mdm, int is_demand_dial)
{
	int i = 0;
	__modem_t *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);

	if (modem_valid_check(mdm) != 0)
		return -1;	
	
	modem_get_ip_port(mdm, 0);

	if (!is_demand_dial || !__mdm->ip_tty[0]) {
		d_printf("try to chat\n");
		for (i= 0; i < 3; i++) {
			if ( modem_try_chat(mdm) == 0)
				break;
		}
	}

	d_printf("to select ip tty\n");
	modem_decide_data_tty(mdm);

	if (__mdm->ip_tty[0])
		return 0;
	
	printf_3g("", "No tty to dial\n");
	return -1;
}

/**************end chat*********************************/


int modem_pin_is_ready(modem_t *mdm)
{	
	__modem_t *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);
	
	if (strlen(__mdm->pininfo) && !strstr(__mdm->pininfo, PIN_INFO_READY)) {
		d_printf("%s", __mdm->pininfo);
		return 0;
	}

	return 1;
}

int modem_reg_is_ready(modem_t *mdm)
{
	__modem_t *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);
	if (strstr(__mdm->reginfo, REG_INFO_NOT_REG) || 
		strstr(__mdm->reginfo, REG_INFO_SEARCH) || 
		strstr(__mdm->reginfo, REG_INFO_NOT_FIND) || 
		strstr(__mdm->reginfo, REG_INFO_REG_DENY) ||
		strstr(__mdm->reginfo, REG_INFO_SEARCH_START)||
		strstr(__mdm->reginfo, REG_INFO_UNKOWN)) {
			d_printf("%s\n", __mdm->reginfo);
			return 0;
	}
	else
		return 1;
		
}

int modem_is_ready(modem_t *mdm)
{
	if (mdm->status != SEARCH_FINISHED)
		return 0;	

	if (!modem_pin_is_ready(mdm))
		return 0;

	if (!modem_reg_is_ready(mdm))
		return 0;

	return 1;
}

/* only use for NO TTY dongle */
void modem_set_ready(modem_t *mdm)
{
	modem_set_reg_info(mdm, REG_INFO_REG_LOCAL);
	modem_set_pin_info(mdm, PIN_INFO_READY);
	mdm->status = SEARCH_FINISHED;
}
/*The last part of modem_wait_search_nt()*/
CDMG_FUNC(modem_search_nt_change, 1, 1, 1, 0, 0, 0, 
		"The last part of modem_wait_search_nt()")
{
	char reginfo[64] = {0};

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	if (!CDMG_GET_ARG("reginfo", reginfo))
		return 0;

	d_printf("network change to [%s]\n", reginfo);
	modem_set_reg_info(mn->mdm, reginfo);

	return 0;
}

int modem_wait_search_nt(modem_t *mdm)
{
	char old_reg_info[32] = {0};
	int i = 0;
	__modem_t *__mdm = 0;
	
	d_printf("AT:Search network...\n");

	__mdm = GET_PRI(mdm, __modem_t);	
	while(i < 1) {

		__mdm->reginfo[0] = 0;
		modem_get_reg_info(mdm, 0);
		

		if (!strlen(__mdm->reginfo) ) {
			printf_3g("", "get register info error\n");
			break;
		}

		if (!__mdm->reginfo[0] || !modem_reg_is_ready(mdm)) {
			
			if (strcmp(old_reg_info, __mdm->reginfo) != 0) {				
				d_printf("%s--->%s\n", old_reg_info, __mdm->reginfo);
				CDMG_SEND_MSG(modem_search_nt_change, 
					"--reginfo=\"%s\" ", 
					__mdm->reginfo);
				i = 0;
				strcpy(old_reg_info, __mdm->reginfo);
			}			
			
			sleep((i + 1) *5);

			i++;
			
			continue;
		} else
			break;
		
	}

	if (strstr(__mdm->reginfo, REG_INFO_SEARCH) ||
        strstr(__mdm->reginfo, REG_INFO_SEARCH_START) ||
        strstr(__mdm->reginfo, REG_INFO_UNKOWN))
		modem_set_reg_info(mdm, REG_INFO_NOT_FIND);

	/*scb+ 2012-2-18 to get the provider code*/
	d_printf("Get provider\n");
	__mdm->provider_code[0] = 0;
	modem_get_prd(mdm, 0);
	
	return 0;
}

int modem_set_network_mode(modem_t *mdm)
{
	d_printf("Set network mode\n");
    
	if (!mdm)
		return -1;	
    
	at_do_cmd(MN(mdm)->at, AT_SET_NETWORK_MODE, 0, AT_NONE, 0, 0);
	return 0;
}

/*scb+ 2011-12-3 some dongle at first is in sleep mode, before searching the network, neet to let it active*/
int modem_search_init(modem_t *mdm)
{
	d_printf("enter\n");
    
	if (!mdm)
		return -1;	

	return at_do_cmd(MN(mdm)->at, AT_SEARCH_INIT , 1, AT_NONE, 0, 0);
}

/***************************************************************/

static void modem_search_info(modem_t *mdm)
{
	__modem_t *__mdm = 0;
	
	d_printf("enter\n");
	__mdm = GET_PRI(mdm, __modem_t);	

	modem_get_imei(mdm, 0);

	if (modem_pin_is_ready(mdm)) {
		d_printf("enter\n");
		modem_get_prd(mdm, 0);
		modem_get_id(mdm, 0);
		modem_get_imsi(mdm, 0);
		modem_get_csq(mdm, 0);

		/*scb+ 2012-5-11 for getting cell id and local area code*/
		modem_get_lac(mdm, 0);
		modem_get_ci(mdm, 0);
		
		/*modem_get_charge(mdm, 0);*/
	}
}

/*
  *action :1 get fast ,2 get pininfo,reginfo,3 another
  */
int modem_get_struct(modem_t *mdm, int action)
{
	int len = SIZE_3G(modem_t, __modem_t);
	time_t curr;
	__modem_t *__mdm = GET_PRI(mn->mdm, __modem_t);

	len = (len > MSG_LEN) ? MSG_LEN : len;

	time(&curr);
	if (curr > __mdm->update_time_info &&
		curr - __mdm->update_time_info < 60) {
			/*return right now!*/
			if (mdm && mdm != mn->mdm)
				memcpy(mdm, mn->mdm, len);	

			return len;	
	}
		
	
	d_printf("enter\n");

	if (action == 1) {
		/*return right now!*/
		if (mdm && mdm != mn->mdm)
			memcpy(mdm, mn->mdm, len);
		
	} else if (action == 2) {	

		/*FIX me:some time, need to re-open the tty,otherwise write will failse*/
		at_set_tty(mn->at, GET_PRI(mn->mdm, __modem_t)->ctrl_tty);

		if (!__mdm->pininfo[0])
			modem_get_pin_info(mn->mdm, 0);

		if (!__mdm->reginfo[0])
			modem_get_reg_info(mn->mdm, 0);

		if (mdm && mdm != mn->mdm)
			memcpy(mdm, mn->mdm, len);
		
	} else  {

		/*FIX me:some time, need to re-open the tty,otherwise write will failse*/
		at_set_tty(mn->at, GET_PRI(mn->mdm, __modem_t)->ctrl_tty);
		
		if (!__mdm->pininfo[0])
			modem_get_pin_info(mn->mdm, 0);

		if (modem_pin_is_ready(mn->mdm)) {
			if (!__mdm->reginfo[0])
				modem_get_reg_info(mn->mdm, 0);
		}

		modem_search_info(mn->mdm);

		if (mdm && mdm != mn->mdm)
			memcpy(mdm, mn->mdm, len);
	}

	
	time(&curr);
	__mdm->update_time_info = curr;

	return len;	
}

CDMG_FUNC(getstatusend, 1, 1, 1, 0, 0, 0, 
		"The last part of modem_show_status()")
{	
	d_printf("enter\n");

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;
	
	modem_read_info(mn);
	mn->do_get_status= 0;

	return 0;	
}

int modem_show_status(modem_t *mdm, char *rbuf, int rlen)
{
	char buf[512] = {0};
	char buf1[10] = {0};
	char cmd[80] = {0};
	__modem_t *__mdm = 0;		

	d_printf("enter\n");
	
	__mdm = GET_PRI(mdm, __modem_t);

    /* ipoe��ʱ�򣬽ӿ�����up�ģ��������Ѿ����� */
    if (strcmp(g_usb_dongle_ifname, IF_PPP_NAME) == 0)
    {
    	snprintf(cmd, sizeof(cmd), "/sbin/ifconfig %s", g_usb_dongle_ifname);
    	
    	lib3g_script_and_get_ret(cmd, buf);   
    	
    	lib3g_reg_exec(buf, "/[\n\r\t ]UP[\n\t ]/", buf1, sizeof(buf1) - 1);
    	
    	if(strlen(buf1)) {
    		snprintf(rbuf, rlen, "CONNECTTED");
    		return 0;
    	}
	}

	d_printf("modem status:do_switch=%d, do_switch_end=%d, do_hotplug=%d,"
		" status=%d\n",
		mn->do_switch, mn->do_switch_end, mn->do_hotplug, mdm->status);
	
	/*no usb card*/
	if (mdm->status == SEARCH_INVALID && 			
			!mn->do_switch && !mn->do_switch_end &&
			!mn->do_hotplug ) {
		snprintf(rbuf, rlen, STATUS_NO_USB);
		return 0;
	}

	/*switching...*/
	if (mn->mdm->status != SEARCH_FINISHED && 
			(mn->do_switch || mn->do_switch_end) &&
			!mn->do_hotplug	) {
		snprintf(rbuf, rlen, STATUS_SWITCHING);
		return 0;
	}

	/*init...*/
	if (mn->mdm->status != SEARCH_FINISHED &&
			mn->do_hotplug && 
			mn->mdm->status != SEARCH_FINISHED) {
		snprintf(rbuf, rlen, STATUS_INIT);
		return 0;
	}
    /* ����fork��������������status״̬�ǲ��ɿصģ���Ϊ������û�еȴ��ӽ��̵ķ���.
     * ����״̬����һ���õ����¡�����ȥ���ٴβ�ѯ��ֱ��ʹ�������̵�״̬.
     */
#if 0
	if (mn->run_on_diald) {
		d_printf("enter\n");
		if (!mn->do_get_status && !mn->do_hotplug && 
				!mn->do_switch && !mn->do_get_modem_info && 
				!mn->do_hotunplug && (!__mdm->pininfo[0] || 
				!__mdm->reginfo[0] || 
				!strcmp(__mdm->reginfo,REG_INFO_SEARCH) ||
				strcmp(__mdm->pininfo,PIN_INFO_READY) )) {
			mn->do_get_status = fork_3g();
			
			if (mn->do_get_status == 0) {
				d_printf("start to get pin&reg info\n");
				
				/*FIX me:some time, need to re-open the tty,otherwise write will failse*/
				at_set_tty(mn->at, GET_PRI(mn->mdm,
					__modem_t)->ctrl_tty);
				
				modem_get_pin_info(mdm, 0);
				
				if (strlen(__mdm->pininfo) && 
						!strstr(__mdm->pininfo,
						PIN_INFO_READY)) {
					modem_write_info();
					CDMG_SEND_MSG(getstatusend, "%s", "");
					exit(0);
				}

				modem_get_reg_info(mdm,0);
	
				modem_write_info();
				CDMG_SEND_MSG(getstatusend, "%s", "");
				exit(0);
			}

			if (mn->do_get_status  < 0) {
				printf_3g("", "can not fork for get modem struct\n");
				mn->do_get_status = 0;
			}
		}
	} 
#endif
	if ( !modem_pin_is_ready(mdm)) {
		snprintf(rbuf, rlen, __mdm->pininfo);
		return strlen(rbuf)+1;
	}

	if (!strlen(__mdm->reginfo) || 
  	   strstr(__mdm->reginfo, REG_INFO_REG_LOCAL) ||
  	   strstr(__mdm->reginfo, REG_INFO_INGNORE)) {
		snprintf(rbuf, rlen, "DISCONNECT");
		return strlen(rbuf)+1;
	}
	
	if ( strstr(__mdm->reginfo, REG_INFO_REG_ROAM)) {
		snprintf(rbuf, rlen, "DISCONNECT;%s", __mdm->reginfo);
		return strlen(rbuf)+1;
	}
	
	snprintf(rbuf, rlen, __mdm->reginfo);

	return strlen(rbuf)+1;
}

/*filter function */
enum{
	MODEM_FILTER_ACTION_ALLOW = 0,
	MODEM_FILTER_ACTION_PROHIBIT,
};

/*0 is pass, 1 is not pass*/
static int s_filter_action = MODEM_FILTER_ACTION_ALLOW;


static char s_filter_ids[8*2*50] = {0};
static int modem_filter_for_ids(const char *idVendor, 
			const char *idProduct, int *lolcal_fit)
{
	char ids[32] = {0};
	
	if (!idVendor || !idVendor[0] || !idProduct || !idProduct[0])
		return 0;

	if (!s_filter_ids[0])
		return 0;
	
	snprintf(ids, sizeof(ids), "(%04x,%04x)", 
		(unsigned int)strtoul(idVendor, 0, 16),
		(unsigned int)strtoul(idProduct, 0, 16));
	lib3g_strl2u(ids);
	d_printf("FILTER:Need to check ids:%s, id:%s\n", 
		s_filter_ids, ids);
	if (strstr(s_filter_ids, ids)) {
		d_printf("FILTER:Fit\n");
		*lolcal_fit = 1;
	}
	else {
		d_printf("FILTER:Not fit\n");
		*lolcal_fit = 0;
	}

	if (*lolcal_fit != 0)
		return 0;

	/*check general mode*/
	d_printf("FILTER:Gerneral ids check\n");
	snprintf(ids, sizeof(ids), "(%04x,*)", 
		(unsigned int)strtoul(idVendor, 0, 16));
	lib3g_strl2u(ids);
	d_printf("FILTER:Need to check ids general:%s, id:%s\n", 
		s_filter_ids, ids);
	if (strstr(s_filter_ids, ids)) {
		d_printf("FILTER:Fit\n");
		*lolcal_fit = 1;
	}
	else {
		d_printf("FILTER:Not fit\n");
		*lolcal_fit = 0;
	}		
	
	return 0;
}

static char s_filter_provider[32] = {0};
static int modem_filter_for_network(const char *idVendor, 
			const char *idProduct, int *lolcal_fit)
{
	__modem_t *__mdm = 0;

	if (!mn)
		return 0;
	if (!mn->mdm)
		return 0;
	if (mn->mdm->status != SEARCH_FINISHED)
		return 0;
	if (!s_filter_provider[0])
		return 0;

	__mdm = GET_PRI(mn->mdm, __modem_t);	

	if (!__mdm->provider_code[0])
		return 0;

	d_printf("FILTER:Check provider code:given:%s, realy:%s\n", 
		s_filter_provider, __mdm->provider_code);
	if (strstr	(s_filter_provider, __mdm->provider_code))
		*lolcal_fit = 1;
	else
		*lolcal_fit = 0;

	return 0;
}

static char s_filter_nettype[32] = {0};
static int modem_filter_for_nettype(const char *idVendor, 
			const char *idProduct, int *lolcal_fit)
{
	__modem_t *__mdm = 0;

	if (!mn)
		return 0;
	if (!mn->mdm)
		return 0;
	if (mn->mdm->status != SEARCH_FINISHED)
		return 0;
	if (!s_filter_nettype[0])
		return 0;

	__mdm = GET_PRI(mn->mdm, __modem_t);	

	if (!__mdm->nt[0])
		return 0;

	d_printf("FILTER:Check net type:given:%s, realy:%s\n", 
		s_filter_nettype, __mdm->nt);
	if (strstr	(s_filter_nettype, __mdm->nt))
		*lolcal_fit = 1;
	else
		*lolcal_fit = 0;

	return 0;
}

typedef int (*modem_fit_action_t)(const char *idVendor, 
			const char *idProduct, int *lolcal_fit);

static modem_fit_action_t modem_fit_action[] = 
	{
		modem_filter_for_ids,
		modem_filter_for_network,
		modem_filter_for_nettype,
	};


/*
* scb+ 2012-1-18 filter function, 
* only support some dongle or some network
*/
int modem_filter_is_allow(const char *idVendor, const char *idProduct)
{
	int i;
	int fit = -1;
	int local_fit = 0;

	d_printf("FILTER:Check for (0x%s,0x%s)\n", idVendor, idProduct);
	for (	i = 0; 
		 	i < sizeof(modem_fit_action)/sizeof(modem_fit_action[0]);
			i++) {
		if (fit == 0) {
			d_printf("FILTER:Un-fit\n");
			break;
		}
			
		local_fit = -1;
		modem_fit_action[i](idVendor, idProduct, &local_fit);
	
		if ( local_fit != -1) {
			d_printf("FILTER:%s\n", local_fit == 1 ? "Fit" : "Not fit");
			if (fit == -1)
				fit = local_fit;
			else if (fit == 1 && local_fit == 0)
				fit = 0;
		} else {
			d_printf("FILTER:Not check\n");
		}

	}

	if (fit != -1) {		
		if (s_filter_action == MODEM_FILTER_ACTION_ALLOW) {
			if (fit)
				return 1;
			else
				return 0;
		} else {
			if (fit)
				return 0;
			else
				return 1;
		}
	}

	d_printf("FILTER:No filter condition\n");
	return 1;
}

CDMG_FUNC(dongle_filter, 1, 0, 0, 0, 0, 0, 
		"Support some dongle or some network by\n"
		"given policy\n"
		"\texam:3g-mngr dongle_filter --show\n"
		"\texam:3g-mngr dongle_filter --action=allow|prohibit --ids=\"(aaaa,bbbb)[,(12d1,*)]\"\n"
		"\t\t--nettype=WCDMA|EVDO|TDCDMA|GPRS --provider=46001\n")
{
	char *buf = 0;
	char show[4] = {0};
	char action[16] = {0};
	char nettype[16] = {0};
	char provider[64] = {0};
	char *ids = 0;

	/*if is need to show*/
	if (!cdmg_is_on_daemon() && MNGR_GET_ARG("show", show) &&
			show[0] != '0')
	{
		CDMG_SEND_AND_GET(buf, 1000000, modem_dongle_filter_info, "%s", "");
		if (buf) {
			/*output */
			printf(buf);
			free(buf);
		}
		return 0;
	}

	/*let the command run at diald process*/
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	/*get the new parameter from command line*/
	if (MNGR_GET_ARG("action", action)) {
		if (strcmp(action, "allow") == 0)
			s_filter_action = MODEM_FILTER_ACTION_ALLOW;
		if (strcmp(action, "prohibit") == 0)
			s_filter_action = MODEM_FILTER_ACTION_PROHIBIT;		
	}
	if (MNGR_GET_ARG("nettype", nettype)) {
		s_filter_nettype[0] = 0;
		if (strcmp(nettype, "WCDMA") == 0)
			snprintf(s_filter_nettype, sizeof(s_filter_nettype),
				"%s", nettype);
		if (strcmp(nettype, "EVDO") == 0)
			snprintf(s_filter_nettype, sizeof(s_filter_nettype),
				"%s", nettype);
		if (strcmp(nettype, "TDCDMA") == 0)
			snprintf(s_filter_nettype, sizeof(s_filter_nettype),
				"%s", nettype);	
		if (strcmp(nettype, "GPRS") == 0)
			snprintf(s_filter_nettype, sizeof(s_filter_nettype),
				"%s", nettype);		
	}
	if (MNGR_GET_ARG("provider", provider)) {
		s_filter_provider[0] = 0;
		if (provider[0])
			snprintf(s_filter_provider, sizeof(s_filter_provider),
				"%s", provider);
	}
	CDMG_MALLOC(sizeof(s_filter_ids), ids, return 0);
	if (MNGR_GET_ARG_LEN("ids", ids, sizeof(s_filter_ids))) {
		s_filter_ids[0] = 0;
		if (ids && ids[0]) {
			snprintf(s_filter_ids, sizeof(s_filter_ids),
				"%s", ids);
			lib3g_strl2u(s_filter_ids);
			lib3g_strdelblank(s_filter_ids);
			lib3g_strdelCR(s_filter_ids);
		}
	}
	free(ids);

	return 0;	
}

/*show the filter info*/
static int modem_dongle_filter_info(int argc, char *argv[], 
				char *rbuf, int len)
{
	if (rbuf && len > 0) {
		snprintf(rbuf, len, 
			"Filter Info:\n"
			" action=%s\n"
			" ids:%s\n"
			" nettype:%s\n"
			" provider:%s\n",
			s_filter_action == MODEM_FILTER_ACTION_ALLOW?
				"MODEM_FILTER_ACTION_ALLOW" : "MODEM_FILTER_ACTION_PROHIBIT",
			s_filter_ids,
			s_filter_nettype,
			s_filter_provider);
		return strlen(rbuf) + 1;
	} else
		return 0;	
}
__CDMG_SETUP_GET(modem_dongle_filter_info, 1, 
	modem_dongle_filter_info, 0, 0, "");
/*filter function  end*/



/*the last part of modem_show()*/
CDMG_FUNC(getmodemstructend, 1, 1, 1, 0, 0, 0, 
	"the last part of modem_show()")
{	
	d_printf("enter\n");

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;
	
	modem_read_info(mn);
	mn->do_get_modem_info = 0;

	return 0;
}

void modem_show(modem_t *mdm, char *rbuf, int rlen)
{
#if 1
#define DP(fmt,args...) d_printf(fmt, ##args)
#else
#define DP(fmt,args...) 
#endif
	provider_t *prd = 0;
	char buf[32] = {0};
	__modem_t *__mdm = 0;

	__mdm = GET_PRI(mdm, __modem_t);	

	if (mn->run_on_diald) {
		DP("enter\n");
		if (!mn->do_get_modem_info && mdm->status == SEARCH_FINISHED) {
			DP("enter\n");
			if ((mn->do_get_modem_info = fork_3g()) == 0) {
				DP("%d to handler modem_show\n", getpid());
				modem_get_struct(mn->mdm, 3);
				modem_write_info();
				CDMG_SEND_MSG(getmodemstructend, "%s", "");
				exit(0);
			} else if (mn->do_get_modem_info  < 0) {
				printf_3g("", "can not fork for get modem struct\n");
				mn->do_get_modem_info = 0;
			}
		}
	} else
		modem_get_struct(mn->mdm, 3);

	/*check the param*/
	if (!rbuf || rlen <= 0)
		return;
	
	memset(rbuf, 0, rlen);

	cdmg_fstrncat(rbuf, rlen, "Product Name:%s\n" , __mdm->product);
	cdmg_fstrncat(rbuf, rlen, "Product Type:%s\n" , __mdm->identify);	
	cdmg_fstrncat(rbuf, rlen, "Product IMEI:%s\n", __mdm->imei);	
	cdmg_fstrncat(rbuf, rlen, "Manufacturer:%s\n" , __mdm->manufacturer);	
	cdmg_fstrncat(rbuf, rlen, "USIM IMSI:%s\n", __mdm->imsi);
#if 1
	cdmg_fstrncat(rbuf, rlen, "Vendor  Id:%04x\n", mdm->idVendor);
	cdmg_fstrncat(rbuf, rlen, "Product Id:%04x\n", mdm->idProduct);
	cdmg_fstrncat(rbuf, rlen, "Down Stream Rate(bps):%s\n",
		__mdm->down_stream_rate[0] ? __mdm->down_stream_rate : "unkown");
	/*cdmg_fstrncat(rbuf, rlen, "Up Stream Rate(bps):unkown\n");*/
#endif

	if (__mdm->provider_code[0]) {
		DP("start search provider\n");
		modem_search_provider(mdm, &prd);
		DP("after search provider\n");

		if (prd) {
			if (prd->provider_code[0])
				snprintf(buf, sizeof(buf),  "%s(%s)", prd->provider_code, 
					prd->provider_name[0]?prd->provider_name:"none");
			else
				buf[0] = 0;			

			cdmg_fstrncat(rbuf, rlen,"Service Provider Code:%s\n", buf);
		}else {
			cdmg_fstrncat(rbuf, rlen, "Service Provider Code:unkown\n");
		}	
	}

	/*scb+ 2012-5-11 for geting ci and lac*/
	if (!__mdm->cellid[0])
		cdmg_fstrncat(rbuf, rlen, "Cell Id:unkown\n");
	else
		cdmg_fstrncat(rbuf, rlen, "Cell id:%s\n", __mdm->cellid);
	if (!__mdm->lac[0])
		cdmg_fstrncat(rbuf, rlen, "Location Area Code:unkown\n");
	else
		cdmg_fstrncat(rbuf, rlen, "Location Area Code:%s\n", __mdm->lac);	
		
	if (__mdm->csq.rssi[0]) 
		snprintf(buf, sizeof(buf), "%s(-113dBm - 0dBm)", __mdm->csq.rssi);
	else 
		snprintf(buf, sizeof(buf), "unkown(-113dBm - 0dBm)");
	
	cdmg_fstrncat(rbuf, rlen, "Singal Intensity:%s\n", buf);

	if (__mdm->csq.ber[0])
		snprintf(buf, sizeof(buf), "%s(level:0-7)", __mdm->csq.ber);
	else 
		snprintf(buf, sizeof(buf), "unkown(level:0-7)");
	
	cdmg_fstrncat(rbuf, rlen, "Singal Ber(RXQUAL):%s\n", buf);
	
#if 0
	if (__mdm->charge[0]) {
		cdmg_fstrncat(rbuf, rlen,"Charge Value:%lu\n", strtoul(__mdm->charge,0, 16));
	} else {
		cdmg_fstrncat(rbuf, rlen,"Charge Value:\n");
	}
#endif

#undef DP
}

void modem_info(modem_t *mdm)
{
	int i = 0;
	__modem_t *__mdm = 0;

	if(!mdm) 
		return ;

	__mdm = GET_PRI(mdm, __modem_t);		

	d_printf("enter\n");
		
	if (modem_valid_check(mdm) != 0)
		return ;

	param_init(MN(mdm)->par);
	
	if (modem_search(mdm) != 0)
		return ;

	at_set_tty(MN(mdm)->at, __mdm->ctrl_tty);	

	modem_set_network_mode(mdm);
	
	modem_get_pin_info(mdm, 0);
	modem_get_reg_info(mdm, 0);
	modem_get_csq(mdm, 0);
	modem_get_id(mdm, 0);
	modem_get_prd(mdm, 0);
	modem_get_imei(mdm, 0);
	modem_get_lock_info(mdm, 0);
	modem_get_imsi(mdm, 0);
    modem_get_charge(mdm, 0);
	
	if (__mdm->nt[0])
		strcpy(MN(mdm)->par->nt, __mdm->nt);
	param_get(MN(mdm)->par);

	printf("ctrl_tty=%s\n", __mdm->ctrl_tty);

	for (i = 0; __mdm->tty_cache[i] && __mdm->tty_cache[i] [0]; i++)
		printf("tty_cache[%d]=%s\n", i, __mdm->tty_cache[i]);
	
	printf("dev_path=%s\n", __mdm->dev_path);
	printf("major=%d\n", __mdm->major);
	printf("minor=%d\n", __mdm->minor);
	printf("manufacturer=%s\n", __mdm->manufacturer);
	printf("product=%s\n", __mdm->product);
	printf("idProduct=0x%04x\n", mdm->idProduct);
	printf("idVendor=0x%04x\n", mdm->idVendor);
	printf("nt=%s\n", __mdm->nt);
	printf("identify=%s\n", __mdm->identify);
	printf("imei=%s\n", __mdm->imei);
	printf("imsi=%s\n", __mdm->imsi);
	printf("provider_code=%s\n", __mdm->provider_code);
	printf("csq.rssi=%s\n", __mdm->csq.rssi);
	printf("csq.ber=%s\n", __mdm->csq.ber);
	printf("pininfo=%s\n", __mdm->pininfo);
	printf("reginfo=%s\n", __mdm->reginfo);
	printf("lockinfo=%s\n", __mdm->lockinfo);
	printf("charge=%s\n", __mdm->charge);
	i = -1;
	i = modem_set_pin_retry_t(mdm);
	printf("pin retry time:%d\n", i);
	
	i =-1;
	i = modem_set_puk_retry_t(mdm);	
	printf("puk retry time:%d\n", i);	

	i =-1;
	i = modem_chg_pin_retry_t(mdm);	
	printf("chang pin  retry time:%d\n", i);

	i =-1;
	i = modem_set_lock_retry_t(mdm);
	printf("enable/disable lock  retry time:%d\n", i);	
	printf("phonenuber=\n");//now can not get local number
	param_show(MN(mdm)->par);
}	

void modem_write_info()
{
	int fd;

	if ((fd = open(WORK_PATH".mn", O_WRONLY|O_CREAT)) >= 0) {
		write(fd, mn, sizeof(mngr_t));
		close(fd);
	}

	if ((fd = open(WORK_PATH".mdm", O_WRONLY|O_CREAT)) >= 0) {
		write(fd, mn->mdm, sizeof(modem_t));
		close(fd);
	}

	if ((fd = open(WORK_PATH".__mdm", O_WRONLY|O_CREAT)) >= 0) {
		write(fd, GET_PRI(mn->mdm, __modem_t), sizeof(__modem_t));
		close(fd);
	}	
}

void modem_read_info(void *par_mngr)
{
	int fd;
	int is_debug = is_debug();
	mngr_t mn_tmp;
	mngr_t *mngr = par_mngr;
	modem_t mdm_tmp;
	__modem_t __mdm_tmp;    

	memset(&mn_tmp, 0, sizeof(mngr_t));
	memset(&mdm_tmp, 0, sizeof(modem_t));
	memset(&__mdm_tmp, 0, sizeof(__mdm_tmp));

	if ((fd = open(WORK_PATH".mn", O_RDONLY)) >= 0) {
		read(fd, &mn_tmp, sizeof(mngr_t));
		close(fd);
		if (!is_debug)
			unlink(WORK_PATH".mn");
	}

	if ((fd = open(WORK_PATH".mdm", O_RDONLY)) >= 0) {
		read(fd, &mdm_tmp, sizeof(modem_t));
		close(fd);
		if (!is_debug)
			unlink(WORK_PATH".mdm");
	}

	if ((fd = open(WORK_PATH".__mdm", O_RDONLY)) >= 0) {
		read(fd, &__mdm_tmp, sizeof(__modem_t));
		close(fd);
		if (!is_debug)
			unlink(WORK_PATH".__mdm");
	}	

	mngr->send_hotplug = mn_tmp.send_hotplug;
	strncpy(mngr->htplug_msg, mn_tmp.htplug_msg, HTPLUG_MSG_SIZE);
	
	mngr->mdm->idProduct = mdm_tmp.idProduct;
	mngr->mdm->idVendor = mdm_tmp.idVendor;
	mngr->mdm->status = mdm_tmp.status;
	
	memcpy(GET_PRI(mngr->mdm, __modem_t), &__mdm_tmp,  sizeof(__modem_t));

	if (mngr->mdm->status == SEARCH_FINISHED)
		at_set_tty(MN(mngr->mdm)->at, GET_PRI(mngr->mdm, __modem_t)->ctrl_tty);

}
char *comm_get_ctrl_tty_direct(modem_t *mdm)
{
    __modem_t *__mdm = GET_PRI(mdm, __modem_t);

    if (__mdm->ctrl_tty[0])
        return __mdm->ctrl_tty;

    return NULL;
}

static int comm_get_ctrl_tty(int argc, char *argv[], char *rbuf, int rlen)
{
	__modem_t *__mdm = GET_PRI(mn->mdm, __modem_t);

    if (__mdm->ctrl_tty[0])
    {
        sprintf(rbuf, "%s", __mdm->ctrl_tty);
    }
   
	return (strlen(rbuf) + 1);	
}

CDMG_SETUP_GET(ctrl_tty, comm_get_ctrl_tty, 1, 5, 
	"get ctrl tty value and return to user.\n");
