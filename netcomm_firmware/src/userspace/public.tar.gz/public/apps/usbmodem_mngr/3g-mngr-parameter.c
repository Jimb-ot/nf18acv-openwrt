#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <fcntl.h>

#include "3g-mngr-include.h"

#include "3g-mngr-parameter.h"


static void param_create_par_map(param_t *p)
{
	struct par *par_map = 0;
	__param_t *__p = 0;	
	
	__p = GET_PRI(p, __param_t);
	par_map = __p->par_map;

#define PAR_SET_MAP(i, n, v)	\
	strcpy(par_map[i].name, #n);	\
	par_map[i].value = v

	PAR_SET_MAP(0, apn, __p->apn);
	PAR_SET_MAP(1, demand, __p->demand);
	PAR_SET_MAP(2, dialdelay, __p->dialdelay);
	PAR_SET_MAP(3, idle_t, __p->idle_t);
	PAR_SET_MAP(4, username, __p->username);
	PAR_SET_MAP(5, password, __p->password);
	PAR_SET_MAP(6, pin, __p->pin);
	PAR_SET_MAP(7, puk, __p->puk);
	PAR_SET_MAP(8, newpin, __p->newpin);
	PAR_SET_MAP(9, nt, p->nt);
	PAR_SET_MAP(10, number, __p->number);
	PAR_SET_MAP(11, code, __p->pin);
	PAR_SET_MAP(12, enable, __p->lock);
	PAR_SET_MAP(13, lock, __p->lock);
	PAR_SET_MAP(14, idle, __p->idle_t);
	PAR_SET_MAP(15, net, p->nt);
	PAR_SET_MAP(16, user, __p->username);
	PAR_SET_MAP(17, mtu, __p->mtu);
	PAR_SET_MAP(18, mru, __p->mru);
    PAR_SET_MAP(19, authmethod, __p->authmethod);
}

int param_init(param_t *par)
{
	if (!par)
		return 0;

	SUB_INIT(par, param_t, __param_t);

	param_create_par_map(par);

	return 0;	
}

param_t *param_new(void *mn)
{
	param_t *p = 0;

	if ((p = ALLOC_3G(param_t, __param_t)) <= 0)
		return 0;

	MN_SET(p, mn);


	param_init(p);

	return p;
}

int param_free(param_t *par)
{
	if (!par)
		return 0;

	if(MN(par))
		MN(par)->par = 0;
		
	free(par);

	par = 0;
	
	return 0;
}

int param_product_pppd_cfg(param_t *par, int chat_at_pppd)
{
	FILE *fp;
	char nm[32] = "none";
	char *ip_tty;
	__param_t *param;
	int idle = 3600;
	char buginfo[10] = {0};
	pid_t *pids = 0;

#define AUTH_AUTO       "AUTO"
#define AUTH_PAP        "PAP"
#define AUTH_CHAP       "CHAP"
#define AUTH_MS_CHAP    "MSCHAP"

	if(!par) 
		return -1;

	if (is_3g_debug_local("/var/3g_debug_dial", DAIL_DEBUF_CONTR_FILE, 0, 0))
		strcpy(buginfo, " -v -s");
	else
		strcpy(buginfo, " ");
	param = GET_PRI(par, __param_t);

	idle = strtoul(param->idle_t, 0, 10);
	idle = (idle >= 0) ? idle : 3600;

	system("mkdir -p "WORK_PATH);
	system("mkdir -p /var/lock"); 

	if ((fp = fopen(PPP_CONFIG, "w+"))) {
		fprintf(fp, "name %s\n", nm);
		fprintf(fp, "ipcp-accept-remote\n");
		fprintf(fp, "ipcp-accept-local\n");

		modem_get_ip_port(MN(par)->mdm, &ip_tty);
		
		if (param->username[0])
			fprintf(fp, "user %s\n", param->username);

		if (param->password[0])
			fprintf(fp, "password %s\n", param->password);		

		if (param->demand[0] && strcmp(param->demand, "1" ) == 0) {
			fprintf(fp, "demand\n");
			fprintf(fp, "defaultroute\n");

			/*demand set*/
			fprintf(fp, "plugin  %s/ppp_demand_plugin.so\n", PPP_PLUGIN_DIR);
			fprintf(fp, "demand_ifname  %s\n", g_usb_dongle_ifname);
			

			if (chat_at_pppd) {
				if ((pids = lib3g_find_pid_by_name("3g-mngr diald"))) {
					fprintf(fp, 
						"connect \"3g-mngr connect_ext_chat --tty=%s\"\n",
						ip_tty);
					free(pids);
				} else
					fprintf(fp, 
						"connect \"chat -f "CHAT_SCRIPT_PATH"%s\"\n", 
						buginfo); 
			}
			else
				fprintf(fp, "connect \"3g-mngr connect\"\n"); 
		
		} else {			
#if   defined(PC)
			fprintf(fp, "defaultroute\n");
#endif	
			if (chat_at_pppd) {
				if ((pids = lib3g_find_pid_by_name("3g-mngr diald"))) {
					fprintf(fp, 
						"connect \"3g-mngr connect_ext_chat --tty=%s\"\n",
						ip_tty);
					free(pids);
				} else
					fprintf(fp, 
						"connect \"chat -f "CHAT_SCRIPT_PATH"%s\"\n", 
						buginfo); 
			}
			else
				fprintf(fp, "#connect \"3g-mngr connect\"\n"); 	
		}

		fprintf(fp, "noipdefault 1\n");
#if   defined(BRCM)		
	  //fprintf(fp, "0.0.0.0:10.10.99.99\n");
#endif

        if (param->demand[0] && strcmp(param->demand, "1" ) == 0 && idle > 0) 
			fprintf(fp, "idle %d\n", idle);

#if   defined(TBS)
		fprintf(fp, "mtu 1400\n");
		fprintf(fp, "mru 1492\n");
#endif
		
		
		fprintf(fp, "lock\n");
		fprintf(fp, "novj\n");
		fprintf(fp, "novjccomp\n");
                
		fprintf(fp, "noccp\n");
        if (param->authmethod[0])
        {
            fprintf(fp, "noauth\n");
            if(!strcmp(param->authmethod, AUTH_PAP))
            {
                fprintf(fp, "refuse-chap\n");
                fprintf(fp, "refuse-mschap\n");
                fprintf(fp, "refuse-mschap-v2\n");
                fprintf(fp, "refuse-eap\n");
            }
            else if(!strcmp(param->authmethod, AUTH_CHAP))
            {
                fprintf(fp, "refuse-pap\n");
                fprintf(fp, "refuse-mschap\n");
                fprintf(fp, "refuse-mschap-v2\n");
                fprintf(fp, "refuse-eap\n");
            }
            else if(!strcmp(param->authmethod, AUTH_MS_CHAP))
            {
                fprintf(fp, "refuse-chap\n");
                fprintf(fp, "refuse-pap\n");
                fprintf(fp, "refuse-mschap-v2\n");
                fprintf(fp, "refuse-eap\n");
            }
        }
		/*scb+ 2012-4-17 some time, time NAK will recved more times*/
		fprintf(fp, "ipcp-max-failure 20\n");
        fprintf(fp, "ipcp-max-configure 40\n");


		if (is_3g_debug_local("/var/3g_debug_dial", DAIL_DEBUF_CONTR_FILE, 0, 0))
			fprintf(fp, "logfile   /proc/self/fd/1\n");
		
		fprintf(fp, "usepeerdns\n");
		
#if   defined(BRCM)
		fprintf(fp, "ifname %s\n", g_usb_dongle_ifname);
#else
		char *unit = g_usb_dongle_ifname;

		for (; *unit && !isdigit(*unit); unit++);
		fprintf(fp, "unit %d\n", (int)strtoul(unit, 0, 10));
#endif
		
		
		fprintf(fp, "%s\n", ip_tty);

		fclose(fp);
	}               

	return 0;
}

int param_get_from_user(param_t *param, int argc, char *argv[])
{
	int i = 0;
	struct par *map;
	
	map = GET_PRI(param, __param_t)->par_map;	

	for (i = 0; i < __PAR_MAP_SIZE && map && map[i].name[0]; i++)
		cdmg_get_arg(argv, map[i].name, map[i].value, 0);
	
	return 0;
}

int param_get_item(param_t *par, const char *name, char *rbuf)
{
	int i = 0;
	__param_t *__par;

	__par = GET_PRI(par, __param_t);

	if (!rbuf)
		return 0;

	for (i = 0; i < __PAR_MAP_SIZE && __par->par_map[i].name[0] ; i++) {
		if (strcmp(name, __par->par_map[i].name) == 0) {
			strcpy(rbuf, __par->par_map[i].value);
			return 0;
		}
	}
	
	rbuf[0] = 0;
	
	return 0;
}

int param_get(param_t *par)
{
	provider_t *prd = 0;
	__param_t *param;

	if(!par) 
		return -1;

    param = GET_PRI(par, __param_t);	

	//serial_send_recv(modem.tty, "atz\r\n", 5, buf, 128, 1, 0, 0, 10000);		
	//modem_get_prd(MN(par)->mdm, 0); //get the provider to get the default apn,number..

	modem_search_provider(MN(par)->mdm, &prd);


	if (!param->apn[0] && prd->apn[0])
		strcpy(param->apn, prd->apn);

	if (!param->number[0] && prd->number[0])
		strcpy(param->number, prd->number);

	if (!param->username[0] && prd->username[0])
		strcpy(param->username, prd->username);

	if (!param->password[0] && prd->password[0])
		strcpy(param->password, prd->password);	
	return 0;
}

int param_replace_var(param_t *par, char *at_str, int len)
{
#define BUF_SIZE 128
	int i;
	int _tlen = 0;
	char reg_tmp[BUF_SIZE + 1] = {0};
	__param_t *param;

	param = GET_PRI(par, __param_t);	
	
	struct  _var_token{char *token; char *var;}  var_token[] = {
		{"@apn@", param->apn},
		{"@number@", param->number},
		{"@username@", param->username},
		{"@password@", param->password},
		{"@pin@", param->pin},
		{"@puk@", param->puk},
		{"@lock@", param->lock},
		{"@newpin@", param->newpin},
	};

	_tlen = sizeof(var_token)/sizeof(var_token[0]);
	for (i = 0; i < _tlen; i++) {
		snprintf(reg_tmp, BUF_SIZE, "s/%s/%s/", var_token[i].token, var_token[i].var);
		//d_printf("at str:[%s], reg[%s]\n", at_str, reg_tmp);
		lib3g_reg_exec(at_str, reg_tmp, at_str, len);	
	}

	return 0;
#undef BUF_SIZE	
}	

int param_get_default(param_t *par)
{
	provider_t *prd = 0;
	__param_t *param;

	if(!par) 
		return -1;

	param = GET_PRI(par, __param_t);		

	modem_get_prd(MN(par)->mdm, 0); //get the provider to get the default apn,number..

	modem_search_provider(MN(par)->mdm, &prd);

	strcpy(param->apn, prd->apn);
	strcpy(param->number, prd->number);
	strcpy(param->username, prd->username);
	strcpy(param->password, prd->password);	
	strcpy(par->nt, prd->nt);	
					   
	return 0;			 
}

int param_show_default(param_t *par, char *rbuf, int rlen)
{
	__param_t *param;

	param = GET_PRI(par, __param_t);	
	
	//modem_search(MN(par)->mdm);	
	//param_get_default(par);

	snprintf(rbuf, rlen, "apn:%s\n", param->apn[0] ? param->apn : "");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf),  "number:%s\n", 
		param->number[0] ? param->number : "");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "user:%s\n", 
		param->username[0] ? param->username : "");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "password:%s\n", 
		param->password[0] ? param->password : "");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "nettype:%s\n", 
		par->nt[0] ? par->nt : "");
	
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "dialdelay:10\n");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "undialdelay:10\n");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "defaultwan:dsl\n");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "idle:0\n");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "autodial:0\n");
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "demand:0\n");
	
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "hotplugdelay:%d\n", 
		DELAY_DO_HOTPLUG_MAX);
	snprintf(rbuf + strlen(rbuf), rlen - strlen(rbuf), "switchdelay:%d\n", 
		DELAY_DO_SWITCH_MAX);
	
	return 0;
}

void param_show(param_t *par)
{/*for debug*/
	__param_t *param;

	param = GET_PRI(par, __param_t);	
	
	printf("#######    dial param #########################\n");
	printf("apn=%s\n", param->apn[0]?param->apn:"none");
	printf("number=%s\n", param->number[0]?param->number:"none");
	printf("username=%s\n", param->username[0]?param->username:"none");
	printf("password=%s\n", param->password[0]?param->password:"none");
	printf("nettype=%s\n", par->nt[0]?par->nt:"none");
	printf("idle=%s\n", param->idle_t);		
}

#define PAR_PUBLIC_FILE		WORK_PATH".par"
#define PAR_PRIVATE_FILE		WORK_PATH".__par"
void param_write_par(param_t *par)
{
	int fd;
	__param_t *__par = 0;

	d_printf("enter\n");

	unlink(PAR_PUBLIC_FILE);
	unlink(PAR_PRIVATE_FILE);	
	
	if (!par)
		return;
	__par = GET_PRI(par, __param_t);

	if ((fd = open(PAR_PUBLIC_FILE, O_WRONLY|O_CREAT)) >= 0) {
		write(fd, par, sizeof(param_t));
		close(fd);
	}

	if ((fd = open(PAR_PRIVATE_FILE, O_WRONLY|O_CREAT)) >= 0) {
		write(fd, __par, sizeof(__param_t));
		close(fd);
	}	
}

void param_read_par(param_t *par)
{
	int fd;
	int is_debug = is_debug();
	param_t  r_par;
	__param_t __r_par;

	d_printf("enter\n");
	memset(&r_par, 0, sizeof(param_t));
	memset(&__r_par, 0, sizeof(__param_t));

	if ((fd = open(PAR_PUBLIC_FILE, O_RDONLY)) >= 0) {
		read(fd, &r_par, sizeof(param_t));
		close(fd);
		if (!is_debug)
			unlink(PAR_PUBLIC_FILE);
	}

	if ((fd = open(PAR_PRIVATE_FILE, O_RDONLY)) >= 0) {
		read(fd, &__r_par, sizeof(__param_t));
		close(fd);
		if (!is_debug)
			unlink(PAR_PRIVATE_FILE);
	}

	snprintf(par->nt, sizeof(r_par.nt), r_par.nt);
	memcpy(GET_PRI(par, __param_t), &__r_par, sizeof(__param_t));	
}

void param_for_hotplug_notify(int is_hotplug)
{
	param_t *par = mn->par;

	if (!is_hotplug) {
		d_printf("clear par\n");
		param_init(par);
	}
}

