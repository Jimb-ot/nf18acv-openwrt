 /*
 * ppp_demand_plugin.c - pppd plugin to implement dial on demand .
 *
 * Copyright (C) 2012 ChangBan Shen <gdscb@tom.com>
 * Copyright (C) 1990-2012 GongJin Corp.
 *
 * Create by ShenChangBan  2012-7-18
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include <stdio.h>		/* for FILE */
#include <limits.h>		/* for NGROUPS_MAX */
#include <fcntl.h>
#include <stdlib.h>
#include <sys/param.h>		/* for MAXPATHLEN and BSD4_4, if defined */
#include <sys/types.h>		/* for u_int32_t, if defined */
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/ppp_defs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <error.h>
#include <errno.h>
#include <signal.h>
#include "module/demand_hook.h"

#if defined(__STDC__)
#include <stdarg.h>
#define __V(x)	x
#else
#include <varargs.h>
#define __V(x)	(va_alist) va_dcl
#define const
#define volatile
#endif

#ifdef INET6
#include "eui64.h"
#endif

#ifdef BRCM
#define IF_3G_NAME "ppp3g0"
#define PPPD_NAME "pppd245"
#else
#define IF_3G_NAME "ppp10"
#define PPPD_NAME "pppd"
#endif

/*pppd.h declare*/
typedef unsigned char	bool;

enum opt_type {
	o_special_noarg = 0,
	o_special = 1,
	o_bool,
	o_int,
	o_uint32,
	o_string,
	o_wild,
};
typedef struct {
	char	*name;		/* name of the option */
	enum opt_type type;
	void	*addr;
	char	*description;
	int	flags;
	void	*addr2;
	int	upper_limit;
	int	lower_limit;
	const char *source;
	short int priority;
	short int winner;
} option_t;

typedef void (*notify_func) __P((void *, int));

struct notifier {
    struct notifier *next;
    notify_func	    func;
    void	    *arg;
};

void add_notifier __P((struct notifier **, notify_func, void *));
void add_options __P((option_t *)); /* Add extra options */
void info __P((char *, ...));	/* log an informational message */
extern int	idle_time_limit;/* Shut down link if idle for this long */
extern int (*idle_time_hook) __P((struct ppp_idle *));
extern void (*ip_up_hook) __P((void));
extern void (*ip_down_hook) __P((void));
extern bool	demand; 		/* do dial-on-demand */
extern struct notifier *sigreceived;

#define DK_BUG(fmt, args...)	info("%s:%d :" fmt, __FILE__, __LINE__, ##args)
static void demand_enter_rule();

static char demand_if[32] = {0};

static int is_remove = 0;

static int write_to_demand_hook(char *buf, int len)
{
	int ret = -1;
	int fd = 0;
	
	if ((fd = open("/proc/"DEMAND_HOOK_PROC_ID, O_RDWR)) != -1) {
		DK_BUG("Demand write to hook:[%s]\n", buf);
		ret = write(fd, buf, strlen(buf));
		if (ret <= 0)
			DK_BUG("Demand write error:%s\n", strerror(errno));
		close(fd);
	}
	return ret;
}

#define write_to_demand_hook1(buf, len)	\
	DK_BUG("Demand write to hook:\n"); write_to_demand_hook((buf), (len))

#if !defined(PC)
static int get_ifidx_by_name(char *ifname)
{
	int	sock = 0;
	int ifidx = DEMAND_HOOK_IFIDX_BAD;
	struct ifreq	ifr;
	
	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_ifrn.ifrn_name, ifname, IFNAMSIZ-1);
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) != -1) {
		if (ioctl(sock, SIOCGIFINDEX, &ifr, sizeof(ifr)) < 0)
			DK_BUG("No intf:%s\n", ifname);
		else
			ifidx = ifr.ifr_ifindex;
		close(sock);
	}
	return ifidx;
}
#endif

static int setdemandname(char **argv)
{
	char buf[128] = {0};

	DK_BUG("Demand set demand if name:%s\n", *argv);
	
	strncpy(demand_if, *argv, sizeof(demand_if)-1);
	snprintf(buf, sizeof(buf), DEMAND_HOOK_IFNAME_TOKEN"%s", demand_if);
	write_to_demand_hook1(buf, strlen(buf));
	demand_enter_rule();
	return 1;
}

static option_t my_options[] = {
    { "demand_ifname", o_special, (void *)setdemandname,
      "Set the demand interface name"},      
	{ NULL }
};

static void demand_enter_rule()
{
	char buf[256] = {0};

#ifdef PC
	/*all the forward pkg*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_FORWARD -o %s -duration 9999999 -th_pkg 1>", 
		demand_if);
	write_to_demand_hook1(buf, strlen(buf));

	/*all the output*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s  -duration 5 -th_pkg 2>",
		demand_if);
	write_to_demand_hook1(buf, strlen(buf));	

	/*ignore udp's ntp*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s  -p %d -dport%d -a DROP "
		"-duration 9999999 -th_pkg 1>",
		demand_if, IPPROTO_UDP, htons(123));
	write_to_demand_hook1(buf, strlen(buf));	

	/*ignore all icmp package.*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s  -p %d -a DROP "
		"-duration 99999 -th_pkg 1>", demand_if, IPPROTO_ICMP);
	write_to_demand_hook1(buf, strlen(buf));
#else
	int	i = 0, ifidx = 0;
	struct {
		char 	*name;
		int		index;
	} bridge_rec[] = {
		{"br0", -1}, {"br1", -1},
		{"br2", -1}, {"br3", -1},
	};
	
	/*Check what brigdge interface do exist*/
	for (i = 0; i < sizeof(bridge_rec)/sizeof(bridge_rec[0]); i++) {
		/*Check the intf if is exist*/
		ifidx = get_ifidx_by_name(bridge_rec[i].name);
		if (ifidx != DEMAND_HOOK_IFIDX_BAD)
			bridge_rec[i].index = ifidx;
	}

    /*ping 8.8.8.8*/	 
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s -dst %x/%x -p %d -duration 9999999 -th_pkg 1>",
		demand_if, 
		inet_addr("8.8.8.8"), inet_addr("255.255.255.255"),/*ping 8.8.8.8*/
		IPPROTO_ICMP);
	write_to_demand_hook1(buf, strlen(buf));

	/*only for test:ping www.sina.com.cn*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s -p %d -dport %d -dns%s "
		"-duration 9999999 -th_pkg 1>",
		demand_if, IPPROTO_UDP, htons(53),/*dns*/
		"www.sina.com.cn");
	write_to_demand_hook1(buf, strlen(buf));

#ifdef TBS
	/*allow tr069*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s -p %d -dport %d"
		"-duration 9999999, -th_pkg 1>",
		demand_if, IPPROTO_TCP, htons(7006));
	write_to_demand_hook1(buf, strlen(buf));
	

	/*allow ntp port*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
		"<-hook NF_INET_LOCAL_OUT -o %s -p %d -dport %d "
		"-duration 9999999, -th_pkg 1>",
		demand_if, IPPROTO_UDP, htons(123));
	write_to_demand_hook1(buf, strlen(buf));
#endif

	for (i = 0; i < sizeof(bridge_rec)/sizeof(bridge_rec[0]); i++) {
		if (bridge_rec[i].index != -1) {
			snprintf(buf, sizeof(buf), DEMAND_HOOK_RULE_TOKEN
				"<-hook NF_INET_FORWARD   -i %s -o %s "
				"-duration 9999999 -th_pkg 1>",
				bridge_rec[i].name, demand_if);
			write_to_demand_hook1(buf, strlen(buf));
		}
	}
#endif
}

static void demand_install(void)
{
	char buf[128] = {0};

	if (access("/var/3g_debug_wan", F_OK) == 0)
		snprintf(buf, sizeof(buf), 
			"insmod %s/demand_hook.ko 2>/dev/null debug_level=5",
			MODULE_DEMAND_DIR);
	else
		snprintf(buf, sizeof(buf), 
			"insmod %s/demand_hook.ko 2>/dev/null debug_level=0",
			MODULE_DEMAND_DIR);
	system(buf);

	DK_BUG("Demand:install module\n");
	is_remove = 0;

	sleep(1);
	
	/*tell module the min time from linkdown to dail again*/
	snprintf(buf, sizeof(buf), DEMAND_HOOK_DIAL_DELAY_TOKEN"%d", 10);
	write_to_demand_hook1(buf, strlen(buf));
	if (demand_if[0]) {
		snprintf(buf, sizeof(buf), DEMAND_HOOK_IFNAME_TOKEN"%s", demand_if);
		write_to_demand_hook1(buf, strlen(buf));
		demand_enter_rule();
	}
}

static void demand_uninstall(void)
{
	DK_BUG("Demand rm module:demand_hook.ko");
	is_remove = 1;/*the got_sigterm will be set to 0, by pppd*/
	system("rmmod demand_hook.ko 2>/dev/null");
}


/*retrun the duration from the last frame send or received time to now*/
static int demand_check_idle(struct ppp_idle *idle)
{
	int fd = 0;
	char buf[8] = {0};

	if (!idle)
		return idle_time_limit;

	if (demand && (fd = open("/proc/"DEMAND_HOOK_PROC_ID,
			O_RDONLY)) != -1) {
		read(fd, buf, sizeof(buf)-1);
		DK_BUG("Demand arg:%s\n", buf);
		close(fd);
		return (idle_time_limit - strtoul(buf, 0, 10));
	} else
		return (idle_time_limit - MIN(idle->xmit_idle, idle->recv_idle));
}

static void demand_link_notify(int is_up)
{
	int  fd = 0;
	char buf[32] = {0};

	if (!demand)
		return;	

	DK_BUG("Demand:tell to demand hook:%s\n", is_up?"up":"down");	

	if ((fd = open("/proc/"DEMAND_HOOK_PROC_ID, O_WRONLY)) >= 0) {
		if (is_up)
			snprintf(buf, sizeof(buf), DEMAND_HOOK_LINKUP_TOKEN"1");
		else
			snprintf(buf, sizeof(buf), DEMAND_HOOK_LINKUP_TOKEN"0");
		DK_BUG("Demand: wite to demand hook:%s\n", buf);
		write(fd, buf, sizeof(buf));
		close(fd);
	}
}

static void demand_change_ipt(int is_add)
{
#if !defined(PC)
	int i = 0;
	char act[4] = {0};
	char buf[128] = {0};
	struct  ifs {
		char name[32];
	} ifs[] = {{"br0"}, {"br1"}, {"br2"}, {"br3"}};

	DK_BUG("Demand:%s ipt rules\n", is_add ? "Add" : "Del");
	if (is_add) {
		if (is_remove) {
			DK_BUG("Demand:demand module removed, not add ipt rules\n");
			return;
		}
		strcpy(act, "-A");
	} else
		strcpy(act, "-D");
	
	for (i = 0; i < sizeof(ifs)/sizeof(ifs[0]); i++) {
		snprintf(buf, sizeof(buf), 
			"iptables %s PREROUTING -t nat -i %s -p udp --dport 53"
			" -j DNAT --to 8.8.8.8", act, ifs[i].name);
		DK_BUG("Demand:do cmd:%s\n", buf);
		system(buf);
	}
#endif	
}

extern int got_sigterm;
static void term(void *opaque, int arg)
{
	if (got_sigterm) {
		DK_BUG("Demand: user terminal, del ipt,rmove hook module.\n");
		demand_change_ipt(0);
		demand_uninstall();
		DK_BUG("Demand: term end\n");
	}
}

/*
* scb+ 2012-9-11, 
* func demand_linkdown and sig func term
* exists crossing runing, 
* so need serial the runing of them.
*/
static void demand_sig_block(int is_block)
{
	sigset_t sigset;

	DK_BUG("Demand: sig %s\n", is_block ? "block" : "unblock");
	
	sigemptyset(&sigset);
	sigaddset(&sigset, SIGTERM);
	sigaddset(&sigset, SIGINT);
	
	if (is_block)
		sigprocmask(SIG_BLOCK, &sigset, 0);
	else
		sigprocmask(SIG_UNBLOCK, &sigset, 0);
}

static void demand_linkup(void)
{
	demand_sig_block(1);
	DK_BUG("Demand: linkup\n");
	demand_link_notify(1);
	demand_change_ipt(0);
	demand_sig_block(0);
}

static void demand_linkdown(void)
{
	demand_sig_block(1);
	DK_BUG("Demand: linkdown\n");
	if (!got_sigterm && !is_remove) {
		demand_link_notify(0);
		demand_change_ipt(1);
	} else
		demand_change_ipt(0);
	demand_sig_block(0);
}

void plugin_init(void)
{
	DK_BUG("Demand: ppp_demand_plugin\n");
	add_options(my_options);
	demand_uninstall();
	demand_install();
	idle_time_hook 	= demand_check_idle;
	ip_up_hook		= demand_linkup;
	ip_down_hook	= demand_linkdown;
	demand_change_ipt(1);	
	add_notifier(&sigreceived,term, NULL);
}

