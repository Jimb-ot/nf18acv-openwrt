#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <limits.h>
#include <stdlib.h>
#include <sys/un.h>
#include <sys/param.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include<sys/wait.h>
#include <sys/ioctl.h>
#include <sys/file.h>

#include "3g-mngr-include.h"

#define DELAY_HOTPLUG_FLAGE_FILE WORK_PATH".delay_hotplug_file"
#define DELAY_BOOT_UP_FILE WORK_PATH".bootupdalay"

/*hotplug and switch delay time*/
static int delay_do_switch = 3;//DELAY_DO_SWITCH_MAX;
static int delay_do_hotplug = 3;//DELAY_DO_HOTPLUG_MAX;

/*set delay parameter*/
#define DELAY_DO_SWITCH delay_do_switch
#define DELAY_DO_HOTPLUG delay_do_hotplug

#define TIMEOUT_DO_SWITCH  60
#define TIMEOUT_DO_HOTPLUG 200

#define TIMEOUT_DO_SWITCH_TATOL  \
	(TIMEOUT_DO_SWITCH + DELAY_DO_SWITCH)
#define TIMEOUT_DO_HOTPLUG_TALTOL  \
	(TIMEOUT_DO_HOTPLUG + DELAY_DO_HOTPLUG)



#ifdef PC
#define DELAY_HOTPLUG_TIME	 10
#else
#define DELAY_HOTPLUG_TIME	60
#endif


void modem_write_info();

static void hotplug_notify(int is_hotplug);
static int   process_switch_start(int argc, char *argv[]);
static int   process_hotplug_start(int argc, char *argv[]);
static void check_process(modem_t *mdm);

static void  stop_all_asyn_action()
{
	if (!mn || !mn->run_on_diald)
		return;
	
	
	timer_del_all();

	if (mn->do_hotplug) {
		kill(mn->do_hotplug, SIGKILL);
		mn->do_hotplug = 0;
	}	

	if (mn->do_get_modem_info) {
		kill(mn->do_get_modem_info, SIGKILL);
		mn->do_get_modem_info = 0;
	}

	if (mn->do_switch) {
		kill(mn->do_switch, SIGKILL);
		mn->do_switch = 0;
	}

	if (mn->do_get_status) {
		kill(mn->do_get_status, SIGKILL);
		mn->do_get_status = 0;
	}

	if (mn->do_dial_wait) {
		kill(mn->do_dial_wait, SIGKILL);
		mn->do_dial_wait = 0;
	}

	if (mn->do_modem_check) {
		kill(mn->do_modem_check, SIGKILL);
		mn->do_modem_check = 0;
	}
    
	if (mn->do_reset_set) {
		kill(mn->do_reset_set, SIGKILL);
		mn->do_reset_set = 0;
	}

	if (mn->do_get_reg_info) {
		kill(mn->do_get_reg_info, SIGKILL);
		mn->do_get_reg_info = 0;
	}

	if (mn->do_connect) {
		kill(mn->do_connect, SIGKILL);
		mn->do_connect = 0;
	}     
	/*stop asynch action*/
	CDMG_DO_FUNC(stop, "%s", " --asynch");

	/*undial force*/
	CDMG_DO_FUNC(undial, "%s", " --force");
}

/*
*	Switch function
*/
static void switchdelay_timer(void *data)
{
	int argc = 1;
	char *argv[1] = {"usbswitch"};

	d_printf("try to do switch again\n");
	process_switch_start(argc, argv);
}

static void switch_timeout_timer(void *data)
{
	d_printf("switch time out\n");

	if (mn->do_switch) {
		kill(mn->do_switch, SIGTERM);
		mn->do_switch = 0;
		timer_del_by_token("switchdelay_timer");
	}		
}


static int  process_switch_start(int argc, char *argv[])
{
	record_3g("switch start:%d, do_hotplug:%d\r\n",
		mn->do_switch, mn->do_hotplug);
		
	if (mn->do_switch) {
		debug_3g("/var/3g_debug_switch", "SWITCH",
			"switch have be done\n");
		return 0;
	}

	if (mn->do_hotplug) {
		debug_3g("/var/3g_debug_switch", "SWITCH",
			"NOTE:doing hotplug,set a timer to do it later\n");
		timer_del_by_token("switchdelay_timer");		
		timer_set(10, "switchdelay_timer", 
			switchdelay_timer, 0);		
		return 0;
	}

	timer_del_by_token("switchdelay_timer");
	timer_del_by_token("switch_timeout_timer");

	if (mn->mdm->status != SEARCH_INVALID) {
		d_printf("modem is init, not allow to do switch\n");
		return 0;
	}

	if ((mn->do_switch = fork_3g()) == 0) {
		sleep(DELAY_DO_SWITCH);

		/*do switch*/
		debug_3g("/var/3g_debug_switch", "SWITCH",
			"Switch Start...\n");
		if (!switch_mngr_switch_for_modem(mn->sw, argc, argv))
        {
            printf("Do default switch...\n");
            switch_mngr_switch_fixup(mn->sw);
        }
		debug_3g("/var/3g_debug_switch", "SWITCH",
			"process_switch end\n");

		/*notify the diald that the action is end*/
		sleep(5);
		CDMG_SEND_MSG(switch_end, "%s", "");
		exit(0);
	} else if (mn->do_switch < 0) {
		printf_3g("", "can not start switch process\n");
		mn->do_switch = 0;
	} else {
		d_printf("fork %d to handle switch\n", mn->do_switch);
		timer_set(TIMEOUT_DO_SWITCH_TATOL, 
			"switch_timeout_timer", 
			switch_timeout_timer, 0);
	}
	return 0;
}

/*
*this timer process is to clear the flag 'mn->do_switch_end'
*/
static void timer_clear_switch_end_flag(void *date)
{
	int *do_switch_end  = (int *)date;

	/*clear*/
	debug_3g("/var/3g_debug_switch", "SWITCH",
		"do_switch_end=%d, clear it\n", *do_switch_end);
	*do_switch_end = 0;
}

static int process_switch_end(int argc, char *argv[])
{
	debug_3g("/var/3g_debug_switch", "SWITCH","switch end\n");

	timer_del_by_token("switchdelay_timer");	
	timer_del_by_token("switch_timeout_timer");

	mn->do_switch = 0;
	/*indicate switch end*/
	mn->do_switch_end = 1;
	record_3g("switch end:%d, do_hotplug:%d\r\n",
		mn->do_switch, mn->do_hotplug);
	timer_set(10, "timer_clear_switch_end_flag", 
		timer_clear_switch_end_flag, 
		(void *)&mn->do_switch_end);
	return 0;
}
CDMG_SETUP_MSG(switch_end, process_switch_end, "");

/*switch function*/
FUNC(usbswitch, "try to switch the usb from storsge to modem\n"
				"args: --devpath=xxxxx")
{
	int ret = CDMG_FORK(0, 0, 0) ;

    /* ��ֹ����������뵽�����ļ�*/
    freopen("/dev/console","w",stdout);
    if (ret == CDMG_ENV_USER_SENT)
		return 0;
	else if (ret == CDMG_ENV_DAEMON) {
		/*let the switch do asynch to not block the daemon*/
		process_switch_start(argc,  argv);
		return 0;
	} else  {
		/*user call*/
#if 0        
		mngr_start(&mn, MNGR_START_CREATE_MODEM|
			MNGR_START_CREATE_SW);
		if (!switch_mngr_switch_for_modem(mn->sw, argc, argv))
        {      
		    printf("Do default switch...\n");
		    switch_mngr_switch_fixup(mn->sw);
        }
#endif
        /*�������̵Ľ������л������ᵼ���л��޷����ƣ�����˵
                ��usb��˫���õ�ʱ�򣬶�ε�ִ���л��ͻᵼ���豸��ͣ��
                ��λ���Լ��л�����������һ�ε��л�����Ϊ�޸����õ�ʱ��
                ��������ǵ�ǰ�����ã��ͻ�ʹ�����ø�λ�������Ϊ����
                ��������
             */
        CDMG_SEND_MSG(usbswitch, "%s", "");
		return 0;
	}
}
/*
*	Switch function End
*/


/*set reginfo to seraching*/
static int hotplug_search_nt_start(int argc, char *argv[])
{
	d_printf("set reginfo to seraching\n");

	modem_set_reg_info(mn->mdm, REG_INFO_SEARCH_START);
	modem_set_pin_info(mn->mdm, PIN_INFO_READY);
	mn->mdm->status = SEARCH_FINISHED;

	return 0;
}
CDMG_SETUP_MSG(hotplug_search_nt_start,
			hotplug_search_nt_start, "");

static void __process_hotplug(int delay, const char *hevent)
{
	char *pininfo = 0;
	
	sleep(delay);
	
	if (modem_search(mn->mdm) != 0) 
    {   
        d_printf("modem_search error\n");
        strncpy(mn->htplug_msg, "MODEM NOT FOUND", HTPLUG_MSG_SIZE);
		return;
    }

	modem_set_cmee_to_numeric(mn->mdm);

	modem_get_pin_info(mn->mdm, &pininfo);

	modem_get_lock_retry_time(mn->mdm, 0, 1);

	if (!pininfo)
    {
        d_printf("get pin info error\n");
        strncpy(mn->htplug_msg, "PIN INFO UNKOWN", HTPLUG_MSG_SIZE);
		return;
    }

	d_printf("%s\n", pininfo);
	
	if (strstr(pininfo, PIN_INFO_PIN) || strstr(pininfo, PIN_INFO_PUK)) {
		d_printf("at reboot, restore hotplug msg\n");
		strncpy(mn->htplug_msg, MNGR_MSG_NEEDPIN, HTPLUG_MSG_SIZE);
		return;
	} else if (strstr(pininfo, MNGR_MSG_INVALID))		
		return;

	/*set reginfo to seraching*/
	CDMG_SEND_MSG(hotplug_search_nt_start, "%s", "");

	modem_set_network_mode(mn->mdm); 

	sleep(1);

	modem_search_init(mn->mdm); 

	sleep(1);
	
	modem_wait_search_nt(mn->mdm); 

	if (!modem_reg_is_ready(mn->mdm))
		return;	

	strncpy(mn->htplug_msg, hevent, sizeof(mn->htplug_msg) - 1);
	
	d_printf("store hotplug result:[%s]\n", mn->htplug_msg);
	
	return;
}

/* ����һ�β�ѯע��״̬ʧ���Ժ󣬻������ѯ */
static void get_reg_info_timer(void *data)
{
    modem_set_reg_info(mn->mdm, REG_INFO_SEARCH);
    lib3g_send_mobile_chage_msg(REG_INFO_SEARCH);
    if ((	mn->do_get_reg_info = fork_3g()) == 0) {
        int reg = -1;
        
        if ((reg = modem_get_reg_for_check(mn->mdm)) >= 0)
        {
            if (reg == 1)   /* local */
                strncpy(mn->htplug_msg, REG_INFO_REG_LOCAL, 80);
            else    /* roam */
                strncpy(mn->htplug_msg, REG_INFO_REG_ROAM, 80);
            CDMG_SEND_MSG(getregend, "%d", reg);
            exit(0);
        }
        else
        {
            strncpy(mn->htplug_msg, REG_INFO_NOT_REG, 80);
        }
        //modem_write_info();
        CDMG_SEND_MSG(getregend, "%s", "NETWORK_NOT_REGISTERED");
        exit(0);
    }    
}

static int process_getreg_end(int argc, char *argv[])
{
    //int i;

    //for(i = 0; i < argc; i++)
    //{
    //    printf("%s:argv[%d] = %s\n", __func__, i, argv[i]);
    //}
    
    //modem_set_reg_info(mn->mdm, argv[1]);
    
    if (strcmp(argv[1], "NETWORK_NOT_REGISTERED") == 0)
    {
		timer_set(5, "get_reg_info_timer", 
			get_reg_info_timer, (char *)0);
        return 0;
    }
    if (argv[1][0] == '1')
    {
        modem_set_reg_info(mn->mdm, REG_INFO_REG_LOCAL);
        lib3g_send_mobile_chage_msg(REG_INFO_REG_LOCAL);
    }
    else
    {
        modem_set_reg_info(mn->mdm, REG_INFO_REG_ROAM);
        lib3g_send_mobile_chage_msg(REG_INFO_REG_ROAM);
    }
    /* ready */
    strncpy(mn->htplug_msg, "ready", sizeof(mn->htplug_msg));
    
    if ((   mn->do_modem_check = fork_3g()) == 0) {
        d_printf("start to handle modem check process, pid = %d\n", getpid());
        check_process(mn->mdm);
        exit(0);
    }

	/*
	* scb+ 2012-1-18 filter function, 
	* only support some dongle or some network
	*/
	if (!modem_filter_is_allow("", "")) {
		d_printf("FILTER:Not allow\n");
		modem_init(mn->mdm);
		return 0;
	}

	lib3g_send_mobile_chage_msg(mn->htplug_msg);
	conn_mngr_set(mn->cnn);
	hotplug_notify(1);
	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);
    d_printf("reg ok\n");
	return 0;
}
CDMG_SETUP_MSG(getregend, process_getreg_end, "");
static void hotplug_timeout_timer(void *data)
{
	d_printf("hotplug timeout, kill the task %d\n", mn->do_hotplug);
	kill(mn->do_hotplug, SIGKILL);
	mn->do_hotplug = 0;
	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);	
    if (mn->mdm->status != SEARCH_FINISHED)
    {
        printf("modem init fail\n");
        return;
    }
	modem_set_reg_info(mn->mdm, REG_INFO_NOT_FIND);
	lib3g_send_mobile_chage_msg(REG_INFO_NOT_FIND);

    /* continue to get reg info,till moderm has been registered */
    timer_set(5, "get_reg_info_timer", 
        get_reg_info_timer, (char *)0);
}

static void hotplugdelay_timer(void *data)
{
	d_printf("try to do hotplug again\n");
	process_hotplug_start(0, 0);
}

/*hotplug command*/
static int process_hotplug_start(int argc, char *argv[])
{
	d_printf("Try to  do hotplug\n");
	record_3g("hotplug start:%d, send_hotplug:%d, do_switch:%d\r\n", 
		mn->do_hotplug, mn->send_hotplug, mn->do_switch);
	
	if (mn->do_hotplug) {
		d_printf("hotplug has being do\n");
		return 0;
	}

	if (mn->send_hotplug)
		return 0;

	if (mn->do_switch) {
		d_printf("NOTE:doing swich,set a timer to do it later\n");
		timer_del_by_token("hotplugdelay_timer");
		timer_set(5, "hotplugdelay_timer", 
			hotplugdelay_timer, (char *)0);
		return 0;
	}

	mn->send_hotunplug = 0;

	memset(mn->htplug_msg, 0, sizeof(mn->htplug_msg));
	
	if ((	mn->do_hotplug = fork_3g()) == 0) {
		d_printf("start to handle hotplug\n");
		__process_hotplug(DELAY_DO_HOTPLUG, "ready");

		/*write the result to a file to let the diald to get the modem info*/
		modem_write_info();	

		/*let daemon do the last part*/
		CDMG_SEND_MSG(hotplugend, "%s", "");
		
		exit(0);
	} else if (mn->do_hotplug  > 0) {
		timer_set(TIMEOUT_DO_HOTPLUG_TALTOL, 
			"hotplug_timeout_timer",
			hotplug_timeout_timer, (void *)mn);
	}

	return 0;
}
__CDMG_SETUP_MSG(hotplug, 0, 0, process_hotplug_start,
			"hotplug proccess.\n"
                    "when usb is ensert, send a msg:'ready' to ssk");

static int process_hotplug_end(int argc, char *argv[])
{
	mn->do_hotplug = 0;
	
	modem_read_info(mn);

	record_3g("hotplug end:%d, send_hotplug:%d, do_switch:%d\r\n", 
		mn->do_hotplug, mn->send_hotplug, mn->do_switch);

	timer_del_by_token("hotplug_timeout_timer");
    timer_del_by_token("switchdelay_timer");

	if (!mn->htplug_msg[0]) {
		d_printf("hotplug no result\n");
        /* continue to get reg info,till moderm has been registered */
        timer_set(5, "get_reg_info_timer", 
            get_reg_info_timer, (char *)0);        
		return 0;
	}

    if ((   mn->do_modem_check = fork_3g()) == 0) {
        d_printf("start to handle modem check process, pid = %d\n", getpid());
        check_process(mn->mdm);
        exit(0);
    }
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	if (access(DELAY_HOTPLUG_FLAGE_FILE, F_OK) == 0) {
		d_printf("hotplug need delay\n");
		return 0;
	}
#endif	

	/*
	* scb+ 2012-1-18 filter function, 
	* only support some dongle or some network
	*/
	if (!modem_filter_is_allow("", "")) {
		d_printf("FILTER:Not allow\n");
		modem_init(mn->mdm);
		return 0;
	}

	lib3g_send_mobile_chage_msg(mn->htplug_msg);
	conn_mngr_set(mn->cnn);
	hotplug_notify(1);
	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);

	return 0;
}
CDMG_SETUP_MSG(hotplugend, process_hotplug_end, "");

static int  process_hotunplug(int argc, char *argv[])
{
	d_printf("enter\n");
	record_3g("hotunplug start %s", "");
	
	if (mn->send_hotunplug)
		return 0;
#if 0
	if (mn->run_on_diald) {
		d_printf("check if exist tty\n");
		if (modem_is_exist_tty(mn->mdm)) {
			d_printf("Exist tty, nothing to do\n");
			return 0;
		}
	}
#endif
	d_printf("modem status:%s\n", 
		mn->mdm->status?
		"SEARCH_FINISHED":"SEARCH_INVALID");

	/* 
	 * scb+ 2012-8-13, when in init status, 
	 * do unplug, the status will become switching 
	 */
	mn->do_switch_end = 0;
	
	stop_all_asyn_action();

	if (mn->mdm->status != SEARCH_FINISHED) {
		d_printf("modem has not init, so return right now!");
		return 0;
	}

	/*Set this to indicate the modem is invalid,
	*because some info at modem is needed  at hotplug_notify, so 
	*here can not do modem_init()
	*/
	mn->mdm->status = SEARCH_INVALID;
	
	//lib3g_send_mobile_chage_msg(MNGR_MSG_HOTUNPLUG);
	hotplug_notify(0);	
	
	at_cmd_free(mn->at);
	dial_mngr_init(mn->dial);
	modem_init(mn->mdm);	
	mn->send_hotplug = 0;
	mn->send_hotunplug = 1;	
	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);
	wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);	

    set_ndis_interface(0);
    record_3g("hotunplug end %s", "");
    
    lib3g_send_mobile_chage_msg(MNGR_MSG_HOTUNPLUG);

    dettachLTEDriver();
    
	return 0;
}
__CDMG_SETUP_MSG(hotunplug, 0, 0, process_hotunplug,
			"hotplug proccess.\n"
                    "when usb is unplug, undial the modem");



static int  process_msg_pinready(int argc, char *argv[])
{
	//at_cmd_free(mn->at);
	//modem_init(mn->mdm);
	param_init(mn->par);
	mn->send_hotplug = 0;
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	if (mn->htplug_msg[0]) {
		unlink(DELAY_HOTPLUG_FLAGE_FILE);
		memset(mn->htplug_msg, 0, 80);
	}
#endif

	if (mn->do_hotplug) {
		d_printf("hotplug has being do\n");
		return 0;
	}

	mn->send_hotunplug = 0;

	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);
	
	if ((	mn->do_hotplug = fork_3g()) == 0) {
		__process_hotplug(10, "pinready");

		/*write the result to a file to let the diald to get the modem info*/
		modem_write_info();	
		
		CDMG_SEND_MSG(hotplugend, "%s", "");
		exit(0);
	} else if (mn->do_hotplug  > 0) {
		modem_set_reg_info(mn->mdm, REG_INFO_SEARCH);
		modem_set_pin_info(mn->mdm, PIN_INFO_READY);
		timer_set(120+10, "hotplug_timeout_timer", 	
			hotplug_timeout_timer, (void *)mn);
	}

	return 0;
}
__CDMG_SETUP_MSG(pinready, 0, 1, process_msg_pinready, "");
__CDMG_SETUP_MSG(pukready, 0, 1, process_msg_pinready, "");


static int  process_cmd_upload(int argc, char *argv[])
{	
	d_printf("stop all action\n");
	stop_all_asyn_action();
	
	d_printf("init modem and at\n");
	at_init(mn->at);
	modem_init(mn->mdm);

	d_printf("Re-set ids to kernel\n");
	CDMG_DO_FUNC(setids, "");

	d_printf("DO switch,hotplug again\n");
	CDMG_SEND_MSG(usbswitch, "%s", "");
	CDMG_SEND_MSG(hotplug, "%s", "");
	return 0;
}
__CDMG_SETUP_MSG(upload, 0, 0, process_cmd_upload, 
				"after upload the driver, need to do something\n");



#ifdef SUPPORT_IP_CONNECT_CHECK
/*format:
*	ipconnect -0[-1]   0 maens ping fail, 1 success
*/
static int process_msg_pingstatus(int argc, char *argv[])
{
	char msg[32] = {0};
	int is_success = CDMG_GET_ARG("1", 0);

	if (!is_success) {
		if (mn->mdm->status != SEARCH_FINISHED) {
			d_printf("no usb modem\n");
			return 0;	
		}

		if (modem_pin_is_ready(mn->mdm) && 
				!modem_reg_is_ready(mn->mdm)) {
			d_printf("network not register\n");
			return  0;
		}
		wan_mngr_ping_status_change(0);
	} else
		wan_mngr_ping_status_change(1);

	snprintf(msg, sizeof(msg), IP_CONN_CHECK_MSG"=%d", is_success);
	d_printf("send %s to user task\n", msg);

	/*send to ssk or logic*/
	lib3g_send_mobile_chage_msg(msg);

	return 0;
}
__CDMG_SETUP_MSG(ipconect, 0, 1, process_msg_pingstatus, "");

#endif

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
static int  process_hotplug_delay(int argc, char *argv[])
{
	d_printf("enter:[%s]\n", mn->htplug_msg);    
	unlink(DELAY_HOTPLUG_FLAGE_FILE);

	if (!mn->htplug_msg[0]) {
		d_printf("hotplug no result\n");
		return 0;
	}

	lib3g_send_mobile_chage_msg(mn->htplug_msg);
	conn_mngr_set(mn->cnn);		
	hotplug_notify(1);
	memset(mn->htplug_msg, 0, HTPLUG_MSG_SIZE);	

	return 0;
}
__CDMG_SETUP_MSG(process_hotplug_delay, 0, 1, 
	process_hotplug_delay, "");
#endif

/****************************************************************************************/
int diald_msg_action_getmodeminfo(int argc, char *argv[], 
			char *rbuf, int rlen)
{
	struct modem_3g_info *info;
	

	info = (struct modem_3g_info *)rbuf;

	info->magic[0] = 'a';
	info->magic[1] = 'b';
	info->magic[2] = 'c';

	if (modem_search(mn->mdm) != 0) {
		d_printf("no usb\n");
		info->have_modem = 0;
	} else {
		info->have_modem = 1;
		
		//modem_get_pin_info(mn->mdm, 0);
		info->pin_ready = modem_pin_is_ready(mn->mdm);

		//modem_get_reg_info(mn->mdm, 0);
		info->reg_ready = modem_reg_is_ready(mn->mdm);
		
		info->ping_enable = mn->cnn->enable;

		info->pin_enter_retry_time = modem_get_lock_retry_time(
				mn->mdm, "pin", 0);
		info->puk_enter_retry_time = modem_get_lock_retry_time(
				mn->mdm, "puk", 0);
		info->pin_change_retry_time = modem_get_lock_retry_time(
				mn->mdm, "pin_change", 0);
		info->lock_change_retry_time = modem_get_lock_retry_time(
				mn->mdm, "lock_change", 0);		

		if (mn->cnn->check_type == CHECK_TYPE_SUCCESS) {
			info->ping_for_success = 1;
		} else if (mn->cnn->check_type == CHECK_TYPE_FAIL) {
			info->ping_for_success = 0;
		} else
			info->ping_for_success = -1;		
				
		info->ping_start = conn_mngr_is_start(mn->cnn);
	}

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	info->web_state = (int)web_mngr_get_state(mn->web);
	d_printf("info->web_state=%d\n", info->web_state);
#endif	


	return sizeof(struct modem_3g_info);
}
__CDMG_SETUP_GET(getmodeminfo, 1, diald_msg_action_getmodeminfo,
		0, 0, "");



/*init function */
static void msg_init(void *date)
{
	wan_init();
}

/******************************************************************************************/

FUNC(diald, 
	"recever the dial and undial msg, then to do corresponding action\n"
	"\texmap:3g-mngr diald\n"
	"\texmap:3g-mngr diald --debug='file_name or func_name or all' -m -i -r\n"
	"\t\t--debug show log of 'file_name' or 'func_name' or all\n"
	"\t\t-m \t run at backgrand\n"
	"\t\t-i \t show /proc/bus/usb/devices info\n"
	"\t\t-r \t restart 3g-mngr diald")
{
	int i = 0;
	int fd = 0;
	pid_t pc = 0;
	pid_t *old_pc = 0;
	char debug_info[80] = {0};
	char debug_tag_file[128] = {0};

	/*scb+ 2012-7-5 for restart diald, kill the old*/
	if (MNGR_GET_ARG_LEN("r", 0, 0)) {
		printf("Restart 3g-mngr diald\n");
		pc = getpid();
		old_pc = lib3g_find_pid_by_name("3g-mngr diald");
		if (old_pc) {
			for (i = 0; old_pc[i]; i++) {
				if (old_pc[i] != pc) {
					printf("kill old diald:%d\n", (int)old_pc[i]);
					kill(old_pc[i], SIGKILL);
					sleep(1);
				}
			}
			free(old_pc);
		}
	}

	/*scb+ 2012-7-5 create debug tag file*/
	if (MNGR_GET_ARG("debug", debug_info)) {
		printf("debug for show log:[%s]\n", debug_info);
		if (!strcmp(debug_info, "all")) {
			snprintf(debug_tag_file, 
				sizeof(debug_tag_file), 
				"%s", 
				DAIL_DEBUF_CONTR_FILE);
		} else {
			snprintf(debug_tag_file, 
				sizeof(debug_tag_file),
				"/var/%s",
				debug_info);
		}
		fd = open(debug_tag_file, O_RDWR|O_CREAT);
		if (fd != -1)
			close(fd);
	} else
		unlink(DAIL_DEBUF_CONTR_FILE);

	/*scb+ 2012-7-5 show 3g info*/
	if (MNGR_GET_ARG_LEN("i", 0, 0)) {
		char buf[8192] = {0};
		printf("\nWan config info:\n------------------------------\n");	
		system("3g-mngr wandump");
		
		printf("\nShow deces:\n------------------------------\n");
		lib3g_read_file("/proc/bus/usb/devices", buf, sizeof(buf)-1);
		write(1, buf, strlen(buf));

		printf("\n------------------------------\n\n3g-mngr info:\n");
		system("\n3g-mngr info");
		printf("\n------------------------------\n");
	}
	
	/*scb+ 2012-7-5, check if does exist the old diald*/
	pc = getpid();
	old_pc = lib3g_find_pid_by_name("3g-mngr diald");		
	if (old_pc) {
		for (i = 0; old_pc[i]; i++) {
			if (old_pc[i] != pc) {
				printf("3g-mngr diald exist not start\n");
				free(old_pc);
				return 0;
			}
		}
		free(old_pc);
	}

	/*scb+ 2012-7-5, run at background*/
	if (MNGR_GET_ARG_LEN("m", 0, 0)) {
		printf("Run at backgroud\n");
		if (fork() != 0)
			return 0;
	}


	
	/*
	* detach from the terminal so we don't catch the user typing control-c.
	* On the desktop, it is smd's job to catch control-c and exit.
	*/
	if (setsid() == -1)
	{
		printf("Could not detach from terminal\n");
	}
	else
	{
		d_printf("detached from terminal\n");
	}
    
    if (search_storage_device(NULL, NULL, NULL, 0) > 0)
    {
    	if (fork_3g() == 0) {
    		sleep(5);
    		d_printf("Try to do usbswitch\n");
    		system("3g-mngr usbswitch");
    		exit(0);
    	}   
    }
    if (search_usb_modem_device() > 0)
    {
    	if (fork_3g() == 0) { 		
            //sleep time must more than '3g-mngr usbswitch'
    		sleep(7);
    		d_printf("Try to do hotplug\n");
    		system("3g-mngr hotplug");
    		exit(0);
    	}        
    }
	/*set the ids for usb module*/
	if (fork_3g() == 0) {
		sleep(1);
		system("3g-mngr setids");
		exit(0);
	}	
   
	//daemon(0, 0);

#if 0
	pc = 0;
	mngr_diald(mn);
#else

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	if ((fd = open(DELAY_HOTPLUG_FLAGE_FILE, O_CREAT)) > 0)
		close(fd);

	if (fork_3g() == 0) {
		sleep(DELAY_HOTPLUG_TIME);

		FILE *pf = NULL;
		char line[64] = {0};
		int bootupdelay = 0;

		/* yzw+, 20110104, Add 3G backup delay time after CPE boot up settings */
		if ((pf = fopen(DELAY_BOOT_UP_FILE, "r")) != NULL)
		{
			if (fgets(line, sizeof(line), pf))
			{
			     /* 
			    * after bootup delay, CPE still need wait 60s to check the WAN link status, 
			    * so add 60s again. and other time should adjust by many tests. 
			    */
				bootupdelay = atoi(line) + 60 - DELAY_HOTPLUG_TIME - 70;

			     /* sleep again */
				if (bootupdelay > 0)
				{
					sleep(bootupdelay);
				}
			}
			fclose(pf);
			unlink(DELAY_BOOT_UP_FILE);
		}

		if (access(DELAY_HOTPLUG_FLAGE_FILE, F_OK) == 0)
		{
			d_printf("tell diald to send the prev hotpluh msg\n");
			CDMG_SEND_MSG(process_hotplug_delay, "%s", "");
		}

		unlink(DELAY_HOTPLUG_FLAGE_FILE);
		
		exit(0);
	}
#endif


	for(;;)
	{
		if ((pc = fork_3g()) <0 )
			printf("can not create diald monitor process!\n");
		else if (pc == 0){
			d_printf("Create diald monitor process with pid of %d.\n", getpid());
			/*setup mngr*/
			mngr_start(&mn, 0xffffffff);	
			mn->run_on_diald = 1;	
			mn->diald_pid = mn->this_pid = getpid();

			/*Start daemon*/
			cdmg_daemon(0, "DIALD", msg_init, 0);
		} else {
			pid_t pid = 0;
			int s = 0;
			
			do {
				pid = waitpid(pc, &s, 0);
				if(WIFEXITED(s))
				{
					d_printf("process %d exit normally.\n", pid);
					d_printf("the return code is %d.\n", WEXITSTATUS(s));
				}else 
					printf_3g("", "process %d exit abnormally.\n", pid); 
			} while(pid != pc);
			
			lib3g_send_mobile_chage_msg(MNGR_MSG_HOTUNPLUG);
		}    
	}
#endif   
	return 0;
}


FUNC(getinfo, "test the get modem info function.\n"
				"For testing the function lib3g_get_modem_info()\n")
{
	struct modem_3g_info info;

	if (lib3g_get_modem_info(&info) != 0) {
		printf("get modem inf error\n");
		return 0;
	}
		

	printf("info.have_modem=%d\n", info.have_modem);
	printf("info.pin_ready=%d\n", info.pin_ready);
	printf("info.pin_enter_retry_time=%d\n", info.pin_enter_retry_time);
	printf("info.puk_enter_retry_time=%d\n", info.puk_enter_retry_time);
	printf("info.pin_change_retry_time=%d\n", info.pin_change_retry_time);
	printf("info.lock_change_retry_time=%d\n", info.lock_change_retry_time);	
	printf("info.reg_ready=%d\n", info.reg_ready);
	
	printf("info.ping_enable=%d\n", info.ping_enable);
	printf("info.ping_start=%d\n", info.ping_start);
	printf("info.ping_for_success=%d\n", info.ping_for_success);	
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	printf("info.web_state=%d\n", info.web_state);
#endif	

	
	return 0;
}


/***************************************************
function: showing the old hotplug and switch delay parameter 
		to the user
args	: 
return:none
note: create at 2011-8-24
**************************************************/	
static int msg_get_setdelay(int argc, char *argv[], char *rbuf, int len)
{
	if (rbuf && len > 0) {
		snprintf(rbuf, len, "delay_do_hotplug:%d delay_do_switch:%d", 
			delay_do_hotplug, delay_do_switch);

		return strlen(rbuf) + 1;
	} else
		return 0;	
}
__CDMG_SETUP_GET(msg_get_setdelay, 1, msg_get_setdelay, 0, 0, "");

/***************************************************
function: the command line for setting hotplug and switch delay 
		parameter
args	: 
return:none
note: craete at 2011-8-24
**************************************************/		
CDMG_FUNC(setdelay, 1, 0, 0, 0, 0, 0,
				"set hotplug delay time and switch delay time\n"
				"\texam: 3g-mngr setdelay --show --hotplug=xx --switch=xx\n")
{
	char *buf = 0;
	char show[4] = {0};
	char hotplug[4] = {0};
	char switchdelay[4] = {0};

	/*if is need to show*/
	if (!cdmg_is_on_daemon() && MNGR_GET_ARG("show", show) &&
			show[0] != '0')
	{
		CDMG_SEND_AND_GET(buf, 1000000, msg_get_setdelay, "%s", "");
		if (buf) {
			/*output */
			printf(buf);
			free(buf);
		}
		return 0;
	}

	/*let the command run at diald process*/
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	/*get the new parameter from command line*/
	MNGR_GET_ARG("hotplug", hotplug);
	MNGR_GET_ARG("switch", switchdelay);
	
	/*change hotplug delay time*/
	if (hotplug[0]) {
		delay_do_hotplug = strtoul(hotplug, 0, 10);
		if (delay_do_hotplug < 3)
			delay_do_hotplug = 3;	
		if (delay_do_hotplug > DELAY_DO_HOTPLUG_MAX)
			delay_do_hotplug = DELAY_DO_HOTPLUG_MAX;		
		
	}

	/*change switch delay time*/
	if (switchdelay[0]) {
		delay_do_switch = strtoul(switchdelay, 0, 10);
		if (delay_do_switch < 3)
			delay_do_switch = 3;
		
		if (delay_do_switch > DELAY_DO_SWITCH_MAX)
			delay_do_switch = DELAY_DO_SWITCH_MAX;

		if (delay_do_hotplug > DELAY_DO_HOTPLUG_MAX)
			delay_do_hotplug = DELAY_DO_HOTPLUG_MAX;
	}

	/*debug output*/
	d_printf("delay_do_switch=%d, delay_do_hotplug=%d\n",
		delay_do_switch, delay_do_hotplug);

	return 0;	
}

static void hotplug_notify(int is_hotplug)
{
	wan_mngr_dial_set(WAN_DIAL_ACT_INIT,0,0,0,0);
	
	wan_mngr_ping_for_hotplug_notify(is_hotplug);
	wan_mngr_dial_for_hotplug_notify(is_hotplug);
	wan_mngr_conn_for_hotplug_notify(is_hotplug);
	param_for_hotplug_notify(is_hotplug);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB
       wan_mngr_web_rule_for_hotplug_notify(is_hotplug);
#endif

        /*
        * scb+ 2011-10-28 if pinready means the user enter the code.
        * so need to dail right now
        */
        if (!strncmp(mn->htplug_msg, "pinready", HTPLUG_MSG_SIZE))
               wan_mngr_dial_set(WAN_DIAL_ACT_SET_DIAL_DELAY,0,0,0,0);
        else
               wan_mngr_dial_set(WAN_DIAL_ACT_SET_DIAL_DELAY,0,0,0,5);

       wan_mngr_dial_decide();
}
typedef struct {
	void  (*check_func)(modem_t *mdm);
    struct timeval interval;
	struct timeval timeout;
} check_func_t;

static void check_csq_notify(modem_t *mdm)
{
    int csq = 99;       /* invalid csq */
    int try = 3;
    char msg[50] = {0};
    
    while ((modem_get_csq_for_check(mdm, &csq) < 0) && (try-- > 0))
    {
        usleep(1000);
    }
    //printf("get csq = %d\n", csq);
    snprintf(msg, sizeof(msg) - 1, "%s=%d", MNGR_MSG_SIGNAL, csq);
    lib3g_send_mobile_chage_msg(msg);
}
#ifdef LTE_CS_CALL
static void check_cs_info(modem_t *mdm)
{
    int fd;
    fd_set fds;
    struct timeval tv;
    char buf[256] = {0};
    char *tty = NULL;
    struct stat stats;

    if (stat(MSG_UNIX_REPORT_PATH, &stats) != 0)    /* voipû�н�����Ϣ */
    {
        return;
    }
#if 0
    if(CDMG_SEND_AND_GET(tty, 300000, ctrl_tty, "%s", "") < 0 || !tty)   /* ��֪������tty�����ü����ϱ� */
    {
        d_printf("no ctl tty -------------\n");
        return;
    }
#endif
    if ((tty = comm_get_ctrl_tty_direct(mdm)) == NULL)
    {
        d_printf("no ctl tty -------------\n");
        return;

    }
    if ((fd = open (tty, O_RDWR | O_NOCTTY | O_NONBLOCK)) < 0)
    {
		d_printf("can not open %s\n", tty);
		return;
	}     
    
    if (flock(fd, LOCK_EX|LOCK_NB) != 0)
    {
        d_printf("cannot get lock----, pid = %d\n", getpid());
        close(fd);
        return;
    }
    //printf("%s:enter\n", __func__);
    FD_ZERO(&fds);
	FD_SET(fd,&fds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    
    if (select(fd + 1, &fds, NULL, NULL, &tv) > 0) 
    {
        if(FD_ISSET(fd,&fds))
        {
            if (read(fd, buf, 256 - 1) > 0)
            {
                printf("send %s to voip\n", buf);
                lib3g_send_voip_echo_msg(buf);
            }
        }
    }
    
    flock(fd, LOCK_UN);
    close(fd);
}
#endif
check_func_t check_funcs[] = {
    {check_csq_notify, {20, 0}, {0, 0}},
//    {check_reg_notify, 30, 0},
#ifdef LTE_CS_CALL    
    {check_cs_info, {0, 100000},{0,0}},
#endif
    {NULL, {0,0}, {0,0}},
};

/* ����һЩ��Ҫ����ִ�е��������Ƕ������������˵���ڲ�ѯע����Ϣ������csq�� */
static void check_process(modem_t *mdm)
{
    int i;
    struct timeval tv;

    gettimeofday(&tv, NULL);
    /* init timeout */
    for(i = 0; check_funcs[i].check_func; i++)
    {
        check_funcs[i].timeout.tv_sec = tv.tv_sec;
        check_funcs[i].timeout.tv_usec = tv.tv_usec;
    }
    
    while(1)
    {
        memset(&tv, 0, sizeof(tv));
        gettimeofday(&tv, NULL);
        for(i = 0; check_funcs[i].check_func; i++)
        {
#if 0        
            //printf("curr(%d,%d), timeout(%d,%d)\n", (int)tv.tv_sec, (int)tv.tv_usec,
            //    (int)check_funcs[i].timeout.tv_sec, (int)check_funcs[i].timeout.tv_usec);
            if ((tv.tv_sec > check_funcs[i].timeout.tv_sec) ||
                ((tv.tv_sec == check_funcs[i].timeout.tv_sec) &&
                (tv.tv_usec > check_funcs[i].timeout.tv_usec)))
            {
                //printf("curr time, sec = %d, usec = %d interval(%d, %d)\n", 
                //    (int)tv.tv_sec, (int)tv.tv_usec, (int)check_funcs[i].interval.tv_sec,
                //    (int)check_funcs[i].interval.tv_usec);
                check_funcs[i].check_func(mdm);
                /* set next timeout */
                check_funcs[i].timeout.tv_sec = tv.tv_sec + check_funcs[i].interval.tv_sec;
                if ((tv.tv_usec + check_funcs[i].interval.tv_usec) >= 1000000)
                    check_funcs[i].timeout.tv_sec++;
                check_funcs[i].timeout.tv_usec = (tv.tv_usec + check_funcs[i].interval.tv_usec)%1000000;
            }
#endif            
        }        
        usleep(50000);
    }
}
