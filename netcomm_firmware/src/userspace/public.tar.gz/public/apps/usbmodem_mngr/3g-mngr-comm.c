#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include<sys/wait.h>
#include <sys/ioctl.h>


//#include "lib/3g-lib.h"
#include "3g-mngr-include.h"

char g_usb_dongle_ifname[IFNAME_LEN+1] = IF_PPP_NAME;

/*wait the sub task to exit*/
void wait_sub_process()
{
	int status = 0;
	pid_t pr;

	d_printf("%d receive SIGCHLD\n", getpid());
	
	while((pr = waitpid(-1, &status, WNOHANG)) > 0) {
		if(WIFEXITED(status))
		{
			d_printf("process %d exit normally.\n",pr);
			d_printf("the return code is %d.\n", WEXITSTATUS(status));
		}else 
			d_printf("process %d exit abnormally.\n", pr); 
	}
}

void signal_handler_set(int sig, void (*handler)())
{
	struct sigaction sa;
	sigset_t signals_handled;

	memset(&sa, 0, sizeof(sa));
	sigemptyset(&signals_handled);
	sigaddset(&signals_handled, sig);   
	sa.sa_mask = signals_handled;
	sa.sa_handler = handler;
	sigaction(sig, &sa, NULL);	
}

void signal_init()
{   
	signal_handler_set(SIGCHLD, wait_sub_process);
	signal(SIGPIPE, SIG_IGN);
}

pid_t fork_3g()
{
	int ret = 0;
	char buf[4] = {0};
	int	fds[2];
	pid_t pid = 0;
	
	ret = pipe(fds);


	if ((pid = fork()) == 0) {
		if (ret == 0) {
			read(fds[0], buf, 1);
			close(fds[0]);
			close(fds[1]);
			/*
			* FIX me:if the sub task exit,
			* the father can not receive the SIGCHID.
			* then will exist a corpse task,
			* so need add this delay.
			*/
			usleep(200000);
		}
		if (mn)
			mn->this_pid= getpid();
	} else {
		if (ret == 0) {
			write(fds[1], "O", 1);
			close(fds[0]);
			close(fds[1]);
		}
	}
	
	
	return pid;
}

/******************************************************************/

FUNC(reg, "test the rematch pattner\n"
			"args: 3g-mngr reg test_string pattner_sting")
{
	char t_s[REG_STR_BUF_SIZE] = {0};
	char pattn[REG_EXPR_BUF_SIZE] = {0};
	char rbuf[REG_STR_BUF_SIZE] = {0};


	if ( argc < 3)
		return 0;

	strncpy(t_s, argv[1],  REG_STR_BUF_SIZE-1);
	strncpy(pattn, argv[2], REG_EXPR_BUF_SIZE-1);
	printf("str:\t%s\n", t_s);
	printf("pattn:\t%s\n", pattn);
	lib3g_reg_exec(t_s, pattn, rbuf, REG_STR_BUF_SIZE-1);
	printf("ret:\t%s\n", rbuf);	
	return 0;
}

FUNC(receve, "for debug. create a unix socket to receve the link notify msg\n"
                      "the ssk can use 'init_mobile_msg_recever_socket()' to init a socket\n"
                      "then use 'receve_mobile_chage_msg(int sock, char *msg)' to recever link up msg")
{
	void dial_test_printf(char *s) 
	{ 
		fprintf(stdout, "RCVD:[%s]\n", s);
		fflush(stdout);
	}
	
	lib3g_msg_process_loop(MSG_UNIX_SEND_PATH, 0, "TEST", dial_test_printf, 0);
	
	return 0;
}

extern char **environ;
FUNC(ipup, "this function will be called at by pppd when linkup.\n"
                    "the call path: 'pppd-->/etc/ppp/ip-up-->3g-mngr ipup' \n" 
                    "it set the dns, default route and send a unix socket msg:'linkup' to the\n"
                    "up management such as ssk\n"
                    "exam: 3g-mngr ipup --dns1=xxx --dns2=yyy")
{
	char dns1[80] = {0};
	char dns2[80] = {0};
    char gateway[32] = {0};
    char ip[32] = {0};
    char netmask[32] = {0};
    char buf[1024] = {0};
    char *pdns = NULL;
	FILE *fp = 0;

	lib3g_fmt_script("mkdir -p "WORK_PATH);

	cdmg_get_arg(argv, "dns1", dns1,  sizeof(dns1) - 1);
	cdmg_get_arg(argv, "dns2", dns2,  sizeof(dns2) - 1);

	d_printf("dns1=%s,dns2=%s\n", dns1, dns2);

    if ((pdns = getenv("ip")) != NULL)
    {
        d_printf("ip = %s\n", pdns);
        strncpy(ip, pdns, sizeof(ip) - 1);
    }
    if ((pdns = getenv("router")) != NULL)
    {
        d_printf("router = %s\n", pdns);
        strncpy(gateway, pdns, sizeof(gateway) - 1);
    }
    if ((pdns = getenv("subnet")) != NULL)
    {
        d_printf("netmask = %s\n", pdns);
        strncpy(netmask, pdns, sizeof(netmask) - 1);
    }
	if (!dns1[0] && ((pdns = getenv("DNS1")) != NULL))
    {   
		strncpy(dns1, pdns, sizeof(dns1) - 1);
    }

	if (!dns2[0] && ((pdns = getenv("DNS2")) != NULL))
    {   
		strncpy(dns2, pdns, sizeof(dns2) - 1);
    }

    if (!dns1[0] && !dns2[0] && ((pdns = getenv("dns")) != NULL))
    {
        //printf("%s:dns = %s\n", __func__, pdns);
        strncpy(dns1, pdns, sizeof(dns1) - 1);
        if ((pdns = strchr(dns1, ' ')) != NULL)
        {
            strncpy(dns2, pdns+1, sizeof(dns1) - 1);
            *pdns = '\0';
        }
    }

    if (dns1[0])
        lib3g_fstrncat(buf, sizeof(buf), " --dns1=%s", dns1);
    if (dns2[0])
        lib3g_fstrncat(buf, sizeof(buf), " --dns2=%s", dns2);
    if (ip[0])
        lib3g_fstrncat(buf, sizeof(buf), " --ip=%s", ip);
    if (gateway[0])
        lib3g_fstrncat(buf, sizeof(buf), " --gateway=%s", gateway);
    if (netmask[0])
        lib3g_fstrncat(buf, sizeof(buf), " --netmask=%s", netmask);
    lib3g_fstrncat(buf, sizeof(buf), " --sessid=123");
	sleep(1);

	/* save the dns to a private file*/
	if ( (fp = fopen(DNS_FILE, "w+")) ){
		lib3g_set_dns(dns1, dns2, fp);
		fclose(fp);	
	}

#if defined(PC) && !defined(SUPPORT_3G_WAN_MANAGEMENT)
	lib3g_fmt_script("rm -f %sdns_bakup", WORK_PATH);
	lib3g_fmt_script("cp  -f /etc/resolv.conf   %sdns_bakup", WORK_PATH);
	lib3g_set_dns(DNS[0], DNS[1], 0);
	
	lib3g_fmt_script("ip route del default");
	lib3g_fmt_script("ip route add default dev %s", g_usb_dongle_ifname);	
#endif		

	/*send msg to daemon to let daemon do the remaind things*/
	CDMG_SEND_MSG(linkup, "%s", buf);

	return 0;   
}

FUNC(ipdown,  "this function will be called at by pppd when linkup.\n"
                         "the call path: 'pppd-->/etc/ppp/ip-down-->3g-mngr ipdown' \n" 
                         "it only set the dns to 0.not need to send msg to ssk\n")
              
{
#if defined(PC) && !defined(SUPPORT_3G_WAN_MANAGEMENT)
	lib3g_fmt_script("mkdir -p"WORK_PATH);
	lib3g_fmt_script("rm -f  /etc/resolv.conf");
	lib3g_fmt_script("cp -f %sdns_bakup  /etc/resolv.conf", WORK_PATH);
#endif

	/*send msg to daemon to let daemon do the remaind things*/
	CDMG_SEND_MSG(linkdown, "%s", "");

	return 0;   
}


FUNC(localip, "")
{
   char cmd[80] = {0};
   char buf[2048] = {0};
   char *p, *q;

   snprintf(cmd, sizeof(cmd), "sbin/ifconfig %s", g_usb_dongle_ifname); 
   
   lib3g_script_and_get_ret(cmd, buf);
   if ( (p = strstr(buf, "inet addr:"))) {
      p = p + strlen("inet addr:");
      if ( (q = strchr(p, ' '))) {
         *q = 0;
         printf(p);
         return 0;
      }
   }
   printf("-----");
   return -1;
}

FUNC(remoteip, "")
{
   char cmd[80] = {0};
   char buf[2048] = {0};
   char *p, *q;

   snprintf(cmd, sizeof(cmd), "sbin/ifconfig %s", g_usb_dongle_ifname); 
   
   lib3g_script_and_get_ret(cmd, buf);
   if ( (p = strstr(buf, "P-t-P:"))) {
      p = p + strlen("P-t-P:");
      if ( (q = strchr(p, ' '))) {
         *q = 0;
         printf(p);
         return 0;
      }
   }
   printf("-----");
   return -1;
}


/*Get 3g-mngr's status*/
static int comm_show_status(int argc, char *argv[], char *rbuf, int rlen)
{
	int ret = 0;
	
	d_printf("enter\n");

	ret = wan_show_status(mn->mdm, rbuf, rlen);

	d_printf("%s\n", rbuf?rbuf:"No result");

	if (ret > 0 && (strstr(rbuf, WAN_3G_CONNECTTED) ||
			strstr(rbuf, WAN_3G_DIALING) ||
			strstr(rbuf, WAN_3G_UNDIALING) ||
			strstr(rbuf, WAN_3G_CONNECTING) ||
			strstr(rbuf, WAN_3G_DIALWAITING)))
		return strlen(rbuf);

	if (ret > 0 && 
		strstr(rbuf, WAN_3G_DISCONNECTTED) &&
		strstr(rbuf, WAN_3G_DIAL_ON_DEMAND) &&
		wan_mngr_cond_check(
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_PING_ENBL|
			WAN_COND_CHECK_NETWORK))
		return strlen(rbuf);

	d_printf("To get status from the modem info\n");
	modem_show_status(mn->mdm, rbuf, rlen);
	
	return strlen(rbuf);
}
CDMG_SETUP_GET(status, comm_show_status, 0, 0, "show the modem status\n");


FUNC(info, "show the informations about the modem.\n"
			"When call this cmd, the modem is dialing, some info cannot be got!")
{
	/*For debug, not allow run at daemon*/
	if (cdmg_is_on_daemon()) {
		d_printf("This func not allow run at daemon\n");
		return 0;
	}
	
	mngr_start(&mn,
		MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_DIAL
		|MNGR_START_CREATE_AT
		|MNGR_START_CREATE_PAR);
	
	modem_info(mn->mdm);
	return 0;	
}

static int comm_diald_info_show(int argc, char *argv[], 
				char *rbuf, int rlen)
{
	modem_show(mn->mdm, rbuf, rlen);
	return strlen(rbuf);
}
CDMG_SETUP_GET(show, comm_diald_info_show, 0, 0, 
		"show the infomation to user.\n");


/*
** this action will do AT cmd, so will ocupy some time of the diald,
** so set the action yo asynch mode to let the daemon have time  to 
** do other things
*/
static int comm_show_default(int argc, char *argv[], char *rbuf, int rlen)
{
	d_printf("enter\n");
	
	memset(rbuf, 0, rlen);

	/*get default*/
	param_get_default(mn->par);

	/*print the default value*/
	param_show_default(mn->par, rbuf, rlen);

	return strlen(rbuf)+1;	
}
CDMG_SETUP_GET(default, comm_show_default, 1, 5, 
	"product the default setting values for user.\n");


FUNC(eject, "eject the cdrom\n"
		    "exam:3g-mngr eject --dev=xx --action=0|[1,2,3]\n"
		    "0--eject scsi, 1--smart cdrom,2--close cdrom")
{
	int do_flags = 0;
	char dev[80] = {0};
	char act[2] = {0};

	cdmg_get_arg(argv, "dev", dev, 80);
	cdmg_get_arg(argv, "action", act, 2);

	if (!dev[0]) {
#if defined (PC)
		strcpy(dev, "/var/dev/sr1");
#else
		strcpy(dev, "/var/dev/sr0");
#endif
	}

	switch (act[0]) {
	case '0':
		do_flags = 4;
		break;
	case '1':
		do_flags = 2;
		break;
	default:
		do_flags = 1;
		break;
	}

	return lib3g_eject(dev,  do_flags);
	
}

static int ifname_show(int argc, char *argv[], 
				char *rbuf, int rlen)
{
    sprintf(rbuf, "%s", g_usb_dongle_ifname);
	return strlen(rbuf);
}
CDMG_SETUP_GET(ifname, ifname_show, 0, 0, 
		"get the interface name of the USB modem.\n");

/*No usefull, only for compatibility*/
CDMG_FUNC(wanup, 0, 0, 1, 0, 0, 0, "This cmd is used for compatibility\n")
{
	return 0;
}

FUNC(version, "Show versions\n")
{
	printf("Version:%s\nDate:%s\n", VERSION, DATE);
	return 0;
}
/*
** implement the cdmg's timer basic the 3g timer
*/
/*Create a timer*/
static void *  comm_timer_set(int tick, const char * name, 
			void(*timer_func)(void *data), void * data)
{
	return (void *)timer_set(tick, name, timer_func, data);
}

/*delete timer*/
static  void  comm_timer_del(void * timer)
{
	timer_del((struct timer_3g *)timer);
}

/*the timer expire check function*/
static struct timeval *comm_timer_handler(void * data)
{
	return timer_handler();
}

int main(int argc, char *argv[])
{
    d_printf("%s:enter\n", __func__);
    if (access(DEV_DIR, F_OK) != 0){
	system("mkdir -p "DEV_DIR);
	system("mkdir -p "WORK_PATH);
    }

	/*setup signal*/
	signal_init();

	/*init the cdmg lib's running evn*/
	cdmg_init(comm_timer_set, comm_timer_del, comm_timer_handler,
		MSG_UNIX_DAEMON_PATH);

	/*Start the shell*/
	cdmg_shell(argc,argv);

	return 0;
}
