/*
 *  ʹ��DHCP��ʽ��ȡusb moderm�ĵ�ַ��ʱ��һ����˵����Ҫͨ��
 *  ������̫�������·�һЩ���ģ�飬��ģ���ڲ���ɲ��ŵĲ�����
 *  ��Ҳ���Ǳ���ġ���Щģ�����úõģ����Ը����Ƿ���dhcp��ȡ��
 *  �������Ƿ��𲦺ţ�����Ҫ�κ��ض�������
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/usbdevice_fs.h>
#include "3g-mngr-dhcp.h"

static int greneral_lte_connect(modem_t *mdm);
static int general_lte_disconnect(modem_t *mdm);

static struct USB_MODERM_DEVICE g_dev_list[]={
    {{0x0000, 0x0000}, NULL, greneral_lte_connect, general_lte_disconnect},
};

static int greneral_lte_connect(modem_t *mdm)
{
    struct wan_config *config = wan_mngr_get_config();
 	int argc = 0;
	char *argv[CDMG_ARGS_NUM];
    char buf[512] = {0};
    char apn[80] = {0};
    
    if (!mdm || !config)
    {
        printf_3g("", "config is null\n");
        return -1;
    }
    
	if (config->apn[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --apn=%s", config->apn);

    cdmg_cmd_to_argv(buf, &argc, argv);
    //param_init(MN(mdm)->par);
    param_get_from_user(MN(mdm)->par, argc, argv);
    
    param_get_item(MN(mdm)->par, "apn", apn);

    //before do AT_DIAL, make sure the g_usb_dongle_ifname is down
    set_ndis_interface(0);
    
    at_do_cmd(MN(mdm)->at, AT_DIAL ,0, AT_NONE, 0, 0);

    return 0;
}

static int general_lte_disconnect(modem_t *mdm)
{
    if (!mdm)
    {
        printf_3g("", "mdm is null\n");
        return -1;
    }

    //before do AT_DIAL, make sure the g_usb_dongle_ifname is down
    set_ndis_interface(0);
    at_do_cmd(MN(mdm)->at, AT_HANGUP, 0, AT_NONE, 0, 0);
    return 0;   
}

struct USB_MODERM_DEVICE *usb_moderm_get_device(unsigned int vid, unsigned int pid)
{
    int size = sizeof(g_dev_list)/sizeof(struct USB_MODERM_DEVICE);
    int i;
    
    for(i = 0; i < size; i++)
    {
        if ((g_dev_list[i].products.pid == pid) &&
            (g_dev_list[i].products.vid == vid))
        {
            return &(g_dev_list[i]);
        }
    }

    return NULL;
}


void set_ndis_interface(UBOOL8 is_up)
{
    char cmd[128] = {0};

    if(isInterfaceUp(g_usb_dongle_ifname) != is_up){
        snprintf(cmd, sizeof(cmd) - 1, "ifconfig %s %s", g_usb_dongle_ifname,
                    is_up?"up":"down");
        d_printf("%s:%s\n", __func__, cmd);
        record_3g("%s\n", cmd);
        lib3g_system(cmd, 1);
    }else{
        record_3g("current interface(%s) is already %s\n", g_usb_dongle_ifname, is_up?"up":"down");
    }
}

