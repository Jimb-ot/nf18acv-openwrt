#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
 #include <stdlib.h>
 #include <errno.h>

#include "3g-mngr-include.h"

#define DEVICE_MUN_MAX 5
#define SWITCH_CFG_ID_LINE_SIZE SWITCH_CFG_LINE_SIZE

#define IDS_BUF_SIZE 1024 

#define	TRY_ATTATCH_DRIVER_TIME_MAX	3
#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_switch", "SWITCH", args)

typedef struct {
	int install_signal;
	int do_num;
	int attch_driver_num;
	
	int s_check_time;
	int s_none_disappears_time;
	int s_storage_disappears_time;
	int s_sw_ck_start;
	int s_sw_ck_end;
	int s_sw_ck_index;
} __switch_mngr_t;

typedef enum{
	SWITCH_MODE_NORMAL = 0,
	SWITCH_MODE_EJECT,
	SWITCH_MODE_SG,
} switch_m_t;

typedef struct {
	switch_m_t mode;
	void  (*switch_func)(void *path);
	int timeout;
} switch_method_t;

/*
* get content from a line
* format:
*	I:%c If#=%2d Alt=%2d #EPs=%2d Cls=%02x(%-5s) Sub=%02x Prot=%02x Driver=%s\n
* refere to driver/usb/device.c
*/
#define	 GET_FROM_LINE_BY_TOKEN(token, buf, r_buf, l)	\
	({					\
		int r = 0;		\
		int i = 0;		\
		char *p = 0;	\
		if ((p = strstr(buf, token))) {	\
			p += strlen(token);	\
			for (i = 0; i < l && *p && *p != '\n' && *p != '\r'; p++)	\
				r_buf[i++] = *p;	\
			r = 1;	\
		} else {	\
			printf_3g("SWITCH", "Get [%s] error\n", token);	\
			r = 0;	\
		}	\
		r;	\
	})
	
static int match_and_get_line_type(char *buf, char *rbuf, int rlen);

int switch_mngr_init(switch_mngr_t *sw)
{
	SUB_INIT(sw, switch_mngr_t, __switch_mngr_t);
	return 0;	
}

switch_mngr_t *switch_mngr_new(void *mn)
{
	switch_mngr_t *sw;

	if ((sw = ALLOC_3G(switch_mngr_t, __switch_mngr_t)) <= 0)
		return 0;

	MN_SET(sw, mn);

	switch_mngr_init(sw);

	return sw;
}

int switch_mngr_free(switch_mngr_t *sw)
{	
	if (!sw)
		return 0;

	if (MN(sw))
		MN(sw)->sw = 0;

	free(sw);

	sw = 0;
	
	return 0;
}


static int pid_num(const char *pids)
{
	int i = 0;
	char  *p;

	if (!pids || !pids[0])
		return 0;

	for (p = strchr(pids, ','); p;  p = strchr(p, ',')) {
		i++;
		p++;
		if (!*p)
			break;
	}
	
	return i+1;
}


static void cat_id_to_idbuf(char *vidbuf, int vidlen, 
			char *pidbuf, int pidlen, 
			const char *vid, const char *pid)
{	
	char *tmp = 0;
	int i, pidnum = 0, len;

	len = vidlen > pidlen ? vidlen : pidlen;

	CDMG_MALLOC(len+1, tmp, return);


	/*mutil pids have the same vid*/
	pidnum = pid_num(pid);
	for (i = 0; i < pidnum; i++) {
		if (!vidbuf[0])
			snprintf(tmp, len, "%s", vid);
		else
			snprintf(tmp, len, "%s,%s", vidbuf, vid);	

		memcpy(vidbuf, tmp, len);
	}	
	
	memset(tmp, 0, len + 1);
	if (!pidbuf[0])
		snprintf(tmp, len, "%s", pid);
	else
		snprintf(tmp, len, "%s,%s", pidbuf, pid);
	
	memcpy(pidbuf, tmp, len);

	free(tmp);
};

static int find_tty_ids_from_cfg_file(const char *cfg_f, const char *out_ids)
{
	FILE *fp, *fp_out;	
	char *buf, *rbuf;
	char *vid_buf = 0,  *pid_buf = 0;	
	char *tvid = 0,    *tpid = 0;
	char *oldvid = 0, *oldpid = 0;
	int type = -1, start = 0;
	int find_vid = 0, find_pid = 0;
	int find_tvid = 0, find_tpid = 0;

	if (access(cfg_f, F_OK) != 0)
		return 0;

	CDMG_FOPEN(fp, fopen, "r", cfg_f, return 0);
	CDMG_FOPEN(fp_out, fopen, "w", out_ids, fclose(fp); return 0);

	CDMG_MALLOC(8*IDS_BUF_SIZE, buf, fclose(fp); fclose(fp_out); return 0);
	rbuf = buf + IDS_BUF_SIZE;
	
	vid_buf = buf + IDS_BUF_SIZE*2;
	pid_buf = buf + IDS_BUF_SIZE*3;

	tvid = buf + IDS_BUF_SIZE*4;
	tpid = buf + IDS_BUF_SIZE*5;
	
	oldvid = buf + IDS_BUF_SIZE*6;
	oldpid = buf + IDS_BUF_SIZE*7;	

	while (fgets(buf, IDS_BUF_SIZE, fp)) 
	{
		type = match_and_get_line_type(buf, rbuf, IDS_BUF_SIZE - 1);

		switch(type) {
			case 0:
				continue;
			case 1:
				/*DefaultVendor */
				find_vid = 1;
				if (start == 1) {
					/*end an entry*/
					if (tvid[0] && tpid[0]) {
						cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
							pid_buf, IDS_BUF_SIZE, tvid, tpid);
						memset(tvid, 0, IDS_BUF_SIZE);
						memset(tpid, 0, IDS_BUF_SIZE);
					}	else if (oldvid[0] && oldpid[0]) {
						cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
							pid_buf, IDS_BUF_SIZE, oldvid, oldpid);
						memset(oldvid, 0, IDS_BUF_SIZE);
						memset(oldpid, 0, IDS_BUF_SIZE);	
					}
					
					start = 0;					
					find_pid = 0;
					
				} else {
					strncpy(oldvid, rbuf, IDS_BUF_SIZE - 1);
					if (find_pid == 1)  {						
						start = 1;
						find_tpid = 0;
						find_tvid = 0;	
					}
				}

				continue;
			case 2:
				/*counter default product id*/
				find_pid = 1;
				if (start == 1) {
					/*end an entry*/
					if (tvid[0] && tpid[0]) {
						cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
							pid_buf, IDS_BUF_SIZE, tvid, tpid);
						memset(tvid, 0, IDS_BUF_SIZE);
						memset(tpid, 0, IDS_BUF_SIZE);
					}	else if (oldvid[0] && oldpid[0]) {
						cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
							pid_buf, IDS_BUF_SIZE, oldvid, oldpid);
						memset(oldvid, 0, IDS_BUF_SIZE);
						memset(oldpid, 0, IDS_BUF_SIZE);	
					}
					
					start = 0;					
					find_vid = 0;		
					
				} else {
					strncpy(oldpid, rbuf, IDS_BUF_SIZE - 1);
					if (find_vid == 1)  {						
						start = 1;
						find_tpid = 0;
						find_tvid = 0;
					}
				}

				continue;
			case 3:
				if (start != 1)
					continue;

				if (!find_tvid && strstr(rbuf, "TargetVendor")) {
					find_tvid = 1;
					lib3g_reg_exec(rbuf, 
						"s/.*=[ ]{1,}0x//, s/[\n\r]*//, /[0-9a-fA-F]*/", 
						tvid, IDS_BUF_SIZE - 1);
				} else if (!find_tpid && strstr(rbuf, "TargetProduct") && 
					!strstr(rbuf, "TargetProductList")) {
						find_tpid = 1;
						lib3g_reg_exec(rbuf, 
							"s/.*=[ ]{1,}0x//, s/[\n\r]*//, /[0-9a-fA-F]*/", 
							tpid, IDS_BUF_SIZE - 1);
				} else if (!find_tpid && strstr(rbuf, "TargetProductList")) {
					find_tvid = 1;
					lib3g_reg_exec(rbuf, 
						"/\".*\"/, /[0-9a-zA-Z].*[0-9a-zA-Z]/, s/[\n\r]*//", 
						tpid, IDS_BUF_SIZE - 1);
				}

				continue;
			default:
				/*blank*/
				continue;
		}//switch 
	}//while

	if (start == 1) {
		/*end an entry*/
		if (tvid[0] && tpid[0]) {
			cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
				pid_buf, IDS_BUF_SIZE, tvid, tpid);
		}	else if (oldvid[0] && oldpid[0]) {
			cat_id_to_idbuf(vid_buf, IDS_BUF_SIZE, 
				pid_buf, IDS_BUF_SIZE, oldvid, oldpid);
		}
	}

	fprintf(fp_out, "idVendor:%s idProduct:%s", vid_buf, pid_buf);

	if (fp)
		fclose(fp);
	if (fp_out)
		fclose(fp_out);

	free(buf);

	return 0;
}

/*
	combines two id file the id file's format:
	idVendor:xxxx,yyyy...  idProduct:zzzz,aaaa...
*/
static void combin_ids(const char *ids1, const char *ids2, const char *ids_out)
{
#define BUF_SIZE (IDS_BUF_SIZE*2)
#define VID_TOKEN "idVendor:"
#define PID_TOKEN "idProduct:"
	FILE *in1 = 0;
	FILE *in2 = 0;
	FILE *out = 0;
	char *vids1 = 0;
	char *vids2 = 0;
	char *pids1 = 0;
	char *pids2 = 0;	
	char *buf1 = 0;
	char *buf2 = 0;
	char blank[] = " ";

	if ((in1 = fopen(ids1, "r")) == NULL)
		d_perror("can not open %s", ids1);


	if ((in2 = fopen(ids2, "r")) == NULL)
		d_perror("can not open %s", ids2);


	if ((out = fopen(ids_out, "w")) == NULL) {
		perror("open %s", ids_out);
		if (in1)
			fclose(in1);
		if (in2)
			fclose(in2);		
		return;
	}

	if ((buf1 = malloc(BUF_SIZE*2)) == NULL) {
		perror("can not malloc");
		goto end;
	}

	memset(buf1, 0, BUF_SIZE*2);

	buf2 = buf1 + BUF_SIZE;

	if (in1 > 0 && fgets(buf1, BUF_SIZE - 1, in1)) {
		vids1 = 	strstr(buf1,VID_TOKEN);
		if (vids1) {
			vids1 += strlen(VID_TOKEN);
		
			pids1 = strstr(vids1, PID_TOKEN);
			if (pids1) {
				*pids1 = 0;
				pids1 += strlen(PID_TOKEN);
			}
		} else
			pids1 = 0;
	}

	if (in2  > 0 && fgets(buf2, BUF_SIZE - 1, in2)) {
		vids2 = 	strstr(buf2,VID_TOKEN);
		if (vids2) {
			vids2 += strlen(VID_TOKEN);
		
			pids2 = strstr(vids2, PID_TOKEN);
			if (pids2) {
				*pids2 = 0;
				pids2 += strlen(PID_TOKEN);
			}
		} else
			pids2 = 0;
	}

	if (!vids1) {
		vids1 = blank;
		pids1 = blank;
	}

	if (!vids2) {
		vids2 = blank;
		pids2 = blank;
	}

	fprintf(out, VID_TOKEN"%s,%s"PID_TOKEN"%s,%s", vids1, vids2, pids1, pids2);
	
	if (buf1)
		free(buf1);
end:
	if (in1)
		fclose(in1);
	if (in2)
		fclose(in2);
	if (out)
		fclose(out);
		
}


static void change_id_output_format(const char *idfile, char *output, int len)
{
	/*the output format of the /proc/usb_modem_id is :
	 (idVendor,idProduct):
	 (15eb,7152) (0af0,6600) (0af0,6901) (0af0,6701) (15eb,6911) (1e0e,9000) 

	 we need to change the above format to such:
	 	idVendor:15eb,0af0,... idProduct:7152,6600,...
	*/
	int buflen = IDS_BUF_SIZE*2;
	int rbuflen = 0;
	int idbuflen = IDS_BUF_SIZE;
	int vpos = 0;
	int ppos = 0;
	char *vids = 0;
	char *pids = 0;
	char *buf = 0;
	char *p = 0;
	char *q = 0;
	char *r = 0;
	FILE *idfp = 0;

	idfp = fopen(idfile, "r");
	if (!idfp) {
		d_perror("open %s", idfile);
		return;
	}
	
	buf = malloc(buflen + idbuflen * 2);
	if (!buf) {
		d_perror("malloc error\n");
		if (len > 0)
			snprintf(output, len, "idVendor: idProduct:");
		return;
	}

	memset (buf, 0, buflen + idbuflen * 2);
	vids = buf + buflen;
	pids = buf + buflen + idbuflen;

	rbuflen = fread(buf, 1, buflen, idfp);

	fclose(idfp);

	if (!buf[0])
		d_printf("%s no content\n", idfile);
		
	q = strchr(buf, '\n');
	if (!q) {
		free(buf);
		return;
	}
	
	p = strchr(q, '(');
	if (!p) {
		free(buf);
		return;
	}	
	q = strchr(p, ',');
	if (!q) {
		free(buf);
		return;
	}	
	r = strchr(p, ')');
	if (!r) {
		free(buf);
		return;
	}	

	if (p - buf > rbuflen) {
		free(buf);
		return;
	}

	if (!p || !q || !r) {
		free(buf);
		return;
	}
	

	while(1) {
		/*
			the position of p, q, r are:			
			( 1234  ,  5678) (90ab,cdef) ...
			|         |	       |
			p        q         r
		*/
		int i = 0;
		char *tmp = p + 1;

		if (vpos + 4 > idbuflen || ppos + 4 > idbuflen)
			break;
		
		/*copy vid to vids*/
		for (i = 0; tmp[i] != *q; i++) {
			vids[vpos] = tmp[i];
			vpos++;
		}
		vids[vpos] = ',';
		vpos++;
		
		
		/*copy pid to pids*/
		tmp = q + 1;
		for (i = 0; tmp[i] != *r; i++) {
			pids[ppos] = tmp[i];
			ppos++;
		}
		pids[ppos] = ',';
		ppos++;

		r++;
		if (r - buf > rbuflen)
			break;
		
		if (!r[0])
			break;
		
		p = strchr(r, '(');
		if (!p)
			break;
		q = strchr(p, ',');
		if (!q)
			break;
		r  = strchr(p, ')');
		if (!r)
			break;

		if (p - buf > rbuflen)
			break;

		if (q - buf > rbuflen)
			break;

		if (r - buf > rbuflen)
			break;		
		
	}

	d_printf("vids:[%s]\nids:[%s]\n", vids, pids);
	if (len > 0) 
		snprintf(output, len, "idVendor:%s idProduct:%s", vids, pids);

	free(buf);
			
}

static void cat_ids_to_driver(char *vids, char *pids)
{
	/*the output format of the /proc/usb_modem_id is :
	 (idVendor,idProduct):
	 (15eb,7152) (0af0,6600) (0af0,6901) (0af0,6701) (15eb,6911) (1e0e,9000) 

	 the input format is idVendor:15eb 0af0 idProduct:7152 6600
	 */

	char tmpfile1[] = WORK_PATH".cat_ids_to_driver1";
	char tmpfile2[] = WORK_PATH".cat_ids_to_driver2";
	char idsbuf[IDS_BUF_SIZE*2] = {0};
	FILE *tmpfp1 = 0;
	FILE *tmpfp2 = 0;

	tmpfp1 = fopen(tmpfile1, "w+");
	if (tmpfp1 == NULL) {
		d_perror("open %s", tmpfile1);
		return;
	}

	tmpfp2 = fopen(tmpfile2, "w+");
	if (tmpfp2 == NULL) {
		d_perror("open %s", tmpfile2);
		return;
	}
	
	change_id_output_format(ID_CONFIG_FILE, idsbuf, IDS_BUF_SIZE*2);
	fwrite(idsbuf, 1, IDS_BUF_SIZE*2, tmpfp1);
	fclose(tmpfp1);
	
	fprintf(tmpfp2, "idVendor:%s idProduct:%s", vids, pids);
	fclose(tmpfp2);

	combin_ids(tmpfile1, tmpfile2, ID_CONFIG_FILE);

	if (!is_debug()) {
		unlink(tmpfile1);
		unlink(tmpfile2);
	}
}


FUNC(setids, "gather tty ids from configure file and set to the 3g_usb_switch module\n")
{	
	char ids[] = WORK_PATH".ids";
	char ids1[] = WORK_PATH".ids1";
	char ids2[] = WORK_PATH".ids2";
	char *buf;
	int fd;
	size_t s = 0;

	if (!(buf = malloc(IDS_BUF_SIZE*2)))
		return -1;	

	memset(buf, 0, IDS_BUF_SIZE*2);

	find_tty_ids_from_cfg_file(USB_AT_CFG_FILE1, ids1);
	find_tty_ids_from_cfg_file(USB_AT_CFG_FILE2, ids2);
	combin_ids(ids1, ids2, ids);
	

	if ((fd = open(ids,O_RDWR)) < 0) 
		goto end;
	
	s = read(fd, buf, IDS_BUF_SIZE*2 - 1);	
	close(fd);

	lib3g_install_modules();
	
	if (s && ((fd = open(ID_CONFIG_FILE, O_RDWR)) >= 0)) {
		write(fd, buf, s);
		close(fd);
	}

end:
	if ((access(DAIL_DEBUF_CONTR_FILE, F_OK)) != 0)  {
		unlink(ids);
		unlink(ids1);
		unlink(ids2);
	}

	free(buf);
	return 0;
}



static int match_and_get_line_type(char *buf, char *rbuf, int rlen)
{
	int type = -1;

	memset(rbuf, 0, rlen);

	/*line: #... */
	lib3g_reg_exec(buf, "/^[ \t]*#/", rbuf, rlen);
	if (rbuf[0])
		type = 0;	

	/*line: ;DefaultVendor= 0xab11 */
	if (type == -1) {
		lib3g_reg_exec(buf, 
			"/.*DefaultVendor[ \t]*=[^\n]*/, s/.*= *// , s/0x//, s/[ \t]*//", 
			rbuf, rlen);
		if (rbuf[0])
			type = 1;
	}

	/*line: ;DefaultProduct= 0xab11 */
	if (type == -1) {
		lib3g_reg_exec(buf, 
			"/.*DefaultProduct[ \t]*=[^\n]*/, s/.*= *// , s/0x//, s/[ \t]*//", 
			rbuf, rlen);
		if (rbuf[0])
			type = 2;
	}
	
	if (type == -1) {
		lib3g_reg_exec(buf, "s/[ \t]*;//", rbuf, rlen);
		if (rbuf[0])
			type = 3;/*other useful line: ;xxx*/
		else
			type = 4;/*un-useful line: xxx*/
	}

	return type;
}

/*
*	get a recorder from the drver config file, the file's format:
*
	########################################################
	# EpiValley SEC-7089 (featured by Alegro and Starcomms / iZAP)
	#
	# Contributor: Chris Wright

	;DefaultVendor=  0x1b7d
	;DefaultProduct= 0x0700

	;TargetVendor=   0x1b7d
	;TargetProduct=  0x0001

	;MessageContent="555342431234567824000000800008FF05B112AEE102000000000000000000"

*/
static int get_next_recorder_from_cfg_file(FILE *cfg_fp,
			const char *out_file, 
			char *next_line, int next_line_len,
			char *vid, 	int vid_len, 
			char *pid, 	int pid_len,
			char *tvid,	int tvidlen, 
			char *tpid, 	int tpidlen)
{
#define ID_SIZE 128
	char buf[SWITCH_CFG_LINE_SIZE] = {0};
	char rbuf[SWITCH_CFG_LINE_SIZE] = {0};
	char vidline[ID_SIZE+1] = {0};
	char pidline[ID_SIZE+1] = {0};	
	int type = -1, ret = 0;
	int find_pid = 0, find_vid = 0;
	FILE *out_fp = 0;


	//d_printf("enter\n");
	
	if (out_file)
		CDMG_FOPEN(out_fp, fopen, "w+", out_file, return 0);
	
	if (next_line && next_line[0])
		strncpy(buf, next_line, SWITCH_CFG_LINE_SIZE-1);
	else
		fgets(buf, SWITCH_CFG_LINE_SIZE-1, cfg_fp);
	
	if (!buf[0]) {
		if (out_fp)
			fclose(out_fp);
		return 0;
	}
	
	if (next_line)
		memset(next_line, 0, next_line_len);

	while(buf[0])
	{
		//d_printf("For config line:[%s]\n", buf);		
		rbuf[SWITCH_CFG_LINE_SIZE-1] = 0;
		type = match_and_get_line_type(buf, rbuf, SWITCH_CFG_LINE_SIZE-1);
		switch(type) 
		{
			case 0: /*comment line*/
				break;
			case 1:/*counter default vendor again*/
				
				/*end*/
				if (find_pid == 1 && find_vid == 1) {
					if (next_line)
						strncpy(next_line, buf, next_line_len);
					ret = 1;/*end*/
					break;
				}

				if (find_vid == 1 && find_pid == 0) {
					/*find default vid twice but not find default pid*/
					ret = -1;/*end*/
					break;
				}

				/*
				* ignore the 0000 id, 
				* it is for ransfer target ids to 
				* the 3g usb module
				*/
				if (!strcmp(rbuf, "0000"))
					break;

				if (vid)
					strncpy(vid, rbuf, vid_len);
				find_vid = 1;
				snprintf(vidline, sizeof(vidline) - 1, "DefaultVendor=0x%s\n", rbuf);
				
				break;
			case 2:/*counter default product id*/
				
				/*end*/
				if (find_pid == 1 && find_vid == 1) {
					if (next_line)
						strncpy(next_line, buf, next_line_len);					
					ret = 1;
					break;
				}

				if (find_vid == 0 && find_pid == 1) {
					/*find default vid twice but not find default pid*/
					ret = -1;
					break;
				}
				
				/*
				* ignore the 0000 id, 
				* it is for ransfer target ids to 
				* the 3g usb module
				*/
				if (!strcmp(rbuf, "0000"))
					break;

				if (pid)
					strncpy(pid, rbuf, pid_len);
				find_pid = 1;
				snprintf(pidline, sizeof(pidline) - 1, "DefaultProduct=0x%s\n", rbuf);
		
				break;
			case 3:/*other useful line*/
				if (find_pid == 1 && find_vid == 1) 
				{
					/*write:DefaultVendor=0xXXXX fined before*/
					if (vidline[0]) {
						if (out_fp)
							fprintf(out_fp, vidline);
						vidline[0] = 0;
					}

					/*write:DefaultProduct=0xXXXX fined before*/
					if (pidline[0]) {
						if (out_fp)
							fprintf(out_fp, pidline);
						pidline[0] = 0;
					}

					if (out_fp)
						fprintf(out_fp, rbuf);	
			
					if (strstr(rbuf, "TargetVendor")) {
						if (tvid) {
							lib3g_reg_exec(rbuf, 
								"s/.*=[ ]{1,}0x//, s/[\n\r]*//, /[0-9a-fA-F]*/", 
								tvid, tvidlen);
						}
					} else if (strstr(rbuf, "TargetProduct") && 
							!strstr(rbuf, "TargetProductList")) {
						if (tpid) {
							lib3g_reg_exec(rbuf, 
								"s/.*=[ ]{1,}0x//, s/[\n\r]*//, /[0-9a-fA-F]*/", 
								tpid, tpidlen);
						}
					} else if (strstr(rbuf, "TargetProductList")) {
						if (tpid) {
							lib3g_reg_exec(rbuf, 
								"/\".*\"/, /[0-9a-zA-Z].*[0-9a-zA-Z]/, s/[\n\r]*//", 
								tpid, tpidlen);
						}
					}				
				}
				break;
			default:	
				break;/*un-useful line*/
		}//switch 
		
		if (ret == -1 || ret == 1)
			break;

		memset(buf, 0, SWITCH_CFG_LINE_SIZE);
		fgets(buf, SWITCH_CFG_LINE_SIZE-1, cfg_fp);	
	}
	
	if (out_fp > 0)
		fclose(out_fp);
	
	if (ret == 0 && find_pid && find_vid)
		return 1;
	else	
		return ret;	
}

static int  usb_search_and_product_cfg(const char *cfg, const char  *sw_f, 
						const char *vid, const char *pid,/*index*/
						char *tvid, int tvidlen, char *tpid, int tpidlen)
{
#define ID_SIZE 128
	FILE *fp;
	char *next_buf;
	char get_vid[ID_SIZE+1] = {0};
	char get_pid[ID_SIZE+1] = {0};
	int ret = 0;

	d_printf("Get the switch file from config file %s by (0x%s, 0x%s)\n",
		cfg, vid, pid);
	
	CDMG_FOPEN(fp, fopen, "r", cfg, return 0);
	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, next_buf, fclose(fp); return 0);

	for(;;)
	{
		if (get_next_recorder_from_cfg_file(fp, sw_f, next_buf, 
				SWITCH_CFG_LINE_SIZE, 
				get_vid, ID_SIZE, 
				get_pid, ID_SIZE,
				tvid, tvidlen,
				tpid, tpidlen))
		{    
			if (strcmp(vid, get_vid) == 0 && 	strcmp(pid, get_pid) == 0)
			{
				d_printf("Find switch recorder from :\n\t%s by (0x%s, 0x%s)\n", 
					cfg, vid, pid);
				ret = 1;
				break;
			}
		} 
		else
			break;/*exit*/
	}

	if (!ret) {
		d_printf("Can not find switch recorder from: \n\t"
			"[%s] "
			"\n\tby (0x%s,0x%s)\n",
			cfg, vid, pid);
		if (tpid)
			memset(tpid, 0, tpidlen);
		if (tvid)
			memset(tvid, 0, tvidlen);
	}

	fclose(fp);
	free(next_buf);
	return ret;
}


static int  get_ids_from_proc_line(char *buf, 
					char *c_vid, char *c_pid, int len)
{
	/*
	*  format:
	*	"P:  Vendor=%04x ProdID=%04x Rev=%2x.%02x\n";
	* refere to driver/usb/device.c
	*/
	memset(c_vid, 0, len);
	memset(c_pid, 0, len);
	if (GET_FROM_LINE_BY_TOKEN("Vendor=", buf, c_vid, 4) == 0)
		return -1;
	if (GET_FROM_LINE_BY_TOKEN("ProdID=", buf, c_pid, 4) == 0)
		return -1;
	d_printf("Find device:0x%s,0x%s\n", c_vid, c_pid);
	
	return 0;
}

static int search_usb_ids_from_proc(const char *copy_f, char *vids, 
			char *pids, int (*match)(char *), int n)
{
#define USB_DEVICES_FILE_TMP 	WORK_PATH".usb_devices"
#define FILE_SIZE (1024*8)
#define DATE_SIZE (ID_SIZE*2)
#define __BUF_SIZE (FILE_SIZE + DATE_SIZE)
	FILE *in = 0, *out = 0;
	char *buf = 0;
	char *c_vid = 0, *c_pid = 0;
	char *date = 0;
	int ret = 0, m = 0;

	d_printf("enter\n");

	if (copy_f && copy_f[0])  {
		if ((in = fopen(copy_f, "r")) == NULL) {
			d_printf("can not open %s\n", copy_f);
		}
	}

	if (!in) {
		if ((in = fopen(USB_INFO_BUS_DEVICES_PROC_FILE, "r")) == NULL) {
			d_printf("can not open %s\n", 
				USB_INFO_BUS_DEVICES_PROC_FILE);
			goto end;
		}
	}

	if ((out = fopen(USB_DEVICES_FILE_TMP, "w+")) == NULL) {
		d_perror("open %s", USB_DEVICES_FILE_TMP);
		goto end;
	}

	if ((buf = malloc(__BUF_SIZE)) == NULL) {
		d_printf("can not malloc\n");
		goto end;
	}

	memset(buf, 0, __BUF_SIZE);
	if (fread(buf, 1, FILE_SIZE, in) <= 0) {
		d_printf("can not read %s\n", 
			USB_INFO_BUS_DEVICES_PROC_FILE);
		goto end;
	}

	if (fwrite(buf, 1, FILE_SIZE, out) <= 0) {
		d_printf("can not read %s\n", USB_DEVICES_FILE_TMP);
		goto end;
	}

	fclose(in);
	in = NULL;

	rewind(out);
	memset(buf, 0, __BUF_SIZE);

	date = buf + FILE_SIZE;
	
	c_vid = date;
	c_pid = date + ID_SIZE;

	while (fgets(buf, FILE_SIZE, out)) {
		
		//d_printf("buf:\n%s\n", buf);
		
		if (buf[0] == 'P' && buf[1] == ':') {			
			if (get_ids_from_proc_line(buf, c_vid, c_pid, ID_SIZE) != 0) {
				d_printf("Can not get vid,pid at:\n[%s]\n", buf);
				goto end;
			}
		}
		else if (c_vid[0] && buf[0] == 'I' && buf[1] == ':' && match(buf)) 
		{		
			/*only attension the first matched interface */	
			char type[32] = {0};
			GET_FROM_LINE_BY_TOKEN("Driver=", buf, type, sizeof(type)-1);

			m++;
		
			d_printf("find an matched %s device %d times, "
				"store it's ids to the old variables\n", 
				type, m);

			if (m >= n) {
			
				ret++;
				
				if (pids && vids) {
					strcpy(vids+(ret-1)*ID_SIZE, c_vid);
					strcpy(pids+(ret-1)*ID_SIZE, c_pid);
				}
				c_vid[0] = 0;
				c_pid[0] = 0;
			}
			
		} 
		else if (buf[0] == 'T' && buf[1] == ':') 
		{ 
			/*new device start line*/		
			d_printf("Search a device\n");
			memset(date, 0, DATE_SIZE);
		} 
		
	}

	if (vids && pids) {
		*(vids + ret*ID_SIZE) = 0;
		*(pids + ret*ID_SIZE) = 0;
	}

end:

	d_printf("find  %d devices\n", ret);
	
	if (buf)
		free(buf);
	if (in)
		fclose(in);
	if (out)
		fclose(out);

	if ( (access(DAIL_DEBUF_CONTR_FILE, F_OK) ) != 0 ) 
		unlink(USB_DEVICES_FILE_TMP);
	
	return ret;
}

/*this macr must be followed by MATCH_CHECK*/
#define MATCH_CHECK_DECLEAR_AND_INIT(buf) \
	char Cls[12] = {0};	\
	char Sub[4] = {0};	\
	char Prot[4] = {0};	\
	char Driver[64] = {0};	\
		\
	if (!buf || !buf[0]) {		\
		printf_3g("SWITCH", "Param error\n");	\
		return 0;			\
	}			\
	if (GET_FROM_LINE_BY_TOKEN("Cls=", buf, Cls, 9) == 0)	\
		return 0;	\
	if (GET_FROM_LINE_BY_TOKEN("Sub=", buf, Sub, 2) == 0)	\
		return 0;	\
	if (GET_FROM_LINE_BY_TOKEN("Prot=", buf, Prot, 2)== 0)	\
		return 0;	\
	if (GET_FROM_LINE_BY_TOKEN("Driver=", buf, \
			Driver, sizeof(Driver)-2) == 0 )	\
		return 0;\
	d_printf("Cls:[%s], Sub:[%s], Prot:[%s], Driver:[%s]\n",	\
		Cls, Sub, Prot, Driver)
	

/*
* Must after the macro:MATCH_CHECK_DECLEAR_AND_INIT,
* ignore means not cmpare it
*/
#define MATCH_CHECK(c, s, p, d)		\
	if (		\
			(	\
				(c && !strcmp(c, "ignore")) || 	\
				((!Cls[0] && (!c || !c[0])) || (strcmp(Cls, c) == 0))	\
			) &&  \
			(	\
				(s && !strcmp(s, "ignore")) || 	\
				((!Sub[0] && (!s || !s[0])) || (strcmp(Sub, s) == 0))	\
			) 	&& \
			(	\
				(p && !strcmp(p, "ignore")) || 	\
				((!Prot[0] && (!p || !p[0])) || (strcmp(Prot, p) == 0))	\
			) 	&& \
			(	\
				(d && !strcmp(d, "ignore")) || 	\
				((!Driver[0] && (!d || !d[0])) || (strcmp(Driver, d) == 0))	\
			) \
		) 	return 1
		
static int match_storage(char *buf)
{
	MATCH_CHECK_DECLEAR_AND_INIT(buf);
	MATCH_CHECK("08(stor.)", "ignore", "ignore", "ignore");
	return 0;
}

static int match_storage_none(char *buf)
{
	MATCH_CHECK_DECLEAR_AND_INIT(buf);
	MATCH_CHECK("08(stor.)", "ignore", "ignore", "(none)");
	MATCH_CHECK("08(stor.)", "ignore", "ignore", "");
	return 0;
}	

static int match_modem(char *buf)
{
	MATCH_CHECK_DECLEAR_AND_INIT(buf);
	
	MATCH_CHECK("ff(vend.)", "02", "ignore", "ignore");
	MATCH_CHECK("02(comm.)", "02", "ignore", "ignore");
	MATCH_CHECK("0a(data )", "02", "ignore", "ignore");
	MATCH_CHECK("ff(vend.)", "ff", "ignore", "ignore");
	MATCH_CHECK("02(comm.)", "ff", "ignore", "ignore");
	MATCH_CHECK("0a(data )", "ff", "ignore", "ignore");
	MATCH_CHECK("ff(vend.)", "08", "ignore", "ignore");
	MATCH_CHECK("02(comm.)", "08", "ignore", "ignore");
	MATCH_CHECK("0a(data )", "08", "ignore", "ignore");
    /* subclass��03��Ӧ���Ǽ��ټ��ˣ�����linux CDC���о�Ȼ�Ҳ���
     * ���Ķ��壬����������Ҳ�Ҳ������Ķ��壬��ʵ�����ǿ��������ġ�
     * Ŀǰ��huawei E303H-6ʹ�ô���ӿ�
     */
    MATCH_CHECK("ff(vend.)", "03", "ignore", "ignore");
    MATCH_CHECK("ff(vend.)", "00", "ignore", "ignore");

	return 0;
}

static int match_modem_no_driver(char *buf)
{
	//d_printf("Match line:[%s]\n", buf);

	MATCH_CHECK_DECLEAR_AND_INIT(buf);

	MATCH_CHECK("ff(vend.)", "02", "ignore", "(none)");
	MATCH_CHECK("02(comm.)", "02", "ignore", "(none)");
	MATCH_CHECK("0a(data )", "02", "ignore", "(none)");

	MATCH_CHECK("ff(vend.)", "02", "ignore", "");
	MATCH_CHECK("02(comm.)", "02", "ignore", "");
	MATCH_CHECK("0a(data )", "02", "ignore", "");

	MATCH_CHECK("ff(vend.)", "ff", "ignore", "(none)");
	MATCH_CHECK("02(comm.)", "ff", "ignore", "(none)");
	MATCH_CHECK("0a(data )", "ff", "ignore", "(none)");

	MATCH_CHECK("ff(vend.)", "ff", "ignore", "");
	MATCH_CHECK("02(comm.)", "ff", "ignore", "");
	MATCH_CHECK("0a(data )", "ff", "ignore", "");

	/* If#= 0 Alt= 0 #EPs= 0 Cls=02(comm.) Sub=08 Prot=00 Driver=(none)*/
	MATCH_CHECK("ff(vend.)", "08", "ignore", "(none)");
	MATCH_CHECK("02(comm.)", "08", "ignore", "(none)");
	MATCH_CHECK("0a(data )", "08", "ignore", "(none)");
    MATCH_CHECK("ff(vend.)", "03", "ignore", "(none)");
    MATCH_CHECK("ff(vend.)", "00", "ignore", "(none)");

	MATCH_CHECK("ff(vend.)", "08", "ignore", "");
	MATCH_CHECK("02(comm.)", "08", "ignore", "");
	MATCH_CHECK("0a(data )", "08", "ignore", "");
    MATCH_CHECK("ff(vend.)", "03", "ignore", "");

    MATCH_CHECK("ff(vend.)", "00", "ignore", "");
	//d_printf("Not find modem interfacer without driver\n");

	return 0;
}

/*dell the vids emem, if it is belong to svids array*/
static int del_same_ids(char *vids, char *pids, char *svids, char *spids)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int ret = 0;
	int same = 0;
 
	while(*(vids + i*ID_SIZE)){
		ret ++;
		same = 0;
		for (j = 0; *(svids+j*ID_SIZE) && *(spids+j*ID_SIZE); j++) {
			if (!strcmp(vids+i*ID_SIZE, svids+j*ID_SIZE) && 
					!strcmp(pids+i*ID_SIZE, spids+j*ID_SIZE)) {
				same = 1;
				break;
			}
		}

		if (same) {
			/*shift to overlay the same one*/
			for (k = 0; *(vids+(k+i+1)*ID_SIZE); k++) {
				strcpy(vids+(i+k)*ID_SIZE, vids+(i+k+1)*ID_SIZE);
				strcpy(pids+(i+k)*ID_SIZE, pids+(i+k+1)*ID_SIZE);
			}

			/*copy the end, it is 0*/
			*(vids+(i+k)*ID_SIZE) = 0;
			*(pids+(i+k)*ID_SIZE) = 0;
			
			ret--;
		} else
			i++;
	}

	return ret;
}

static int search_storage_device_match(const char *copy_f, 
			int (*match)(char *),
			char *vids, char *pids, int len)
{
	char tmp_vids[ID_SIZE *DEVICE_MUN_MAX*4] = {0};
	char *tmp_pids = 0;
	char *tmp_svids = 0;
	char *tmp_spids = 0;
	int strg = 0, rnum=0;
	int i = 0;
	int ret = 0;
	
	tmp_pids = tmp_vids + ID_SIZE *DEVICE_MUN_MAX;
	tmp_svids = tmp_vids + ID_SIZE *DEVICE_MUN_MAX*2;
	tmp_spids = tmp_vids + ID_SIZE *DEVICE_MUN_MAX*3;

	d_printf("enter\n");
	strg = search_usb_ids_from_proc(copy_f, tmp_vids, tmp_pids, 
				match, 1);
	//i = search_usb_ids_from_proc(copy_f, tmp_svids, tmp_spids, 
	//			match_modem, 1);
    //d_printf("aa");
	ret = del_same_ids(tmp_vids, tmp_pids, tmp_svids, tmp_spids);

	if (len == 0)
		rnum = DEVICE_MUN_MAX;
	else		
		rnum = len/ID_SIZE;
	rnum = rnum > (ret+1) ? (ret+1) : rnum;
	
	if (vids && pids) {
		for(i = 0; i < rnum-1; i++) {
			strcpy(vids + i * ID_SIZE, tmp_vids + i * ID_SIZE);
			strcpy(pids + i * ID_SIZE, tmp_pids + i * ID_SIZE);
		}

		*(vids + (rnum - 1) * ID_SIZE) = 0;
		*(pids + (rnum - 1) * ID_SIZE) = 0;
	}

	
	return ret;	
}

int search_storage_device(const char *copy_f, 
			char *vids, char *pids, int len)
{
	return search_storage_device_match(copy_f, 
		match_storage, vids, pids, len);
}

static int search_storage_device_none(const char *copy_f, 
			char *vids, char *pids, int len)
{
	return search_storage_device_match(copy_f, 
		match_storage_none, vids, pids, len);
}

static void switch_mngr_do_eject( void *data)
{
#if 0
#define DP(fmt,args...) d_printf(fmt, ##args)
#else
#define DP(fmt,args...) 
#endif

#if defined(PC)
	char buf[1024] = {0};
	char *p = 0;
	
	__lib3g_script_and_get_ret("ls /dev/sr*", buf, 1000);

	

	DP("cdrom list: [%s]\n", buf);

	/*the result:'/dev/sr0  /dev/sr1'*/
	if (buf[0]) {		
		p = buf + strlen(buf);

		p -= strlen("/dev/sr1");

		DP(" return some char:[%s]\n", p);

		for (; *p && !isdigit(*p); p++);

		DP("first digital:[%s]\n", p);
		
		snprintf(buf, sizeof(buf), "/dev/sr%d", (int)strtoul(p, 0, 10));

		d_printf("eject [%s]\n", buf);

		lib3g_eject(buf, 4);
	}
#else	
	lib3g_eject(CDROM_DEV, 4);
#endif

#undef DP
}

static void __do_switch(int wait, void  (*sub_process_func)(void *data), 
				void *data)
{
	pid_t sub_pid = 0; 
	
	if ((sub_pid = fork_3g()) > 0) {
		if (sleep(wait) == 0) {
			d_printf("switching time out kill it\n");
			kill(sub_pid, SIGTERM);
		}
	}  else if (sub_pid < 0) {
		d_printf("can not create sub process\n");
	} else {
		/*sub proccess*/
		sub_process_func(data);
		exit(0);
	}	
}

static void switch_method_by_usb_intf(void *path)
{
	d_printf("enter\n");

	char cfg_file[128] = {0};

	snprintf(cfg_file, sizeof(cfg_file), "%s", (char *)path);
	
	/*sub proccess*/

	int i = 0;
	char *_argv[5];
	_argv[i++] = USB_SWITCH_CMD;
	_argv[i++] = "-W";
	_argv[i++] = "-c";
	_argv[i++] = cfg_file;
	_argv[i++] = 0;
	d_printf("Start to do%s...\n", cfg_file);
	execvp(_argv[0], _argv);
	d_printf("could not exec %s\n", cfg_file);
	//exit(99);
}

static void switch_method_by_eject(void *path)
{
	d_printf("enter\n");
	
	/*sub proccess*/
	switch_mngr_do_eject(path);
}

static void switch_method_by_sg(void *path)
{
	d_printf("enter\n");
#ifdef PC
	/*FIX ME: there is a bug, some time the sg dev is not sg1*/
	CDMG_DO_FUNC(switch_by_sg, " --file=%s --dev=/dev/sg1", (char *)path);
#else
	CDMG_DO_FUNC(switch_by_sg, " --file=%s ", (char *)path);
#endif
}

static switch_m_t switch_mngr_str_to_m(const char *mode_str)
{
	static struct sm_to_m {
		switch_m_t m;
		char m_str[80];
	} sm_to_m[] = {
		{SWITCH_MODE_SG, "SWITCH_MODE_SG"},
		{SWITCH_MODE_NORMAL, "SWITCH_MODE_NORMAL"},
		{SWITCH_MODE_EJECT, "SWITCH_MODE_EJECT"},
	};
	
	int i;
	for (i = 0; i < sizeof(sm_to_m)/sizeof(sm_to_m[0]); i++) {
		if (strcmp(mode_str, sm_to_m[i].m_str) == 0)
			return sm_to_m[i].m;
	}

	d_printf("Mode:[%s] not define\n", mode_str);
	return SWITCH_MODE_NORMAL;	
}

static switch_m_t switch_mngr_get_switch_mode(switch_mngr_t *sw, 
					const char *cfg_file)
{
	switch_m_t mode = SWITCH_MODE_NORMAL;
	char *buf = 0;
	char mode_str[80] = {0};
	FILE *fp;

	d_printf("enter\n");

	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, buf, return mode);
	CDMG_FOPEN(fp, fopen, "r", cfg_file, free(buf); return mode);

	while(fgets(buf, SWITCH_CFG_LINE_SIZE-1, fp)) {
		memset(mode_str, 0, sizeof(mode_str));
		lib3g_reg_exec(buf, 
			"/Do_eject[ \t]*=.*/, s/Do_eject[ \t]*=//, /[0-9]{1,}/", 
			mode_str, sizeof(mode_str)-1);
		if (mode_str[0] && mode_str[0] == '1') {
			mode = SWITCH_MODE_EJECT;
			break;
		}
		
		memset(mode_str, 0, sizeof(mode_str));
		lib3g_reg_exec(buf, 
			"/SwitchMode[ \t]*=.*/, s/SwitchMode[ \t]*=//, /[^ \t\r\n]{1,}/", 
			mode_str, sizeof(mode_str)-1);
		if (mode_str[0]) {
			mode = switch_mngr_str_to_m(mode_str);
			break;
		}

		memset(buf, 0, SWITCH_CFG_LINE_SIZE);
	}

	fclose(fp);
	free(buf);
	
	return mode;	
}

static switch_method_t s_switch_method[] = {
	{SWITCH_MODE_NORMAL, switch_method_by_usb_intf, 7},
	{SWITCH_MODE_EJECT, switch_method_by_eject, 5},
	{SWITCH_MODE_SG, switch_method_by_sg, 5},
};

static void do_switch(switch_mngr_t *sw, const char *cfg_file)
{
	switch_m_t switch_mode = 
		switch_mngr_get_switch_mode(sw, cfg_file);
	d_printf("switch mode is:%d\n", switch_mode);
	int i;
	for (i = 0; i< sizeof(s_switch_method)/sizeof(s_switch_method[0]); i++) {
		if (s_switch_method[i].mode == switch_mode) {
			__do_switch(s_switch_method[i].timeout, 
				s_switch_method[i].switch_func, (void *)cfg_file);
			break;
		}
	}
}
	
int switch_mngr_switch(switch_mngr_t *sw, int agrc, char *argv[])
{
	char idProduct[ID_SIZE] = {0};
	char idVendor[ID_SIZE] = {0};
	
	cdmg_get_arg(argv, "vid", idVendor, ID_SIZE);
	cdmg_get_arg(argv, "pid", idProduct, ID_SIZE);

	d_printf("Enter __usbswitch idVendor=0x%s, idProduct=0x%s\n", 
			idVendor, idProduct);	
	if (!idVendor[0] || !idProduct[0] || !sw)
		goto _end;
#if 0
	if (usb_search_and_product_cfg(USB_SWITCH_FILE1, 
				USB_SWITCH_CFG_TMP, 
				idVendor, idProduct, 0, 0, 0, 0) != 1) 
	{
				idVendor, idProduct, USB_SWITCH_FILE1);

			if (usb_search_and_product_cfg(USB_SWITCH_FILE2, 
					USB_SWITCH_CFG_TMP, 
				idVendor, idProduct, 0, 0, 0, 0) != 1) 
			{
					idVendor, idProduct, USB_SWITCH_FILE2);
				goto _end;
			}
	}
#endif
	/*not run on diald, so need to set signal */
	if (!(MN(sw)->run_on_diald))
		signal_init();

	do_switch(sw, USB_SWITCH_CFG_TMP);
    return 1;
_end:
	return 0;	
}


static int is_need_switch(modem_t *mdm, const char *idVendor, 
			const char *idProduct)
{
	char _idProduct[ID_SIZE] = {0};
	char _idVendor[ID_SIZE] = {0};

	if (modem_search(mdm) != 0)
		return 1;
	
	_idVendor[0] = '0';
	_idVendor[1] = 'x';
	strcpy(_idVendor + 2, idVendor);
	_idProduct[0] = '0';
	_idProduct[1] = 'x';
	strcpy(_idProduct + 2, idProduct);

	if (mdm->idProduct == strtoul(_idProduct, 0, 16) &&  
			mdm->idVendor == strtoul(_idVendor, 0, 16)) {
		d_printf("USB dongle been supported!!,  not need to check\n");
		return 0;
	}

	return 1;
}

static int switch_device(modem_t *mdm, const char *idVendor, 
			const char *idProduct)
{
	int i = 0;
	record_3g("idVendor:%s, idProduct:%s\r\n", idVendor, idProduct);
	d_printf("stat to switch (%s,%s)\n", idVendor, idProduct);

	if (usb_search_and_product_cfg(USB_SWITCH_FILE1, 
				USB_SWITCH_CFG_TMP, 
				idVendor, idProduct, 0, 0, 0, 0) != 1) 
	{
			d_printf("can not find cfg idV=%s, idP=%s at file %s\n", 
				idVendor, idProduct, USB_SWITCH_FILE1);

			if (usb_search_and_product_cfg(USB_SWITCH_FILE2, 
					USB_SWITCH_CFG_TMP, 
				idVendor, idProduct, 0, 0, 0, 0) != 1) 
			{
				d_printf("can not find cfg idV=%s, idP=%s at file %s\n", 
					idVendor, idProduct, USB_SWITCH_FILE2);
                /* fix up action will do default switch */
                return 0;
			}
	}

	for (i = 0; i < 2; i++) {
		if (!is_need_switch(mdm, idVendor, idProduct))
			return 1;		

		if (i != 0)
			sleep(2);
		
		CDMG_DO_FUNC(__usbswitch,  
				"--vid=%s --pid=%s", 
				idVendor, idProduct);
		sleep(3);
		if (!search_storage_device(0, 0, 0, 0)) {
			d_printf("no storage device\n");
			return 1;
		}
	}

    return 1;
}

int switch_mngr_switch_for_modem(switch_mngr_t *sw, int agrc, char *argv[])
{
	char devpath[128] = {0};
	char id_file[128] = {0};
	char *idProduct;
	char *idVendor;
	char *p = 0;
	int num = 0;
	int i;
    int ret = 0;

	idVendor = malloc(ID_SIZE*DEVICE_MUN_MAX*2);
	idProduct = idVendor + ID_SIZE*DEVICE_MUN_MAX;

	memset(idVendor, 0, ID_SIZE*DEVICE_MUN_MAX*2);

	d_printf("Enter usbswitch\n");

    if (!sw)
        goto _end;
	if (cdmg_get_arg(argv, "devpath", devpath, sizeof(devpath) - 1)) 
	{	
		d_printf("devpath=%s\n", devpath);
		lib3g_reg_exec(devpath, 
			"/.*usb[0-9][^:]*:/, s/[0-9]-[0-9.]{1,}://", 
			devpath, 128);
		if (!devpath[0])
			goto _end;
		d_printf("devpath=%s\n", devpath);
		
		snprintf(id_file, sizeof(id_file) - 1, "%sidProduct", devpath);
		if ( (access(id_file, F_OK) ) != 0 ) {
			d_printf("no %s\n", id_file);
			goto _end;
		}
		
		lib3g_read_file(id_file, idProduct, 10);
		if ((p = strchr(idProduct, '\r')) || (p = strchr(idProduct, '\n'))) {
			*p = 0;
		}
		if (!idProduct[0]) {
			d_printf("%s is blank\n", id_file);
			goto _end;
		}
		
		snprintf(id_file, sizeof(id_file) - 1, "%sidVendor", devpath);
		if ( (access(id_file, F_OK) ) != 0 ) {
			d_printf("no %s\n", id_file);
			goto _end;
		}

		lib3g_read_file(id_file, idVendor, sizeof(id_file) - 1);
		if ((p = strchr(idVendor, '\r')) || (p = strchr(idVendor, '\n'))) {
			*p = 0;
		}		
		if (!idVendor[0]) {
			d_printf("%s is blank\n", id_file);
			goto _end;
		}

		num = 1;
		
	}
	else 
	{
		if ((num = search_storage_device(0, idVendor, idProduct, 0)) <= 0) 
		{
			d_printf("no usb storage device\n");
			goto _end;
		}
	}

	num = num > DEVICE_MUN_MAX ? DEVICE_MUN_MAX : num;

	for (i = 0; i < num && *(idVendor+i*ID_SIZE) && 
			*(idProduct+i*ID_SIZE); i++)  
	{
		d_printf("Switch... vid=%s, pid=%s\n",
			idVendor+i*ID_SIZE,
			idProduct+i*ID_SIZE);
		/*
		* scb+ 2012-1-18 filter function, 
		* only support some dongle or some network
		*/
		d_printf("FILTER:Check filter at switch for:(%s,%s)\n", 
			idVendor, idProduct);
		if (!modem_filter_is_allow(idVendor+i*ID_SIZE, 
				idProduct+i*ID_SIZE)) {
			d_printf("We do not support this dongle:(0x%s,0x%s)\n", 
				idVendor+i*ID_SIZE, idProduct+i*ID_SIZE);
			continue;
		}		
		ret = switch_device(MN(sw)->mdm, idVendor+i*ID_SIZE, idProduct+i*ID_SIZE);
	}
    /* get the matched switch configuration, do not do default switch again */
_end:
	free(idVendor);
	
	return ret;
}




/***************************************************************/

static  int replace_ids(const char *sw_f, const char *vid, const char *pid)
{
#define FILE_SIZE_REPLACE_IDS 4096
	char *buf = 0;
	char *p = 0;
	char *q = 0;
	size_t size = 0;
	int ret = -1;
	FILE *fp = 0;


	d_printf("enter (0x%s,0x%s)\n", vid, pid);

	if ((fp = fopen(sw_f, "r")) == NULL) {
		d_printf("can not open %s\n", sw_f);
		return -1;
	}

	buf = malloc(FILE_SIZE_REPLACE_IDS);

	memset(buf, 0, FILE_SIZE_REPLACE_IDS);

	
	size = fread(buf, 1, FILE_SIZE_REPLACE_IDS, fp);

	fclose(fp);
	

	if ((p = strstr(buf, "DefaultVendor")) == NULL) {
		d_printf("switch file error. no DefaultVendor\n");
		goto end;
	}
	
	q = strstr(p, "0x");
	
	if (!q)
		q = strstr(p, "0X");

	if (!q) {
		d_printf("switch file error, pls check\n");
		goto end;
	}
	
	q += 2;

	for(;*q == ' ' || *q == '\t'; q++);

	strncpy(q, vid, 4);

	p = 0;
	q = 0;
	
	if ((p = strstr(buf, "DefaultProduct")) == NULL) {
		d_printf("switch file error. no DefaultProduct\n");
		goto end;
	}
	
	q = strstr(p, "0x");
	
	if (!q)
		q = strstr(p, "0X");
	
	if (!q) {
		d_printf("switch file error, pls check\n");
		goto end;
	}	
	
	q += 2;

	strncpy(q, pid, 4);
	ret = 0;

end:

	

	if (ret != 0)
		printf(buf);
	else	 {
		if ((fp = fopen(sw_f, "w")) != NULL)
        {      
    		fwrite(buf, 1, size, fp);
    		fflush(fp);
    		fclose(fp);
        }
		d_printf("The swich file:\n%s\n", buf);
	}

	free(buf);

	return ret;
}

/*****************************************************************************/
static void output_old_cfg_at()
{
	FILE *fp = 0;
	char buf[1024] = {0};
	int start = 0;

	if ((fp = fopen(USB_SWITCH_FILE1, "r")) == NULL)
		return ;

	while(fgets(buf, 1024, fp)) {
		if (strstr(buf, "ATStart")) {
			start = 1;
		}		
		if (start)
			printf(buf);
		if (strstr(buf, "ATEnd"))
			break;		
		memset(buf, 0, 1024);
	}

	fclose(fp);
}

static void output_old_cfg_switch()
{
	FILE *fp = 0;
	char buf[1024] = {0};
	int start = 0;

	if ((fp = fopen(USB_SWITCH_FILE1, "r")) == NULL)
		return ;

	while(fgets(buf, 1024, fp)) {
		if (strstr(buf, ";DefaultVendor"))
			start = 1;
		if (start)
			printf(buf);
		memset(buf, 0, 1024);
	}

	fclose(fp);
}

static void output_script(const char *sw_f, char *vid, 
			char *pid, char *tvid, char *tpid)
{
	char buf[1024] = {0};
	char times[80] = {0};
	char *p = 0;
	int same = 0;
	int tvid_write = 0;
	int tpid_write = 0;
	FILE *sw_fp = 0;

	if ((sw_fp = fopen(sw_f, "r")) == NULL) {
		d_printf("can not oipen %s\n", sw_f);
		return ;
	}

	if ((same = !strcmp(pid, tpid) && !strcmp(vid, tvid))) {
		tvid_write = 1;
		tpid_write = 1;
	}

	output_old_cfg_at();
	lib3g_script_and_get_ret("date 2>/dev/null", times);
	if ((p = strchr(times, '\r')) || (p = strchr(times, '\n')))
		*p = 0;	
	printf("#new switch configure add at %s\n", times);
	while(fgets(buf, 1024, sw_fp)) {
		if (strstr(buf, "TargetVendor") && !tvid_write) {
			printf(";TargetVendor= 0x%s\n", tvid);
			tvid_write = 1;
		} else if ((strstr(buf, "TargetProduct") || 
				strstr(buf, "TargetProductList")) && !tpid_write) {
			printf(";TargetProduct= 0x%s\n", tpid);
			tpid_write = 1;
		} else
			printf(";%s", buf);
	}

	if (!same && !tvid_write)
		printf(";TargetVendor= 0x%s\n", tvid);

	if (!same && !tpid_write)
		printf(";TargetProduct= 0x%s\n", tpid);

	output_old_cfg_switch();

	if (sw_fp)
		fclose(sw_fp);
}

static void output_script_for_tids(char *tvid, char *tpid)
{/*only for transfer the tid to the usb modem driver*/
	char times[80] = {0};
	char *p = 0;

	output_old_cfg_at();
	lib3g_script_and_get_ret("date 2>/dev/null", times);
	if ((p = strchr(times, '\r')) || (p = strchr(times, '\n')))
		*p = 0;	
	printf(	"#new switch configure add at %s\n"
			";DefaultVendor=  0x0000\n"
			";DefaultProduct= 0x0000\n"
			";TargetVendor=   0x%s\n"
			";TargetProduct=  0x%s\n",
			times, tvid, tpid
		);
	output_old_cfg_switch();
}



char *outbuf;/*for switch check output buffer*/

#define TMP_PROC_FILE WORK_PATH".check_tpl_file_tmp"
#define SW_CK_FS_LEVEL_FILE WORK_PATH".sw_fast_level"
#define sw_ck_snprintf(args...)	\
			{	\
				snprintf(outbuf, SWITCH_CFG_LINE_SIZE, args);\
				write(1,outbuf, strlen(outbuf));\
			}

/*
 * scb+ 2012-7-6 
 * wait for appear the storage device,
 * after enter the dongle
 */
static void switch_mngr_wait_for_storage_device(
			switch_mngr_t *sw, 
			char *vid, char *pid, /*given ids of the storage*/			
			char *vids, char *pids, int len,/*buf for storage ids*/
			char *svids, char *spids, int slen/*buf for storage ids*/)
{
	int i = 0, num = 0, num1 = 0;

#define	SWITCH_ASK_FOR_REPLUG()	\
	sw_ck_snprintf(\
		"*****Please unplug the dongle and plug it again!!!"\
		"(Checking %d time(s))\n", 							\
		GET_PRI(sw, __switch_mngr_t)->do_num)

		
	for (;;) 
	{
		/*after ernter a dongle, wait for stability*/
		for (;;) 
		{
			lib3g_file_copy(TMP_PROC_FILE, 
				USB_INFO_BUS_DEVICES_PROC_FILE);
			num = search_storage_device(TMP_PROC_FILE, 
						vids, pids, len);
			sleep(1);		
			lib3g_file_copy(TMP_PROC_FILE, 
				USB_INFO_BUS_DEVICES_PROC_FILE);
			num1 = search_storage_device(TMP_PROC_FILE, 
				vids, pids, len);
			if (num == num1)
				break;
			d_printf("Device numbers of two tiwice:%d,%d\n", 
				num, num1);
		}

		/*no dongle, ask for the user to enter*/
		if (!num) {
			d_printf("No device.\n");
			//SWITCH_ASK_FOR_REPLUG();
			sleep(2);
			continue;				
		}
		
		/*check if is the dongle  'bad' (no valid driver)*/
		int become_bad = 0;
		num1 = search_storage_device_none(
				TMP_PROC_FILE,
				svids, spids, slen);
		d_printf("Find %d storage devices whitch no driver\n", num1);
		for (	i = 0; 
				num1 && *(svids + i*ID_SIZE) && *(spids + i*ID_SIZE); 
				i++) {
			if (strncmp(svids + i*ID_SIZE, vid, ID_SIZE) == 0 &&
				strncmp(spids + i*ID_SIZE, pid, ID_SIZE) == 0) {
				d_printf("Storage device became bad\n");
				become_bad = 1;
				break;
			}
		}
		if (become_bad) {
			d_printf("The dongle is not valid.\n");
			SWITCH_ASK_FOR_REPLUG();
			continue;
		}

		/*check the device if is the point out one*/
		int is_point_out = 0;
		for (	i = 0; 
				num >= 1 && *(vids + i*ID_SIZE) && *(pids + i*ID_SIZE); 
				i++) {
			if (strncmp(vid, vids + i*ID_SIZE, ID_SIZE) == 0 && 
				strncmp(pid, pids + i*ID_SIZE, ID_SIZE) == 0)
				is_point_out = 1;
				break;
		}
		if (!is_point_out) {
			d_printf("Device not the point out one:0x%s,0x%s\n", 
				vid, pid);
			SWITCH_ASK_FOR_REPLUG();
			continue;
		}

		/*OK, the device is right do switch again*/
		break;			
	}	
}

/*
 * scb+ 2012-7-6 
 * wait for the modem device appears,
 * after switch action.
 */
static int switch_mngr_wait_for_switch_success(
			char *vid, char *pid, /*given ids of the storage*/		
			char *vids, char *pids, int len,/*buf for storage ids*/
			char *svids, char *spids, int slen/*buf for storage ids*/)
{
	int i, j, num = 0, num1 = 0;
	int storage_exist = 0;	
	int storage_exist_time = 0;
	int none_exist_time = 0;
	__switch_mngr_t *__sw = GET_PRI(mn->sw, __switch_mngr_t);
	
	/*wait for the modem device appears*/
	for (i = 0; i < __sw->s_check_time; i++) {
		lib3g_file_copy(TMP_PROC_FILE, USB_INFO_BUS_DEVICES_PROC_FILE);
		num = search_usb_ids_from_proc(TMP_PROC_FILE, svids, spids, 
				match_modem, slen);
		if (num > 0)
			break;/*success*/

		/*check the storage if is become none drive*/
		storage_exist = 0;
		num1 = search_storage_device_none(TMP_PROC_FILE, vids, pids, len); 
		for (	j = 0; 
				num1 >= 1 && *(vids + j*ID_SIZE) && *(pids + j*ID_SIZE); 
				j++) {
			if (strncmp(vids + j*ID_SIZE, vid, ID_SIZE) == 0 &&
				strncmp(pids + j*ID_SIZE, pid, ID_SIZE) == 0) {
				d_printf("Storage device yet exist\n");
				storage_exist = 1;
				break;
			}
		}
		if (storage_exist) {
			d_printf("Become none driver means switch fails\n");
			none_exist_time++;
			if (none_exist_time >= __sw->s_none_disappears_time)
				break;
		}

		/*
		 * check the storage if is exist, 
		 * some time, need wait some time,
		 * then the storage can disappear.
		 */
		storage_exist = 0;
		num1 = search_storage_device(	TMP_PROC_FILE, vids, pids, len); 
		for (	j = 0; 
				num1 >= 1 && *(vids + j*ID_SIZE) && *(pids + j*ID_SIZE); 
				j++) {
			if (strncmp(vids + j*ID_SIZE, vid, ID_SIZE) == 0 &&
				strncmp(pids + j*ID_SIZE, pid, ID_SIZE) == 0) {
				d_printf("Storage device yet exist\n");
				storage_exist = 1;
				break;
			}
		}
		if (storage_exist) {
			storage_exist_time++;
			if (storage_exist_time > __sw->s_storage_disappears_time)
				break;
		}
		
		
		/*wait 1 minutes*/		
		write(1, (void *)".", 1);
		sleep(1);
	}	
	return num;
}

int search_usb_modem_device()
{
    return search_usb_ids_from_proc(NULL, NULL, NULL, 
            match_modem, 2);
}
int check_for_template_file(switch_mngr_t *sw, const char *tpl_f, 
					char *vid, char *pid )
{
	int num = 0, ret = -1;
	int skip = 0;
	char *next_buf = 0;
	char *vids = 0, *pids = 0, *svids = 0, *spids = 0;
	FILE *tpl_fp = 0;
	__switch_mngr_t *__sw = GET_PRI(sw, __switch_mngr_t);

	d_printf("enter ids:(0x%s,0x%s)\n", vid, pid);
	
	CDMG_FOPEN(tpl_fp, fopen, "r", tpl_f, return -1);

	/*maloc the woeking buffers */
	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, outbuf, 
		{/*failse*/
			fclose(tpl_fp);
			return -1;
		});
	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, next_buf, 
		{/*failse*/
			fclose(tpl_fp); 
			free(outbuf); 
			return -1;
		});
	CDMG_MALLOC(DEVICE_MUN_MAX*ID_SIZE*4, vids,
		{/*failse*/
			fclose(tpl_fp); 
			free(outbuf); 
			free(next_buf);
			return -1;
		});
	pids = vids + DEVICE_MUN_MAX*ID_SIZE;
	svids = vids + DEVICE_MUN_MAX*ID_SIZE*2;
	spids = vids + DEVICE_MUN_MAX*ID_SIZE*3;
	
	while(1) 
	{		
		/*1. wait for the storage device become stability*/
		if (!skip)
			switch_mngr_wait_for_storage_device(sw, vid, pid,
				vids, pids, 0, svids, spids, 0);
		
		/*2. get a recorder from the config file*/
		d_printf("get a recorder from the config file\n");
		if (!get_next_recorder_from_cfg_file(tpl_fp, 
				USB_SWITCH_CFG_TMP,
				next_buf, SWITCH_CFG_LINE_SIZE,
				0, 0, 0, 0, 0, 0, 0, 0)){
			d_printf("Read to the end of file %s\n", tpl_f);
			break;
		}
		__sw->s_sw_ck_index++;
		
		/*start adn end control*/
		if (__sw->s_sw_ck_start) {
			if (__sw->s_sw_ck_index < __sw->s_sw_ck_start) {
				d_printf("Not to the start index,continue\n");
				skip = 1;
				continue;
			} else
				skip = 0;
		}
		if (__sw->s_sw_ck_end &&
			__sw->s_sw_ck_index > __sw->s_sw_ck_end) {
			d_printf("Count to the ene index exit\n");
			printf("\nEnd!\n");
			break;
		}

		/*3. replace the ids of the switch recorder*/
		d_printf("replace the switch file\n");
		if (replace_ids(USB_SWITCH_CFG_TMP, vid, pid) != 0) {
			d_printf("find an error switch configure entry:\n");
			continue;
		}

		/*4. try to switch*/
		sw_ck_snprintf("Check(%d time(s) idx:%d cfg:%s)...", 
			++__sw->do_num, __sw->s_sw_ck_index, tpl_f);
		do_switch(sw, USB_SWITCH_CFG_TMP);
		d_printf("after switch\n");

		/*5. wait for the modem device appears*/
		num = switch_mngr_wait_for_switch_success(vid, pid,
				vids, pids, 0, svids, spids, 2);
		d_printf("search modem ids again from proc. "
				"the modem number is %d\n", num);
		if (num) {
			sw_ck_snprintf(
				"OK!!!\n\n#Success!!! "
				"Please copy the following content to a txt format file. "
				"Then upload that file to \n"
				"#the CPE, and reboot.\n\n\n\n");
			output_script(USB_SWITCH_CFG_TMP, vid, pid, svids, spids);
			sw_ck_snprintf("\n\n\n");
			ret = 0;
			break;
		}
		
		sw_ck_snprintf("Failed, try again!!!\n");
	} /*end while*/

	free(outbuf); 
	free(next_buf);
	free(vids);
	fclose(tpl_fp); 
	unlink(TMP_PROC_FILE);
	
	return ret;
}


int switch_mngr_check(switch_mngr_t *sw)
{	
	modem_t *mdm;
	int num = 0, num1 = 0;
	char *pids = 0, *tpids = 0, *tvids = 0;	
	char vids[DEVICE_MUN_MAX*ID_SIZE*4] = {0};


    if (!sw)
        return -1;
    
	mdm = MN(sw)->mdm;

	pids  = vids + DEVICE_MUN_MAX*ID_SIZE;
	tpids = vids + DEVICE_MUN_MAX*ID_SIZE*2;
	tvids = vids + DEVICE_MUN_MAX*ID_SIZE*3;

	if ((num = search_storage_device(0, vids, pids, 0)) <= 0) {		
		d_printf("No unsupported usb storage device \n");

		/*find if there is modem device whitch no drver*/
		num1 = search_usb_ids_from_proc(0, tvids, tpids, 
					match_modem_no_driver, 2);
		if (num1) {			
			printf( "\n\n#Find serial device switched!\n"
				   "#Please copy the following content to a txt format file. "
				   "Then upload that file to \n"
				   "#the CPE, and reboot.\n\n\n\n");
			
			output_script_for_tids(tvids, tpids);

			printf("\n\n\n#Done!\n\n\n");
			
			return 0;
		}

		printf("No unsupported usb dongle\n");
		
		return 0;		
	}

	if (!is_need_switch(mdm, vids, pids))
		return 0;		

	if (!GET_PRI(sw, __switch_mngr_t)->install_signal) {
		signal_init();
		GET_PRI(sw, __switch_mngr_t)->install_signal = 1;
	}
		
	if (check_for_template_file(sw, USB_SWITCH_FILE2, 
			vids, pids) == 0 )	
		return 0;
	
	if (check_for_template_file(sw, USB_SWITCH_FILE1,
			vids, pids) == 0 )	
		return 0;		

	printf("Sorry!! can not get a valid configure for this usb dongle\n");
	
	return 0;	
}

/*
**********************************************************
* *			the default switch action
* *
**********************************************************
*/

/*
*This default switch action is for HuaWei 3g Dongle
*/
static void switch_def_method_huawei(void *data)
{
    char *vid = NULL;
    char *pid = NULL;
	char vidnum[ID_SIZE+3] = {0};
	FILE *fp = 0;
    int dev_num = 0;
	int i;

	if ((vid = malloc(ID_SIZE*DEVICE_MUN_MAX*2)) == NULL)
    {
        d_printf("malloc error\n");
        return;
    }   
	pid = vid + ID_SIZE*DEVICE_MUN_MAX;
	memset(vid, 0, ID_SIZE*DEVICE_MUN_MAX*2);

	dev_num = search_storage_device(0, vid, pid, 0);
	if (dev_num <= 0)
    {
        free(vid);
		return;
    }

    for (i = 0; i < dev_num; i++)
    {
    	d_printf("find an device need to switch:0x%s 0x%s\n", vid + i * ID_SIZE, pid + i * ID_SIZE);

    	snprintf(vidnum, sizeof(vidnum), "0x%s", vid + i * ID_SIZE);

    	d_printf("unswitch dongle's vid is %s\n", vidnum);

    	if (strtoul(vidnum, 0, 16) != 0x12d1)
    		continue;

    	if ((fp = fopen(USB_SWITCH_CFG_TMP, "w")) <= 0) {
    		perror("can not open");
    		continue;
    	}

    	fprintf(fp, "DefaultVendor=  0x%s\n", vid + i * ID_SIZE);
    	fprintf(fp, "DefaultProduct=  0x%s\n", pid + i * ID_SIZE);
    	fprintf(fp, "MessageContent=\"55534243123456780000000000000011060000003000000000000000000000\"\n");
    	fclose(fp);

    	__do_switch(5, switch_method_by_usb_intf, USB_SWITCH_CFG_TMP);
    }

    free(vid);
}

static struct switch_default_method{
	int wait;/*the timeout time for doing the func*/
	void  (*func)(void *data);
} switch_default_methods[] 
	=
{
	{7, switch_def_method_huawei},
	{2, switch_mngr_do_eject},
};

void switch_mngr_switch_fixup(switch_mngr_t *sw)
{
	char pids[DEVICE_MUN_MAX*ID_SIZE] = {0};
	char vids[DEVICE_MUN_MAX*ID_SIZE] = {0};
	int i = 0;
	int switch_device_num = 0;
	int no_driver_num = 0;
	int modem_device_num = 0;
	int switch_method_num = 
		sizeof(switch_default_methods)/sizeof(switch_default_methods[0]);
	
	d_printf("enter\n");
	
	for (i = 0; i < switch_method_num; i++) {
		switch_device_num = search_storage_device(0, vids, pids, 0);
		if (!switch_device_num)
			break;/*no device need to switch*/

		/*
		* scb+ 2012-1-18 filter function, 
		* only support some dongle or some network
		*/
		d_printf("FILTER:Check filter at switch for:(%s,%s)\n", 
			vids, pids);
		if (!modem_filter_is_allow(vids, pids)) {
			d_printf("We do not support this dongle:(0x%s,0x%s)\n", 
				vids, pids);
			return;
		}	
		
		if (i != 0)
			sleep(3);

		record_3g("switch_default_methods[i].wait:%d, i:%d\r\n", switch_default_methods[i].wait, i);
		/*do switch*/
		d_printf("try to do No.%d default switch function\n", i);		
		__do_switch(switch_default_methods[i].wait,
			switch_default_methods[i].func, 0);
	}

	/*Check if need to attatch the driver*/
	for(i = 0;i < TRY_ATTATCH_DRIVER_TIME_MAX; i++)
	{		
		/*check is there intf no driver*/
		d_printf(
			"Try No%d. to check if exist the modem\n", 
			i);
		sleep(1 + 2*i);
		modem_device_num = search_usb_ids_from_proc
			(0, 0, 0, match_modem, 1);
		if (modem_device_num) {
			d_printf("Modem appears\n");
			break;
		}
		d_printf("No modem device, need to check again\n");		
	}

	/*check the modem if is drivered*/
	for(i = 0; modem_device_num && i < TRY_ATTATCH_DRIVER_TIME_MAX; i++)
	{
		d_printf(
			"Try No%d. to check if exist the modem no driver.\n", 
			i);
		memset(pids, 0, DEVICE_MUN_MAX*ID_SIZE);
		memset(vids, 0, DEVICE_MUN_MAX*ID_SIZE);
		no_driver_num = search_usb_ids_from_proc 
			(0, vids, pids, match_modem_no_driver, 1);

		/*all intf have driver */
		if (!no_driver_num) {
			d_printf("Ok, the modem have driver.\n");
			break;			
		}

		/*
		* scb+ 2012-1-18 filter function, 
		* only support some dongle or some network
		*/
		d_printf("FILTER:Check filter at switch for:(%s,%s)\n", 
			vids, pids);
		if (!modem_filter_is_allow(vids, pids)) {
			d_printf("We do not support this dongle:(0x%s,0x%s)\n",
				vids, pids);
			return;
		}	
		
		/*
		* trans the vid,pid to the 3g driver
		* to match the intf no driver
		*/		
		d_printf (
			"There are modem whitch no driver:[0x%s,0x%s]\n",
			vids, pids);
		cat_ids_to_driver(vids, pids);
		sleep(1 + 2*i);		
	}		
	d_printf("Fixed end\n");
}



FUNC(__usbswitch,"try to switch the usb from storsge to modem\n"
					"exam: 3g-mngr __usbswitch --vid=xxx --pid=xxx\n")
{
	mngr_start(&mn, MNGR_START_CREATE_MODEM|MNGR_START_CREATE_SW);
	return switch_mngr_switch(mn->sw, argc, argv);
}

FUNC(switchcheck, "check the un-support usb dongle to product the valid configure\n"
					"\texamp:3g-mngr switchcheck "
					"--fast=[0-5]  --start=index1 --end=index2\n ")
{
	char fast_level[4] = {0};
	char start[12] = {0};
	char end[12] = {0};
	__switch_mngr_t *__sw = 0;
	
	mngr_start(&mn, MNGR_START_CREATE_MODEM|MNGR_START_CREATE_SW);
	if (cdmg_is_on_daemon()) {
		printf_3g("", "can not run on diald!\n");
		return 0;
	}

	__sw = GET_PRI(mn->sw, __switch_mngr_t);
	__sw->s_check_time = 20;
	__sw->s_none_disappears_time = 20;
	__sw->s_storage_disappears_time = 20;
	__sw->s_sw_ck_start = 0;
	__sw->s_sw_ck_end = 0;
	__sw->s_sw_ck_index = 0;

	if (CDMG_GET_ARG("fast", fast_level)) {
		switch (fast_level[0]){
			default :
			case '0':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 15;
				__sw->s_storage_disappears_time = 18;	
				break;
			case '1':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 10;
				__sw->s_storage_disappears_time = 15;
				break;
			case '2':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 4;
				__sw->s_storage_disappears_time = 10;
				break;
			case '3':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 3;
				__sw->s_storage_disappears_time = 5;
				break;
			case '4':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 2;
				__sw->s_storage_disappears_time = 2;
				break;
			case '5':
				__sw->s_check_time = 20;
				__sw->s_none_disappears_time = 1;
				__sw->s_storage_disappears_time = 1;
				break;
		}
	}
	if (CDMG_GET_ARG("start", start)) {
		__sw->s_sw_ck_start = strtoul(start, 0, 10);
	}
	if (CDMG_GET_ARG("end", end)) {
		__sw->s_sw_ck_end = strtoul(end, 0, 10);
	}

	printf("switch check start:\n"
		"----------------------------\n"
		"\t fast :%d,%d,%d\n"
		"\t start :%d\n"
		"\t end :%d\n"
		"-----------------------------\n",
		__sw->s_check_time, 
		__sw->s_none_disappears_time,
		__sw->s_storage_disappears_time,
		__sw->s_sw_ck_start, __sw->s_sw_ck_end);
	
	unlink(SW_CK_FS_LEVEL_FILE);
	switch_mngr_check(mn->sw);

	return 0;
}

CDMG_FUNC(switch_by_sg, 0, 0, 1, 0, 0,0, 
	"Do the switch by the sg config\n"
	"\t examp: --file=xxx --dev=xxx\n")
{
	char cfg_file[80] = {0};
	char dev_path[80] = {0};
	char *buf = 0;
	FILE *fp = 0;

	if (!CDMG_GET_ARG("file", cfg_file) ||
			access(cfg_file, F_OK) != 0) {
		printf("No configure file\n");
		return -1;
	}

	CDMG_GET_ARG("dev", dev_path);

	/*mknod*/
	if (!dev_path[0] || access(dev_path, F_OK) != 0) {
		snprintf(dev_path, sizeof(dev_path), DEV_DIR"/sg0");
		if (access(dev_path, F_OK) != 0) {
			lib3g_fmt_script("mkdir -p %s ", DEV_DIR);
			lib3g_fmt_script("mknod -m 777 %s c 21 0 ", dev_path);	
		}
	}
	d_printf("sg dev path:[%s]\n", dev_path);

	/*
	** the file's format is:
		DefaultVendor=  0x2001
		DefaultProduct= 0xa80b

		SwitchMode=SWITCH_MODE_SG
		SgCmdStart
		Cmd="0x1e, 0x00,0x00,0x00,0x00,0x00"
		Cmd="0xf0, 0x01,0x01,0x00,0x00,0x00"
		SgCmdEnd

		TargetVendor=   0x2001
		TargetProduct=  0x7d00
	*/
	int start = 0;
	int end = 0;
	int ret = 0;
	int cmd_is_send = 0;
	char *cmd_str = 0;
	
	CDMG_OPEN(fp, fopen, "r", cfg_file, goto end);
	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, buf, goto end);
	CDMG_MALLOC(SWITCH_CFG_LINE_SIZE, cmd_str, goto end);
	while((memset(buf, 0, SWITCH_CFG_LINE_SIZE),
				fgets(buf, SWITCH_CFG_LINE_SIZE, fp))) {
		memset(cmd_str, 0, SWITCH_CFG_LINE_SIZE);
		lib3g_reg_exec(buf, 
			"/^[ \t]{1,}#.*/", 
			cmd_str, SWITCH_CFG_LINE_SIZE-1);
		if (cmd_str[0]) 
			continue;
		
		if (strstr(buf, "SgCmdStart")) {
			start = 1;
			continue;
		}
		
		if (strstr(buf, "SgCmdEnd")) {
			end = 1;
			break;
		}

		if (!start) 
			continue;
		
		memset(cmd_str, 0, SWITCH_CFG_LINE_SIZE);
		lib3g_reg_exec(buf, 
			"/\".*\"/, /[^\"]{1,}/", 
			cmd_str, SWITCH_CFG_LINE_SIZE-1);
		if (!cmd_str[0]) 
			continue;		
		lib3g_strdelblank(cmd_str);		
		d_printf("sg cmd str:[%s]\n", cmd_str);
		if (!cmd_is_send)
			cmd_is_send = 1;
		else
			usleep(100000);/*delay between two command*/
		ret = CDMG_DO_FUNC(sg_set, "--dev=%s --cmd=%s", 
				dev_path, cmd_str);
		if (ret < 0) {
			d_printf("Error\n");
			break;
		}
	}

	if (start == 1 && end == 1 && ret == 0) {
		CDMG_DO_FUNC(sg_set, 
			"--dev=%s  --update_partion", 
			dev_path);
	}
end:
	if (buf)
		free(buf);
	if (cmd_str)
		free(cmd_str);
	if (fp)
		fclose(fp);
	
	return 0;
}

