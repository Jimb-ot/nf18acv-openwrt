/*
  *	3g wan management function
  *	scb+ 2011-3-15
  */
#ifdef SUPPORT_3G_WAN_MANAGEMENT
#include <setjmp.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/ppp_defs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "3g-mngr-include.h"

/*the switch file for outputting debug info*/
#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_wan", "WAN", args)

#define DEBUG

#undef DPRINT
#ifdef DEBUG
#define DPRINT(args...)  printf_3g("", args)
#else
#define DPRINT(args...)  d_printf(args)
#endif

#define  CHANGE_NTWK_DELAY 3
#define  CHANGE_NTWK_TRY_TIME 10


/*scb+ 2012-4-26 for dial delay timer*/
struct wan_dial_delay{
	int is_dial;
	int is_undial;
};

typedef enum{
	SWITCH_ACT_NONE = 0,
	SWITCH_ACT_DIAL ,
	SWITCH_ACT_UNDIAL,
} wan_switch_act_t;

/*scb+ 2012-3-28 for setting dial delay timer*/
struct  wan_switch_date {
	char wan_name[WANNAME_LEN+1];	
	int is_down;
	int is_up;
	wan_switch_act_t action;	
	int delay;
};


/*scb+ 2012-4-21 for wan dial*/
struct wan_dial_param {
	int need_check_dial;

	wan_dial_act_t act;

	int delay;
	
	struct  wan_switch_date	 switch_date;	
};

struct wan_ntwk{
	int ntwk_permanence;
	struct  wan_connect *real_conn;/*set by ssk*/

	/*used by change ntwk, when 3g down need change default gw*/
	int ntwk_res_defgw_to_dsl;
	
	/*for the param of the timer:wan_mngr_ntwk_timer*/
	int   ntwk_num;
	struct  wan_connect *want_conn;
	struct timer_3g *ntwk_timer;	
};

typedef struct {
	struct  wan_connect *wans;
	struct  wan_config config;

	struct wan_ntwk  ntwk;
	
	struct  wan_connect *real_conn;/*set by ssk*/
	


		
	int ping_check_start;	
	int ping_success;	
	int ping_fail;

	int add_web_rule;

	int is_update;
	int old_is_update;

	/*
	* indicate this dial is manual dial.
	* this flag only be clear at 3g conn down or hotunplug.
	*/
	int dial_manual;

	int is_link_down;
	
	/*scb+ 2012-4-21 for dial*/
	struct wan_dial_param dial_param;

	/*scb+ 2012-4-26 for dial delay timer*/
	struct wan_dial_delay dial_delay;

	/*scb+ 2012-9-24 for hotunplug,need to note change def gw*/
	int 	need_select_def_gw;
} __wan_mngr_t;

static char * wan_mngr_conn_status2str(wan_status_t s);

#ifdef PC
static void wan_mngr_config_init_for_pc();
#endif
static void wan_mngr_del_all_wan(__wan_mngr_t *__wan);
static void wan_mngr_to_get_conns(__wan_mngr_t *__wan);
static void wan_mngr_get_conn_up(struct  wan_connect  **conn_3g, 
			struct  wan_connect  **conn_dsl, int dsl_num);
static void wan_mngr_connect_status_change(__wan_mngr_t *__wan,
			struct  wan_connect  *conn);
static void wan_mngr_connect_del(__wan_mngr_t *__wan, 
			struct  wan_connect *conn);
static void wan_mngr_ping_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn);
static void wan_mngr_ping_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg);
static void wan_mngr_dial_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg);
static void wan_mngr_dial_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn);
static void wan_mngr_conn_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg);

static void wan_mngr_dial_for_update_notify(__wan_mngr_t *__wan);
static void wan_mngr_ping_for_update_notify(__wan_mngr_t *__wan);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
static void wan_mngr_web_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn);

static void wan_mngr_web_for_update_notify(__wan_mngr_t *__wan);
#endif
static void wan_mngr_dialing_timeout(void *data);
static void wan_mngr_for_each_conn(void (*fn)(struct  wan_connect *conn, 
			void *data), void *data);
static void wan_mngr_switch_action_timer(void *data);
static void wan_mngr_dial(int delay, int is_dial);
static void wan_mngr_ntwk_set_not_change(int is_set);
static void wan_mngr_ntwk_change_recvd(__wan_mngr_t *__wan, 
			struct  wan_connect  *def_conn);
static void wan_mngr_ntwk_change(__wan_mngr_t *__wan);
#ifdef PC
static void wan_mngr_set_dns_for_pc(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn);
static void wan_mngr_set_ntwk_for_pc(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn);
#endif
static struct  wan_connect *wan_mngr_connect_add(__wan_mngr_t *__wan, 
			struct  wan_connect *conn);
static struct  wan_connect *wan_mngr_get_wan(__wan_mngr_t *__wan, 
			const char *wan_name, int by_ifname);
static struct wan_connect *wan_mngr_defgw_select(int is_change);

static int wan_mngr_check_in_connecting(void);


int wan_mngr_init(wan_mngr_t *wan)
{	
	SUB_INIT(wan, wan_mngr_t, __wan_mngr_t);
	wan_mngr_to_get_conns(GET_PRI(wan, __wan_mngr_t));
	return 0;	
}

wan_mngr_t *wan_mngr_new(void *mn)
{
	wan_mngr_t *wan;

	if ((wan = ALLOC_3G(wan_mngr_t, __wan_mngr_t)) <= 0)
		return 0;

	MN_SET(wan, mn);

	wan_mngr_init(wan);

	return wan;
}

int wan_mngr_free(wan_mngr_t *wan)
{
	if (!wan)
		return 0;
	
	if (MN(wan))
		MN(wan)->wan = 0;

	free(wan);
	wan = 0;
	return 0;
}
/*********************************************************************/
static int is_3g_wan(const char *name)
{
	if (!name)
		return 0;	

	/* BEGIN: Added by zhoumingming, 2014/10/16   PN:86743, defaultwan string value is "3g", so we must add this to match. */
	if (!strcmp(name, "3g"))
		return 1;
	/* END:   Added by zhoumingming, 2014/10/16   PN:86743 */

	if (!strcmp(name, g_usb_dongle_ifname))
		return 1;

	return 0;
}

static int conn_can_ignore(const char *wan_name)
{
	struct  wan_connect *conn;

	
	if (!wan_name) {
		printf_3g("", "Wan Nane is 0\n");
		return 1;
	}

	conn = wan_mngr_get_wan(GET_PRI(mn->wan, __wan_mngr_t), wan_name, 0);
	if (!conn)
		return 0;
	
	if (conn->status == WAN_S_DIALING || conn->status == WAN_S_UNDIALING
			||conn->status == WAN_S_DIALWAITING)
		return 1;	

	return 0;
}

/*
* scb+ 2012-3-4 for sending dial status to upper module
*/
static int conn_dial_status_notify(struct  wan_connect *conn)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_connect *new_conn = 0;
	d_printf("enter\n");

	/*if not 3g wan, ignore*/
	if (!conn || !is_3g_wan(conn->wan_name))
		return 0;

	d_printf("To get new conn for new status\n");
	new_conn = wan_mngr_get_wan(__wan, conn->wan_name, 0);
	if (!new_conn || new_conn->status == conn->status)
		return 0;
	
	/*send the status*/
	switch(	conn->status) {
	case	WAN_S_DIALING:
		lib3g_send_mobile_chage_msg(WAN_3G_DIALING);
		break;
	case 	WAN_S_UNDIALING:
		lib3g_send_mobile_chage_msg(WAN_3G_UNDIALING);
		break;
	case 	WAN_S_DIALWAITING:
		lib3g_send_mobile_chage_msg(WAN_3G_DIALWAITING);
		break;
	case	WAN_S_CONNECTING:
		lib3g_send_mobile_chage_msg(WAN_3G_CONNECTING);
		break;
	case	WAN_S_DISCONNECTED:
		if (conn->status == WAN_S_UNDIALING && conn->isdemand)
			lib3g_send_mobile_chage_msg(WAN_S_DISCONNECTED);
			
	default:
		break;
	}
	
	d_printf("Finish send status to upper module\n");
	return 0;	
}

static int conn_is_up(struct wan_connect *conn)
{
	if (conn && (conn->status == WAN_S_CONNECTED || 
			(conn->status == WAN_S_CONNECTING && conn->isdemand)))
		return 1;
	
	return 0;
}

static int conn_is_dialing(struct wan_connect *conn)
{
	if (conn && (conn->status == WAN_S_DIALING || 
			(conn->status == WAN_S_DIALWAITING)))
		return 1;
	
	return 0;
}

int wan_mngr_cond_check(unsigned int type)
{
	int ret = 1;
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_config	 *config = &__wan->config;	

	if (ret && (type & WAN_COND_CHECK_MODEM_READY)) {
		if (mn->mdm->status != SEARCH_FINISHED) {
			d_printf("Modem not ready\n");
			ret = 0;	
		}

		/*scb+ 2012-9-21, check pin and network if is ready*/
		if (ret && !modem_is_ready(mn->mdm)) {
			d_printf("Pin or network not ready.\n");
			ret = 0;
		}
	}
	
	if (ret && (type & WAN_COND_CHECK_3G_ENBL)) {
		if (!config->enable) {
			d_printf("3G not enable\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_PIN_READY)) {
		if (!modem_pin_is_ready(mn->mdm)) {
			d_printf("PIN not ready\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_NETWORK)) {
		if (!modem_reg_is_ready(mn->mdm)) {
			d_printf("Network not register\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_PING_ENBL)) {
		if (!config->pingenble) {
			d_printf("PING check not enable\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_3G_CONN_EXIST)) {
		struct wan_connect *wan_3g = 
			wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
		if (!wan_3g) {
			d_printf("NO 3G conn\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_3G_CONN_UP)) {
		struct wan_connect *wan_3g = 
			wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
		if (!wan_3g) {
			d_printf("NO 3G conn\n");
			ret = 0;
		} else if (!conn_is_up(wan_3g)) {
			d_printf("3G WAN not up\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_DEF_IS_3G)) {
		if (!is_3g_wan(config->defaultwan)) {
			d_printf("DEF WAN not 3G\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_ALLOW_MANUAL_DIAL)) {
		if (!config->manualdial) {
			d_printf("Not Only allow manual dial\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_ALLOW_AUTO_DIAL)) {
		if (!config->autodial) {
			d_printf("Not Allow auto dial\n");
			ret = 0;
		}
	}
	if (ret && (type & WAN_COND_CHECK_IS_MANUAL_DIAL)) {
		if (!__wan->dial_manual) {
			d_printf("Not manual dial\n");
			ret = 0;
		}
	}	
	return ret;
}

static void wan_mngr_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *old_conn)
{
	/*
	  *wan conn has changed
	  *if connect status changed,conn is the old one.
	  *if add,conn is the add one.
	  *if del, conn is the del one.
	  */
	int ignore = 0;
	struct  wan_connect  *new_conn = 0;
	
	if (!old_conn)
		return;

	new_conn = wan_mngr_get_wan(__wan, old_conn->wan_name, 0);
	
	d_printf("Wan conn info %s:[%s] [%s-->%s] %s\n",
			(old_conn->action == WAN_ADD)?"ADD":((old_conn->action == WAN_DEL)?"DEL":"Change"),
			old_conn->wan_name, 
			wan_mngr_conn_status2str(old_conn->status),
			new_conn ? wan_mngr_conn_status2str(new_conn->status) : "",
			old_conn->isdemand?"demand":"not_demand");

	if (__wan->is_update)
		return;

    if (new_conn && (old_conn->status == new_conn->status))
    {
        d_printf("%s nothing to be change\n", old_conn->wan_name);
        return;
    }
	/*scb+ 2012-6-19, ignore dsl status change, when 3g not valid*/
	if (!is_3g_wan(old_conn->wan_name) && !wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK|
			WAN_COND_CHECK_3G_CONN_EXIST)) {
		d_printf("Dsl status change, 3g not valid, ignore\n");
		return;
	}

	/*scb+ 2012-3-4 for notify the status to upper module*/
	conn_dial_status_notify(old_conn);
	
	ignore = conn_can_ignore(old_conn->wan_name);


	if (!ignore) {
		wan_mngr_dial_set(WAN_DIAL_ACT_INIT, 0, 0, 0, 0);
		wan_mngr_connect_status_change(__wan, old_conn);
		wan_mngr_ping_for_conn_notify(__wan, old_conn);		
	}
	wan_mngr_dial_for_conn_notify(__wan, old_conn);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	wan_mngr_web_for_conn_notify(__wan, old_conn);
#endif

	/*must at the end*/
	if (!ignore)
		wan_mngr_dial_decide();

	return;
}

/*
* when update the conn info, nothing can be done, 
* if update finish, need to check if does need
* to do something.
*/
static void wan_mngr_update_end_notify(__wan_mngr_t *__wan)
{	
	wan_mngr_dial_set(WAN_DIAL_ACT_INIT, 0,0,0,0);
	
	wan_mngr_ping_for_update_notify(__wan);
	wan_mngr_dial_for_update_notify(__wan);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	wan_mngr_web_for_update_notify(__wan);
#endif

	wan_mngr_dial_decide();
}

static void wan_mngr_to_get_conns(__wan_mngr_t *__wan)
{
	d_printf("del all old conn\n");
	wan_mngr_del_all_wan(__wan);
	__wan->wans = 0;
	lib3g_send_mobile_chage_msg(MNGR_MSG_GETCONNS);
}
#if 0
static void reset_timeout_timer(void *data)
{
	d_printf("reset timeout, kill the task %d\n", mn->do_reset_set);
	kill(mn->do_reset_set, SIGKILL);
	mn->do_reset_set = 0;
}

static int process_reset_end(int argc, char *argv[])
{
	mn->do_hotplug = 0;
	
	timer_del_by_token("reset_timeout_timer");

      d_printf("reset end\n");
	return 0;
}
CDMG_SETUP_MSG(resetend, process_reset_end, "");
#endif
static void wan_mngr_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg)
{
	struct wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g = wan_mngr_get_wan(__wan, 
					g_usb_dongle_ifname, 0);
	
	/*wan conn has changed*/
	d_printf("enter\n");

    /* apn or netmode change ,need to reset moderm */
#if 0   /* ���治��Ҫ�����Ĵ��� */
    d_printf("apn(new=%s,old=%s)\n", config->apn, oldcfg->apn);
    if (strcmp(config->apn, oldcfg->apn) != 0)
    {
        if ((   mn->do_reset_set = fork_3g()) == 0) {
            d_printf("start to handle reset\n");           
            //modem_reset(mn->mdm);
    		/*let daemon do the last part*/
    		CDMG_SEND_MSG(resetend, "%s", "");
            CDMG_SEND_MSG(hotunplug, "%s", "");
            exit(0);
        } else if (mn->do_reset_set  > 0) {
            timer_set(5, 
                "reset_timeout_timer",
                reset_timeout_timer, (void *)mn);
        }
        
        return;
    }
#endif    
	if (__wan->is_update)
		return;
	
	if (!oldcfg->enable && config->enable) {
		d_printf("3g become enable, update wan info\n");
		wan_mngr_to_get_conns(__wan);
		return;
	}

	/*2011-9-7*/
	if (config->demand && !oldcfg->demand) {
		d_printf("3g become demand\n");

		/*set 3g to demand*/
		if (conn_3g)
			conn_3g->isdemand = 1;
	} else if (!config->demand && oldcfg->demand) {
		d_printf("3g become not demand\n");

		/*set 3g to none demand*/
		if (conn_3g)
			conn_3g->isdemand = 0;	
	}

	wan_mngr_dial_set(WAN_DIAL_ACT_INIT, 0,0,0,0);
	
	wan_mngr_dial_for_config_notify(__wan, oldcfg);
	wan_mngr_ping_for_config_notify(__wan, oldcfg);
	wan_mngr_conn_for_config_notify(__wan, oldcfg);

	/*must at the end*/
	wan_mngr_dial_decide();
	return;
}

static struct  wan_connect *wan_mngr_get_wan(__wan_mngr_t *__wan, 
			const char *wan_name, int by_ifname)
{
	struct  wan_connect  *conn = __wan->wans;

	while (conn) {
 		if (!by_ifname && !strcmp(wan_name, conn->wan_name))
			break;
		else if (by_ifname && !strcmp(wan_name, conn->ifname))
			break;		
		conn = conn->next;
	}

	return conn;
}

static struct  wan_connect *wan_mngr_get_pre_wan(__wan_mngr_t *__wan, 
			const char *wan_name)
{
	int find = 0;
	struct  wan_connect   *conn = __wan->wans;


	while (conn && conn->next) {
		if (!strcmp(wan_name, conn->next->wan_name)) {
			find = 1;
			break;	
		}
		conn = conn->next;
	}

	if (find)
		return conn;
	else
		return 0;
}

static void wan_mngr_connect_del(__wan_mngr_t *__wan, 
			struct  wan_connect *conn)
{
	struct  wan_connect  *conn1, *conn2;

	conn1 = wan_mngr_get_wan(__wan, conn->wan_name, 0);
	if (!conn1)
		return ;

	conn2 = wan_mngr_get_pre_wan(__wan, conn->wan_name);
	if (conn2)
		conn2->next = conn1->next;
	else
		__wan->wans = conn1->next;

	conn1->action = WAN_DEL;
	wan_mngr_conn_notify(__wan, conn1);
	free(conn1);	
}
	
static struct wan_connect * 
wan_mngr_connect_add(__wan_mngr_t *__wan, struct  wan_connect *conn)
{
	struct  wan_connect  *conn1;
	struct wan_config *config = &__wan->config;

	conn1 = wan_mngr_get_wan(__wan, conn->wan_name, 0);
	if (conn1) {
		DPRINT("conn %s exist\n", conn->wan_name);
		return conn1;
	}
	if ((conn1 = malloc(sizeof(struct  wan_connect))) == NULL) {
		d_perror("malloc error:");
		return 0;
	}

	memset(conn1, 0, sizeof(struct  wan_connect));
	memcpy(conn1, conn, sizeof(struct  wan_connect));
	
	if (is_3g_wan(conn->wan_name)) {
		d_printf("Add 3g conn update demand from config\n");
		conn1->isdemand = config->demand;
		conn->isdemand = config->demand;
	}
	
	conn->action = WAN_ADD;

	conn1->next = __wan->wans;
	__wan->wans = conn1;	
    wan_mngr_conn_notify(__wan, conn);
	return conn1;	
}

void wan_mngr_set_3g_link_info(wan_status_t status)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_connect *conn_3g = wan_mngr_get_wan(__wan, 
		g_usb_dongle_ifname, 0);

    if (!conn_3g)
    {
        return;
    }
    
	if (!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL))
		return;

	if (conn_3g->status == status)
		return;

	if (status == WAN_S_UNDIALING && 
		!(conn_3g->status 	== WAN_S_CONNECTED || 
			conn_3g->status == WAN_S_CONNECTING||
		 	conn_3g->status == WAN_S_DIALING||
		 	conn_3g->status == WAN_S_DIALWAITING))
		return;
		

	CDMG_DO_FUNC(wanlinkinfo, 
		" --act=set --wanname=%s  --link=%d", 
		g_usb_dongle_ifname, status); 
}

static int wan_mngr_conn_is_change(struct  wan_connect *old, 
		struct  wan_connect *new)
{
	if (old->status != new->status)
		return 1;
	if (old->status_ipv6 != new->status_ipv6)
		return 1;
	if (old->isdemand != new->isdemand)
		return 1;
	if (strcmp(old->dns_server, new->dns_server) != 0)
		return 1;

	return 0;
}

CDMG_FUNC(wanlinkinfo, 1, 0, 0, 0, 0, 0,
			"set all the wan connection link status. if set update option,\n"
			"means only update the wan info, can not do any action.\n"
                   "exam: 3g-mngr wanlinkinfo --act=set|del|add  \n"
                   "\t\t--wanname=xxx --wanalias=xxx --ifname=xxx \n"
                   "\t\t--link=xxx --linkv6=xxx, --demand=x\n"
                   "\t\t--notadd=1 --dns=x.x.x.x,y.y.y.y --update=x \n"
                   "\t\t--gateway=x --nexthop=x.x.x.x --priority=0 \n"
                   "\t\t--notadd=0|1")
{
	char act[8] = {0};
	char gateway[8] = {0};
	char not_add[4] = {0};
	char link[16] = {0};
	char demand[4] = {0};
	char update[4] = {0};
	char ifname[IFNAME_LEN+1] = {0};
	char dns[DNS_SERVER_SIZE+1] = {0};
	char wan_name[WANNAME_LEN+1] = {0};
	char wan_alias[WAN_ALIAS_NAME_LEN+1] = {0};	
	char wan_nexthop[CDMG_IPV4_ADDR_LEN] = {0};
	char priority[4] = {0};
#ifdef PC
	char wan_gw_addr[IPV4_ADDR_SIZE+1] = {0};
#endif
	__wan_mngr_t *__wan = 0;
	struct  wan_connect conn;
	struct  wan_connect *conn1 = 0;
	struct  wan_config *config = 0;

	d_printf("enter\n");
	
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	__wan =  GET_PRI(mn->wan, __wan_mngr_t);
	config = &__wan->config;
		
	MNGR_GET_ARG("act", act);
	MNGR_GET_ARG("ifname", ifname);
	MNGR_GET_ARG("wanname", wan_name);
	MNGR_GET_ARG("wanalias", wan_alias);
	MNGR_GET_ARG("link", link);
	MNGR_GET_ARG("demand", demand);
	MNGR_GET_ARG("dns", dns);
	MNGR_GET_ARG("update", update);
	MNGR_GET_ARG("notadd", not_add);
#ifdef PC
	MNGR_GET_ARG("gwaddr", wan_gw_addr);
#endif

	/*this conn is gate way*/
	MNGR_GET_ARG("gateway", gateway);
    MNGR_GET_ARG("nexthop", wan_nexthop);

	MNGR_GET_ARG("priority", priority);
	
	d_printf("param:\n"
			"\tact:%s\n"
			"\tifname:%s\n"
			"\twanname:%s\n"
			"\twanalias:%s\n"
			"\tlink:%s\n"
			"\tdemand\n"
			"\tdns:%s\n"
			"\tupdate:%s\n"
			"\tgateway:%s\n"
			"\tnexthop:%s\n"
			"\tpriority:%s\n",
		act, ifname, wan_name, 
		wan_alias, link, dns, update, gateway,wan_nexthop, priority);

	if (!config->enable && strcmp(act, "del")) {
		d_printf("3g not enable\n");
		return 0;
	}

    /*
	* in tbs, the ifname is not the Connection Object's id,in brcm, 
	* the ifname is the id of the WanConnection
	*/
	if (!wan_name[0] && ifname[0])
		strncpy(wan_name, ifname, WANNAME_LEN);

	__wan->old_is_update = __wan->is_update;
	if (update[0] == '1')
		__wan->is_update = 1;
	else
		__wan->is_update = 0;

	memset(&conn, 0, sizeof(conn));
	
#ifdef PC
	if (wan_gw_addr[0])
		strncpy(conn.wan_gw_addr, wan_gw_addr, IPV4_ADDR_SIZE);
#endif

	if (!strcmp(act, "add")) {
		strncpy(conn.wan_name, wan_name, WANNAME_LEN);
		
		if (ifname[0]) {
			strncpy(conn.ifname, ifname, IFNAME_LEN);
		}
		
		if (wan_alias[0]) {
			strncpy(conn.wan_alias, wan_alias, WAN_ALIAS_NAME_LEN);
		}
		if(wan_nexthop[0])
		{
			strncpy(conn.wan_nexthop, wan_nexthop, IPV4_ADDR_SIZE);
		}
		
		conn.isdemand= demand[0] == '1'?1:0;
		conn.status = 0;
		wan_mngr_connect_add(GET_PRI(mn->wan, __wan_mngr_t), &conn);
	}
	
	if (!strcmp(act, "del")) {
		strncpy(conn.wan_name, wan_name, WANNAME_LEN);
		wan_mngr_connect_del(GET_PRI(mn->wan, __wan_mngr_t), &conn);
	} 
	
	if (!strcmp(act, "set") && wan_name[0]) {
		strncpy(conn.wan_name, wan_name, WANNAME_LEN);
		
		if (ifname[0]) {
			strncpy(conn.ifname, ifname, IFNAME_LEN);
		}
		
		if (wan_alias[0]) {
			strncpy(conn.wan_alias, wan_alias, WAN_ALIAS_NAME_LEN);
		}
		if(wan_nexthop[0])
		{
			strncpy(conn.wan_nexthop, wan_nexthop, IPV4_ADDR_SIZE);
		}
		

		conn1 = wan_mngr_get_wan(GET_PRI(mn->wan, __wan_mngr_t), 
				conn.wan_name, 0);
		if (!conn1) {
			d_printf("No %s, add it\n", wan_name);
            #if 0
			if (not_add[0] == '1') {
				d_printf("User not add the wan\n");
				return 0;
			}
			#endif
			conn.isdemand= demand[0] == '1'?1:0;
			conn.status = 0;
			wan_mngr_connect_add(GET_PRI(mn->wan, __wan_mngr_t), &conn);

			conn1 = wan_mngr_get_wan(GET_PRI(mn->wan, __wan_mngr_t),
					conn.wan_name, 0);
		}

		memcpy(&conn, conn1, sizeof(conn));
		
		if (link[0])
			conn1->status = strtoul(link, 0, 10);

		if (demand[0])
			conn1->isdemand = demand[0] == '1'?1:0;

		if (dns[0])
			strncpy(conn1->dns_server, dns, DNS_SERVER_SIZE);

		/*scb+ 2012-3-30 for support wan priority*/
		if (priority[0])
			conn1->priority = strtoul(priority, 0, 10);

		if (ifname[0])
			strncpy(conn1->ifname, ifname, IFNAME_LEN);
		if (wan_nexthop[0])
			strncpy(conn1->wan_nexthop, wan_nexthop, CDMG_IPV4_ADDR_LEN-1);

		if (wan_alias[0])
			strncpy(conn1->wan_alias, wan_alias, WAN_ALIAS_NAME_LEN);		

		/*update, nothing been done*/
		if (!__wan->old_is_update && !__wan->is_update && 
				(wan_mngr_conn_is_change(&conn,  conn1) ||
				conn.priority != conn1->priority)) {
			conn.action = WAN_EDIT;
			wan_mngr_conn_notify(GET_PRI(mn->wan, __wan_mngr_t), &conn);
		}

		if (gateway[0] == '1') {
			d_printf("update gateway info\n");
			wan_mngr_ntwk_change_recvd(__wan, conn1);
		}
	}

	
	if (__wan->old_is_update && !__wan->is_update) {
		d_printf("wan info update end, start to do some action\n");
		wan_mngr_update_end_notify(__wan);
	}
	
	__wan->old_is_update = 0;
	
	
	return 0;
}

static WAN_CONFIG_TYPE wan_mngr_get_config_type(const char *type)
{
    if (strstr(type, "ipoe") || strstr(type, "IPOE") || strstr(type, "IPoE"))
        return TYPE_IPOE;

    return TYPE_PPP;
}

CDMG_FUNC(wancfginfo, 1, 0, 0, 0, 0, 0,
			"set/get all the 3g wan configure info.\n"
            "exam: 3g-mngr wancfginfo  --autodial=x --manualdial=0|1 --enable=x \n"
            "\t\t\t --apn=xx --dialnumber=xxx --username=xxx --passwd=xxx\n"
            "\t\t\t --idletime=xxx --dialdelay=xxx --undialdelay=xxx --demand=x \n"
            "\t\t\t --defaultwan=xx --nettype=xx --pingenble=x --pingintf=xxx \n"
            "\t\t\t --pingaddr=xxx --pingperiod=x --pingtimeout=xx --pingtolerance=x  \n"
            "\t\t\t --lanip=x.x.x.x --lanmask=y.y.y.y --ndis=0|1 --type=ppp|ipoe\n")
{	
    char tmp[128] = {0};
    int i = 0;
    
	struct  wan_config oldcfg;

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;
	
	struct  wan_config  *config = &(GET_PRI(mn->wan, __wan_mngr_t)->config);

	memcpy(&oldcfg, config, sizeof(oldcfg));
    while(argv[i] && argv[i][0])
    {
        d_printf("argv[%d] = %s\n", i, argv[i]);
        i++;
    }
	if (MNGR_GET_ARG("enable", tmp)) {
		config->enable = (tmp[0] == '1'?1:0);		
	}	
	if (MNGR_GET_ARG("autodial", tmp)) {
		config->autodial = (tmp[0] == '1'?1:0);
	}	
	if (MNGR_GET_ARG("demand", tmp)) {
		config->demand = (tmp[0] == '1'?1:0);
	}	
	if (MNGR_GET_ARG("pingenble", tmp)) {
		config->pingenble = (tmp[0] == '1'?1:0);
	}
	if (MNGR_GET_ARG("manualdial", tmp)) {
		config->manualdial = (tmp[0] == '1' ? 1 : 0);
	}
	if (config->manualdial) {
		config->autodial = 0;		
	}
    if (MNGR_GET_ARG("ndis", tmp)) {
        config->enblNDIS = (tmp[0] == '1'?1:0);
    }
    if (MNGR_GET_ARG("type", tmp)) {
        config->type = wan_mngr_get_config_type(tmp);
    }
    
#define MNGR_SET_ARG(c, n, v) \
	do{ \
		if (MNGR_GET_ARG((n), (v)))	\
			sprintf((c), "%s", (v));	\
	}while(0)


	MNGR_SET_ARG(config->nettype, "nettype", tmp);
	MNGR_SET_ARG(config->username, "username", tmp);	
	MNGR_SET_ARG(config->passwd, "passwd", tmp);
    MNGR_SET_ARG(config->authmethod, "authmethod", tmp);
	MNGR_SET_ARG(config->idletime, "idletime", tmp);
	MNGR_SET_ARG(config->apn, "apn", tmp);	
	MNGR_SET_ARG(config->dialnumber, "dialnumber", tmp);
	MNGR_SET_ARG(config->dialdelay, "dialdelay", tmp);
	MNGR_SET_ARG(config->undialdelay, "undialdelay", tmp);
	MNGR_SET_ARG(config->defaultwan, "defaultwan", tmp);
	MNGR_SET_ARG(config->pingintf, "pingintf", tmp);
	MNGR_SET_ARG(config->pingaddr, "pingaddr", tmp);
	MNGR_SET_ARG(config->pingperiod, "pingperiod", tmp);
	MNGR_SET_ARG(config->pingtimeout, "pingtimeout", tmp);
	MNGR_SET_ARG(config->pingtolerance, "pingtolerance", tmp);
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	MNGR_SET_ARG(config->lanip, "lanip", tmp);
	MNGR_SET_ARG(config->lanmask, "lanmask", tmp);
#endif
    d_printf("config->type = %d\n", config->type);
    if (config->enblNDIS && (config->type == TYPE_IPOE))
    {
        sprintf(g_usb_dongle_ifname, "%s", IF_IPOE_NAME);    
    }
    else
    {
        sprintf(g_usb_dongle_ifname, "%s", IF_PPP_NAME);
    }
    d_printf("g_usb_dongle_ifname = %s\n", g_usb_dongle_ifname);
	wan_mngr_config_notify(GET_PRI(mn->wan, __wan_mngr_t), &oldcfg);
	
	return 0;
}

/*
***************************************************************************
*					Default GW Control Start
***************************************************************************
*/
static void wan_mngr_ntwk_change_timer(void *date);

/*decide the current defGW anf DNS */
static struct wan_connect *wan_mngr_defgw_select(int is_change)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	int ntwk_permanence = 	__wan->ntwk.ntwk_permanence;
	struct wan_config	*config = &__wan->config;
	struct wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;
	struct wan_connect *real_conn = __wan->ntwk.real_conn;
	struct wan_connect *active_ping = 0;	
	

	d_printf(
		"To select the defGW:real_conn:[%s], ntwk_permenent:%d.\n",
		real_conn ? real_conn->wan_name : "NONE",ntwk_permanence);

	if (ntwk_permanence) {
		d_printf("Switch said not need to change def GW.\n");
		return real_conn;
	}	
	
	if (	!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL) ||
			!wan_mngr_cond_check(WAN_COND_CHECK_MODEM_READY) ||
			!wan_mngr_cond_check(WAN_COND_CHECK_3G_CONN_EXIST)) {
		if (is_change) {
			d_printf("Change ntwk, need get the default gw\n");
			wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
			return conn_dsl_up;
		} else
			return 0;
	}

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	if (is_change && !conn_3g_up && conn_dsl_up) {
		if (__wan->ntwk.ntwk_res_defgw_to_dsl) {
			d_printf("3G down,restore def gw to:[%s]\n",
				conn_dsl_up->wan_name);
			__wan->ntwk.ntwk_res_defgw_to_dsl = 0;
			return conn_dsl_up;
		} else {
			/*
			* scb+ 2012-5-29
			* if more wan up, the 1st change the def GW, 
			* 3g send change def GW to ssk/logic.
			* the 2nd up, then the ssk/logic change 
			* the def GW to the 2nd wan,
			* at that time, the ssk/logic receive the message, 
			* it will change the def GW to
			* the 1st wan.
			*/
			if (__wan->ntwk.want_conn) {
				d_printf("Have send the MNGR_MSG_NTWKCHANG...\n");
				if (strcmp(__wan->ntwk.want_conn->wan_name,
					conn_dsl_up->wan_name) != 0) {
					d_printf("Fix the def GW\n");
					return conn_dsl_up;
				}
			}
			d_printf("3G not up,let upper system to decide the Def GW\n");
			return 0;
		}
	}
	
	if (conn_3g_up && wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)) {
		d_printf("3G up, manual dial, use 3g as the DefGW.\n");
		return conn_3g_up;
	}
	if (conn_3g_up && wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G)) {
		d_printf("3G up, def gw is 3g, use 3g.\n");
		return conn_3g_up;
	}
	if (conn_3g_up && !conn_dsl_up) {
		d_printf("3G up, no dsl up, use 3g.\n");
		return conn_3g_up;
	}
	if (conn_3g_up && conn_dsl_up ) {
		d_printf("3g up, dsl up, check ping check\n");		
		if (!wan_mngr_cond_check(WAN_COND_CHECK_PING_ENBL)) {
			d_printf("Ping not enable,use dsl\n");
			return conn_dsl_up;	
		}
		else
		{
			if (!__wan->ping_check_start) {
				d_printf("Ping check not start,use dsl\n");
				return conn_dsl_up;	
			} else {
				active_ping = wan_mngr_get_wan(__wan, config->active_pingintf, 1);
				if (!active_ping || !conn_is_up(active_ping)) {
					d_printf("Not ping intf or ping wan not up,use dsl\n");
					return conn_dsl_up;
				} else {
					if (active_ping != conn_dsl_up) {
						printf_3g(
							"WAN", 
							"Ping check intf:[%s] is not right.mybe:[%s]\n",
							active_ping->wan_name,
							conn_dsl_up->wan_name);
						return real_conn;
					} else {
						if (__wan->ping_fail) {
							d_printf("Ping fail, use 3g as DefGW\n");
							return conn_3g_up;
						} else if (__wan->ping_success) {
							d_printf("Ping success, use dslas DefGW\n");
							return conn_dsl_up;
						} else {
							printf_3g(
								"WAN", 
								"ERROR can not decide ping success or not\n");
							return real_conn;
						}
					}
				}
			}			
		}	
	}	
	
	return 0;
}

/*this function fix the dns and default gate way for orignal ntwk setting  */
static int wan_mngr_get_ntwk(int argc, char *argv[], char *rbuf, int len)
{
	int is_get_dns = 0;
	char act[16] = {0};
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_connect *conn_df = 	0;
	struct wan_ntwk *ntwk = &__wan->ntwk;
    struct  wan_config *config = &__wan->config;

	CDMG_GET_ARG("act", act);
	
	d_printf(
		"enter act:[%s],wan_conn:[%s]\n", 
		act,
		ntwk->want_conn ? ntwk->want_conn->wan_name : "");
	/*if want to change to 3g wan, and 3g not valid*/
	if (ntwk->want_conn && is_3g_wan(ntwk->want_conn->wan_name) && 
				!wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK)) {
		d_printf("3G not valid, let upper decide def gw\n");
		return 0;
	}	

	if (ntwk->want_conn && conn_is_up(ntwk->want_conn))
		conn_df = ntwk->want_conn;
	else
		conn_df = wan_mngr_defgw_select(0);
	
	d_printf("Def gw is:[%s]\n", conn_df ? conn_df->wan_name : "");
	if (!conn_df)
		return 0;

	if (strstr(act, "dns")) {
		d_printf("is get dns\n");
		is_get_dns = 1;
	}

	if (conn_df && strcmp(config->defaultwan, "dsl")) {
		d_printf("use ntwk %s\n", conn_df->wan_name);
		if (is_get_dns)
			snprintf(rbuf, len, "%s", conn_df->dns_server);
		else
			snprintf(rbuf, len, "%s", conn_df->wan_name);
	}

	d_printf("result is:[%s]\n", rbuf);


	return strlen(rbuf);
	
}
CDMG_SETUP_GET(getwanntwk, wan_mngr_get_ntwk, 0, 0, 
			"get dns default wayway info.\n"
            " exam: 3g-mngr getwanntwk --act=dns|gateway\n");

/*set the */
static void wan_mngr_ntwk_change(__wan_mngr_t *__wan)
{
	char *buf = 0;
	struct wan_ntwk *ntwk = &__wan->ntwk;
	struct  wan_connect  *conn = 0;
	struct  wan_connect  *conn_real = ntwk->real_conn;
	

	d_printf(
		"Check if need change the ntwk, real_conn:[%s]\n",
		conn_real ? conn_real->wan_name : "none");
	conn = wan_mngr_defgw_select(1);
	if (!conn || conn == conn_real) {
		d_printf("Not need change ntwk\n");
#ifdef PC
		if (conn) {
			/*at dial on demand, the dns need changed at PC*/
			d_printf("Check if is need change dns\n");
			wan_mngr_set_dns_for_pc(__wan, conn);
		}
#endif
		return;
	}
	d_printf("Need change ntwk:[%s-->%s]\n",
		conn_real ? conn_real->wan_name : "none",
		conn->wan_name);

	ntwk->want_conn = conn;

	
	/*
	*Some time, the upper manager is too busy,
	*this command can not be received,
	*and need to send several times. 
	*So here set a timer to send this msg for serveral time.
	**/
	d_printf("Set ntwk  timer to re-send ntwk change mgs\n");	

	if (ntwk->ntwk_timer)
		timer_del(ntwk->ntwk_timer);

	ntwk->ntwk_timer = timer_set(CHANGE_NTWK_DELAY, 
			"wan_mngr_ntwk_change_timer",
			wan_mngr_ntwk_change_timer, 
			(void *)ntwk);
	ntwk->ntwk_num = CHANGE_NTWK_TRY_TIME;

	CDMG_MALLOC(MNGR_LEN_CMD+1, buf, {return;});
			
	snprintf(buf, MNGR_LEN_CMD, 
		MNGR_MSG_NTWKCHANG"=%s", 
		conn->wan_name);
	lib3g_send_mobile_chage_msg(buf);
	free(buf);	
#ifdef PC
	wan_mngr_set_ntwk_for_pc(__wan, conn);
#endif	
}

static void wan_mngr_ntwk_set_not_change(int is_set)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_ntwk *ntwk = &__wan->ntwk;
	
	if (is_set && conn_is_up(ntwk->real_conn)) {
		d_printf("Not change def GW\n");
		ntwk->ntwk_permanence = 1;
	}
	else if (!is_set) {
		d_printf("Clear permanence flag\n");
		ntwk->ntwk_permanence = 0;
	} else {
		d_printf("Nothing done!\n");
	}
}

static void wan_mngr_ntwk_change_timer(void *date)
{
	char *buf = 0;
	__wan_mngr_t *__wan = (__wan_mngr_t *)date;
	struct wan_ntwk *ntwk = &__wan->ntwk;
	

	d_printf("Try re-sent ntwk msg\n");
	if (ntwk->want_conn && is_3g_wan(ntwk->want_conn->wan_name) && 
			!wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY)) {
		d_printf("Disable, not need to send ntwk msg\n");
		ntwk->ntwk_num = 0;
		ntwk->ntwk_timer = 0;
		ntwk->want_conn = 0;
		return;	
	}
			
	if (!ntwk->want_conn) {
		d_printf("ntwk is be got!\n");
		ntwk->ntwk_num = 0;
		ntwk->ntwk_timer = 0;
		__wan->need_select_def_gw = 0;
		return;
	}

	/* 
	* scb+ 2012-2-23 some time,
	* the upper manger can not process this message,
	* so send it more time untill the wan become disconnected.
	*/
	if ((!ntwk->want_conn->isdemand && 
					ntwk->want_conn->status != WAN_S_CONNECTED) ||
					(ntwk->want_conn->isdemand && 
					(ntwk->want_conn->status == WAN_S_CONNECTED || 
					ntwk->want_conn->status == WAN_S_CONNECTING))) {
		d_printf("Ntwk [%s] become un-connected, "
			"not need to change the network to it\n", 
			ntwk->want_conn->ifname);
		ntwk->ntwk_num = 0;
		ntwk->ntwk_timer = 0;
		ntwk->want_conn = 0;
		__wan->need_select_def_gw = 0;
		return;
	}
			
	
	ntwk->ntwk_num--;

	if (ntwk->ntwk_num <= 0) {
		printf_3g("", "Ntwk msg is Fail %d times\n",
			CHANGE_NTWK_TRY_TIME);
		ntwk->ntwk_num = 0;
		ntwk->ntwk_timer = 0;
		ntwk->want_conn = 0;
		__wan->need_select_def_gw = 0;
		return;
	}

	d_printf("Re-set ntwk timer\n");
	ntwk->ntwk_timer = timer_set(CHANGE_NTWK_DELAY, 
		"wan_mngr_ntwk_change_timer",
		wan_mngr_ntwk_change_timer, 
		(void *)__wan);
	CDMG_MALLOC(MNGR_LEN_CMD+1, buf, {d_printf("Malloc error\n"); return;});			
	snprintf(buf, MNGR_LEN_CMD, 
		MNGR_MSG_NTWKCHANG"=%s", 
		ntwk->want_conn->wan_name);
	lib3g_send_mobile_chage_msg(buf);
	free(buf);
}

/*
* when the upper system change the defgw,
* means network change is revieved.
* call this func to end the re_change timer
*/
static void wan_mngr_ntwk_change_recvd(__wan_mngr_t *__wan, 
				struct  wan_connect  *def_conn)
{
	struct wan_ntwk *ntwk = &__wan->ntwk;
	
	d_printf("Uper module have rcvd ntwk change msg\n");

	timer_set(0, "wan_mngr_ntwk_change_timer", 0, 0); 
	ntwk->real_conn = def_conn;
	ntwk->ntwk_num 	= 0;
	ntwk->ntwk_timer= 0;
	ntwk->want_conn = 0;

	/*
	 * scb+ 2012-9-24, 
	 * if change def gw to 3g, and exist dsl wan,need 
	 * restore when unplug,so here set a marker 'need_select_def_gw'
	 */
	if (def_conn && is_3g_wan(def_conn->wan_name)) {
		d_printf("Change def gw to 3g,check if is dsl wan\n");
		struct  wan_connect  *conn_3g = 0, *conn_dsl = 0;
		wan_mngr_get_conn_up(&conn_3g, &conn_dsl, 1);
		if (conn_dsl) {
			d_printf("There dsl wan:[%s], later maybe need restore to it,"
				"when unplug\n", conn_dsl->wan_name);
			__wan->need_select_def_gw = 1;
		}
	} else		
		__wan->need_select_def_gw = 0;
}

#ifdef PC
static void wan_mngr_set_dns_for_pc(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn)
{
	/*for PC, no ssk or logic so here setting the route and dns*/
	if (!conn)
		return;

	char dns1[IPV4_ADDR_SIZE+1] = {0};
	char *dns2 = 0;
	char *p = conn->dns_server;	

	int i = 0;

	for(;*p && *p != ',' && i <= IPV4_ADDR_SIZE; p++) 
		dns1[i++] = *p;

	d_printf("dns1:[%s],dns2:[%s]\n", dns1, p);

	if (*p && *p == ',') {
		p++;
		dns2 = p;
	} 		

	d_printf("Set local network:%s,gw:[%s],dns1:[%s],dns2:[%s]\n", 
		conn->wan_name, conn->wan_gw_addr, 
		dns1, dns2);

	lib3g_set_dns(dns1, dns2, 0);
}

static void wan_mngr_set_ntwk_for_pc(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn)
{
	/*for PC, no ssk or logic so here setting the route and dns*/
	if (!conn)
		return;

	wan_mngr_set_dns_for_pc(__wan, conn);

	d_printf("Set default GW:[%s]\n", conn->ifname);
	if (!lib3g_is_def_gw(conn->ifname)) {	
		lib3g_fmt_script("ip route del default");
		sleep(1);
		if (conn->wan_gw_addr[0])
			lib3g_fmt_script("ip route add default via %s dev %s", 
				conn->wan_gw_addr, conn->ifname);
		else
			lib3g_fmt_script("ip route add default  dev %s", conn->ifname);
	
		
		if (conn->wan_gw_addr[0])
			lib3g_fmt_script("ip route add default via %s dev %s", 
				conn->wan_gw_addr, conn->ifname);
		else
			lib3g_fmt_script("ip route add default  dev %s", conn->ifname);
	}

	wan_mngr_ntwk_change_recvd(__wan, conn);
}

void wan_mngr_config_init_for_pc()
{
	CDMG_DO_FUNC(wandefault, "%s", "");
}

/*let the wan sub system running at PC for debug*/
CDMG_FUNC(wandefault, 1, 0, 0, 0, 0, 0,
			"Setting the default wan config for PC.\n"
                    " exam: 3g-mngr wandefault\n")
{
	char local_intf[IFNAME_LEN+1] = {0};
	char local_gw[IPV4_ADDR_SIZE+1] = {0};
	char local_dns1[IPV4_ADDR_SIZE+1] = {0};
	char local_dns2[IPV4_ADDR_SIZE+1] = {0};
	char cmd[120] = {0};
	char *p = 0;
	struct wan_connect *conn1 = 0;

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	__wan_mngr_t *__wan =  GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;

	
	
	d_printf("enter\n");


	/*get local intf*/
	snprintf(cmd, MNGR_LEN(cmd), 	
		"route -n|sed -n /^0\\.0\\.0\\.0/p|awk \'{print $8}\' ");
	d_printf("do %s\n", cmd);
	lib3g_script_and_get_ret(cmd, local_intf);
	if (local_intf[0]) {
		/*get local gw addr*/
		snprintf(cmd, MNGR_LEN(cmd), 	
			"route -n|sed -n /^0\\.0\\.0\\.0/p|awk \'{print $2}\' ");
		d_printf("do %s\n", cmd);
		lib3g_script_and_get_ret(cmd, local_gw);

		/*get local gw dns1*/
		snprintf(cmd, MNGR_LEN(cmd), 	
			"cat /etc/resolv.conf |awk \'/^nameserver/{print $2}\'|sed -n 1p");
		d_printf("do %s\n", cmd);
		lib3g_script_and_get_ret(cmd, local_dns1);

		/*get local gw dns2*/
		snprintf(cmd, MNGR_LEN(cmd), 	
			"cat /etc/resolv.conf |awk \'/^nameserver/{print $2}\'|sed -n 2p");
		d_printf("do %s\n", cmd);
		lib3g_script_and_get_ret(cmd, local_dns2);		
	}
	if ((p = strchr(local_intf, '\n')))
		*p = 0;
	if ((p = strchr(local_gw, '\n')))
		*p = 0;
	if ((p = strchr(local_dns1, '\n')))
		*p = 0;
	if ((p = strchr(local_dns2, '\n')))
		*p = 0;
	printf("local info: intf[%s] gw:[%s] dns1:[%s] dns2:[%s]\n",
			local_intf, local_gw, local_dns1, local_dns2);	

	memset(config, 0, sizeof(struct  wan_config));
	wan_mngr_del_all_wan(GET_PRI(mn->wan, __wan_mngr_t));

	/*set config*/
	config->enable = 1;
	strcpy(config->defaultwan, "3g");
	config->demand = 1;
	strcpy(config->idletime, "60");
	config->pingenble = 0;
	strcpy(config->dialdelay, "3");	
	

	/*add local wan*/
	if (local_intf[0] && (conn1 = malloc(sizeof(struct wan_connect)))) 
	{	
		memset(conn1, 0, sizeof(struct wan_connect));
		snprintf(conn1->ifname, IFNAME_LEN, "%s", local_intf);
		snprintf(conn1->wan_name, WANNAME_LEN,  "%s", local_intf);
		if (local_dns1[1] && local_dns2[0])
			snprintf(conn1->dns_server, DNS_SERVER_SIZE, 
				"%s,%s", local_dns1, local_dns2);
		else if (local_dns1[1] ) 
			snprintf(conn1->dns_server, DNS_SERVER_SIZE, 
				"%s", local_dns1);
		
		snprintf(conn1->wan_gw_addr, IPV4_ADDR_SIZE, 
			"%s", local_gw);
		
		conn1->status = WAN_S_CONNECTED;

		/*add*/	
		d_printf("add %s\n", conn1->wan_name);
		conn1->next = __wan->wans;
		__wan->wans = conn1;

	}

	/*add 3g*/
	if (strcmp(local_intf, g_usb_dongle_ifname) != 0 && 
			(conn1 = malloc(sizeof(struct wan_connect)))) {
		memset(conn1, 0, sizeof(struct wan_connect));
		snprintf(conn1->ifname,IFNAME_LEN,  "%s", g_usb_dongle_ifname);
		snprintf(conn1->wan_name, WANNAME_LEN,  "%s", g_usb_dongle_ifname);
		conn1->status = WAN_S_DISCONNECTED;
		conn1->isdemand = 1;
		
		/*add*/	
		d_printf("add %s\n", conn1->wan_name);
		conn1->next = __wan->wans;
		__wan->wans = conn1;
	}	

	wan_mngr_conn_notify(__wan, conn1);

	return 0;
}
#endif
/*
***************************************************************************
*					Default GW Control End
***************************************************************************
*/








/*
***************************************************************
*     Switch and Wan dial Control section Start
***************************************************************
*/
/*scb+ 2012-3-28 for doing switching the wan delay*/
static void wan_mngr_switch_action_timer(void *data)
{	
	__wan_mngr_t *__wan = (__wan_mngr_t *)data;
	struct  wan_switch_date  *switch_wan =  
				&__wan->dial_param.switch_date;
	struct  wan_connect  *conn_3g = 0;
	struct  wan_connect  *conn = 0;

	
	d_printf("Try to do wan switch\n");
	
	if (switch_wan->action != 1 && switch_wan->action != 2) {
		d_printf("No action\n");
		return;
	}

	if (!switch_wan->wan_name[0] || !wan_mngr_cond_check(
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_NETWORK|
			WAN_COND_CHECK_PIN_READY)) {
		d_printf("Not need to do switch\n");
		return;
	}
	
	/*check the conn if does exist*/
	conn = wan_mngr_get_wan(__wan, switch_wan->wan_name, 0);	
	if (conn) {
        /*check the connect status if does change*/
        if ((conn->status == WAN_S_CONNECTED  ||
                (conn->status == WAN_S_CONNECTING && conn->isdemand)) && 
                switch_wan->is_down ) {
            d_printf("[%s] become connected yet,not need dial 3g.\n", 
                conn->wan_name);
            return; 
        }
        if (conn->status == WAN_S_DISCONNECTED && switch_wan->is_up) {
            d_printf("[%s] become disconnected yet.not need undial 3g.\n",
                conn->wan_name);
            return; 
        }
        /*undial 3g*/
        if (switch_wan->action == SWITCH_ACT_UNDIAL) {
            d_printf("To check if need undial 3g\n");
		conn_3g = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
            if (conn_3g && conn_is_up(conn_3g)){
                d_printf("3G up, change net to [%s],undial 3g.\n",
                    conn->wan_name);
                wan_mngr_ntwk_set_not_change(0);
                wan_mngr_ntwk_change(__wan);
                wan_mngr_dial(0, 0);
                return;
            }
        }
	}
    
	/*dial 3g*/
	if (switch_wan->action == SWITCH_ACT_DIAL) {
		d_printf("To check if need dial 3g\n");
		conn_3g = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
		if (conn_3g && ! conn_is_up(conn_3g)) {
			d_printf("3G not up, dial it.\n");
			wan_mngr_dial(0, 1);
			return;
		}
	}
}


static void wan_mngr_dial_delay_timer(void *date)
{
	struct wan_dial_delay *dial_delay = (struct wan_dial_delay *)date;

	d_printf("Process dial delay timer:is_dial:%d, is_undial:%d\n",
		dial_delay->is_dial, dial_delay->is_undial);

	if (dial_delay->is_dial)
		wan_mngr_dial(0, 1);
	else if (dial_delay->is_undial)
		wan_mngr_dial(0, 0);
}

static void wan_mngr_dial(int delay, int is_dial)
{
	int argc = 0;
	//int dial_delay = delay;
	char *argv[CDMG_ARGS_NUM];
	char *buf = 0;
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_config *config = &__wan->config;
	

	d_printf("%s\n", is_dial?"dial...":"undial...");	
	
	if (!is_dial) {
		if (delay) {
			__wan->dial_delay.is_dial = 0;
			__wan->dial_delay.is_undial = 1;
			d_printf("Wan dial delay,set timer:");
			timer_set(delay, "wan_mngr_dial_delay_timer",
				wan_mngr_dial_delay_timer, 
				(void*)&__wan->dial_delay);
			goto end;
		}
		argc = 1;
		argv[0] = "undial";
		argv[1] = 0;

		d_printf("Wan undial...\n");
		
		wan_mngr_set_3g_link_info(WAN_S_UNDIALING);
		dial_mngr_daemon_undial(argc, argv);
		
		goto end;
	}

	/*scb+ 2011-11-30*/
	d_printf("Cond check--if is only allow manual dial\n");
	if (wan_mngr_cond_check(WAN_COND_CHECK_ALLOW_MANUAL_DIAL)) {
		d_printf("Only allow manual dial\n");
		if (wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)) {
			d_printf(
				"Now is manual dial, "
				"so allow to dial\n");
		} else {
			d_printf(
				"Now is auto dial, "
				"so not allow to dial\n");
			goto end;
		}
	}

	d_printf("Cond check\n");
	if (wan_mngr_cond_check(WAN_COND_CHECK_3G_CONN_UP)||
		!wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK)) {
		d_printf("Cond check fail,not dial\n");
		goto end;
	}
	
	if (delay) {
		__wan->dial_delay.is_dial = 1;
		__wan->dial_delay.is_undial = 0;
		d_printf("Wan dial delay,set timer:\n");
		timer_set(delay, "wan_mngr_dial_delay_timer",
			wan_mngr_dial_delay_timer, 
			(void*)&__wan->dial_delay);
		goto end;
	}
	
	wan_mngr_set_3g_link_info(WAN_S_DIALING);

	d_printf("Wan dial...\n");
	
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	if (wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)) {
		d_printf("Send web event:WEB_EVENT_MANUAL_DIAL\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_MANUAL_DIAL);
	}
#endif		

	CDMG_MALLOC(CDMG_CMD_LINE_LEN, buf, return);

	if (config->idletime[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --idle=%s", config->idletime);

	if (config->apn[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --apn=%s", config->apn);


	if (config->dialnumber[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --number=%s", config->dialnumber);

	if (config->username[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --user=%s", config->username);

	if (config->passwd[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --password=%s", config->passwd);

	if (config->authmethod[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --authmethod=%s", config->authmethod);

	if ( config->nettype[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --net=%s", config->nettype);

	if (config->demand )
		lib3g_fstrncat(buf, MNGR_LEN_CMD, 
			" --demand=%s", (config->demand == 1)?"1":"0");
    if (config->enblNDIS)
        lib3g_fstrncat(buf, MNGR_LEN_CMD, " --ndis=%d", config->enblNDIS);

    lib3g_fstrncat(buf, MNGR_LEN_CMD, " --type=%d", config->type);
#ifdef PC
	lib3g_fstrncat(buf, MNGR_LEN_CMD, 	" -m");
#endif	


	d_printf("dial cmd:[%s]\n", buf);

	cdmg_cmd_to_argv(buf, &argc, argv);
	dial_mngr_daemon_dial(argc, argv);
	
end:
	if (buf)
		free(buf);
}


/*
* set the dial action.
*/
void wan_mngr_dial_set(wan_dial_act_t act, 
				int switch_event_is_up, 
				char *switch_wan_name,
				int is_manual_dial, int dial_delay)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_dial_param *dial_param = &__wan->dial_param;
	struct wan_switch_date *switch_date = 
				&__wan->dial_param.switch_date;
	struct wan_config *config = &__wan->config;

	d_printf("act:%d\n", act);

	if (WAN_DIAL_ACT_INIT == act) {
		memset(dial_param, 0, sizeof(*dial_param));
		wan_mngr_ntwk_set_not_change(0);
		return;
	}
	
	
	if (WAN_DIAL_ACT_SET_DIAL_DELAY == act) {
		d_printf("Modyfy dial delay:%d, not change other dial_param\n", 
			dial_delay);
		if (dial_param->need_check_dial && (
		   		dial_param->act == WAN_DIAL_ACT_DIAL ||
			 	dial_param->act == WAN_DIAL_ACT_SWITCH_DIAL))
		dial_param->delay = dial_delay;
		return;
	}

	dial_param->need_check_dial = 1;
	dial_param->act = act;
	
	if (WAN_DIAL_ACT_WAIT == act) {
		d_printf("Wait upper notify to decide what to do\n");
		return;
	}

	/*Set switch action*/
	if (act == WAN_DIAL_ACT_SWITCH_DIAL ||
			act == WAN_DIAL_ACT_SWITCH_UNDIAL) {			
		d_printf("Set switch.\n");
		if (act == WAN_DIAL_ACT_SWITCH_DIAL) {
			switch_date->action = SWITCH_ACT_DIAL;/*dial*/
			if (config->dialdelay && config->dialdelay[0])
				switch_date->delay = 
					strtoul(config->dialdelay, 0, 10);
			else
				switch_date->delay = SWITCH_ACT_UNDIAL;
		} else {
			switch_date->action = SWITCH_ACT_UNDIAL;
			if (config->undialdelay && config->undialdelay[0])
				switch_date->delay = 
					strtoul(config->undialdelay, 0, 10);
			else
				switch_date->delay = 0;
		}
		if (switch_date->delay && act == WAN_DIAL_ACT_SWITCH_UNDIAL) {
			d_printf("Switch delay, try to set not change the default gw\n");
			wan_mngr_ntwk_set_not_change(1);
		}
		if (switch_event_is_up) {
			switch_date->is_down = 0;
			switch_date->is_up = 1;
		} else {
			switch_date->is_down = 1;
			switch_date->is_up = 0;				
		}
		snprintf(switch_date->wan_name, WANNAME_LEN,
			"%s", switch_wan_name);
	}
	
	if (act == WAN_DIAL_ACT_DIAL || act == WAN_DIAL_ACT_UNDIAL) {
		d_printf("Set %s\n", act == WAN_DIAL_ACT_DIAL ? "dial" : "undial");
		dial_param->delay = dial_delay;
		/*
		* when open web pop function,
		* after manual dial,the upper system will send this cmd again,
		* so we can not clear the dial_manual here.
		*/
		if (is_manual_dial)
			__wan->dial_manual = 1;
	}
}

void wan_mngr_dial_decide()
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct wan_switch_date *switch_date = 
				&__wan->dial_param.switch_date;
	struct wan_dial_param *dial_param = &(__wan->dial_param);

	d_printf("enter:need_check_dial:%d, act:%d\n",
		dial_param->need_check_dial, dial_param->act);

	if (!dial_param->need_check_dial)
		goto end;

	/*dial/undial from upper system*/
	if (dial_param->act == WAN_DIAL_ACT_DIAL ||
			dial_param->act == WAN_DIAL_ACT_UNDIAL) 
	{
		/*Do switch*/
		d_printf("Dial/undial check:%s,%s\n",
			__wan->dial_manual ? "manual" : "auto",
			switch_date->action == SWITCH_ACT_NONE ? 
			"no switch setting" : "exist switch setting");
		if (!__wan->dial_manual && 
				switch_date->action != SWITCH_ACT_NONE) {
			d_printf("Need do switch\n");
			if (switch_date->delay) {
				/*switch delay*/
				d_printf("Switch need delay:[%d]!, switch_date->action = %d\n", switch_date->delay, switch_date->action);
				timer_set(0, "wan_mngr_switch_action_timer", 0, 0);
				timer_set(switch_date->delay,
					"wan_mngr_switch_action_timer",
					wan_mngr_switch_action_timer,
					(void*)__wan);
				goto end;
			} else {
				/*switch right now*/
				d_printf("Do switch right now!\n");
				wan_mngr_switch_action_timer((void *)__wan);
				goto end;
			}
		} else {
			/*dial/undial*/
			d_printf("Do dial/undial %s\n",
				dial_param->delay ? "delay" : "right now");
			/*delete timner*/
			timer_set(0, "wan_mngr_switch_action_timer", 0, 0);
			int is_dial = dial_param->act == WAN_DIAL_ACT_DIAL ? 1 : 0;
			if (is_dial)
				wan_mngr_set_3g_link_info(WAN_S_DIALING);
			else
				wan_mngr_set_3g_link_info(WAN_S_UNDIALING);
			wan_mngr_dial(dial_param->delay, is_dial);
			goto end;
		}
			
	}

	if (dial_param->act == WAN_DIAL_ACT_SWITCH_DIAL ||
			dial_param->act == WAN_DIAL_ACT_SWITCH_UNDIAL) {
		d_printf("Check for switch\n");			
		if (switch_date->action != SWITCH_ACT_NONE) {
			d_printf("Need do switch\n");
			if (switch_date->delay) {
				/*switch delay*/
				d_printf("Switch need delay:[%d], "
					"set timer:wan_mngr_switch_action_timer\n",
					switch_date->delay);
				timer_set(0, "wan_mngr_switch_action_timer", 0, 0);
				timer_set(switch_date->delay,
					"wan_mngr_switch_action_timer",
					wan_mngr_switch_action_timer,
					(void*)__wan);
				goto end;
			} else {
				/*switch right now*/
				d_printf("Do switch right now\n");
				wan_mngr_switch_action_timer((void *)__wan);
				goto end;
			}
		} else
			d_printf("Not need do switch\n");
		goto end;
	}

	if (dial_param->act == WAN_DIAL_ACT_WAIT) {
		d_printf("Need to wait the dial req from upper system\n");
		goto end;
	}

end:
	d_printf("Check default gw,need_select_def_gw=%d\n", 
		__wan->need_select_def_gw);
	if (__wan->need_select_def_gw || wan_mngr_cond_check(
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY))		
		wan_mngr_ntwk_change(__wan);
	else
		d_printf("Not need change def gw.\n");
}

/*manual dial*/
CDMG_FUNC(wandial, 1, 0, 0, 0, 0, 0,  
			"dial using the wan configure infomation.\n"
            " exam: 3g-mngr wandial --act=dial|undial --manual=1|0\n")
{
	char act[8] = {0};
	char manual[4] = {0};
	__wan_mngr_t *__wan = 0; 
	struct  wan_connect  *conn_3g_up = 0, *conn_dsl_up = 0;

	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_DAEMON)
		return 0;

	__wan = GET_PRI(mn->wan, __wan_mngr_t);

	CDMG_GET_ARG("act", act);
	CDMG_GET_ARG("manual", manual);
	
	d_printf("dial action:%s at %s\n", act, manual[0] == '1' ? 
			"manual" : "not_manual");

    if (CDMG_GET_ARG("noat", NULL))
    {
        d_printf("is a wingle, modem no at, set it to ready\n");
        mn->send_hotunplug = 0;
        modem_set_ready(mn->mdm);
    }

	if (!modem_is_ready(mn->mdm)) {
		d_printf("modem not ready\n");
		return 0;
	}

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	__wan->is_link_down = 0;
	
	if (!strcmp(act, "dial")) {
		if (conn_3g_up) {
			d_printf("3g  up, nothing to do\n");
			return 0;
		}

		if (manual[0] == '1') {
			d_printf("manual dial\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 1, 5);
		} else {
			d_printf("Auto dial\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0, 1);
		}
	} else {
		/*
		if (!conn_3g_up) {
			d_printf("3g not up, nothing to done\n");
			return 0;
		}
		*/

		if (manual[0] == '1') {
			d_printf("Manual undail\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 0, 0, 1, 5);
		} else {
			d_printf("Manual dail\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 0, 0, 0, 1);		
		}
	}

	wan_mngr_dial_decide();
	
	return 0;
}
/*
***************************************************************
*     Switch and Wan dial Control section  End
***************************************************************
*/








/*Del all the wan conn struct*/
static void wan_mngr_del_all_wan(__wan_mngr_t *__wan)
{
	struct wan_connect *conn = __wan->wans;
	struct wan_connect *conn1 = 0;
	
	d_printf("del all old conn\n");
	while (conn) {
		conn1 = conn;
		conn = conn->next;
		free(conn1);
	}
	__wan->wans = 0;
}

static char *wan_mngr_conn_status2str(wan_status_t s)
{	
#define Case(__s)	case __s: return #__s
	static char status[4];

	switch(s) {
		Case(WAN_S_DISCONNECTED);
		Case(WAN_S_CONNECTED);
		Case(WAN_S_CONNECTING);
		Case(WAN_S_DISCONNECTING);
		Case(WAN_S_DIALING);
		Case(WAN_S_UNDIALING);
		Case(WAN_S_DIALWAITING);
		Case(WAN_S_INVALID);
		default:break;
	}
	snprintf(status, sizeof(status), "%d", s);

	return status;
#undef Case	
}

static int wan_mngr_info_dump(int argc, char *argv[], char *rbuf, int len)
{
	int item = 1;
	int num = 0;
	int ping_result = 0;
	char ntwk_num[2] = {0};
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_connect *conn = __wan->wans;
	struct  wan_config *config = &__wan->config;

#define WAN_SHOW_LINE					"----------------------------------"
#define WAN_CONTENT_SHOW_FMT			"   %-18s: %s\n"
#define WAN_SHOW_START(i , n)	if (len > strlen(rbuf))	\
									snprintf(rbuf + strlen(rbuf), len - strlen(rbuf), \
										"%d) %s :\n" \
										WAN_SHOW_LINE"\n",\
										(i), (n))
								
#define WAN_SHOW_BR()			if (len > strlen(rbuf))	\
									snprintf(rbuf + strlen(rbuf), len - strlen(rbuf), \
										"\n\n\n\n")
#define WAN_SHOW_END()		if (len > strlen(rbuf))	\
									snprintf(rbuf + strlen(rbuf), len - strlen(rbuf), \
										WAN_SHOW_LINE"\n");

#define WAN_SHOW_PRINTF(args...)	\
		if (len > strlen(rbuf))	\
			snprintf(rbuf + strlen(rbuf), len - strlen(rbuf), args)
		
	memset(rbuf, 0, len);

	WAN_SHOW_START(item++, "WAN Connect");
	for (; conn; conn = conn->next) {
		WAN_SHOW_PRINTF(	" No.%d:\n", num++);
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
				"wan  name",
				conn->wan_name);
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
				"is  3g wan",
				strcmp(conn->wan_name, g_usb_dongle_ifname) == 0?
				"Yes" : "No");		
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT, 
				"wan  alias", 
				conn->wan_alias[0]?conn->wan_alias : "");
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"interfacer name", 
				conn->ifname[0]?conn->ifname : "");
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"interfacer status", 
				wan_mngr_conn_status2str(conn->status));
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"Connect  Demand", 
				conn->isdemand?"Yes":"No");
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"Dns servers", 
				conn->dns_server[0]?
				conn->dns_server:"None");
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"Next Hop", 
				conn->wan_nexthop[0]?
				conn->wan_nexthop:"None");

		/*scb+ 2012-3-30 show conn's priority*/
		char str_prio[4] = {0};
		snprintf(str_prio, sizeof(str_prio), "%d", conn->priority);
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"Priority",
				conn->priority == 0 ? "None" : str_prio);
#ifdef PC
		WAN_SHOW_PRINTF(WAN_CONTENT_SHOW_FMT,
				"default gw addr", 
				conn->wan_gw_addr);
#endif
	}
	WAN_SHOW_END();
	WAN_SHOW_BR();

	
	WAN_SHOW_START(item++, "network info");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"real_conn", 
		__wan->ntwk.real_conn ? __wan->ntwk.real_conn->wan_name : "");
	ntwk_num[0] = '0' + __wan->ntwk.ntwk_num;
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ntwk_num", ntwk_num);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"want_conn", 
		__wan->ntwk.want_conn ? __wan->ntwk.want_conn->wan_name : "");	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ntwk_permanence", 
		__wan->ntwk.ntwk_permanence ? "1" : "0");	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ntwk_res_defgw_to_dsl", 
		__wan->ntwk.ntwk_res_defgw_to_dsl ? "1" : "0");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ntwk has changed", 
		__wan->need_select_def_gw ? "yes" : "no");		

	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"manual dail", 
		__wan->dial_manual ? "yes" : "no");	

	
	struct timer_3g *s_timer = 0, *d_timer = 0;
	char tm_info[120] = {0};
	
	s_timer = timer_get("wan_mngr_switch_action_timer");
	if (s_timer) {
		timer_3g_show(s_timer, tm_info, sizeof(tm_info));
		WAN_SHOW_PRINTF(	
			WAN_CONTENT_SHOW_FMT,
			"switch timer",
			tm_info);			
	}	
	d_timer = timer_get("wan_mngr_dial_delay_timer");
	if (d_timer) {
		timer_3g_show(d_timer, tm_info, sizeof(tm_info));
		WAN_SHOW_PRINTF(	
			WAN_CONTENT_SHOW_FMT,
			"dail timer",
			tm_info);
	}
	

	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"need switch later", 
		__wan->dial_param.switch_date.action != SWITCH_ACT_NONE ? 
		"yes" : "no");
	if (__wan->dial_param.switch_date.action != SWITCH_ACT_NONE) {
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
			"switch wan", __wan->dial_param.switch_date.wan_name);
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
			"switch action", 
			__wan->dial_param.switch_date.action == SWITCH_ACT_DIAL ?
			"dial" : "undial");
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
			"switch event", 
			__wan->dial_param.switch_date.is_up ?
			"up" : "down");
	}
	
	WAN_SHOW_END();
	WAN_SHOW_BR();

	WAN_SHOW_START(item++, "3g wan");		
	WAN_SHOW_PRINTF("%s\n",g_usb_dongle_ifname);
	WAN_SHOW_END();
	WAN_SHOW_BR();

	WAN_SHOW_START(item++, "Config Info");	
	WAN_SHOW_PRINTF("==%s, %s, %s, %s, %s==\n", 
			config->enable?"enable":"disable",
			config->autodial?"autodial":"not autodial",	
			config->demand?"demand":"not demand",
			config->pingenble?"ping enable":"ping disable",
			config->manualdial ? "manualdial" : "not manualdial");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"nettype",config->nettype);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"username",config->username);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"passwd",config->passwd);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"authmethod",config->authmethod);    
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"idletime",config->idletime);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"apn",config->apn);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"dialnumber",config->dialnumber);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"dialdelay",config->dialdelay);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"undialdelay",config->undialdelay);	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"defaultwan",config->defaultwan);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"pingintf",config->pingintf);	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"pingaddr",config->pingaddr);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"pingperiod",config->pingperiod);	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"pingtimeout",config->pingtimeout);	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"pingtolerance",config->pingtolerance);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ndis",config->enblNDIS?"yes":"no");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"prototype",(config->type == TYPE_IPOE)?"IPOE":"PPP");
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"lanip",config->lanip);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"lanmask",config->lanmask);
#endif
	WAN_SHOW_END();
	WAN_SHOW_BR();

	WAN_SHOW_START(item++, " ping info");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ping status", __wan->ping_check_start ? "Start" : "Stop");
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ping interface", __wan->config.active_pingintf);
	WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
		"ping aim", 
		mn->cnn->check_type == CHECK_TYPE_INVALID ? 
		"unknown":  
		(mn->cnn->check_type == CHECK_TYPE_SUCCESS ?
		"For success": "For fail"));
	ping_result =	__wan->ping_fail	? 0 : (__wan->ping_success ? 1 : -1);
	if (ping_result != -1)
		WAN_SHOW_PRINTF(	WAN_CONTENT_SHOW_FMT,
			"ping result ", ping_result ? "success" : "fail");	
	WAN_SHOW_END();

	return strlen(rbuf) + 1;
}
CDMG_SETUP_GET(wandump, wan_mngr_info_dump, 
	0, 0,"display some  wan info\n");



void  wan_init()
{
#ifdef PC
	wan_mngr_config_init_for_pc();
#endif
}

/*
** traval all the conn, and do fn() for each conn
*/
static void wan_mngr_for_each_conn(void (*fn)(struct  wan_connect *conn, 
			void *data), void *data)
{	
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_connect *conn = __wan->wans;

	/*traval all the wan*/
	while(conn) {
		d_printf("for %s status:%s\n", conn->wan_name,
				wan_mngr_conn_status2str(conn->status));
		fn(conn, data);
		conn = conn->next;
	}	
}

/*param for get upping wan*/
struct wan_get_up_data{
	struct  wan_connect  **conn_3g;
	struct  wan_connect  **conn_dsl;
	int dsl_num;
	int curr_dsl_num;
};

/*
* get an up wan conn
*/
static void wan_mngr_get_one_up_wan(struct  wan_connect  *conn, void *data)
{
	struct wan_get_up_data *param = data;

	d_printf("up 3g:%s, %d up dsl, the 1st dsl:%s\n",
		*(param->conn_3g) ? (*(param->conn_3g))->wan_name : "none",
		param->curr_dsl_num,
		param->curr_dsl_num > 0 ? param->conn_dsl[0]->wan_name : "none");
	
	if (conn_is_up(conn)) {
		if (is_3g_wan(conn->wan_name) && param->conn_3g) 
			*(param->conn_3g) = conn;
		else if (param->conn_dsl && param->curr_dsl_num < param->dsl_num) {
			param->conn_dsl[param->curr_dsl_num++]
				= conn;
		}
	}
}

/*  Cmp the priority */
static int wan_mngr_priority_is_higher_than(struct  wan_connect *conn1, 
				struct  wan_connect *conn2)
{
	/*0 is most lowest, except 0, more small more high*/
	if (conn1->priority != 0 && conn1->priority == conn2->priority)
		return 0;
	
	if (conn1->priority == 0 && conn2->priority > 0)
		return -1;
	if (conn2->priority == 0 && conn1->priority > 0)
		return 1;

	/*not point out the priority, the ppp0 is higher than ppp1*/
	if (conn1->priority == 0 && conn2->priority == 0){		
		char *num1 = 0, *num2 = 0;
		for (num1 = conn1->ifname; *num1 && !isdigit(*num1); num1++);
		for (num2 = conn2->ifname; *num2 && !isdigit(*num2); num2++);
		if (num1 && num2) {
			if (strtoul(num1, 0, 10) < strtoul(num2, 0, 10))
				return 1;
			else if (strtoul(num1, 0, 10) == strtoul(num2, 0, 10))
				return 0;
			else
				return -1;
		} else
			return 0;
	}
	
	if (conn1->priority < conn2->priority)
		return 1;
	else
		return -1;
}

/*check if there is wan connection in connecting status*/
static int wan_mngr_check_in_connecting()
{
    __wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
    struct  wan_connect *conn = __wan->wans;

    /*traval all the wan*/
    while(conn) 
    {
        d_printf("for %s status:%s\n", conn->wan_name, wan_mngr_conn_status2str(conn->status));
        /*not 3g, and in connecting status*/
        if(!is_3g_wan(conn->wan_name) && conn->status == WAN_S_CONNECTING)
        {
            return 1;
        }

        conn = conn->next;
    }	

    return 0;
}

/*
** get the up wan conn
*/
static void wan_mngr_get_conn_up(struct  wan_connect  **conn_3g, 
			struct  wan_connect  **conn_dsl, int dsl_num)
{
#define DSL_NUM 20
	int i, j;
	struct  wan_connect  *conn_tmp = 0;
	struct  wan_connect  *conn_dsls[DSL_NUM] = {0};
	struct wan_get_up_data wan_get_up_param;

	wan_get_up_param.curr_dsl_num	= 0;
	wan_get_up_param.dsl_num 	= DSL_NUM;
	wan_get_up_param.conn_dsl 	= conn_dsls;
	wan_get_up_param.conn_3g 	= conn_3g;

	d_printf("enter\n");
	
	if (wan_get_up_param.conn_3g)
		*(wan_get_up_param.conn_3g) 	= 0;

	/*traval the wan*/
	wan_mngr_for_each_conn(wan_mngr_get_one_up_wan, 
			(void *)&wan_get_up_param);
	
	/*scb+ 2012-3-30 for sort the conn by priority*/
	d_printf("Sort conns by priority.total dsl wan num is [%d]\n",
		wan_get_up_param.curr_dsl_num);
	for (i = 0; i < wan_get_up_param.curr_dsl_num - 1; i++) {
		for (j = i + 1; j < wan_get_up_param.curr_dsl_num; j++) {
			/*if j is more higher than i,changed them*/
			if (wan_mngr_priority_is_higher_than(conn_dsls[j], 
					conn_dsls[i]) > 0) {
				conn_tmp = conn_dsls[i];
				conn_dsls[i] = conn_dsls[j];
				conn_dsls[j] = conn_tmp;
			}
		}
	}

	if (conn_dsl) {
		int num = dsl_num > wan_get_up_param.curr_dsl_num ? 
						wan_get_up_param.curr_dsl_num : dsl_num;
		for (i = 0; i < num; i++)
			conn_dsl[i] = conn_dsls[i];
	}
	
	d_printf("3g wan:%s, the 1st dsl wan:%s\n",
		(conn_3g && *conn_3g) ?  (*conn_3g)->wan_name : "none",
		(wan_get_up_param.conn_dsl && wan_get_up_param.conn_dsl[0])? 
		wan_get_up_param.conn_dsl[0]->wan_name : "none");
}

/*
* after a wan  became connected, to check 
* if need to down the other type wan , 
* and if need o change the dns and default gateway.
*/
static void wan_mngr_connect_up(__wan_mngr_t *__wan, 
	struct  wan_connect  *oldconn)
{
	struct  wan_connect  *conn_3g = 0, *conn_dsl = 0;
	struct  wan_connect  *conn = wan_mngr_get_wan(__wan, 
								oldconn->wan_name, 0);

	/*Check if need change default gateway*/
	d_printf("Up:[%s]. Check if need change default gateway\n",
		conn->wan_name);	

	/*scb+ 2012-3-29 delete dial delay timer*/
	timer_del_by_token("wan_mngr_switch_action_timer");	
	
	/*check if need undial 3g*/
	d_printf("Check if need undial 3g\n");
	wan_mngr_get_conn_up(&conn_3g, &conn_dsl, 1);	
	if (is_3g_wan(conn->wan_name) &&  conn_dsl)
	{
		/*3g up*/		
		d_printf("3g become up, dsl  also up\n");
		if (	!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL) ||
				(!wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) &&
			 	 !wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)&&
			 	 !(__wan->ping_check_start && __wan->ping_fail))) {
			d_printf(
				"default wan is not 3g and not manual dial, "
				"not ping check fail,need to let 3g down\n");
			if (!__wan->is_link_down) {
				wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 
					0, conn->wan_name, 0, 0); 
			} else
				d_printf("Link down,dail again, let 3g up\n");
		}
		__wan->is_link_down = 0;
	} 
	else if (!is_3g_wan(conn->wan_name) && conn_3g) 
	{
		d_printf("dsl up, 3g also up\n");
		if (	!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL) ||
				(!wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) &&
			 	 !wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL) &&
			 	 !(__wan->ping_check_start && __wan->ping_fail))) 
		{
			/*set switch to undial 3g, later*/
			d_printf(
				"Def is not 3g, not manual dial, "
				"not ping fial,need undial\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_SWITCH_UNDIAL, 
				1, conn->wan_name, 0, 0);
		}
	}
	/* BEGIN: Added by zhoumingming, 2014/10/13   PN:86627 */
	else if (!is_3g_wan(conn->wan_name) && conn_dsl && !conn_3g)
	{
		struct  wan_connect  *conn_3g_dialing = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
		if(conn_is_dialing(conn_3g_dialing)) {
			d_printf("3g is dialing, dsl up\n");
			if (	!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL) ||
					(!wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) &&
			 		 !wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)&&
			 		 !(__wan->ping_check_start && __wan->ping_fail))) {
				d_printf(
					"default wan is not 3g and not manual dial, "
					"not ping check fail,need to let 3g down\n");
                
				wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 
					0, g_usb_dongle_ifname, 0, 0); 
			}
		} 
	}
	/* END:   Added by zhoumingming, 2014/10/13   PN:86627 */
    
	d_printf("end\n");
}	

static void wan_mngr_connect_down(__wan_mngr_t *__wan, 
			struct  wan_connect  *oldconn)
{		
	struct  wan_connect  *conn_3g_up = 0, *conn_dsl_up = 0;
	struct  wan_connect  *conn = wan_mngr_get_wan(__wan, 
				oldconn->wan_name, 0);

	d_printf("Down:[%s]. Check if need change default gateway\n",
			conn->wan_name);

	/*scb+ 2012-3-29 delete dial delay timer*/
	timer_del_by_token("wan_mngr_switch_action_timer");

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	if (is_3g_wan(conn->wan_name)) {
		/*3g down*/
		d_printf("Clear manual dial flag\n");
		__wan->dial_manual = 0;
	}
	else 
	{
		/*dsl down*/
		if (conn_dsl_up) {
			/*there is other dsl*/
			if (wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G)) {
				d_printf(
					"there other dsl up, but default is 3g,"
					"Set switch to dial 3g later\n");
				/*set  switch to dial 3g, later*/
				wan_mngr_dial_set(WAN_DIAL_ACT_SWITCH_DIAL, 0,
					conn->wan_name, 0, 0);
			} else {
				d_printf("exist other dsl up, not neet to dial 3g\n");
			}
		} else {
			/*there is not other dsl*/
			if (!conn_3g_up){
				d_printf("No dsl up,set switch to dial 3g later\n");
				/*set  switch to dial 3g, later*/
				wan_mngr_dial_set(WAN_DIAL_ACT_SWITCH_DIAL, 0,
					conn->wan_name, 0, 0);
			} else
				d_printf("3G up, nothing done\n");
		}
	}
}

static void wan_mngr_connect_status_change(__wan_mngr_t *__wan, 
			struct  wan_connect  *conn)
{
	struct  wan_connect *newconn = wan_mngr_get_wan(__wan, 
					conn->wan_name, 0);

	d_printf("enter\n");

	if (!newconn)
		return;

	/*scb+ 2012-6-21*/
	if (conn->status == newconn->status)
		return;

	/*when 3g down, need change default gw */
	if (	is_3g_wan(conn->wan_name) && 
			conn->status != newconn->status && 
			!conn_is_up(newconn)) {
		d_printf("3G down need change def gw later\n");
		__wan->ntwk.ntwk_res_defgw_to_dsl = 1;
	} else
		__wan->ntwk.ntwk_res_defgw_to_dsl = 0;

	if (conn->status != WAN_S_CONNECTED && 
			newconn->status == WAN_S_CONNECTED) {
		wan_mngr_connect_up(__wan, conn);
	} else if (conn->status != WAN_S_DISCONNECTED && 
				newconn->status == WAN_S_DISCONNECTED) {
		wan_mngr_connect_down(__wan, conn);
	} else if (conn->status != WAN_S_CONNECTING && 
			newconn->status == WAN_S_CONNECTING &&	
			conn->isdemand) {
		wan_mngr_connect_up(__wan, conn);	
	}
}

/**************************************************************/
static void wan_mngr_dial_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg)
{
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0; 

	d_printf("enter\n");
	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	if (!conn_3g_up && wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_NETWORK|
			WAN_COND_CHECK_3G_CONN_EXIST) && 
			(wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) || 
			!conn_dsl_up)) {
		d_printf("set dial 3g\n");
		wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0,0);
		return;
	} 

	if (	conn_3g_up &&
			((!wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) && 
				conn_dsl_up) ||
			(!wan_mngr_cond_check(
				WAN_COND_CHECK_3G_ENBL|
				WAN_COND_CHECK_3G_CONN_EXIST)))) {
		d_printf("3g up, need to set undial\n");
		wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 0, 0, 0,0);
		return;
	}
}

static void	wan_mngr_dial_for_update_notify(__wan_mngr_t *__wan)
{
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0; 

	d_printf("enter\n");

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	if (!wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL)) {
		d_printf("3g not enable\n");
		if (conn_3g_up) {
			d_printf("3g not enable, undial 3g\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL,0,0,0,0);
		}

		return;
	}

	if (wan_mngr_cond_check(
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK)) {
		d_printf("Check if need dial 3g\n");
		if (!conn_dsl_up && !conn_3g_up) {
			d_printf("no 3g up, no dsl up, dial 3g\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL,0,0,0,0);
			return;
		}

		if (conn_dsl_up && !conn_3g_up && 
				is_3g_wan(config->defaultwan)) {
			d_printf("no 3g up, dsl up, default is 3g, dial 3g\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL,0,0,0,0);
			return;
		}
	}

	if (conn_dsl_up && conn_3g_up && 
			!is_3g_wan(config->defaultwan)) {
		d_printf("dsl up, 3g up, but default is not 3g, undial 3g\n");
		wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL,0,0,0,0);
		return;
	}

	return ;
}



/****for ip connect check function*/
static void wan_mngr_stop_ip_check()
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	
	if (__wan->ping_check_start)
	{
		CDMG_DO_FUNC(ipconn, "--action=stop");
		__wan->ping_check_start = 0;
	}
}

static void wan_mngr_set_ip_check(int isStart, const char *checktype)
{
	int i;
	char buf[MNGR_LEN_CMD+1] = {0};
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up[9] = {0}; 
	struct  wan_connect *chk_conn = 0;

	/*check if need stop the ping check action*/
	d_printf("Enter, %s, check for:[%s]\n", 
		isStart ? "Start" : "Stop", 
		checktype ? checktype : "");
	if (!isStart || !wan_mngr_cond_check(
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_PING_ENBL|
			WAN_COND_CHECK_3G_CONN_EXIST)) {
		d_printf("Stop ping check\n");
		wan_mngr_stop_ip_check();
		return;	
	}

	if (!config->pingaddr || !config->pingaddr[0]) {
		d_printf("no ip_check_addr\n");
		return;
	}

	wan_mngr_get_conn_up(&conn_3g_up, conn_dsl_up, 8);
	
	if (!conn_dsl_up[0]) 
	{
		d_printf("dsl not up, not to start ip ping check\n");
		wan_mngr_stop_ip_check();
		return;
	}
	
	if (!config->pingintf[0]) 
	{
		/*not point out check intf, check by the first up dsl wan*/		
		d_printf("check by the first up dsl wan:[%s]\n",
			conn_dsl_up[0]->ifname);
		chk_conn = conn_dsl_up[0];
	}
	else
	{
		/*point out check intf, to get the check wan*/
		d_printf(
			"the point out check If:[%s],"
			"to get the coresponding conn\n", 
			config->pingintf);
		for (i = 0; conn_dsl_up[i]; i++) {
			if (!strcmp(conn_dsl_up[i]->ifname, config->pingintf)) {
				d_printf("Find the wan:%s for %s\n", 
					conn_dsl_up[i]->wan_name, 
					config->pingintf);
				chk_conn = conn_dsl_up[i];
				break;
			}
		}
		if (!chk_conn && conn_3g_up && 
				!strcmp(conn_3g_up->ifname, config->pingintf)) {
			d_printf("Find the wan:%s for %s\n", 
				conn_3g_up->wan_name, 
				config->pingintf);		
			chk_conn = conn_3g_up;
		}		
	}

	if (!chk_conn) {
		d_printf("Can not get the check wan\n");
		return;
	}
	snprintf(config->active_pingintf, 
			sizeof(config->active_pingintf), "%s",
			chk_conn->ifname);	

	
	/*combine check command*/
	d_printf("Start ping check\n");
	lib3g_fstrncat(buf, MNGR_LEN_CMD, " --action=start");	
	lib3g_fstrncat(buf, MNGR_LEN_CMD, " --chtype=%s", checktype);	
	lib3g_fstrncat(buf, MNGR_LEN_CMD, " --intf=%s",
			config->active_pingintf);
	lib3g_fstrncat(buf, MNGR_LEN_CMD, " --addr=%s", 
			config->pingaddr);
	if (chk_conn->wan_nexthop[0])
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --nexthop=%s", 
			chk_conn->wan_nexthop);
	if (config->pingperiod && config->pingperiod[0]) 
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --period=%s", 
			config->pingperiod);
	if (config->pingtimeout && config->pingtimeout[0]) 
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --timeout=%s", 
			config->pingtimeout);
	if (config->pingtolerance && config->pingtolerance[0]) 
		lib3g_fstrncat(buf, MNGR_LEN_CMD, " --Tolerance=%s", 
			config->pingtolerance);

	d_printf("ipconn %s\n", buf);
	CDMG_DO_FUNC(ipconn, "%s", buf);

	__wan->ping_check_start = 1;
}

/*
* check if is need change the ping interface.
* if need, restart the ping action.
*/
static void wan_mngr_ping_check_start(struct wan_connect *first_conn, 
				const char *check_type)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;
	struct wan_connect	*chk_conn = 0;

	if (!__wan->ping_check_start)
		wan_mngr_set_ip_check(1, check_type);
	else {
		if (config->pingintf)
			chk_conn = wan_mngr_get_wan(__wan, config->pingintf, 1);
		
		/*start, check if is need restart*/
		if (	(!config->pingintf && /*auto decide the check intf*/
				strcmp(config->active_pingintf, first_conn->ifname)) ||
				(config->pingintf && chk_conn && /*point out the check intf*/
				strcmp(config->active_pingintf, config->pingintf) != 0)) {
			d_printf("the check wan is not the first wan, need change\n");
			wan_mngr_set_ip_check(0, "");
			wan_mngr_set_ip_check(1, check_type);
		}
	}
}

/*called when ping status changed*/
void wan_mngr_ping_status_change(int is_success)
{
	struct  wan_connect *conn_3g_up = 0;
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);

	wan_mngr_get_conn_up(&conn_3g_up, 0, 0);

	wan_mngr_dial_set(WAN_DIAL_ACT_INIT, 0, 0, 0,0);

	if (is_success) {
		d_printf("ping success\n");
		__wan->ping_fail = 0;
		__wan->ping_success = 1;
		wan_mngr_set_ip_check(1, CONN_CHECK_FOR_FAIL);
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB			
		wan_mngr_check_web_rule(PIN_RULE_ENVENT_PING_SUCCESS);
#endif
		if (conn_3g_up) {
			d_printf("ping success, undial 3g\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL, 0, 0, 0,0);
		}
	} else {
		d_printf("ping fail\n");
		__wan->ping_fail = 1;
		__wan->ping_success = 0;		
		wan_mngr_set_ip_check(1, CONN_CHECK_FOR_SUCCESS);
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB			
		wan_mngr_check_web_rule(PIN_RULE_ENVENT_PING_FAILSE);
#endif
		if (!conn_3g_up) {
			d_printf("ping fail, dial 3g\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0,0);
		}
	}

	wan_mngr_dial_decide();
}

static void wan_mngr_ping_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *old_conn)
{
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *new_conn	= wan_mngr_get_wan(
				__wan, old_conn->wan_name, 0);
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;	

	d_printf("enter\n");
	if (!config->pingenble) {
		d_printf("ping not enable\n");
		if (__wan->ping_check_start) {
			d_printf("stop ping check\n");
			wan_mngr_set_ip_check(0, "");
		}
		return;
	}

    if (!new_conn)
    {
        d_printf("no 3g config, do nothing\n");
        return;
    }
	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
	if (!conn_dsl_up) {
		d_printf("no dsl, stop ip ping check\n");
		wan_mngr_set_ip_check(0, "");
		return;
	}

	/*scb+ 2012-6-9 when ping checing for sucess,3g down,stop check.*/
	if (is_3g_wan(old_conn->wan_name) &&  
			conn_is_up(old_conn) && !conn_3g_up) {
		d_printf("3G become disconnect, stop ping check\n");
		if (__wan->ping_check_start)
			wan_mngr_set_ip_check(0, "");
		return;
	}

	if (!conn_3g_up) {
		d_printf("dsl up, no 3g,try to start the ping\n");
		/*scb+ 2012-6-20, if the wan priority change, restart ping*/
		if (new_conn->priority != old_conn->priority) {
			d_printf("Proirity change rstart pingcheck:[%d->%d] for [%s]\n",
				old_conn->priority, new_conn->priority,
				old_conn->wan_name);
			wan_mngr_set_ip_check(0, "");
		}		
		wan_mngr_ping_check_start(conn_dsl_up, CONN_CHECK_FOR_FAIL);
		return;
	}

	if (!is_3g_wan(config->defaultwan)) {
		d_printf("dsl up,3g up,default is not 3g,"
			"try to start ping action\n");

		/*scb+ 2012-6-20, if the wan priority change, restart ping*/
		if (new_conn->priority != old_conn->priority) {
			d_printf("Proirity change rstart pingcheck:[%d->%d] for [%s]\n",
				old_conn->priority, new_conn->priority,
				old_conn->wan_name);
			wan_mngr_set_ip_check(0, "");
		}
		wan_mngr_ping_check_start(conn_dsl_up, CONN_CHECK_FOR_FAIL);
	} else {
		if (__wan->ping_check_start) {
			d_printf(
				"dsl up, 3g up, default is 3g,"
				" try to stop ip ping!\n");
			wan_mngr_set_ip_check(0, "");
		}
	}
}

static void wan_mngr_ping_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg)
{
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;

	d_printf("enter\n");
	if (!config->pingenble) {
		if (__wan->ping_check_start)
			wan_mngr_set_ip_check(0, "");
		return;
	}

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
	if (!conn_dsl_up || (conn_3g_up && is_3g_wan(config->defaultwan)))
		return;

	if (!config->pingaddr[0]) {
		d_printf("No ping check address, using %s\n",
			PING_CHECK_DEFAULT_ADDR);
		strcpy(config->pingaddr, PING_CHECK_DEFAULT_ADDR);
	}		

	d_printf("ping enable, have dsl wan, try to start ping check\n");
	wan_mngr_ping_check_start(conn_dsl_up, CONN_CHECK_FOR_FAIL);
}

static void	wan_mngr_ping_for_update_notify(__wan_mngr_t *__wan)
{
	return;
}

void wan_mngr_ping_for_hotplug_notify(int is_hotplug)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;
	
	if (is_hotplug) {		
		if (!strcmp(mn->htplug_msg, "ready") || 
				!strcmp(mn->htplug_msg, "pinready") ) {
			d_printf("3g dongle is ready, check if need to start ip check\n");
			if (config->pingenble) {
				wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
				if (conn_dsl_up) {
					if (!is_3g_wan(config->defaultwan)) {
						d_printf("3g ready, dsl up, default wan not 3g,"
								" start ping check\n");
						wan_mngr_ping_check_start(conn_dsl_up, 
							CONN_CHECK_FOR_FAIL);
					}
				}
			}
		}
		return;
	}

	if (!__wan->ping_check_start) 
		return;

	d_printf("stop ping check\n");
	wan_mngr_set_ip_check(0, "");
}

#ifdef SUPPORT_IP_CONNECT_CHECK
void wan_mngr_ping_for_undial_notify(void)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;
			
	d_printf("3g dongle is undial, check if need to start ip check\n");
	if (config->pingenble) {
		wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
		if (conn_dsl_up) {
			if (!is_3g_wan(config->defaultwan)) {
				d_printf("dsl up, default wan not 3g,"
						" start ping check\n");
                if (!__wan->ping_check_start)
                    wan_mngr_set_ip_check(1, CONN_CHECK_FOR_FAIL);
                else {
                    d_printf("start new ping check\n");
                    wan_mngr_set_ip_check(0, "");
                    wan_mngr_set_ip_check(1, CONN_CHECK_FOR_FAIL);
                }
            }
	    }
    }
}
#endif
static void wan_mngr_timer_for_ping(void *data)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_connect *conn_3g = wan_mngr_get_wan(__wan,
				g_usb_dongle_ifname, 0);

	
	d_printf("Try to ping t ostart dial\n");

	if (conn_3g && conn_3g->status == WAN_S_CONNECTING &&
			__wan->config.demand)
	{
		d_printf("Fork a sub task to ping\n");
		if (fork_3g() == 0) {
			CDMG_DO_FUNC(ping, "%s", " --addr=8.8.8.8");
			exit(0);
		}
	}
}

void wan_mngr_dial_for_hotplug_notify(int is_hotplug)
{
	int need_dial = 0;
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;

	d_printf("Enter\n");
	
	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
	
	if (!is_hotplug) {
		if (conn_3g_up)
			wan_mngr_dial_set(WAN_DIAL_ACT_UNDIAL,0,0,0,0);
	} else {
		if (wan_mngr_cond_check(
				WAN_COND_CHECK_3G_ENBL|
				WAN_COND_CHECK_3G_CONN_EXIST|
				WAN_COND_CHECK_MODEM_READY|
				WAN_COND_CHECK_PIN_READY|
				WAN_COND_CHECK_NETWORK)) {
			if (conn_dsl_up && 
					wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G)) {
				d_printf("3g hotplug, dsl up,but default is 3g, dial 3g\n");
				need_dial = 1;
				if (!strncmp(mn->htplug_msg, "pinready", HTPLUG_MSG_SIZE))
				{
					d_printf("pinready means the user enter the pin code, "
							"So need to connect later\n");
					if (config->demand) {
						d_printf(
							"We need to set a timer"
							" to ping to force to dial\n");
						timer_del_by_token("wan_mngr_timer_for_ping");
						timer_set(5, 
							"wan_mngr_timer_for_ping", 
							wan_mngr_timer_for_ping, 0);
					}
				}				
			} else if (!conn_dsl_up && !wan_mngr_check_in_connecting()) {/*û��dsl wan����up������wan�������ڲ��ţ���ʱҲ��Ӧ����3g����*/                                                                             
				d_printf("3g hotplug, no dsl up, dial 3g\n");
				need_dial = 1;
			}
		}

		if (need_dial)
			wan_mngr_dial_set(WAN_DIAL_ACT_DIAL,0,0,0,0);
	}	
}

static void wan_mngr_dialing_timeout(void *data)
{
	struct wan_connect *conn_3g = (struct wan_connect *)data;

	d_printf("enter:[%s]\n", wan_mngr_conn_status2str(conn_3g->status));

	/*this condition will be process at other place*/
	if (conn_3g->status != WAN_S_DIALING &&
			conn_3g->status != WAN_S_UNDIALING)
		return;

	CDMG_SEND_MSG(dialfail, "%s", "");
}

static void wan_mngr_dial_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *old_conn)
{
	struct wan_connect *wan_3g 	= wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
	//struct wan_connect *newconn = wan_mngr_get_wan(__wan, old_conn->wan_name, 0);
	struct wan_config  *config 	= &__wan->config;
	struct wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;	

	d_printf("enter\n");

	/*scb+ 2012-6-21*/
	//if (newconn && old_conn->status == newconn->status)
	//	return;	
	
	if ((old_conn->action == WAN_EDIT) && !strcmp(old_conn->wan_name, 
			g_usb_dongle_ifname) && wan_3g) {
		/*3g conn status changed*/	
		d_printf("3g conn status changed\n");
		if (wan_3g->status == WAN_S_UNDIALING && 
				old_conn->status != WAN_S_UNDIALING) {
			d_printf("set undial_flag to 0, not let dial again \n");
			mn->dial->undial_flag = 0;	
			dial_mngr_del_timers();
		}
		if ((wan_3g->status == WAN_S_DIALING && 
					old_conn->status != WAN_S_DIALING) || 
			(wan_3g->status == WAN_S_UNDIALING && 
					old_conn->status != WAN_S_UNDIALING)){
			d_printf(
				"become dialing, del timers and set timer:"
				"wan_mngr_dialing_timeout\n");
			dial_mngr_del_timers();
			
			/*delete the old*/
			timer_set(0, "wan_mngr_dialing_timeout", 0, 0);

            d_printf("config->enblNDIS = %d, config->type = %d\n", config->enblNDIS, config->type);
            if (config->enblNDIS && (config->type == TYPE_IPOE))
               timer_set(30,"wan_mngr_dialing_timeout", 
				    wan_mngr_dialing_timeout,
				    (void *)wan_3g);
            else 
			    timer_set(90,"wan_mngr_dialing_timeout", 
				    wan_mngr_dialing_timeout, 
				    (void *)wan_3g);

		}
		if (	wan_3g->status != old_conn->status && 
				wan_3g->status != WAN_S_UNDIALING && 
				wan_3g->status != WAN_S_DIALING) {
			d_printf(
				"3G not in dialing/undialing status,"
				"delete dialing timer\n");
			timer_set(0, "wan_mngr_dialing_timeout", 0, 0);	
		}
	}
	
	if ((old_conn->action == WAN_DEL) && strcmp(old_conn->wan_name, g_usb_dongle_ifname) ) {
		d_printf("dsl conn del\n");
		if (wan_3g && config->enable) {
			d_printf("check if does need to up 3g\n");
			wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
			if (!conn_3g_up && !conn_dsl_up) {
				d_printf("no dsl up,no 3g up, need to up 3g\n");
				wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0, 0);
			}
		}		
	}

	/*scb+ 2012-4-27, for add 3g*/
	if ((old_conn->action == WAN_ADD) && is_3g_wan(old_conn->wan_name)) {
		d_printf("Add 3g conn ,check if need dial 3g\n");
		if (wan_mngr_cond_check(WAN_COND_CHECK_3G_ENBL)) {
			wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);
			if (wan_mngr_cond_check(WAN_COND_CHECK_DEF_IS_3G) ||
					!conn_dsl_up) {
				d_printf("Need to up 3g\n");
				wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0, 0);
			}
		}		
	}		
}

void wan_mngr_conn_for_hotplug_notify(int is_hotplug)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_connect  *conn_3g = 0;
	//struct wan_ntwk *ntwk = &__wan->ntwk;

	d_printf("ener\n");
	if (!is_hotplug) {
		conn_3g = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
		if (conn_3g) {
			if (conn_3g->status == WAN_S_DIALWAITING || 
					conn_3g->status == WAN_S_UNDIALING) {
				d_printf("hotunplug, change 3g status to disconnected\n");
				wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);
			}
		}
		//ntwk->want_conn = 0;
		//ntwk->ntwk_num	= 0;
	} else
		__wan->need_select_def_gw = 0;
}

static void wan_mngr_conn_for_config_notify(__wan_mngr_t *__wan, 
			struct  wan_config *oldcfg)
{
	struct wan_connect*wan_3g = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
	struct wan_config *config = &__wan->config;

	d_printf("enter\n");
	if (wan_3g) {
		if (wan_3g->isdemand != config->demand) {
			CDMG_DO_FUNC(wanlinkinfo, 
				" --act=set --wan_name=%s  --demand=%d",
				g_usb_dongle_ifname, config->demand); 
		}
	}
}

/**************end ip connect check function *************************/


#ifdef	SUPPORT_ALLWAYS_CONNECTED
/*
* scb+ 2012-6-9 for dail again when linkdown.
* call at 3g-mngr-dial.c
*/
void wan_mngr_linkdown_dial()
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	
	d_printf("Link down, dial again\n");
	__wan->is_link_down = 1;
	wan_mngr_dial(0, 1);
}
#endif


#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
void wan_mngr_set_web_ctl_event(const char *event)
{
	__wan_mngr_t *__wan      	= GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config 	= &__wan->config;

	if (config->lanip[0]) {
		CDMG_DO_FUNC(webctl," --event=%s --lan=%s --lanmsk=%s",
			event, config->lanip, config->lanmask);
	} else
		CDMG_DO_FUNC(webctl, "");
}

static void wan_mngr_set_web_rule()
{
	d_printf("enter\n");
	
	if (!wan_mngr_cond_check(WAN_COND_CHECK_MODEM_READY)) {
		d_printf("no usb modem\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_STOP);
		return;
	}

	if (!wan_mngr_cond_check(WAN_COND_CHECK_PIN_READY)) {
		d_printf("need pin code, send 'NEED_PIN_CODE' "
				"to start state mechine to pop pin cfg page\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_NEED_PIN_CODE);	
		return;
	}

	if (wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL)) {
		d_printf(
			"pin ready, reg ready, manual dial,"
			" set web state machine to "
			"'MANUAL_DIAL'\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_MANUAL_DIAL);
		d_printf("set not dial, let ssk to decide to dial\n");
		wan_mngr_dial_set(WAN_DIAL_ACT_WAIT,0, 0,0,0);
		return;
	}

	d_printf("pin ready,reg ready, send 'READY' "
			"to start state mechine to pop dial req page\n");
	/*
	* Modify backup mechanism, 
	* if 3G pin code is corrert or do not need pin code, 
	* dail immediately 
	*/
	//wan_mngr_set_web_ctl_event(WEB_EVENT_READY);
	d_printf("set not dial, let ssk to decide to dial\n");
	wan_mngr_set_web_ctl_event(WEB_EVENT_MANUAL_DIAL);
	wan_mngr_dial_set(WAN_DIAL_ACT_WAIT,0, 0,0,0);	

	/* Pop up a WEB page, tell user connect to internet by 3G WAN */
	system("echo 1 > /var/needinform3gup");	
}

void wan_mngr_check_web_rule(web_rule_event_t event)
{
	__wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);
	struct  wan_config *config = &__wan->config;		
	struct  wan_connect *conn_3g_up = 0, *conn_dsl_up = 0;

	if (!config->enable)
		return;

	if (!wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0))
		return;

	wan_mngr_get_conn_up(&conn_3g_up, &conn_dsl_up, 1);

	switch(event) {
	case PIN_RULE_EVENT_NEEDPINCODE:		
		if (!conn_dsl_up)
		{
			d_printf("no dsl, need to add page rule\n");
			wan_mngr_set_web_ctl_event(WEB_EVENT_NEED_PIN_CODE);
		}
		break;
	case PIN_RULE_EVENT_READY:
		d_printf("modem ready\n");		
		if (!conn_dsl_up)
		{
			d_printf("no dsl, modem ready, send 'READY' event to "
					"web ctl state mechine to\n"
					" change state to 'READY' to add dial req  page rule\n"
					" and set _wan_3g_info.user_is_accept"
					" to 0 to prohibit dial\n");
         
			/*
			* Modify backup mechanism, 
			* if 3G pin code is corrert or do not need pin code, 
			* dail immediately 
			*/
			//wan_mngr_set_web_ctl_event(WEB_EVENT_READY);
			wan_mngr_set_web_ctl_event(WEB_EVENT_MANUAL_DIAL);
			
			d_printf("Set to wait upper to switch\n");
			wan_mngr_dial_set(WAN_DIAL_ACT_WAIT,0, 0,0,0);
			         
			/* Pop up a WEB page, tell user connect to internet by 3G WAN */
			system("echo 1 > /var/needinform3gup");
		}
		break;
	case 	PIN_RULE_EVENT_PINREADY:	
		d_printf("pin  ready\n");		
		if (!conn_dsl_up)
		{
			d_printf(
				"no dsl, pin code correct, "
				"send 'PINREADY' event to "
				"web ctl state mechine to"
				" change state to 'PIN_READY' \n");
			wan_mngr_set_web_ctl_event(WEB_EVENT_PIN_READY);
			wan_mngr_dial_set(WAN_DIAL_ACT_WAIT, 0, 0, 0, 0);
		}
		break;

	case PIN_RULE_EVENT_DIAL_REQ:
		d_printf(
			"receive dial req, means user allowed "
			"to access Internet by 3G,"
			"and set 'dial_allow' to 1 to allowed dial\n");
		wan_mngr_dial_set(WAN_DIAL_ACT_DIAL, 0, 0, 0, 0);
		break;
	case PIN_RULE_EVENT_DSL_UP:		
		d_printf("dsl up, stop web ctl state mechine\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_STOP);
		break;
	case PIN_RULE_EVENT_DSL_DOWN:		
		d_printf("dsl down check web rule\n");
		if (conn_3g_up || conn_dsl_up)
			d_printf(
				"other dsl up or 3g up, "
				"not need to set web rule\n");
		else 
			wan_mngr_set_web_rule();
		break;
	case PIN_RULE_EVENT_TRY_UP_3G:		
		d_printf("3g try up, check web rule\n");		

		if (conn_3g_up) 
			d_printf("3g up, not need to set web rule\n");
		else
			wan_mngr_set_web_rule();
		break;
	case PIN_RULE_ENVENT_PING_FAILSE:		
		d_printf("ping failse, check web rule\n");
		if (conn_3g_up) {
			d_printf("3g is up, cancel pin rule\n");
			wan_mngr_set_web_ctl_event(WEB_EVENT_STOP);
		} else {
			d_printf("3g is not up, check web rule by modem info\n");
			wan_mngr_set_web_rule();
		}
		break;
	case PIN_RULE_ENVENT_PING_SUCCESS:
		d_printf("ping success, stop web state mechine\n");
		wan_mngr_set_web_ctl_event( WEB_EVENT_STOP);
		break;
	case PIN_RULE_EVENT_USB_UNPLUG:
		d_printf("unplug need to stop web state mechine\n");
		wan_mngr_set_web_ctl_event(WEB_EVENT_STOP);
		break;
	default:
		break;
	}	
}

void wan_mngr_web_rule_for_hotplug_notify(int is_hotplug)
{	
	if (!is_hotplug) {
		wan_mngr_check_web_rule(PIN_RULE_EVENT_USB_UNPLUG);
		return;
	}

	if (!strncmp(mn->htplug_msg, "ready", HTPLUG_MSG_SIZE))
		wan_mngr_check_web_rule(PIN_RULE_EVENT_READY);
	else if (!strncmp(mn->htplug_msg, "pinready", HTPLUG_MSG_SIZE)) {
		d_printf("web check for pinready, not allow dial, let dial later\n");
		wan_mngr_check_web_rule(PIN_RULE_EVENT_PINREADY);
	} else if (!strncmp(mn->htplug_msg, "needpincode", HTPLUG_MSG_SIZE))
		wan_mngr_check_web_rule(PIN_RULE_EVENT_NEEDPINCODE);
}

static void wan_mngr_switch_to_connected_timer(void *data)
{
	
	d_printf("3g demand switch to connected\n");
	
	wan_mngr_set_web_ctl_event(WEB_EVENT_DIAL_SUCCESS);
}

static void wan_mngr_web_for_conn_notify(__wan_mngr_t *__wan, 
			struct  wan_connect  *old_conn)
{
	struct  wan_connect *newconn = wan_mngr_get_wan(__wan, 
					old_conn->wan_name, 0);

	d_printf("%s status change, check web rule\n", old_conn->wan_name);

	if (!newconn)
		return;
	
	d_printf("conn status change, ckeck web rule==%s:%s--->%s\n",
		old_conn->wan_name, 
		wan_mngr_conn_status2str(old_conn->status),
		wan_mngr_conn_status2str(newconn->status));
	
	if (strncmp(old_conn->wan_name, g_usb_dongle_ifname, WANNAME_LEN) != 0) {
		d_printf("dsl changed\n");
		if ((old_conn->status !=WAN_S_CONNECTED && 
				newconn->status == WAN_S_CONNECTED) ||
				((old_conn->status ==WAN_S_DISCONNECTED)  && 
				(newconn->status == WAN_S_CONNECTING && 
				newconn->isdemand))) {
			wan_mngr_check_web_rule(PIN_RULE_EVENT_DSL_UP);
		}
		else if (newconn->status == WAN_S_DISCONNECTED)
			wan_mngr_check_web_rule(PIN_RULE_EVENT_DSL_DOWN);
	} else {
		d_printf("3g changed\n");
		if ((old_conn->action == WAN_EDIT) && 
				newconn->status == WAN_S_DIALING) {
			d_printf("3g become dialing set web rule\n");
			wan_mngr_set_web_ctl_event(WEB_EVENT_DIALING);	
			if (newconn->isdemand) {
				d_printf("3g demand at dialing, set a timer, "
						"later change to connected\n");
				timer_set(3, "wan_mngr_switch_to_connected_timer", 
						wan_mngr_switch_to_connected_timer, 0);
			}
		}
	}	
}

static void	wan_mngr_web_for_update_notify(__wan_mngr_t *__wan)
{
	return;
}
#endif



int wan_show_status(modem_t *mdm, char *rbuf, int rlen)
{
	__wan_mngr_t *__wan = NULL;
	struct  wan_connect *conn;

	if (!rbuf || rlen <= 0 || !mdm)
		return 0;

    __wan = GET_PRI(MN(mdm)->wan, __wan_mngr_t);
    
	/*scb+ 2011-8-26 chech if is enable*/
	if (!__wan->config.enable) {
		d_printf("3g not enable\n");
		memset(rbuf, 0, rlen);
		return 0;
	}
		

	conn = wan_mngr_get_wan(__wan, g_usb_dongle_ifname, 0);
	if (!conn) {
		d_printf("no 3g conn\n");
		memset(rbuf, 0, rlen);
		return 0;
	}

	d_printf("3g wan linkstatus:%s\n", 
		wan_mngr_conn_status2str(conn->status));
	
	switch(conn->status) {
	case WAN_S_DISCONNECTED:
		snprintf(rbuf, rlen, "%s", WAN_3G_DISCONNECTTED);		
		break;
	case WAN_S_CONNECTED:
		snprintf(rbuf, rlen, "%s", WAN_3G_CONNECTTED);
		break;
	case WAN_S_CONNECTING:
		snprintf(rbuf, rlen, "%s", WAN_3G_CONNECTING);		
		break;
	case WAN_S_DIALING:
		snprintf(rbuf, rlen, "%s", WAN_3G_DIALING);		
		break;
	case WAN_S_UNDIALING:
		snprintf(rbuf, rlen, "%s", WAN_3G_UNDIALING);	
		break;
	case WAN_S_DIALWAITING:
		snprintf(rbuf, rlen, "%s", WAN_3G_DIALWAITING);			
		break;
	default:
		snprintf(rbuf, rlen, "%s", WAN_3G_INALID);
		break;	
	}	

	/*show dial on demand*/
	if (!strstr(rbuf, WAN_3G_INALID) && conn->isdemand)
		cdmg_fstrncat(rbuf, rlen, ", %s", WAN_3G_DIAL_ON_DEMAND);
	
	if (strstr(rbuf, WAN_3G_CONNECTING) || strstr(rbuf, WAN_3G_CONNECTTED)) 
	{
		/*is manual dial*/
		if (wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL))
			cdmg_fstrncat(rbuf, rlen, ", %s", WAN_3G_MANUAL_DIAL);

		/*is auto dial*/
		if (!wan_mngr_cond_check(WAN_COND_CHECK_IS_MANUAL_DIAL))
			cdmg_fstrncat(rbuf, rlen, ", %s", WAN_3G_AUTO_DIAL);
	}
	
	return strlen(rbuf)+1;
	
}

struct wan_config *wan_mngr_get_config(void)
{
    __wan_mngr_t *__wan = GET_PRI(mn->wan, __wan_mngr_t);

    return &(__wan->config);    
}

#undef DPRINT
#endif

