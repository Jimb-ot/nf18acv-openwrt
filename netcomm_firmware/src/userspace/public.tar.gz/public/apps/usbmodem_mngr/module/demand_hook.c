/*
 * This is for check if does need dial at ppp demand function
 *
 * Copyright (C) 2012 ChangBan Shen <gdscb@tom.com>
 * Copyright (C) 1990-2012 GongJin Corp.
 *
 * Create by ShenChangBan  2012-7-20
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/netfilter_ipv4/ip_tables.h>
#include <linux/list.h>
#include <net/ip.h>
#include <net/udp.h>
#include <linux/proc_fs.h>
/* backwards compatibility crap. only exists in userspace - HW */
#include <linux/version.h>
#include "demand_hook.h"

#ifndef KERNEL_VERSION
#define KERNEL_VERSION(a,b,c) (((a) << 16) | ((b) << 8) | (c))
#endif
static char *rules = NULL;
static int  debug_level = 0;
static int  is_linkup   = 0;
static char  ifname_demand[IFNAMSIZ]  = {0};
/*after linkdown,must wait some time to dail again*/
static int  dial_delay  = 0;
static long unsigned down_jt = 0;


#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,21)	
#define NF_INET_PRE_ROUTING 	NF_IP_PRE_ROUTING
#define NF_INET_LOCAL_IN 		NF_IP_LOCAL_IN
#define NF_INET_FORWARD 		NF_IP_FORWARD
#define NF_INET_LOCAL_OUT		NF_IP_LOCAL_OUT
#define NF_INET_POST_ROUTING NF_IP_POST_ROUTING
#define NF_INET_NUMHOOKS      NF_IP_NUMHOOKS
#endif

#define	DEMAND_HK_JT_MAX (~0)
#define DEMAND_HK_JT_INIT	(DEMAND_HK_JT_MAX-1)

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("ChangBan Shen <gdscb@tom.com>");
MODULE_DESCRIPTION("Ppp dial on demand check");
module_param(debug_level, int, 0);
module_param(rules, charp, 0444);
MODULE_PARM_DESC(debug_level, "Set the debug level\n");
MODULE_PARM_DESC(rules,
	"Check rules  format:\n"
	"	<-c chains -i iif -o oif -s y|n src/mask "
	"-d y|n|x dst/mask -p protocol "
	"-dp dport -dt duration -tg th_pkg>,<...>,...\n"
);

#define demand_bug(level, fmt, args...) \
	do {\
		if (unlikely(debug_level >= level))	\
			printk(KERN_EMERG"%s():%d " fmt, __FUNCTION__, __LINE__, ##args);\
	}while(0)

#define demand_dlt_jt(n,o)		\
	({	\
		typeof(jiffies) __dlt_jt = 0;\
		if ((n) > (o))	\
			__dlt_jt = (n) - (o);	\
		else	\
			__dlt_jt = (DEMAND_HK_JT_MAX - (o)) + (n);\
		__dlt_jt;	\
	})

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,21)
#define DEMAND_GET_HDR(skb, i, u) \
	do { \
		(i) = (skb)->nh.iph;	\
		(u) = (struct udphdr *)((u8 *)(i) + \
				(((struct iphdr   *)(i))->ihl) * 4);\
	}while(0)
#else
#define DEMAND_GET_HDR(skb, i, u) \
	do { \
		(i) = ip_hdr(skb);	\
		(u) = (struct udphdr *)((skb)->data + \
				(((struct iphdr   *)(i))->ihl) * 4);\
	}while(0)
#endif	
	
#define OUT_PKG(l, skb,info)	\
	do {						\
		if (unlikely(debug_level >= (l) && (skb))) { 	\
			const struct iphdr   *ip = 0;	\
			const struct udphdr  *udp = 0;\
			DEMAND_GET_HDR(skb, ip, udp);\
			printk(KERN_EMERG				\
				info 						\
				"protocol:%s,src:0x%x, dst:0x%x, source port:%u, dest port:%u\n",\
				ip->protocol == IPPROTO_ICMP ? "IPPROTO_ICMP" :	\
				(ip->protocol == IPPROTO_UDP ? "IPPROTO_UDP"  :	\
				(ip->protocol == IPPROTO_TCP ? "IPPROTO_TCP"  : "UNKOWN")),	\
					\
				ntohl(ip->saddr), ntohl(ip->daddr),\
					\
				((ip->protocol == IPPROTO_UDP || ip->protocol == IPPROTO_TCP) ?	\
					ntohs(udp->source) : 0),	\
				((ip->protocol == IPPROTO_UDP || ip->protocol == IPPROTO_TCP) ?	\
					ntohs(udp->dest) : 0));\
			if (ip->protocol == IPPROTO_UDP && udp->dest == htons(53)) {\
				char *__dns = demand_hook_get_dns_name(udp);\
				if (__dns) {\
					char __dns_buf[128] = {0};\
					dns_print_name(__dns_buf, __dns, sizeof(__dns_buf));\
					printk(KERN_EMERG	"dns:[%s]\n", __dns_buf);\
				}\
			}\
		} \
	}while(0)

#define STR_OUT_RULE(s,len,rule,fmt, info...)	\
	do {					\
		char *h = (		\
			rule->hooknum == NF_INET_PRE_ROUTING ? "NF_INET_PRE_ROUTING":\
			rule->hooknum == NF_INET_LOCAL_IN ? "NF_INET_LOCAL_IN" :	\
			rule->hooknum == NF_INET_FORWARD ? "NF_INET_FORWARD" :		\
			rule->hooknum == NF_INET_LOCAL_OUT ? "NF_INET_LOCAL_OUT" :	\
			rule->hooknum == NF_INET_POST_ROUTING ? "NF_INET_POST_ROUTING" :\
			rule->hooknum == NF_INET_NUMHOOKS ? "NF_INET_NUMHOOKS" : "NG");\
		char *p = (\
				rule->protocol == IPPROTO_ICMP ? "IPPROTO_ICMP" :	\
				rule->protocol == IPPROTO_UDP ? "IPPROTO_UDP"  :	\
				rule->protocol == IPPROTO_TCP ? "IPPROTO_TCP"  : "UNKOWN");\
		char __dns[128] = {0};	\
		snprintf((s) + strlen(s), len - strlen(s), \
			fmt 	\
			"<-hook%s -i%s -o%s %s-src%x/%x %s-dst%x/%x "	\
			"%s-p%s %s-dport%d %s \n\t%s-dns%s -duration%lu -th_pkg%d>\n", \
			##info, \
			h,	rule->iif, rule->oif, 		\
			rule->is_snot ? "!" : "", ntohl(rule->src), ntohl(rule->smask),	\
			rule->is_dnot ? "!" : "", ntohl(rule->dst), ntohl(rule->dmask),	\
			rule->is_p_not ? "!" : "", p, /*protocol*/\
			rule->is_dport_not ? "!" : "", ntohs(rule->dport), 	\
			rule->is_drop ?  "-a DROP " : "-a ACCEPT ",/*action*/\
			rule->is_dns_not ? "!" : "", \
			dns_print_name(__dns, rule->dns, sizeof(__dns)), \
			(rule->duration/HZ), rule->th_pkg);		\
	}while(0)
	
#define OUT_RULE(l, rule,fmt, info...)	\
	do {	\
		if (unlikely(debug_level >= (l))) { 	\
			char __buf[128] = {0};\
			STR_OUT_RULE(__buf, sizeof(__buf),rule,fmt,##info);\
			printk("<0>" "%s\n", __buf);\
		}	\
	}while(0)

//#define LOCK_DEBUG

#ifdef LOCK_DEBUG
#define LOCK_BUG(fmt, args...)		\
	do{								\
		demand_bug(0, fmt " (lock is:%d)\n",  			\
			##args, atomic_read(&demand.refcnt));	\
	} while(0)
#else
#define LOCK_BUG(fmt, args...)		
#endif
	
#define	ACESS_LIST_ENTER(not_entry)	\
		if (!demand.rules)	\
			goto not_entry;	\
		atomic_inc(&demand.refcnt);	\
		LOCK_BUG("Lock enter.");	\
		if (!demand.rules) {	\
			atomic_dec(&demand.refcnt);	\
			LOCK_BUG("Lock exit.\n");	\
			goto not_entry;\
		}
				
#define	ACESS_LIST_EXIT() {atomic_dec(&demand.refcnt); LOCK_BUG("Lock exit.");}

struct demand_rule {
	int		hooknum;
	u8		protocol;
	char 	iif[IFNAMSIZ];
	char 	oif[IFNAMSIZ];	
	__be16	dport;
	__be32	src, smask, dst, dmask;
	char	is_snot;
	char	is_dnot;
	char	is_dport_not;
	char	is_p_not;
	char	is_dns_not;
	char 	is_drop;
	char 	*dns;
	
	long unsigned duration;	
	int		th_pkg;
	
	struct list_head list;
	struct list_head pkg_events;	
};


struct  hook_demand {
	struct list_head 	*rules;
	long unsigned 		last_jt;	
	atomic_t			refcnt;
};

static void dns_encode_name(char *name,  char *raw, int len);
static char *dns_print_name(char *name, char *buf, int n_len);

static char *get_arg(char *buf, char *token, char *rbuf, int rlen, int *not)
{
	int i =0;
	int status = 0;
	int is_not = 0;
	char *p = buf;

	for (;*p;p++) {
        switch(status) {
        case 0:/*init*/
            if (*p == '-')
                status = 1;/*token start*/
            if (*p == '!')
                is_not = 1;
            break;
        case 1:
            if (*p == ' ' || !token[i]) {
                    if (!token[i]) {
                        status = 2;/*token is the same*/
                        if (*p != ' ') {
                            status = 3;/*start args*/
                            i = 0;
                            rbuf[i++] = *p;
                        }
                    } else {
                        status = 0; /*token not same, reset */
                        is_not = 0;
                        i = 0;
                    }
            }
            else {
                    /*token cmp*/
                    if (*p != token[i]) {
                        status = 0; /*token not same, reset */
                        is_not = 0;
                        i = 0;
                    } else
                        i++;
            }
            break;
        case 2:/*token is the same*/
            if (*p != ' ') {
                status = 3; /*start args*/
                i = 0;
                rbuf[i++] = *p;
            }
            break;
        case 3:/*start args*/
            if (i >= rlen -1 || *p == ' ') {/*args end*/
                rbuf[i++] = 0;
                *not = is_not;
                return rbuf;
            }
            rbuf[i++] = *p;
            break;
        default:
            return 0;
        }
	}
	if (status == 3) {
        rbuf[i] = 0;
        *not = is_not;
        return rbuf;
	}
	return 0;
}


int arg_get_hook(char *arg, int not, void *data)
{
	int i = 0;
	struct demand_rule *rule = (struct demand_rule *)data;
	struct hook_map{
		char *name;
		unsigned int  hook;
	} hook_map[] = {
		{"NF_INET_PRE_ROUTING", NF_INET_PRE_ROUTING},
		{"NF_INET_LOCAL_IN", NF_INET_LOCAL_IN},
		{"NF_INET_FORWARD", NF_INET_FORWARD},
		{"NF_INET_LOCAL_OUT", NF_INET_LOCAL_OUT},
		{"NF_INET_POST_ROUTING", NF_INET_POST_ROUTING},
		{"NF_INET_NUMHOOKS", NF_INET_NUMHOOKS}
	};	

	for (i = 0; i < sizeof(hook_map)/sizeof(hook_map[0]); i++) {
		if (strcmp(arg, hook_map[i].name) == 0) {
			rule->hooknum = hook_map[i].hook;
			return 0;
		}
	}
	
	demand_bug(0, "No hook [%s]\n", arg);
	return -1;
}

int arg_get_iif(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;
	strncpy(rule->iif, arg, IFNAMSIZ);
	return 0;
}

int  arg_get_oif(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;
	strncpy(rule->oif, arg, IFNAMSIZ);
	return 0;
}

int arg_get_src(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%x/%x", &rule->src, &rule->smask);
	if (not)
		rule->is_snot = 1;
	return 0;
}

int  arg_get_dst(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%x/%x", &rule->dst, &rule->dmask);
	if (not)
		rule->is_dnot = 1;
	return 0;
}

int arg_get_protocol(char *arg, int not, void *data)
{
	int p = 0;
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%d", &p);
	rule->protocol = (u8)p;
	if (not)
		rule->is_p_not = 1;
	return 0;
}

int arg_get_dest_port(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%hi", &rule->dport);
	if (not)
		rule->is_dport_not= 1;
	return 0;
}

int arg_get_dns(char *arg, int not, void *data)
{
	char name[64] = {0};
	char *dns = 0;
	int len = strlen(arg) + 4;
	struct demand_rule *rule = (struct demand_rule *)data;

	demand_bug(0, "arg:%s\n", arg);

	/*kfree at destroy thr rule*/
	if ((dns = kmalloc(len, GFP_KERNEL)) > 0) {	
		memset(dns, 0, len);
		dns_encode_name(dns, arg, len-1);
		demand_bug(0, "dns:[%s]\n", 
			dns_print_name(name, dns, sizeof(name)-1));
		rule->dns = dns;
		if (not)
			rule->is_dns_not = 1;
		return 0;
	} else
		return -1;
}

int arg_get_act(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	if (strcmp(arg, "DROP") == 0)
		rule->is_drop = 1;
	else if (strcmp(arg, "ACCEPT") == 0)
		rule->is_drop = 0;
	else
		return -1;
	
	return 0;
}

int arg_get_duration(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%lu", &rule->duration);
	rule->duration *= HZ;/*second to jiffers*/
	return 0;
}

int arg_get_th(char *arg, int not, void *data)
{
	struct demand_rule *rule = (struct demand_rule *)data;

	sscanf(arg, "%d", &rule->th_pkg);
	return 0;
}

struct __args_process {
        char token[12];
        int (*proc)(char *arg, int not, void *data);
} args_process [] = {
    {"hook", arg_get_hook},  {"i", arg_get_iif},
	{"o", arg_get_oif}, 	   {"src", arg_get_src},
	{"dst", arg_get_dst},    {"p", arg_get_protocol},
	{"dport", arg_get_dest_port}, {"dns", arg_get_dns},
	{"duration", arg_get_duration}, {"th_pkg", arg_get_th},
    {"a", arg_get_act}, {"j", arg_get_act},
};

int hook_demand_fill_rule(char *buf, struct demand_rule *rule)
{
    int i = 0;
    int not = 0;
    char arg[128] = {0};

    for (;i < sizeof(args_process)/sizeof(args_process[0]);
			i++) {
        not = 0;
        memset(arg, 0, sizeof(arg));
        if (get_arg(buf, args_process[i].token,
				arg, sizeof(arg)-1, &not)) {
			demand_bug(0, "Arg parse: [%s:%s]\n", 
				args_process[i].token, arg);
			if (args_process[i].proc(arg, not, (void *)rule) != 0) {
				demand_bug(0, "Arg parse error: [%s:%s]\n", 
					args_process[i].token, arg);
				return -1;
			}
        }
    }

	if (rule->hooknum == -1 || (!rule->oif[0] && !rule->iif[0])) {
		demand_bug(0, "Rule error\n");
		return -1;
	}
		
	return 0;
}

struct pkg_events {
	long unsigned	jiffies;
	struct list_head list;
};

static struct hook_demand demand = {
		.rules	= 0,
		.last_jt = 0,			
		.refcnt	= ATOMIC_INIT(0),
	};

struct dnshdr {
	__be16	id;
	__be16	flag;
	__be16	QUCount;
	__be16  ANCount;
	__be16	AUCount;
	__be16	ADCount;
	char 	QName[1];
} __attribute__((packed));

static char *dns_print_name(char *name, char *buf, int n_len)
{
	static char null[] = "NULL";	
	int i = 0, j = 0, k = 0, s = 0;
	
	if (!name || !buf)
		return null;
	
	for (i = 0, j = s = buf[0], k = 0;
	        buf[i] != 0 && k < n_len && s > 0;
	        i++) {
	        if (j == s) {
	                j = 0;
	                s = buf[i];
	                snprintf(&name[k], n_len - k, "\\%03d", s);
	                k = strlen(name);
	        } else {
	                j++;
	                name[k++] = buf[i];
	        }
	}
	return name;
}

static void dns_encode_name(char *name,  char *raw, int len)
{
    int i, j, k;
    char *p = raw;
    char buf[128] = {0};

    i = 1;
    j = 0;
    k = 0;
    for (i = 1, j = 0, k = 0;*p && i < sizeof(buf);i++, p++) {
            if (*p == '.') {
                    buf[j] = k;
                    j = i;
                    k = 0;
                    continue;
            }
            buf[i] = *p;
            k++;
    }
    buf[j] = k;

    memset(name, 0, len);
    strncpy(name, buf, len-1);
}

static char *
demand_hook_get_dns_name(const struct udphdr  *udp)
{
	struct dnshdr *dns  = 0;
	const 	__be16 fmsk  = htons(0x001f);


	dns = (struct dnshdr *)((char *)udp + sizeof(*udp));
	
	demand_bug(6, 
		"dns id:0x%04x,flag:0x%04x,qu:0x%04x, an:0x%04x,au:0x%04x,"
		"ad:0x%04x\n", 
		ntohs(dns->id), ntohs(dns->flag), ntohs(dns->QUCount), 
		ntohs(dns->ANCount), ntohs(dns->AUCount), 
		ntohs(dns->ADCount));
	
	/*check if is request*/
	if (fmsk & (dns->flag))
		return 0;
	/*check is there some question*/
	if (ntohs(dns->QUCount) <= 0)
		return 0;
	return dns->QName;
}

static inline int 
demand_dns_check(const struct udphdr  *udp, 
			char 	*name)
{
	char	*p = name;
	char 	*QName 	= 0;


	/*no need check dns*/
	if (!name)
		return 1;

	QName = demand_hook_get_dns_name(udp);
	if (!QName)
		return 1;
	
	
	while(*QName && *p) {
		if (*QName != *p)
			return 0;/*not fit*/
		QName++;
		p++;
	}

	if (*QName == 0 && *p == 0)
		return 1;/*fit*/
	else
		return 0;
}

static inline int demand_check_rule(struct demand_rule *rule, 
					const struct net_device *in,
					const struct net_device *out,
					const struct iphdr   *ip,
					const struct udphdr  *udp)
{
	int is_match;
	int   fit = 0;
	unsigned long  delt_jt = 0;
	struct pkg_events	*last_event = 0;	

#define DK_CHECK(n,m) \
	if (((n) && (m)) || (!(n) && !(m)))	\
		goto end


	if (in  && rule->iif[0] && strcmp(rule->iif,  in->name))
		goto end;
	if (out && rule->oif[0] && strcmp(rule->oif, out->name))
		goto end;

	demand_bug(3, "Interface match\n");

	/*check the src*/
	if (rule->src > 0) {
		is_match = ((rule->src & rule->smask) == ip->saddr);
		
		DK_CHECK(rule->is_snot, is_match);
	}
	demand_bug(3, "Src match\n");

	/*check the dst*/
	if (rule->dst > 0) {
		is_match = ((rule->dst & rule->dmask) == ip->daddr);
		DK_CHECK(rule->is_dnot, is_match);
	}		
	demand_bug(3, "Dst match\n");
	
	/*check protocol*/
	if (rule->protocol) {
		is_match = rule->protocol == ip->protocol;
		DK_CHECK(rule->is_p_not, is_match);
	}
	demand_bug(3, "Protocol match\n");
	
	/*check dst port*/
	if (rule->dport > 0 && 
			((rule->protocol ==  IPPROTO_UDP) || 
			(rule->protocol ==  IPPROTO_TCP))) {	
		is_match = udp->dest == rule->dport;
		DK_CHECK(rule->is_dport_not, is_match);
	}
	demand_bug(3, "Dest port matched.\n");
	
	/*check dns*/
	if (unlikely(ip->protocol == IPPROTO_UDP && 
			udp->dest == htons(53))) {
		is_match = demand_dns_check(udp, rule->dns);
		DK_CHECK(rule->is_dns_not, is_match);
		demand_bug(3, "Dns matched.\n");
	}
	demand_bug(3, "All segment of the package is matched\n");

	if (list_empty(&rule->pkg_events) || rule->is_drop) {
		demand_bug(3, "Fit\n");
		fit = 1;
		goto end;
	}

	/*for double list,the head's prev is the last node of the list*/
	last_event = list_entry(rule->pkg_events.prev, 
					struct pkg_events, list);
	delt_jt = demand_dlt_jt(jiffies, last_event->jiffies);
	if (delt_jt < rule->duration) {
		demand_bug(3, "Fit\n");
		fit = 1;
	} else {
		/*record the package event*/
		last_event->jiffies = jiffies;
		demand_bug(2, "Pkg Count not enough! record the package event:%lu\n", 
				last_event->jiffies/HZ);
		list_move(&last_event->list, &rule->pkg_events);
	}
end:
	return fit;
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,21)
static unsigned int demand_check_hook(unsigned int hook,
	 struct sk_buff **pskb, const struct net_device *in,
	 const struct net_device *out, int (*okfn)(struct sk_buff *))
#else
static unsigned int demand_check_hook(unsigned int hook,
	 struct sk_buff *skb, const struct net_device *in,
	 const struct net_device *out, int (*okfn)(struct sk_buff *))
#endif
{
	int   fit = 0;
	int allow = 0;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,21)	
	struct sk_buff *skb = *pskb;
#endif
	struct demand_rule *rule = 0, *n;
	const struct iphdr   *ip;
	const struct udphdr  *udp;

	/*dial on demand is not set*/
	if (likely(!demand.rules || !out || 
			strcmp(out->name, ifname_demand) != 0))
		return NF_ACCEPT;
	else {
		atomic_inc(&demand.refcnt);
		LOCK_BUG("Lock enter.");
	}

	/*must check again!*/
	if (unlikely(!demand.rules)) {
		atomic_dec(&demand.refcnt);
		LOCK_BUG("Lock exit.");
		return NF_ACCEPT;
	}

	demand_bug(3, 
		"demand_check_hook: "
		"hook<%d>, in_dev<%s>, out_dev:<%s>, is_linkup:%d\n",
		hook, 
		in  ? in->name  : "none", 
		out ? out->name : "none", is_linkup);	
	OUT_PKG(5, skb, "Count a pkg:\n");

	DEMAND_GET_HDR(skb, ip, udp);
	list_for_each_entry_safe(rule, n, demand.rules, list) {
		/*check the interface*/
		OUT_RULE(3, rule, "Check for rule:\n  ");
		if (rule->hooknum != hook)
			continue;
		fit = demand_check_rule(rule, in, out, ip, udp);
		if (rule->is_drop) {
			if (fit) {
				allow = 0;
				break;
			}
		} else if (fit)
			allow = 1;
	}
	atomic_dec(&demand.refcnt);
	LOCK_BUG("Lock exit.");

	if (allow) {
		demand.last_jt = jiffies;
		demand_bug(2, "Package is allowed by the rules,update last_jt:%d\n",
			(int)(demand.last_jt/HZ));
	} else
		demand_bug(2, "Package is not allow.\n");	
	
	if (unlikely(!is_linkup)) {
		demand_bug(2, 
			"Check if need dial:allow:%d,down_jt:%d, dial_delay:%d,now:%d\n",
			allow, (int)(down_jt/HZ), 
			(int)(dial_delay/HZ), (int)(jiffies/HZ));
		if (allow && (!dial_delay || !down_jt ||
				demand_dlt_jt(jiffies, down_jt) > dial_delay)) {
			OUT_PKG(2, skb, "The pkg may cause to dial...\n");
			return NF_ACCEPT;
		}
		OUT_PKG(2, skb, "Link down drop the not allow pkg:\n");
		return NF_DROP;
	} 
	return NF_ACCEPT;
}

static void 
hook_demand_destroy_rule(struct demand_rule	*rule)
{
	struct pkg_events 	*event = 0, *n = 0;
	
	list_for_each_entry_safe(event, n, &rule->pkg_events, list) {
		demand_bug(0, "free event list.\n");
		list_del(&event->list);
		kfree(event);
	}
	demand_bug(0, "free dns buffer.\n");
	if (rule->dns)
		kfree(rule->dns);
	demand_bug(0, "Rmove rule from the list.\n");
	list_del(&rule->list);

	demand_bug(0, "free rule's buffer.\n");
	kfree(rule);
}

static void 
hook_demand_destroy_rules(struct list_head *rules_head)
{
	struct demand_rule	*rule 	= 0, *n 	= 0;
	
	list_for_each_entry_safe(rule, n, rules_head, list) {
		OUT_RULE(0, rule, "%s", "Free :");
		hook_demand_destroy_rule(rule);
	}
}

static void hook_demand_destroy(void)
{
	struct list_head *rule_list = 0;

	demand_bug(0, "Rmove rules\n");

	if (!demand.rules) {
		demand_bug(0, "No rules\n");
		return;
	}

	rule_list = demand.rules;
	demand.rules = 0;/*so, no reader*/	

	/*wait for free*/
	for (; atomic_read(&demand.refcnt);) {
		demand_bug(0, "Wait rules become free\n");
		msleep(500);
	}

	demand_bug(0, "Rule no reader, free them.\n");
	hook_demand_destroy_rules(rule_list);
}

static char  *
hook_demand_get_rule(char *ls, 
	char **start, char **end, char **next)
{	
	char *p = 0;
	enum {
		STATE_INIT,
		STATE_SEE_START,
		STATE_SEE_END,
		STATE_SEE_NEXT,
	} state = STATE_INIT;

	/*
	 * get a rule recorder, the recorder's format is:
	 * <....>,<.....>,...
	 */
	for (p = ls; p && *p; p++) {
		switch (*p) {
			case '<':
				if (state == STATE_INIT) {
					*start = p;
					state   = STATE_SEE_START;
				} else if (state == STATE_SEE_END) {
					state = STATE_SEE_NEXT;
					*next = p;
				}
				break;
			case '>':
				if (state == STATE_SEE_START) {
					*end = p;
					state   = STATE_SEE_END;
				}
				break;
			default:
				break;				
		}
		if (state == STATE_SEE_NEXT)
			break;
	}
	if (state != STATE_SEE_NEXT)
		*next = 0;
	if (state != STATE_SEE_END && state != STATE_SEE_NEXT) {
		*start 	= 0;
		*end	= 0;
	}
	return *start;
}

/*check if is the rule is the same*/
static int 
hook_demand_cmp(struct demand_rule 	*rule1, 
			struct demand_rule *rule2)
{	
	char *dns1 = rule1->dns;
	char *dns2 = rule2->dns;
	int size = (char *)&rule1->dns - (char *)rule1;

	if (memcmp(rule1, rule2, size) != 0)
		return -1;	

	if ((!dns1 && dns2) || (dns1 && !dns2))
		return -1;
	if (dns1 && dns2) {
		for(;*dns1 && *dns2 && *dns1 == *dns2;dns1++,dns2++);
		if (*dns1 || *dns2)
			return -1;
	}

	return 0;		
}

static void 
hook_demand_init_rule(struct demand_rule 	*rule)
{
	memset(rule, 0, sizeof(*rule));
	rule->hooknum  = -1;
	INIT_LIST_HEAD(&rule->pkg_events);
	INIT_LIST_HEAD(&rule->list);	
}

/*create the check rule*/
static int hook_demand_creat_rule(char *rule_str, 
						struct list_head *head)
{
	struct demand_rule 	*rule = 0, *rule1 = 0, *n =0;
	
	if ((rule = kmalloc(sizeof(*rule), GFP_KERNEL)) < 0) {
		demand_bug(0, "malloc error\n");
		return -1;
	}
	hook_demand_init_rule(rule);
	if (hook_demand_fill_rule(rule_str, rule) != 0) {
		demand_bug(0, "Fill rule error\n");
		goto destroy;	
	}

	/*check the rule if is exist*/
	demand_bug(0, "Check the rule if is exist\n");
	list_for_each_entry_safe(rule1, n, head, list) {
		OUT_RULE(0, rule1, "Rule:\n");
		if (hook_demand_cmp(rule, rule1) == 0) {
			demand_bug(0, "Rule exist\n");
			goto destroy;
		}
	}
	
	list_add(&rule->list, head);
	return 0;
	
destroy:
	demand_bug(0, "Create error,destroy\n");
	hook_demand_destroy_rule(rule);
	return -1;	
}

/*create the check rule*/
static int hook_demand_del_rule(char *rule_str, 
				struct list_head *head)
{
	int exist = 0;
	struct demand_rule 	*rule = 0, *rule1 = 0, *n =0;
	
	if ((rule = kmalloc(sizeof(*rule), GFP_KERNEL)) < 0) {
		demand_bug(0, "malloc error\n");
		return -1;
	}
	hook_demand_init_rule(rule);
	if (hook_demand_fill_rule(rule_str, rule) != 0) {
		demand_bug(0, "Can not get the rule from the str:[%s]\n", 
				rule_str);
		hook_demand_destroy_rule(rule);
		return -1;
	}
	/*check the rule if is exist*/
	demand_bug(0, "Check the rule if is exist\n");
	list_for_each_entry_safe(rule1, n, head, list) {
		OUT_RULE(0, rule1, "Rule:\n");
		if (hook_demand_cmp(rule, rule1) == 0) {
			OUT_RULE(0, rule1, "Rule exist,del it:\n");
			exist = 1;
			break;
		}
	}
	hook_demand_destroy_rule(rule);
	if (exist) {
		hook_demand_destroy_rule(rule1);
		return 0;
	} else {
		demand_bug(0, "rule not exist\n");
		return -1;	
	}
}
	
static int hook_demand_init(void)
{
	char 	*buf = 0;
	char 	*start, *end, *next;
	static struct list_head rules_head;

	INIT_LIST_HEAD(&rules_head);

	if (rules && *rules) {
		if ((buf = kmalloc(1024, GFP_KERNEL)) < 0)
			return -1;
		
		memset(buf, 0, 1024);
		strncpy(buf, rules, 1023);

		demand_bug(0, "parse rules:\n%s\n", rules);
		
		for (hook_demand_get_rule(buf, &start, &end, &next);
			end;
			hook_demand_get_rule(next, &start, &end, &next)) {
			*(end + 1) = 0;
			hook_demand_creat_rule(start, &rules_head);
		}

		kfree(buf);
	}

	demand.last_jt = jiffies;
	demand.rules = &rules_head;	
	return 0;
}

#ifdef CONFIG_PROC_FS
ssize_t demand_hook_proc_read(struct file *file,
	char __user *buf, size_t size, loff_t *ppos)
{		
	int i = 0;
	char result[8] = {0};
	char *p = 0, *q = 0;
	ssize_t  len = 0;
	const int buf_len = 1024;
	struct demand_rule *rule = 0, *n = 0;

	demand_bug(6, "last jt:%d, now:%d\n",
		(int)(demand.last_jt/HZ), (int)(jiffies/HZ));
	snprintf(result, sizeof(result), "%d", 
		demand_dlt_jt(jiffies, demand.last_jt)/HZ);
	demand_bug(2, "read idle:%s\n", result);

	if (debug_level) {
		q = kmalloc(buf_len, GFP_KERNEL);
		if (q > 0) {
			memset(q, 0, buf_len);
			snprintf(q, buf_len, 
				"%s\n"
				"rules parameter:\n%s\n"
				DEMAND_HOOK_DEBUG_TOKEN"%d\n"
				DEMAND_HOOK_LINKUP_TOKEN"%d\n"
				DEMAND_HOOK_IFNAME_TOKEN"%s\n"
				DEMAND_HOOK_DIAL_DELAY_TOKEN"%d\n",
				result, rules, 
				debug_level, 
				is_linkup, 
				ifname_demand, (dial_delay/HZ));
			snprintf(q+strlen(q), buf_len-strlen(q),
				"rule:\n");
			ACESS_LIST_ENTER(exit_list);
			list_for_each_entry_safe(rule, n, demand.rules, list)
				STR_OUT_RULE(q, buf_len, rule, "%d: ", i++);
			ACESS_LIST_EXIT();
exit_list:
			p = q;
		} else
			p = result;
	} else
		p = result;
	
	p  += *ppos;
	len = strlen(p);
	len = len > size ? size : len;
	copy_to_user(buf, p, len);
	*ppos += len;

	if (q > 0)
		kfree(q);
	return len;
}

ssize_t demand_hook_proc_write(struct file *file, 
			const char __user *buf, size_t size, loff_t *ppos)
{	
	int old_link = is_linkup;
	int delay = 0;
	char *str = 0;
	char *p = 0; 
	struct demand_rule *rule = 0, *n = 0;
#define IF_DK_EXIST_TOKEN(token)		\
	if ((p = str) && !strncmp(str, token, strlen(token)))		
#define DK_GET_TOKEN(token, fmt, v, act) \
		IF_DK_EXIST_TOKEN(token) {	\
			sscanf(p, token fmt, &(v));\
			{act;};\
		}
#define DK_GET_TOKEN1(token, act) \
		IF_DK_EXIST_TOKEN(token) {	\
			p += strlen(token);\
			{act;};\
		}

	if ((str = kmalloc(size + 1, GFP_KERNEL)) <= 0 )
		return 0;
	memset(str, 0, size + 1);
	
	copy_from_user(str, buf, size);

	DK_GET_TOKEN(DEMAND_HOOK_DEBUG_TOKEN, "%d", debug_level,{});	
	DK_GET_TOKEN(DEMAND_HOOK_IFNAME_TOKEN, "%s", ifname_demand, {});

	/*the unit is second, so need to change it to jiffer*/
	DK_GET_TOKEN(DEMAND_HOOK_DIAL_DELAY_TOKEN, "%d", delay,
		dial_delay = delay * HZ);
	
	/*init the recorder*/
	DK_GET_TOKEN(DEMAND_HOOK_LINKUP_TOKEN, "%d", is_linkup, 
	{	
		if (is_linkup && !old_link)
			down_jt = 0;
		if (!is_linkup && old_link)
			down_jt = jiffies;
		demand.last_jt = jiffies;
	});

	DK_GET_TOKEN1(DEMAND_HOOK_RULE_TOKEN,
	{
		ACESS_LIST_ENTER(end);
		hook_demand_creat_rule(p, demand.rules);
		ACESS_LIST_EXIT();	
	});

	DK_GET_TOKEN1(DEMAND_HOOK_DEL_RULE_TOKEN,
	{
		ACESS_LIST_ENTER(end);
		hook_demand_del_rule(p, demand.rules);
		ACESS_LIST_EXIT();	
	});
	
end:
	kfree(str);
	return size;
}

static const struct file_operations demand_hook_proc_fops = {
	.read		= demand_hook_proc_read,
	.write		= demand_hook_proc_write,
};

#endif

static struct nf_hook_ops demand_hook_ops[] __read_mostly = {
	{
		.hook		= demand_check_hook,
		.owner		= THIS_MODULE,
		.pf			= PF_INET,
		.hooknum	= NF_INET_FORWARD,
		.priority	= NF_IP_PRI_LAST,
	},
	{
		.hook		= demand_check_hook,
		.owner		= THIS_MODULE,
		.pf			= PF_INET,
		.hooknum	= NF_INET_LOCAL_OUT,
		.priority	= NF_IP_PRI_LAST,
	},
	{
		.hook		= demand_check_hook,
		.owner		= THIS_MODULE,
		.pf			= PF_INET,
		.hooknum	= NF_INET_PRE_ROUTING,
		.priority	= NF_IP_PRI_LAST,
	},	
};

static int __init demand_hook_init(void)
{
	int ret = 0;

	demand_bug(0, "Init demand_hook\n");
	
	hook_demand_init();

#ifdef CONFIG_PROC_FS	
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
	proc_create(DEMAND_HOOK_PROC_ID, 
		S_IFREG | S_IRUGO | S_IWUSR, NULL, 
		&demand_hook_proc_fops);
#else
	struct proc_dir_entry *e;

	e = create_proc_entry(DEMAND_HOOK_PROC_ID, 
			S_IFREG | S_IRUGO | S_IWUGO, 
			NULL);
	if (e)
		e->proc_fops = &demand_hook_proc_fops;
#endif	
#endif

	/* Register hooks */
	ret = nf_register_hooks(demand_hook_ops, 
			ARRAY_SIZE(demand_hook_ops));
	if (ret < 0)
		goto error;
		
	return 0;

error:
	hook_demand_destroy();
#ifdef CONFIG_PROC_FS
	remove_proc_entry(DEMAND_HOOK_PROC_ID, NULL);	
#endif

	return 0;
}

static void __exit demand_hook_fini(void)
{
	demand_bug(0, "Start rmove demand_hook...\n");
	nf_unregister_hooks(&demand_hook_ops, 
		ARRAY_SIZE(demand_hook_ops));
#ifdef CONFIG_PROC_FS
	remove_proc_entry(DEMAND_HOOK_PROC_ID, NULL);	
#endif
	hook_demand_destroy();
	demand_bug(0, "Rmoved demand_hook!\n");
}

module_init(demand_hook_init);
module_exit(demand_hook_fini);

