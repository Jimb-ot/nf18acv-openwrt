/*
 *For usb modem
 *scb 2010-7-7
 *
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/tty.h>
#include <linux/tty_flip.h>
#include <linux/usb.h>
#include <linux/usb/serial.h>
#include <linux/proc_fs.h>
#include <linux/version.h>

#include <asm/uaccess.h>

#define DRIVER_AUTHOR "TW scb"
#define DRIVER_DESC "USB  for mobile modem Serial driver"

#define d_printk(format, args...)  \
	printk( "[USB MODEM SERIAL %s:%d] " format, __FUNCTION__, __LINE__, ##args)

#define MAX_ID 512


static struct usb_device_id id_table[MAX_ID];
static struct usb_driver modem_usb_driver;
//MODULE_DEVICE_TABLE(usb, id_table);

#ifdef CONFIG_PROC_FS
#define TOKEN_VID  "idVendor:"
#define TOKEN_PID "idProduct:"

static uint vid = 0;
static uint pid = 0;

ssize_t modem_usb_id_proc_read(struct file *file, 
	char __user *buf, size_t size, loff_t *ppos)
{
	char *__buf = 0;
	char *p = 0;
	int i = 0;
	int j = 0;
	int count = 0;
	int __size = 0;

	for( i = 0; i < MAX_ID; i++) {
		if (id_table[i].match_flags ==  0)
			break;
	}

	__size = i *13 + 80;

	if (!(p = kmalloc(__size, GFP_KERNEL))) {
		d_printk("kmalloc error\n");
		return 0;
	}

	memset(p, 0, __size);	

	__buf = p;
	__buf += sprintf(__buf, "(idVendor,idProduct):\n");

	for (i = 0; id_table[i].match_flags != 0 &&
				i < MAX_ID && __buf + 13 < p + __size; i++) {			
			if (j == 6) {
				__buf += sprintf(__buf, "\n");
				j = 0;
			}
			j++;
			__buf += sprintf(__buf, "(%04x,%04x) ", 
				id_table[i].idVendor, id_table[i].idProduct);
	}

	if (__buf[0])
		__buf += sprintf(__buf, "\n");

	count = __buf - p;	

	if (*ppos > count) {
		kfree(p);
		return 0;
	}

	__buf = p;

	__buf += *ppos;

	count -= *ppos;
	count = count>size?size:count;

	if (copy_to_user(buf, __buf, count)) {
		kfree(p);
		return -EFAULT;
	}
	
	*ppos += count;
	kfree(p);
	return count;	
}

ssize_t modem_usb_id_proc_write(struct file *file, 
			const char __user *buf, size_t size, loff_t *ppos)
{
	/*the format :  idVendor:2345 idProduct:1234,abcd,2234 */
	struct device_driver *driver;
   	char *vid = 0;
	char *pid = 0;
	char *tmp = 0;
	char *pid_p = 0;
	char *pid_q = 0;
	char *vid_p = 0;
	char *vid_q = 0;	
	int ret = 0;
	int i_pid = 0;
	int i_vid = 0;
	int o_i_pid = 0;
	int o_i_vid = 0;
	int i = 0, j = 0;

	memset(&id_table, 0, sizeof(id_table));
	if (!(tmp = kmalloc(size, GFP_KERNEL))) {
		d_printk("kmalloc error\n");
		return 0;
	}
	memset(tmp, 0, size);
	

	if (copy_from_user(tmp, buf, size)) {
		kfree(tmp);
		return -EFAULT;
	}


	vid  = strstr(tmp, TOKEN_VID);
	pid  = strstr(tmp, TOKEN_PID);

	if (vid) {
		vid[0] = 0;
		vid += strlen(TOKEN_VID);
	}

	if (pid) {
		pid[0] = 0;
		pid += strlen(TOKEN_PID);
	}

	for (vid_p = vid, pid_p = pid, i = 0; i < MAX_ID;) {	
		i_vid = 0;
		i_pid = 0;

		if (vid_p && vid_p[0]) {	
			vid_q = strchr(vid_p, ',');
			if (vid_q) {
				*vid_q = 0;
				vid_q++;
			}
			for (;vid_p && vid_p[0] && 
					(*vid_p == ' ' || *vid_p == '\t');
					vid_p++);
			if (vid_p[0])
				i_vid = simple_strtoull(vid_p, 0, 16);	
			vid_p = vid_q;
		}

		if (pid_p && pid_p[0]) {
			pid_q = strchr(pid_p, ',');
			if (pid_q) {
				*pid_q = 0;
				pid_q++;
			}
			for (;pid_p && pid_p[0] && 
					(*pid_p == ' ' || *pid_p == '\t');
					pid_p++);
			i_pid = simple_strtoull(pid_p, 0, 16);		
			pid_p = pid_q;
		}
		if (i_pid || i_vid) {	
			o_i_pid = i_pid == 0 ? o_i_pid : i_pid;
			o_i_vid = i_vid == 0 ? o_i_vid : i_vid;

			for (j = 0; j < i; j++) {
				if (id_table[j].match_flags == USB_DEVICE_ID_MATCH_DEVICE &&
							id_table[j].idVendor == o_i_vid &&
							id_table[j].idProduct== o_i_pid)
						break;
			}

			/*no overlap, add the vid,pid to the id table*/
			if ( j == i) {
				id_table[i].match_flags =  USB_DEVICE_ID_MATCH_DEVICE;
				id_table[i].idVendor = o_i_vid;
				id_table[i].idProduct= o_i_pid;
				/*
				d_printk("Add to id_table[%d].idVendor =%04x,"
					"id_table[%d].idProduct=%04x\n", 
					i, id_table[i].idVendor, i, id_table[i].idProduct);
				*/
				i++;
			}
		}			

		if ((!pid_p || !pid_p[0]) && (!vid_p || !vid_p[0]))
			break;
	}	

	kfree(tmp);

	/*atttach the device to the driver*/	
	driver = &(modem_usb_driver.drvwrap.driver);
	d_printk("Do attach...\n");
	ret = driver_attach(driver);

	return size;
}

static const struct file_operations usb_modem_id_proc_fops = {
	.read		= modem_usb_id_proc_read,
	.write		= modem_usb_id_proc_write,
};

#define  USB_MODEM_ID "usb_modem_id"

#endif

static void modem_usb_resubmit_read_urb(struct usb_serial_port *port, 
				gfp_t mem_flags)
{
	struct urb *urb = port->read_urb;
	struct usb_serial *serial = port->serial;
	int result;

	/* Continue reading from device */
	usb_fill_bulk_urb(urb, serial->dev,
			   usb_rcvbulkpipe(serial->dev,
					port->bulk_in_endpointAddress),
			   urb->transfer_buffer,
			   urb->transfer_buffer_length,
			   ((serial->type->read_bulk_callback) ?
			     serial->type->read_bulk_callback :
			     usb_serial_generic_read_bulk_callback), port);
	result = usb_submit_urb(urb, mem_flags);
	if (result)
		dev_err(&port->dev,
			"%s - failed resubmitting read urb, error %d\n",
							__func__, result);
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,19)	
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
void modem_usb_unthrottle(struct tty_struct *tty)
#else
void modem_usb_unthrottle(struct usb_serial_port *port )
#endif
{
	int was_throttled;
	unsigned long flags;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
	struct usb_serial_port *port = tty->driver_data;
#endif
	


	d_printk("port %d", port->number);

	/* Clear the throttle flags */
	spin_lock_irqsave(&port->lock, flags);
	was_throttled = port->throttled;
	port->throttled = port->throttle_req = 0;
	spin_unlock_irqrestore(&port->lock, flags);

	if (was_throttled) {
		/* Resume reading from device */
		modem_usb_resubmit_read_urb(port, GFP_KERNEL);
	}
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
void modem_usb_throttle(struct tty_struct *tty)
#else
void modem_usb_throttle(struct usb_serial_port *port )
#endif
{
	unsigned long flags;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
	struct usb_serial_port *port = tty->driver_data;
#endif	

	d_printk("port %d", port->number);

	/* Set the throttle request flag. It will be picked up
	 * by usb_serial_generic_read_bulk_callback(). */
	spin_lock_irqsave(&port->lock, flags);
	port->throttle_req = 1;
	spin_unlock_irqrestore(&port->lock, flags);
}
#endif

static void modem_usb_cleanup(struct usb_serial_port *port)
{
	struct usb_serial *serial = port->serial;

	d_printk("port %d", port->number);

	if (serial->dev) {
		/* shutdown any bulk reads that might be going on */
		if (serial->num_bulk_out)
			usb_kill_urb(port->write_urb);
		if (serial->num_bulk_in)
			usb_kill_urb(port->read_urb);
	}
}

static void modem_usb_shutdown(struct usb_serial *serial)
{
	int i;

	d_printk("enter\n");

	/* stop reads and writes on all ports */
	for (i = 0; i < serial->num_ports; ++i)
		modem_usb_cleanup(serial->port[i]);
}

static void modem_usb_disconnect(struct usb_serial *serial)
{
	int i;

	d_printk("%s", __func__);

	/* stop reads and writes on all ports */
	for (i = 0; i < serial->num_ports; ++i)
		modem_usb_cleanup(serial->port[i]);
}

static struct usb_driver modem_usb_driver = {
	.name			= "3g_modem",
	.probe			= usb_serial_probe,
	.disconnect		= usb_serial_disconnect,
	.id_table		= id_table,
	.no_dynamic_id =	1,
};

static struct usb_serial_driver modem_usb_serial_driver = {
	.driver = {
		.owner     = THIS_MODULE,
		.name      = "3g_modem",
	},
	.description         = "3G_USB_modem",
	.id_table            = id_table,
	.num_ports =		1,

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
	.shutdown =		modem_usb_shutdown, 
#elif LINUX_VERSION_CODE == KERNEL_VERSION(2,6,30)
#if KERNEL_EXTRA_VERSION < 9
	.shutdown =		modem_usb_shutdown, 
#endif
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,19)			
	.usb_driver          = &modem_usb_driver,
//	.throttle =		modem_usb_throttle,
//	.unthrottle =	modem_usb_unthrottle,

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,27)	
	.resume =	usb_serial_generic_resume,

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,30)
	.disconnect =		modem_usb_disconnect,
#elif  LINUX_VERSION_CODE == KERNEL_VERSION(2,6,30) && KERNEL_EXTRA_VERSION >= 9
	.disconnect =		modem_usb_disconnect,
#endif

#endif	
#else
	.num_interrupt_in =	NUM_DONT_CARE,
	.num_bulk_in =		NUM_DONT_CARE,
	.num_bulk_out =		NUM_DONT_CARE,		
#endif
};

static struct usb_serial_driver * const modem_usb_serial_drivers[] = {
    &modem_usb_serial_driver, NULL
};

static int __init modem_usb_init(void)
{
	int retval;

	memset(&id_table, 0, sizeof(id_table));
	if (vid != 0 || pid != 0) {
		id_table[0].idVendor = vid;
		id_table[0].idProduct= pid;
		id_table[0].match_flags = USB_DEVICE_ID_MATCH_DEVICE;
	}

#ifdef CONFIG_PROC_FS	
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)	
	proc_create(USB_MODEM_ID, 
		S_IFREG | S_IRUGO | S_IWUSR, NULL, 
		&usb_modem_id_proc_fops);
#else
	struct proc_dir_entry *e;

	e = create_proc_entry(USB_MODEM_ID, 
			S_IFREG | S_IRUGO | S_IWUSR, 
			NULL);
	if (e)
		e->proc_fops = &usb_modem_id_proc_fops;
#endif	
#endif
	/*
	retval = usb_serial_register(&modem_usb_serial_driver);
	if (retval)
		return retval;

	retval = usb_register(&modem_usb_driver);
	*/
    retval = usb_serial_register_drivers(&modem_usb_driver, modem_usb_serial_drivers);	
	if (retval) {
#ifdef CONFIG_PROC_FS			
		remove_proc_entry(USB_MODEM_ID, NULL);	
#endif
		//usb_serial_deregister(&modem_usb_serial_driver);
		return retval;
	}

	return 0;
}

static void __exit modem_usb_exit(void)
{
#ifdef CONFIG_PROC_FS	
	remove_proc_entry(USB_MODEM_ID, NULL);	
#endif
	//usb_deregister(&modem_usb_driver);
	//usb_serial_deregister(&modem_usb_serial_driver);
    usb_serial_deregister_drivers(&modem_usb_driver, modem_usb_serial_drivers);
}

module_init(modem_usb_init);
module_exit(modem_usb_exit);

module_param(vid, uint, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(vid, "Vendor id");

module_param(pid, uint, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(pid, "Product id");


MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL v2");
