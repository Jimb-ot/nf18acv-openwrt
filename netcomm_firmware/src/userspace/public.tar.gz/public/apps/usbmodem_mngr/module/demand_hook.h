/*
 * This is for check if does need dial at ppp demand function
 *
 * Copyright (C) 2012 ChangBan Shen <gdscb@tom.com>
 * Copyright (C) 1990-2012 GongJin Corp.
 *
 * Create by ShenChangBan  2012-7-20
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
 
#define DEMAND_HOOK_IFIDX_BAD		999

#define DEMAND_HOOK_DEBUG_TOKEN 	"debug:"
#define DEMAND_HOOK_LINKUP_TOKEN "linkup:"
#define DEMAND_HOOK_IFNAME_TOKEN "ifname:"
#define DEMAND_HOOK_DIAL_DELAY_TOKEN "dial_delay:"
#define DEMAND_HOOK_RULE_TOKEN "rule:"
#define DEMAND_HOOK_DEL_RULE_TOKEN "del_rule:"
#define DEMAND_HOOK_PROC_ID "demand"

