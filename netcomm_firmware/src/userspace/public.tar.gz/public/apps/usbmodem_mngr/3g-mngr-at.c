#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "3g-mngr-include.h"
#ifdef BRCM
#include <sys/time.h>
#else
#include <time.h>
#endif

#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_at", "AT", args)

struct ext_at_func {
	AT_func_t at;
	struct ext_at_func *p;
	struct ext_at_func *n;
};

typedef struct{
	int fd;
	char at_tty[32];

	AT_func_t at_special;
	AT_func_t at_nt_defalt;
	AT_func_t at_normal_default;
	struct ext_at_func *ext_at_func_list;
	int at_cmd_load_flag;
	int at_config_load_flag;	
	int delay;
	time_t last_do_at;

	int error_time;
} __at_t;

extern char *at_func_map[];

static int at_replace_var(at_t *at, char *at_str, int len)
{
	/*d_printf("enter\n");*/
    if (!at)
    {
        printf_3g("", "at is null\n");
        return -1;
    }
	if (!MN(at)->par) {
		printf_3g("", "at can not point out param\n");
		return -1;
	}

	return param_replace_var(MN(at)->par, at_str, len);
}	

static int at_get_cmd_str(const char *at_str, char *rcmd, char **next)
{/*return the next cmd string at 'next', return 1 means find an at cmd string*/
	const char *p = 0;
	int i = 0;
	int len = 0;

	if ( !at_str || !*at_str) {
		rcmd[0] = 0;
		*next = 0;
		return 0;
	}

	for (p = at_str; *p && *p != ';'; p++)
		rcmd[i++] = *p;
	rcmd[i] = 0;
	/*d_printf("get an at cmd:%s\n", rcmd);*/

	len = strlen(at_str);
	if (*p == ';' && p < at_str + len -1)
		*next = (char *)(p + 1);
	else 
		*next = 0;
	
	return 1;

}

static void __get_at(at_t *at, at_cmd_t cmd, char *rbuf, int rlen)
{
	__at_t *__at;

	if (!rbuf||!at)
		return;

	memset(rbuf, 0, AT_CMD_LEN);
	
	__at = GET_PRI(at, __at_t);

	at_config_load(at);
	at_cmd_load(at);

	if (__at->at_special.atcmd[cmd])
		snprintf(rbuf, rlen, "%s", __at->at_special.atcmd[cmd]);
	else if (__at->at_nt_defalt.atcmd[cmd]) 
		snprintf(rbuf, rlen, "%s", __at->at_nt_defalt.atcmd[cmd]);
	else if (__at->at_normal_default.atcmd[cmd])
		snprintf(rbuf, rlen, "%s", __at->at_normal_default.atcmd[cmd]);
	
	if (rbuf && rbuf[0] && rlen > 0 && is_debug()) {
		printf_3g("", "get at item:");
		lib3g_at_ret_print(rbuf);
	}
	
}

char *at_cmd_to_str(at_cmd_t item)
{
	if (item >= AT_CMD_END || item <= AT_NONE) {
		static char at_cmd[] = "AT_CMD_UNKWN";
		return at_cmd;
	} else
		return at_func_map[item];
}

int at_get_item(at_t *at, at_cmd_t item, char *rbuf, int rlen)
{
	__get_at(at, item, rbuf, rlen);
	return 0;
}

/*scb+ 2011-12-5 check if does exist the cmd:AT_GET_REG*/
int at_item_get_and_check_exist(at_t *at, at_cmd_t item, char *rbuf, int rlen)
{
	char at_expr[AT_CMD_LEN + 1] = {0};
	
	at_get_item(at, item, at_expr, sizeof(at_expr));
	
	if (at_expr[0] && rbuf && rlen > 0)
		snprintf(rbuf, rlen, "%s", at_expr);
	
	lib3g_strdelblank(at_expr);
	if (at_expr[0])
		return 1;
	else
		return 0;
}
	
static void at_delay(at_t *at)
{
#if 0
#define DP(fmt,args...) d_printf(fmt, ##args)
#else
#define DP(fmt,args...) 
#endif
	__at_t *__at = GET_PRI(at, __at_t);
	time_t curr = 0;
	time_t delt = 0;

	if (__at->delay == 0 || __at->last_do_at == 0)
		return;	

	time(&curr);

	delt = curr - __at->last_do_at;
	delt = delt > 0 ? delt : -delt;
	
	if (delt < __at->delay) {
		DP("curr=%u last_do_at=%u delay=%u delt=%u\n",
			(unsigned int)curr, (unsigned int)__at->last_do_at, (unsigned int)__at->delay, (unsigned int)delt);
		sleep(__at->delay - delt);
	}
	
	return;
#undef DP	
}

static void at_last_do_time(at_t *at)
{
	__at_t *__at = GET_PRI(at, __at_t);
	time_t curr;

	time(&curr);

	__at->last_do_at = curr;	
}

void  at_set_delay(at_t *at)
{	
	char atbuf[AT_CMD_LEN] = {0};
	__at_t *__at = GET_PRI(at, __at_t);

	at_get_item(at, AT_CMD_DELAY, atbuf, AT_CMD_LEN);

	d_printf("AT_DELAY=%s\n", atbuf);

	if (atbuf[0]) {
		d_printf("set at delay to %s\n", atbuf);
		__at->delay = strtoul(atbuf, 0, 10);
	} else
		__at->delay = 0;
}

static int __at_cmd(at_t *at, int fd, const char *at_str, char *rbuf, int rlen)
{
	char atbuf[AT_CMD_LEN + 1] = {0};
	char _rbuf[AT_CMD_LEN + 1] = {0};
	const char *p = 0;
	int at_wait_us = 10000;
	int at_wait_s = 0;
	int mul = 1;
	char *unit = 0;
	char str_at_to[32] = {0};	
	int ret = -1;
	int is_do = 0;
	__at_t *__at;

	__at = GET_PRI(at, __at_t);

	d_printf("enter\n");

	//DIALD_RUN_CHECK();

	if (fd <= 0) {
		d_printf("the point out tty fd is %d use the at obj's fd %d\n", fd, __at->fd);
		//fd = __at->fd;
		//if (fd <= 0) {
		//	d_printf("no valid fd\n");
		//	return ret;
		//}
	}

	if (!(p = at_str)) {
		d_printf("no at string\n");
		return ret;
	}

	while((memset(str_at_to, 0, sizeof(str_at_to)),
				at_get_cmd_str(p, atbuf, (char **)&p))) {
		/*scb+ 2012-2-7 for set the delay for each command*/
		lib3g_reg_exec(atbuf, 
			"/<[0-9]{1,}[um]{0,1}>/,/[0-9]{1,}[um]{0,1}/", 
			str_at_to, 
			sizeof(str_at_to)-1);
		if (str_at_to[0]) {			
			char *tmp = 0;
			if ((tmp = strchr(atbuf, '<')))
				*tmp = 0;	
			d_printf("AT command:[%s] need delay %s\n", atbuf, str_at_to);
			
			if ((unit = strrchr(str_at_to, 'u'))) {
				d_printf("The delay unit is 'u'\n");
				*unit = 0;
				mul = 1;
			} else if ((unit = strrchr(str_at_to, 'm'))) {
				d_printf("The delay unit is 'm'\n");
				*unit = 0;
				mul = 1000;
			} else {
				d_printf("The delay unit is 's'\n");
				mul = 1000000;
			}
			
			at_wait_us = strtoul(str_at_to, 0, 10) * mul;
			
			at_wait_s = at_wait_us/1000000;
			at_wait_us %= 1000000;
			
			if (at_wait_s < 0)
				at_wait_s = 0;

			
			d_printf("AT timeout is %ds %dus\n", at_wait_s, at_wait_us);
		}
		
		
		at_replace_var(at, atbuf, AT_CMD_LEN);
		lib3g_fstrncat(atbuf, AT_CMD_LEN, "\r\n");
		
		if (is_debug()) {
			printf_3g("", "%s", "Do the following at cmd:\n");
			lib3g_at_ret_print(atbuf);
		}

		at_delay(at);

		if (is_debug()) {
			printf_3g("", "%s","\nAT SEND >: ");
			lib3g_at_ret_print(atbuf);
		}
        
		record_3g("AT SEND >: \r\n%s", atbuf);

		is_do = 1;/*exist AT command*/
		
		memset(_rbuf, 0, AT_CMD_LEN);
        /*
		__lib3g_serial_send_recv(fd, 0, atbuf, strlen(atbuf), 
			_rbuf, AT_CMD_LEN, 
			0, 300000,
			at_wait_s, at_wait_us,
			0, 0);
		*/	
        lib3g_serial_send_recv(__at->at_tty, atbuf, strlen(atbuf), 
			_rbuf, AT_CMD_LEN, 
			0, 400000,
			at_wait_s, at_wait_us,
			0, 0);
        
		if ( is_debug()) {
			printf_3g("", "%s","AT RCVD >: ");
			lib3g_at_ret_print(_rbuf);
			printf_3g("", "%s","\n");
		}

		if (lib3g_at_is_end(_rbuf, AT_CMD_LEN))
			usleep(10000);
		else
			usleep(100000);
		
		at_last_do_time(at);
		
		if(is_debug()) {
			printf("The at cmd result:\n");
			lib3g_at_ret_print(_rbuf);
		}
	}

	if (is_do == 0 || lib3g_at_is_end(_rbuf, AT_CMD_LEN))
		ret = 0;
    
	record_3g("AT RECV >: \r\n%s", _rbuf);
    
	if (rbuf && rlen > 0)
		strncpy(rbuf, _rbuf, rlen);
	else if (rbuf && rlen == 0)
		strcpy(rbuf, _rbuf);
	
	
	return ret;
	
}

/*
  * return:
  *	0	OK,
  *   1     AT cmd OK, but system return can not support CMEE error,
  *	-1   AT cmd error
*/
static int __call_at(at_t *at, at_cmd_t cmd, char *rbuf, int rlen)
{
	int ret = 0;
	int at_errno = 0;
	char atbuf[AT_CMD_LEN] = {0};
	char err_buf[10] = {0};
	char err_regexe[] = "s/.*CME *ERROR:[ \t]*//, s/[\n\r]*//, /[0-9]*/";


	__get_at(at, cmd, atbuf, AT_CMD_LEN);
	ret =  __at_cmd(at, GET_PRI(at, __at_t)->fd, atbuf, rbuf, rlen); 
	if (rbuf[0]) {		
		lib3g_reg_exec(rbuf, err_regexe, err_buf, MNGR_LEN(err_buf));
		d_printf("return :[%s], errno:[%s]\n", rbuf, err_buf);
		if (err_buf[0]) {
			at_errno = strtoul(err_buf, 0, 10);
			d_printf("CMMERR:%d\n", at_errno);
			switch (at_errno) {
				case   3:
				case   4:
				case 20:
				case 21:
				case 22:
				case 23:
					ret = 1;
					break;
				default:
					break;
			}
		}			
	}
	return ret;
}

int at_do_cmd(at_t *at, at_cmd_t cmd, int retry,  at_cmd_t cmd_pattn, char *rb, int rlen)
{
	int i = 0;
	int ret = 0;
	char rbuf[AT_CMD_LEN] = {0};
	char regbuf[AT_CMD_LEN] = {0};
	__at_t *__at = 0;

	if(at==NULL)
		return -1;
	
	if (modem_search(MN(at)->mdm) != 0)
		return -1;

	__at = GET_PRI(at, __at_t);

	d_printf("Try to do AT command:[%d]\n", cmd);
	DIALD_RUN_CHECK();
	

	/*scb+ 2011-12-5 check if does exist the cmd:AT_GET_REG*/
	if (!at_item_get_and_check_exist(at, cmd, 0, 0)) {
		d_printf("No %d cmd,No AT command to do\n", cmd);
		if (rb && rlen > 0)
			rb[0] = 0;
		return 0;
	}
	
	for (i = 0; i <= retry; i++) 
		if ((ret = __call_at(at, cmd, rbuf, AT_CMD_LEN)) >= 0)
			break;
		
	if (i == 	retry + 1) {
		d_printf("at cmd failure:%s\n", at_func_map[cmd]);
		ret = -1;	
	}

	if (ret == 1) {
		d_printf("Unsprised CMEE error\n");
		ret = -1;
	}

	if (mn && mn->run_on_diald) {
		if (!rbuf[0]) {
			d_printf("AT not output\n");
			__at->error_time++;
			if (__at->error_time > 500) {
				printf_3g("", "%s","AT not output, maybe tty is bad, do hotunplug\n");
				CDMG_SEND_MSG(hotunplug, "%s", "");
				return -1;
			}				
		} else
			__at->error_time = 0;
	}

	d_printf("AT:result:ret=%d, str:[%s], to process by pattn:%d\n", 
		ret, rbuf, cmd_pattn);
	if (ret == 0 && cmd_pattn != AT_NONE && rb) {
		__get_at(at, cmd_pattn, regbuf, AT_CMD_LEN);
		d_printf("AT: pattn is:[%s]\n", regbuf);
		if (lib3g_reg_exec(rbuf, regbuf, rb, rlen) == -1) {
			printf_3g("", "%s","do reg err, the reg express:\n");
			lib3g_at_ret_print(regbuf);	
		}
		d_printf("Result:[%s]\n", (rb && rb[0]) ? rb : "");
		if (is_debug())	{ 
			printf_3g("", "%s","pattn:\n");
			lib3g_at_ret_print(regbuf[0]?regbuf:"none");	
			printf("reg result:");
			lib3g_at_ret_print(rb);
		}
			
	}

	return ret;
}

int at_parse(at_t *at, at_cmd_t pattn, char *str, char *rbuf, int rlen)
{
	char regbuf[AT_CMD_LEN] = {0};
	__at_t *__at = NULL;

	__at = GET_PRI(at, __at_t);
	
	__get_at(at, pattn, regbuf, AT_CMD_LEN);
	
	if ( (access(DAIL_DEBUF_CONTR_FILE, F_OK) ) == 0) {
		d_printf("get a at pattn:\n");
		lib3g_at_ret_print(regbuf[0]?regbuf:"none");	
	}
	
	return lib3g_reg_exec(str, regbuf, rbuf, rlen);
}


FUNC(chat, "send  msg to modem and print the rcvd\n"
			"\texamp1: 3g-mngr chat [--tty=/dev/ttyUSB0] msg\n"
			"\texamp2: 3g-mngr chat [--tty=/dev/ttyUSB0] --file=xx [--log=xxx]\n")
{
	int tout = 5;
	int point_out_tty = 0;
	int rate = 0; 
	char msg[128] = {0};
	char r_msg[128] = {0};
	char tty[80] = {0};
	char *tmp = 0;
	char *file = 0;
	char *log = 0;

	mngr_start(&mn, 
		MNGR_START_CREATE_MODEM|
		MNGR_START_CREATE_AT|
		MNGR_START_CREATE_PAR);

	d_printf("enter\n");
	
	/*decide the tty*/
	if (!cdmg_get_arg(argv, "tty", tty, 80)) {   	
		modem_search(mn->mdm);
		modem_get_ctrl_port(mn->mdm, &tmp);
		if ( !tmp) {
			printf("no usb modem device");
			return 0;
		}

		lib3g_strncpy(tty, 80, tmp, 0);
	} else
		point_out_tty = 1;

	if (!tty[0]) {
		printf("No tty\n");
		return -1;
	}

	/*chat from the script file*/
	if (CDMG_GET_ARG("file", 0)) {
		CDMG_MALLOC(128, file, return -1;);
		cdmg_get_arg(argv, "file", file, 127);
		CDMG_MALLOC(128, log, free(file); return -1;);
		cdmg_get_arg(argv, "log", log, 127);
		if (!log[0] && is_debug()) {
#ifdef PC			
			snprintf(log, 127, "%s", "/proc/self/fd/1");
#else
			snprintf(log, 127, "%s", "/dev/console");
#endif
		}

		printf("Start chat...\n");

		rate = lib3g_chat_file(file, tty, log);

		if (rate > 0)
			printf("Connect rate:%d\n", rate);
		else 
			printf("Chat fails: tty:%s\n", tty );

		if (log)
			free(log);
	
		return rate;
	}		

	if (!point_out_tty) {
		if (argc > 1 )
			lib3g_strncpy(msg, 128, argv[1], 0);
		else
			lib3g_strncpy(msg, 128, " ", 0);
	} else {
		if (argc > 2)
			lib3g_strncpy(msg, 128, argv[2], 0);
		else
			lib3g_strncpy(msg, 128, " ", 0);
	}
	lib3g_fstrncat(msg, 128, "\r\n");

	lib3g_serial_send_recv(tty, msg, strlen(msg), 
		r_msg, 128, tout, 2, 0, 1000, 0, 0);

	if (r_msg[0]) {
		printf("%s\n", r_msg);
		lib3g_at_ret_print(r_msg); 
	}
	else
		printf("NO RCVD MSG\n");

	if (log)
		free(log);

	return 0;
}


/*********************************************************************/

#define ATS(n, id, n_t)   .name=n,  .ids=id,  .nt=n_t
#define AT(n, s) .atcmd[n]=s

AT_func_t atfuncs[] = {
		{
			ATS("default", "", "CDMA2000"),
#if defined(CONFIG_DRIVER_Chile)
			AT(AT_CONFIG, ""),
#else
			AT(AT_CONFIG, "AT&FE0V1X1&D2&C1S0=0"),
#endif
			AT(AT_GET_PRVDR, "AT+CIMI"),
		},
		{
			ATS("default", "", "EVDO"),			
#if defined(CONFIG_DRIVER_Chile)
			AT(AT_CONFIG, ""),
#else
			AT(AT_CONFIG, "AT&FE0V1X1&D2&C1S0=0"),
#endif
			AT(AT_GET_PRVDR, "AT+CIMI"),
		},
		{   /* 4G����Ĭ�Ͼ�ʹ��ndis(cdc,ncm,cee)��ʽ�����ˣ���������ô�ͳ��tty��ʽ�����ʺ�
		     * ��atָ��
		     */
			ATS("default", "", "LTE"),			
            AT(AT_DIAL, "AT^NDISDUP=1,1,\"@apn@\""),
            AT(AT_HANGUP, "AT^NDISDUP=1,0"),
		},		
        {
            ATS("general", "", "WCDMA"),
						
#if defined(CONFIG_DRIVER_Chile)
			AT(AT_CONFIG, "AT+CGDCONT=1,\"IP\",\"@apn@\",,0,0"),
#else
			AT(AT_CONFIG, "AT&FE0V1X1&D2&C1S0=0;AT+CGDCONT=1,\"IP\",\"@apn@\",,0,0"),
#endif			
			AT(AT_DIAL, "ATDT@number@"),	
		
			AT(AT_END, "CONNECT"),
			
			AT(AT_HANGUP, "ATH"),
			

			AT(AT_GET_PRVDR, "AT+COPS=3,2;AT+COPS?"),
			/* AT+COPS?\r\r\r+COPS: 0,2,"46001",2\r\r\r\rOK\r\r  */
			//AT(AT_GET_PRVDR_PATTN, "/[0-3],[0-3],\"[0-9]{5,}\",/,   /[0-9]{5}/"),
			AT(AT_GET_PRVDR_PATTN, "/[0-9]{5}/"),
			AT(AT_GET_ACT_PATTN, "/[\n\r][^\n\r]{1,}[\n\r]/, s/[^0-9]*//, s/.*\",//, /[0-9]{1,}/"),
			
			AT(AT_GET_CSQ, "AT+CSQ"),
			/*AT+CSQ\n\n\n+CSQ: 16,99\n\n\n\nOK\n\n*/
			AT(AT_GET_CSQ_BER_PATTN, "/[\n\r][^\n\r]{1,}[\n\r]/, s/[^0-9]*//, s/.*,//, /[0-9]{1,}/"),
			AT(AT_GET_CSQ_RSSI_PATTN, "/[\n\r][^\n\r]{1,}[\n\r]/, s/[^0-9]*//,s/,.*//"),

			AT(AT_GET_ID, "AT+CGMM"),
			/*AT+CGMM\n\r\r\nE180\n\r\r\nOK\n\n*/
			AT(AT_GET_ID_PATTN, "/[\r\n][a-zA-Z0-9]{1,}[\r\n]/,/[^\n\r]{1,}/"),

			AT(AT_GET_IMEI, "AT+CGSN"),
			/*AT+CGSN\n\n\n354241028008276\n\n\n\nOK\n\n*/
			/*AT+CGSN\n\n\n+CGSN: 0xAC1A431C\n\n\n\nOK\n\n*/
			AT(AT_GET_IMEI_PATTN,  "/[\n\r][^\n\r]{1,}[\n\r]/,/[\n\r: ][^\n\r :]{1,}[\n\r]/,/[\n\r: ][^\n\r :]{1,}/, /[^\n\r]{1,}/"),


			AT(AT_GET_IMSI, "AT"),
			AT(AT_GET_IMSI, "AT+CIMI"),
			/*at+cimi\n\n\n460991234567890\n\n\n\nOK\n\n*/
			AT(AT_GET_IMSI_PATTN,  "/[\n\r][^\n\r]{1,}[\n\r]/,/[0-9]{1,}/"),

			AT(AT_GET_CHARGE, "AT+CAOC=0"),
			/*AT+CAOC=0\r\r\n+CAOC: "000000"\r\n\r\nOK\r\n*/
			AT(AT_GET_CHARGE_PATTN, "/[\n\r][^\n\r]{1,}[\n\r]/, /[0-9]{1,}/"),			

#ifdef SUPPORT_MORE_DONGLE
			AT(AT_GET_REG, " "),
#else
			AT(AT_GET_REG, "AT+CREG=0;AT+CREG?"),
			/*+CREG? +CREG: <n>,<stat>[,<lac>,<ci>]*/
			/*at+creg?\n\n\n+CREG: 0,1\n\n\n\nOK\n\n*/
#endif
            AT(AT_GET_REG_LTE, " "),
			AT(AT_GET_REG_PATTN, "/[:\n\r ][^,]*,[^,\n\r]*/,/,[^,]*/, /[^ \t,]{1,}/, s/[^0-9]/9/, s/[0-9]{2,}/9/"),	

#ifdef SUPPORT_MORE_DONGLE
			AT(AT_GET_PIN, " "),
#else
			AT(AT_GET_PIN, "AT+CPIN?"),
			/*+CPIN: <code>*/
			/*at+cpin?\n\n\n+CPIN: READY\n\n\n\nOK\n\n*/
			/*AT+CPIN?\n\n\n+CME ERROR: SIM failure\n\n*/	
#endif
			/*+CPIN: <code>*/
			/*at+cpin?\n\n\n+CPIN: READY\n\n\n\nOK\n\n*/
			/*AT+CPIN?\n\n\n+CME ERROR: SIM failure\n\n*/					
			AT(AT_GET_PIN_PATTN, "s/.*:[ ]*//, /[^ ][^\n\r]*/"),
			
			AT(AT_SET_PUK, "AT+CPIN=\"@puk@\",\"@pin@\""),
#ifdef SUPPORT_MORE_DONGLE
			AT(AT_SET_PUK_RETRY_T," "),
#else
			AT(AT_SET_PUK_RETRY_T,"AT^CPIN?"),	
#endif			
			/*at^cpin?\n\n\n^CPIN: SIM PUK,9,9,0,10,3\n\n\n\nOK\n\n*/
			AT(AT_SET_PUK_RETRY_T_PATTN, "/,[^\n]*[\n]/,  s/,[^,]*,//,   s/,.*//"),
					
			AT(AT_SET_LOCK, "AT+CLCK=\"SC\",@lock@,\"@pin@\""),
#ifdef SUPPORT_MORE_DONGLE
			AT(AT_SET_LOCK_RETRY_T," "),
#else
			AT(AT_SET_LOCK_RETRY_T,"AT^CPIN?"),	
#endif				
			/*at^cpin?\n\n\n^CPIN: READY,,10,2,10,3\n\n\n\nOK\n\n*/
			AT(AT_SET_LOCK_RETRY_T_PATTN, "/,[^\n]*[\n]/, s/,[^,]*,[^,]*,//,   s/,.*//"),
			
			AT(AT_GET_LOCK, "at+clck=\"SC\",2"),
			/*at+clck="SC",2\n\n\n+CLCK: 0\n\n\n\nOK\n\n*/
			AT(AT_GET_LOCK_PATTN, "/[\n\r][^\n\r]{1,}[\n\r]/, /[0-9]/"),

			AT(AT_CHG_PIN, "AT+CPWD=\"SC\",\"@pin@\",\"@newpin@\""),
#ifdef SUPPORT_MORE_DONGLE
			AT(AT_CHG_RETRY_T," "),
#else
			AT(AT_CHG_RETRY_T,"AT^CPIN?"),	
#endif				
			/*at^cpin?\n\n\n^CPIN: READY,,10,2,10,3\n\n\n\nOK\n\n*/
			AT(AT_CHG_RETRY_T_PATTN,  "/,[^\n]*[\n]/, s/,[^,]*,[^,]*,//,   s/,.*//"),

			AT(AT_SET_PIN, "AT+CPIN=\"@pin@\""),
#ifdef SUPPORT_MORE_DONGLE
			AT(AT_SET_PIN_RETRY_T," "),
#else
			AT(AT_SET_PIN_RETRY_T,"AT^CPIN?"),	
#endif				
			/*at^cpin?\n\n\n^CPIN: READY,,10,3,10,3\n\n\n\nOK\n\n*/ 
			/*at^cpin?\n\n\n^CPIN: SIM PIN,2,10,3,10,3\n\n\n\nOK\n\n*/				
			AT(AT_SET_PIN_RETRY_T_PATTN, "/PIN.*,[^\n]*[\n]/, /,[^\n]*[\n]/, s/,,[^,]{1,2}//,  s/,//,   s/,.*//"),		

			/*because the nor numeric mode is not standard*/
			AT(AT_SET_CMEE_TO_NUM_MODE, "AT+CMEE=1"),

			/*default, no init AT command*/
			AT(AT_PHONE_INIT, " "),

#ifdef SUPPORT_MORE_DONGLE
			AT(AT_SET_NETWORK_MODE, "AT"),	
#else
			AT(AT_SET_NETWORK_MODE, "AT+COPS=0,2"),
#endif

			/*scb+ 2012-5-11 for getting   location area code*/
			AT(AT_GET_LAC, "AT+CREG=2;AT+CREG?"),
			/*result:\n\n+CREG: 2,1,"2497","0EF9"\n\n\n\nOK\n\n*/
			AT(AT_GET_LAC_PATTN, "/[0-9a-fA-F]{4,4}/"),

			/*scb+ 2012-5-11 for getting cell id */
			AT(AT_GET_CELLID, "AT+CREG=2;AT+CREG?"),
			/*result:\n\n+CREG: 2,1,"2497","0EF9"\n\n\n\nOK\n\n*/
			AT(AT_GET_CELLID_PATTN, "/[0-9a-fA-F]{4,4}.*/, s/[0-9a-fA-F]{4,4}//, /[0-9a-fA-F]{4,4}/"),
		},
};
/***************************************************************************/

static void at_func_free(AT_func_t *at)
{
	int i = 0;
	
	for (; i < sizeof(at->atcmd)/sizeof(at->atcmd[0]); i++)
		if (at->atcmd[i]) {
			free(at->atcmd[i]);
			at->atcmd[i] = 0;
		}
		
	if (at->ids)
		free(at->ids);
}

static void at_func_mv(AT_func_t *a1, AT_func_t *a2) 
{
	int i = 0;
	int len;

	lib3g_strncpy(a1->name, AT_NAME_LEN, a2->name, 0);
	lib3g_strncpy(a1->nt, NET_TYPE_NAME_LEN, a2->nt, 0);


	if (a2->ids && (len = strlen(a2->ids))) {
		if (a1->ids)
			free(a1->ids);
		
		if (!(a1->ids = malloc(len + 1))) 
			d_printf("No enough memory!\n");
		else 
			lib3g_strncpy(a1->ids, len + 1, a2->ids, 0);
	} else 
		a1->ids = NULL;

	for (i = 0; i < sizeof(a1->atcmd)/sizeof(a1->atcmd[0]); i++) {
		if (a1->atcmd[i]) 
			free(a1->atcmd[i]);
		
		if (a2->atcmd[i]) {			
			a1->atcmd[i] = malloc(AT_CMD_LEN);
			memset(a1->atcmd[i], 0, AT_CMD_LEN);
			lib3g_strncpy(a1->atcmd[i], AT_CMD_LEN, a2->atcmd[i], 0);
		} else
			a1->atcmd[i] = 0;			
	}	
	
}

static int at_id_match(const char *ids, int vid, int pid)
{
	char buf[32] = {0};
	char ids_tmp[AT_CONTENT_LEN] = {0};
	int ret;

	if (!ids || !ids[0])
		return 0;
	
	snprintf(buf, sizeof(buf), "(%04x,%04x)", vid, pid);
	lib3g_strl2u(buf);

	memset(ids_tmp, 0, AT_CONTENT_LEN);
	lib3g_strncpy(ids_tmp, AT_CONTENT_LEN, ids, 0);
	lib3g_strdelblank(ids_tmp);
	lib3g_strl2u(ids_tmp);

	ret = (int)strstr(ids_tmp, buf);

	
	if (ret)
		return 1;
	else
		return 0;
}

int at_cfg_file_ids_is_exist(__at_t *__at, const char *ids)
{
	struct ext_at_func *atlist;
	char *ids1 = 0;
	char *ids2 = 0;


	if ((ids1 = malloc(AT_CONTENT_LEN*2)) == NULL) {
		d_printf("can not malloc\n");
		return 1;
	}

	memset(ids1, 0, AT_CONTENT_LEN*2);

	ids2 = ids1 + AT_CONTENT_LEN;

	lib3g_strncpy(ids1, AT_CONTENT_LEN, ids, 0);

	lib3g_strdelblank(ids1);
	lib3g_strl2u(ids1);	
	
	for ( atlist  = __at->ext_at_func_list; 
		atlist && atlist->at.ids && atlist->at.ids[0]; atlist = atlist->n) {
			lib3g_strncpy(ids2, AT_CONTENT_LEN, atlist->at.ids, 0);
			lib3g_strdelblank(ids2);
			lib3g_strl2u(ids2);				
			
			if (strstr(ids2, ids1)) {
				free(ids1);
				return 1;	
			}
			memset(ids2, 0, AT_CONTENT_LEN);
	}

	free(ids1);
	return 0;
}

/*parse the ext at func cfg file to create the ext at func list*/
static void __at_cfg_file_read(__at_t *__at, const char *at_cfg_file)
{
#if 0
#define DP(fmt,args...) d_printf(fmt, ##args)
#else
#define DP(fmt,args...) 
#endif
	/*
		the cfg file format:
			;ATStart
			;I="(12d1,1003),(19d2,1004)"
			;AT_INIT="at"
			...
			;I="(abcd,1003)"
			;AT_INIT="at"
			...
			;ATEnd		
	*/
	FILE *fp;
	int start = 0;
	int i;
	int find = 0;
	char at_line[AT_CFG_LINE_LEN] = {0};
	char reg_ret[AT_CFG_LINE_LEN] = {0};
	char token[AT_TOEKN_LEN] = {0};
	char at_content[AT_CONTENT_LEN] = {0};
	char *p = 0;
	char *q = 0;
	struct ext_at_func *at_tail;
	struct ext_at_func *at;


	d_printf("Start to load ext at function configure from %s\n", at_cfg_file);

	for(at_tail = __at->ext_at_func_list; at_tail && at_tail->n; at_tail = at_tail->n);
	
	
	if ((fp = fopen(at_cfg_file, "r")) == NULL) {
		d_printf("can not open %s\n", at_cfg_file);
		return;
	}

	while (fgets(at_line, AT_CFG_LINE_LEN, fp)) {
		if (start == 0) {
			memset(reg_ret, 0, AT_CFG_LINE_LEN);
			lib3g_reg_exec(at_line, "/^[ \t]*;ATStart/", reg_ret, AT_CFG_LINE_LEN);
			if (reg_ret[0]) 
				start = 1;
			continue;
		}

		/*;ATEnd	*/
		memset(reg_ret, 0, AT_CFG_LINE_LEN);
		lib3g_reg_exec(at_line, "/^[ \t]*;ATEnd/", reg_ret, AT_CFG_LINE_LEN);
		if (reg_ret[0]) {
			break;
		}

		/*process such line: #...*/
		memset(reg_ret, 0, AT_CFG_LINE_LEN);
		lib3g_reg_exec(at_line, "/^[ \t]*#/", reg_ret, AT_CFG_LINE_LEN);
		if (reg_ret[0]) { 			
			continue;
		}

		/*get AT configure token,such as I, AT_INIT, AT_CONFIG...*/
		memset(reg_ret, 0, AT_CFG_LINE_LEN);
		lib3g_reg_exec(at_line, "/^[ \t]*;.*/, /[IA][A-Z_]{0,}/", reg_ret, AT_CFG_LINE_LEN);
		if (!reg_ret[0]) {
			DP("line[%s] no token\n", at_line);
			continue;
		}
		else {			
			memset(token, 0, AT_TOEKN_LEN);
			lib3g_strncpy(token, AT_TOEKN_LEN, reg_ret, 0);
			DP("find token[%s]\n", token);
		}


		/*get at configur content*/
		DP("get at content frome line[%s]\n", at_line);
		memset(at_content, 0, AT_CONTENT_LEN);
		
		p = strchr(at_line, '\"');
		q = strrchr(at_line, '\"');
		
		if (!p || !q || (q <= p + 1)) {
			DP("AT configure format error at line[%s]\n", at_line);
			continue;
		}

		*q = 0;
		p++;

		lib3g_strncpy(at_content, AT_CONTENT_LEN, p, 0);
	
		if (!at_content[0]) {
			DP("AT configure content is zero\n");
			continue;
		}		

		d_printf("Loading  an at confiure :%s=\"%s\"\n", token, at_content);
		
		if (token[0] == 'I') {
			
			find = 0;
			
			if (at_cfg_file_ids_is_exist(__at, at_content)) {
				d_printf("%s exist\n", at_content);				
				continue;
			}
			
			if (!(at = malloc(sizeof(struct ext_at_func)))) {
				d_printf("malloc error\n");
				continue;
			}
			
			memset(at, 0, sizeof(struct ext_at_func));

			at->at.ids = malloc(strlen(at_content) + 1);
			if (at->at.ids)
				strcpy(at->at.ids, at_content);

			if (!at_tail) {
				at_tail = at;
				__at->ext_at_func_list = at;
			} else {
				at_tail->n = at;
				at->p = at_tail;
				at_tail = at;
			}

			find = 1;
			
			continue;
		} else {

			if (find == 0)
				continue;
			
			for(i = 0; i <= AT_CMD_END; i++) {
				if (strcmp(at_func_map[i], token) == 0) {
					at_tail->at.atcmd[i] = malloc(strlen(at_content) + 1);
					if (at_tail->at.atcmd[i] )
						strcpy(at_tail->at.atcmd[i] , at_content);
					continue;
				}
			}
		}	

		memset(at_line, 0, AT_CFG_LINE_LEN);
	}	

	fclose(fp);
#undef DP	
}

/*parse the ext at func cfg file to create the ext at func list*/
static void at_cfg_file_read(__at_t *__at)
{/*
	the cfg file format:
		;ATStart
		;I="(12d1,1003),(19d2,1004)"
		;AT_INIT="at"
		...
		;I="(abcd,1003)"
		;AT_INIT="at"
		...
		;ATEnd		
   */
	if (__at->at_config_load_flag) {
		//d_printf("The ext at functions configure has been loaded\n");
		return;
	}
	
	__at_cfg_file_read(__at, USB_AT_CFG_FILE1);
	__at_cfg_file_read(__at, USB_AT_CFG_FILE2);
	
	__at->at_config_load_flag = 1;

	__at->at_cmd_load_flag = 0;

}

static void ext_at_free(__at_t *__at)
{
	struct ext_at_func *eatf, *eatf1;

	if (!__at->ext_at_func_list )
		return;

	for (eatf = __at->ext_at_func_list; eatf;) {
		at_func_free(&(eatf->at));
		eatf1 = eatf;
		eatf = eatf->n;
		free(eatf1);
	}

	__at->ext_at_func_list = NULL;	
}

static void at_special_find_ext(at_t *a)
{
	struct ext_at_func *at;

    if (!a)
    {
        printf_3g("", "at is null\n");
        return;
    }

	for (at = GET_PRI(a, __at_t)->ext_at_func_list; at; at = at->n) {
		if (at_id_match(at->at.ids, MN(a)->mdm->idVendor, MN(a)->mdm->idProduct)) {
				d_printf("Find an ext at func ids=\"%s\"\n", at->at.ids);
				at_func_mv(&GET_PRI(a, __at_t)->at_special, &(at->at));
				return;
		}
	}	
}

static void at_special_find(at_t *at)
{
	int i = 0;
	int vid = 0;
	int pid = 0;

    if (!at)
    {
        printf_3g("", "at is null\n");
        return;
    }

	modem_get_serial_id(MN(at)->mdm, &vid, &pid);

	for (i = 0; i < sizeof(atfuncs)/sizeof(atfuncs[0]); i++) {
		if (at_id_match(atfuncs[i].ids, vid, vid)) {
				d_printf("use at func:%s\n", atfuncs[i].name);
				at_func_mv(&GET_PRI(at, __at_t)->at_special, atfuncs+i);
				return;
		}
	}
	/*search  file */
	at_special_find_ext(at);
}

static void at_nt_find(at_t *at)
{
	int i = 0;
	char *nt = 0;
    
    if (!at)
    {
        printf_3g("", "at is null\n");
        return;
    }

	if (MN(at)->par->nt[0] && !strcmp(MN(at)->par->nt, "Auto")) {
		d_printf("User point out get the nettype auto!\n");
		modem_get_nt(MN(at)->mdm, &nt);
	} 
	if (!nt && MN(at)->par->nt[0]) {
		d_printf("User point out the nettype:[%s]\n", MN(at)->par->nt);
		nt = MN(at)->par->nt;
	} 
	if (!nt)
		modem_get_nt(MN(at)->mdm, &nt);	
	
	d_printf("nt=[%s]\n", nt);

	for (i = 0; i < sizeof(atfuncs)/sizeof(atfuncs[0]); i++) {
		if ((strcmp(nt, atfuncs[i].nt) == 0) &&
			strcmp("default", atfuncs[i].name) == 0) {
				at_func_mv(&GET_PRI(at, __at_t)->at_nt_defalt, atfuncs+i);
				return;
		}
	}
	/*search  file */
}

static void at_normal_find(at_t *at)
{
	int i = 0;

	for (i = 0; i < sizeof(atfuncs)/sizeof(atfuncs[0]); i++) {
		if (strcmp("general", atfuncs[i].name) == 0) {
				at_func_mv(&GET_PRI(at, __at_t)->at_normal_default, atfuncs+i);
				return;
		}
	}
}

at_t *at_new(void *mn)
{
	at_t *at = 0;
	__at_t *__at;
	
	if ((at = ALLOC_3G(at_t, __at_t)) <= 0) {
		printf_3g("", "malloc error\n");
		return 0;
	}

	MN_SET(at, mn);

	__at = GET_PRI(at, __at_t); 
	__at->at_config_load_flag = 0; 
	__at->at_cmd_load_flag = 0; 	
 
	at_init(at);
 
	return at;
}

int at_free(at_t *at)
{
	if (!at)
		return 0;
	
	at_cmd_free(at);
	at_config_free(at);

	if (MN(at))
		MN(at)->at = 0;

	free(at);	

	at = 0;
	return 0;
}

int at_init(at_t *at)
{
	at_cmd_free(at);
	at_config_free(at);	

	SUB_INIT(at, at_t, __at_t);
 
	return 0;
}

int at_cmd_load(at_t *at)
{/*when modem exchage, do this*/
	__at_t *__at;
    
    if (!at)
    {
        printf_3g("", "at is null\n");
        return 0;
    }

	if (MN(at)->mdm->status  == SEARCH_INVALID)
		return 0;

	__at = GET_PRI(at, __at_t);	

	if (__at->at_cmd_load_flag) {
		//d_printf("at is update\n");
		return 0;
	}

	d_printf("Start to load at cmd...\n");
	
	memset(&__at->at_special, 0, sizeof(AT_func_t));	
	memset(&__at->at_normal_default, 0, sizeof(AT_func_t));

	at_special_find(at);
	at_nt_find(at);
	at_normal_find(at);	

	__at->at_cmd_load_flag = 1;

	at_set_delay(at);
	
	return 0;
	
}

int at_cmd_free(at_t *at)
{
	__at_t *__at = 0;

	__at = GET_PRI(at, __at_t);
	
	
	if (!at)
		return 0;	

	if (!__at->at_cmd_load_flag)
		return 0;

	d_printf("Free at cmd...\n");

	at_func_free(&__at->at_special);
	at_func_free(&__at->at_nt_defalt);
	at_func_free(&__at->at_normal_default);	
	
	__at->at_cmd_load_flag = 0;

	__at->delay = 0;
	__at->last_do_at = 0;
	
	return 0;
}

int at_config_load(at_t *at)
{
	__at_t *__at = 0;

    if (!at)
    {
        printf_3g("", "at is null\n");
        return -1;
    }

	__at = GET_PRI(at, __at_t);

	if (!MN(at)->mdm) {
		printf_3g("", "can not attach at and the modem\n");
		return -1;
	}

	if (__at->at_config_load_flag)
		return 0;
		
	at_cfg_file_read(GET_PRI(at, __at_t));
	at_cmd_free(at);
	at_cmd_load(at);

	__at->at_config_load_flag = 1;
	
	return 0;
}

int at_config_free(at_t *at)
{	
	__at_t *__at = 0;

	if (!at)
		return 0;	
	
	__at = GET_PRI(at, __at_t);

	if (!__at->at_config_load_flag)
		return 0;
	

	d_printf("Free at config...\n");
	
	ext_at_free(__at);

	__at->at_config_load_flag = 0;
	
	return 0;
}

int at_set_tty(at_t *at, const char *port)
{
	__at_t *__at;

	if (!port || !port[0]) {
		d_printf("param error\n");
		return -1;
	}
		
	__at = GET_PRI(at, __at_t);

	//if (__at->fd > 0)  {
	//	d_printf("close old tty file: %s fd=%d\n", (__at->at_tty[0]? __at->at_tty : "none"), __at->fd);
	//	close(__at->fd );
	//}
    memset(__at->at_tty, 0, sizeof(__at->at_tty));
	strncpy(__at->at_tty, port, sizeof(__at->at_tty) - 1);

	//if ((__at->fd = open (__at->at_tty, O_RDWR | O_NOCTTY | O_NONBLOCK)) < 0) {
	//	d_printf("can not open %s\n", __at->at_tty);
	//	return -1;
	//}

	d_printf("new at tty:%s fd=%d\n", __at->at_tty, __at->fd );

	return 0;
		
}

/*********************************************************************/
int at_product_chat_script(at_t *at, int argc, char *argv[])
{
	char atbuf[AT_CMD_LEN] = {0};
	char atbuf1[AT_CMD_LEN] = {0};
	char *p = 0;
	FILE *chat_fd = 0;

    if (!at)
    {
        printf_3g("", "at is null\n");
        return -1;
    }

	if (!(MN(at)->par))  {
		printf_3g("", "No param object!\n");
		return -1;
	}

	param_init(MN(at)->par);

	param_get_from_user(MN(at)->par, argc, argv);

	param_get(MN(at)->par);

	if ((chat_fd  = fopen(CHAT_SCRIPT_PATH, "w+"))) {
		fprintf(chat_fd, 
			"ECHO ON\n"
			"ABORT 'BUSY'\n"
			"ABORT 'NO ANSWER' \n"
			"ABORT 'ERROR' \n");
		fprintf(chat_fd, "TIMEOUT 40\n");
		fprintf(chat_fd, " ''  AT\n");

		__get_at(at, AT_INIT, atbuf, AT_CMD_LEN);
		p = atbuf;
		while(at_get_cmd_str(p,  atbuf1, &p)) {
			at_replace_var(at, atbuf1, AT_CMD_LEN);
			fprintf(chat_fd, "'OK'		%s\n", atbuf1);
		}

		__get_at(at, AT_CONFIG, atbuf, AT_CMD_LEN);
		p = atbuf;	  
		while(at_get_cmd_str(p,  atbuf1, &p)) {
			at_replace_var(at, atbuf1, AT_CMD_LEN);
			fprintf(chat_fd, "'OK'		%s\n", atbuf1);
		}	 

		__get_at(at, AT_DIAL, atbuf, AT_CMD_LEN);
		p = atbuf;	  
		while(at_get_cmd_str(p,  atbuf1, &p)) {
			at_replace_var(at, atbuf1, AT_CMD_LEN);
			fprintf(chat_fd, "'OK'		%s\n", atbuf1);
		}	  

		__get_at(at, AT_END, atbuf, AT_CMD_LEN);
		if (atbuf[0])
			fprintf(chat_fd, "%s\n", atbuf);
		
	
		fclose(chat_fd);
	}
	
	return 0;
}
