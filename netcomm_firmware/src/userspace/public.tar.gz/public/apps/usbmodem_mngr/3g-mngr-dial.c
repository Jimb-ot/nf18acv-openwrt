#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if.h>

#include "3g-mngr-include.h"
#include     "ndis_qmi_service.h"

#undef d_printf
#define d_printf(args...) debug_3g("/var/3g_debug_dial", "DIAL", args)

#define CONNECT_TIME_OUT  30    //15 seconds
#define DISCONNECT_TIME_OUT  3    //seconds
typedef enum {
	DAIL_STAT_DAILING,
	DAIL_STAT_DAILED,
	DAIL_STAT_UNDAILING,
	DAIL_STAT_UNDAIL
} dialstat_t;

struct dial_state {
	dialstat_t dialstat;
	struct timeval tv;
};

typedef struct {
	struct dial_state stat;

	pid_t do_chat;
	
	int chat_at_pppd;	

	struct timer_3g *chat_timer;/*for chat time out*/
} __dial_mngr_t;

static void dial_mngr_process_againdial_timer(void *data);
static void fix_dial_stat(struct dial_state *s);
static void change_dial_stat(struct dial_state *s, dialstat_t newstat);
static void dial_mngr_dial(int argc, char *argv[]);
static void dial_mngr_do_undial();

static dialstat_t dial_stat(struct dial_state *s);

static struct USB_MODERM_PRODUCTS g_qmi_list[]={
	{0x05c6, 0x9215},
	{0x1c9e, 0x9b05},
	{0x05c6, 0x9025},

};
static char *dialstat_name(dialstat_t s)
{
	static char *s_n[] = {
		"DAIL_STAT_DAILING",
		"DAIL_STAT_DAILED",
		"DAIL_STAT_UNDAILING",
		"DAIL_STAT_UNDAIL",
	};	
	static char s_bad[] = "BAD";

	if (s >= sizeof(s_n)/sizeof(s_n[0]))
		return s_bad;
	return s_n[s];
}

#define DIAL_GET_STAT(d)   ((GET_PRI(d, __dial_mngr_t))->stat)

int dial_mngr_init(dial_mngr_t *dial)
{
	__dial_mngr_t *__dial;
	struct dial_state  *stat;	

	SUB_INIT(dial, dial_mngr_t, __dial_mngr_t);

	__dial = GET_PRI(dial, __dial_mngr_t);

	stat = &DIAL_GET_STAT(dial);

	stat->dialstat = DAIL_STAT_UNDAIL;

	return 0;
}

dial_mngr_t *dial_mngr_new(void *mn)
{
	dial_mngr_t *dial;

	if ((dial = ALLOC_3G(dial_mngr_t, __dial_mngr_t)) <= 0)
		return 0;

	MN_SET(dial, mn);

	dial_mngr_init(dial);

	return dial;

}

int dial_mngr_free(dial_mngr_t *dial)
{
	if (!dial)
		return 0;
	
	if (MN(dial))
		MN(dial)->dial = 0;

	free(dial);
	dial = 0;
	return 0;
}






static void dial_mngr_do_greneral_dial(dial_mngr_t *dial, UBOOL8 isPpp)
{
	int ret;
    char cmd[128] = {0};
	
	if (is_3g_debug_local("/var/3g_debug_dial", 
			DAIL_DEBUF_CONTR_FILE, __FILE__, 0))
    {
        if (isPpp)
            snprintf(cmd, sizeof(cmd) - 1, "%s -d", PPPD_CMD);
        else
            snprintf(cmd, sizeof(cmd) - 1, "%s -i %s -s %s -p %s", DHCP_NAME, g_usb_dongle_ifname, DHCP_SCRIPT, DHCP_PID_FILE);
    }
	else
    {
        if (isPpp)
		    snprintf(cmd, sizeof(cmd) - 1, "%s", PPPD_CMD);
        else
            snprintf(cmd, sizeof(cmd) - 1, "%s -i %s -s %s -p %s", DHCP_NAME, g_usb_dongle_ifname, DHCP_SCRIPT, DHCP_PID_FILE);
    }
    
    record_3g("%s\r\n" ,cmd);
    lib3g_system(cmd, 0);

	mn->do_dial_wait = fork_3g();
	if (mn->do_dial_wait  == 0) {
		sleep(1);
		ret = CDMG_DO_FUNC(wait, "--action=dial --time=30");
		if (ret == 0 && dial->demand_dial)
			CDMG_SEND_MSG(demandok, "%s", "");		
		exit(0);
	}
}


int  usb_moderm_match_qmi_module(unsigned int vid, unsigned int pid)
{
    int size = sizeof(g_qmi_list)/sizeof(struct USB_MODERM_PRODUCTS);
    int i;

    for(i = 0; i < size; i++)
    {
                d_printf("vid = %04x, pid = %04x,g_qmi_list[i].vid=%04x,g_qmi_list[i].pid=%04x\n",
                vid, pid,g_qmi_list[i].vid,  g_qmi_list[i].pid);
				
        if ((g_qmi_list[i].pid == pid) &&
            (g_qmi_list[i].vid == vid))
        {
            return 1;
        }
    }

    return 0;
}



int qmi_module_connect( char *apn, char *usrname, char *pwd, int authtype, dial_mngr_t *dial, UBOOL8 isPpp )
{
	char version[64] = {0};
	int ret = -1;
	ndis_ipinfo pipinfo;
	int connecting_timeout = CONNECT_TIME_OUT;
	int fd = 0;
	unsigned char mac[32] = {0};
	
	fd = ndis_open();	
	if(fd == -1)
	{
		d_printf("ndis_open failed.\n");
		return -1;
	}
	
	//if get version failed, indicated initliaze error.
	ret = ndis_get_lib_version(fd,version,sizeof(version));
	if(ret!=0||strlen(version)<3)
	{
		d_printf("ndis_get_lib_version failed,ret=%d.\n",ret);	
        ndis_close(fd);
		return -1;		
	}else
	{
		d_printf("ndis_get_lib_version success,version=%s.\n",version);		
	}

	d_printf("ndis connect test! \n");
	// connect to internet
	{
		d_printf("connection use apn:%s,usrname:%s,pwd:%s,auth:%d.\n",apn,usrname,pwd,authtype);	
		ret = ndis_connect(fd,apn,usrname,pwd, authtype);			
		if(ret!=0)
		{
			d_printf("ndis_connect failed,ret=%d.\n",ret);	
			goto EXIT_CON_PROGRAM;
		}else
		{
			d_printf("ndis_connect success.\n");
		}
		
	}
	
	while(connecting_timeout--)
	{
		ret = ndis_get_status(fd,&pipinfo);
		if(ret!=0)
		{
			d_printf("ndis_get_status failed,ret=%d.\n",ret);					
		}else
		{
			d_printf("ndis_get_status success.\n");
			if(NDIS_CONNECTED==pipinfo.i32status){
			    d_printf("connected to internet success, .\n");
				dial_mngr_do_greneral_dial(dial, isPpp);
				break;
			}
		}
		usleep(500000);
	}

	if(NDIS_CONNECTING==pipinfo.i32status)
	{
		d_printf("connecting to internet time out,disconnect from internet.\n");	
		ret = ndis_disconnect(fd);
		if(ret!=0)
		{
			d_printf("ndis_disconnect failed,ret=%d.\n",ret);	
            goto EXIT_CON_PROGRAM;		
		}else
		{
			d_printf("ndis_disconnect success.\n");
		}	
		ret = ndis_get_status(fd,&pipinfo);
	}
EXIT_CON_PROGRAM:	
	ndis_close(fd);
	return 0;
}

int qmi_module_disconnect()
{
	char version[64] = {0};
	int ret = -1;
	int option = -1;
	ndis_ipinfo pipinfo;
	int disnnecting_timeout = DISCONNECT_TIME_OUT;
	int fd = ndis_open();
	
	
	if(fd == -1)
	{
		d_printf("ndis_open failed.\n");
		return -1;
	}
	ret = ndis_get_status(fd,&pipinfo);	

	if(ret<0)
	{
		d_printf("init failed.\n");
		ndis_close(fd);
		return -1;
	}
	d_printf("ndis disconnect test! \n");
	// disconnect to internet	
	{
		ret = ndis_disconnect(fd);
		if(ret!=0)
		{
			d_printf("ndis_disconnect failed,ret=%d.\n",ret);	
            goto EXIT_DISCON_PROGRAM;		
		}else
		{
			d_printf("ndis_disconnect success.\n");
		}		
	}
	
	// to release resource.
	while(disnnecting_timeout--)
	{
		ret = ndis_get_status(fd,&pipinfo);
		if(ret!=0)
		{
			d_printf("ndis_get_status failed,ret=%d.\n",ret);					
		}
		usleep(50000);

	}

EXIT_DISCON_PROGRAM:	
	ndis_close(fd);
	return 0;
}

static void dial_mngr_do_dial(dial_mngr_t *dial, UBOOL8 isPpp)
{
	int ret;
	int qmiModule = 0;
	__param_t *param;
	
        qmiModule = usb_moderm_match_qmi_module(MN(dial)->mdm->idVendor, MN(dial)->mdm->idProduct);    /* do generic connect */
        		
        param = GET_PRI(mn->par, __param_t);
		
	 if(qmiModule)
            qmi_module_connect(param->apn, param->username, param->password, 0, dial, isPpp);
	 else
	     dial_mngr_do_greneral_dial(dial, isPpp);
}

static int dial_mngr_dial_check(dial_mngr_t *dial)
{
    if (!dial)
    {
        printf_3g("", "dial is null\n");
        return -1;
    }

	if (modem_search(MN(dial)->mdm) != 0) {
		printf(STATUS_NO_USB"\n");
		CDMG_SEND_MSG(dialfail, "%s", "");		 
		return -1;
	}

	if (!MN(dial)->run_on_diald) 
		modem_get_pin_info(MN(dial)->mdm, 0);
	
	if (!modem_pin_is_ready(MN(dial)->mdm)) {
		/*add notify user code here*/
		printf(PIN_INFO_PIN"\n");
		CDMG_SEND_MSG(dialfail, "%s", "");	
		return -1;
	}

	if (!MN(dial)->run_on_diald) 
		modem_get_reg_info(MN(dial)->mdm, 0);
	
	if (!modem_reg_is_ready(MN(dial)->mdm)) {
		/*add notify user code here*/
		printf(REG_INFO_NOT_REG"\n");
		CDMG_SEND_MSG(dialfail, "%s", "");	
		return -1;
	}

	return 0;
}

/*
* at daemon, deciding to dial continue or not by the dial mechine
*/
static int __dial_mngr_daemon_dial(dial_mngr_t *dial)
{
	struct dial_state *s;

	s = &DIAL_GET_STAT(dial);
	
	fix_dial_stat(s);

	if ( dial_stat(s) == DAIL_STAT_DAILING) {
		debug_3g("", "already in dialing\n");
		return 0;
	}
	
	if ( dial_stat(s) == DAIL_STAT_UNDAILING) {
		debug_3g("","in undialing\n");
		return 0;
	}

	if ( dial_stat(s) == DAIL_STAT_DAILED) {
		debug_3g("","have be dialed\n");
		return 0;
	}

	change_dial_stat(s, DAIL_STAT_DAILING);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB
	web_mngr_event	(mn->web, WEB_EVENT_DIALING);
#endif

	debug_3g("","start to dial...\n");

	dial_mngr_dial(dial->dial_argc, dial->dial_argv);

	return 0;
}

static void dail_mngr_delay_timer(void *data)
{
	dial_mngr_t *dial = (dial_mngr_t *)data;

	d_printf("timer delaydail start\n");

	dial->delay = 0;

#if 0
	if (modem_search(mn->mdm) != 0)
		return;

	if (!modem_pin_is_ready(mn->mdm))
		return;

	if (!modem_reg_is_ready(mn->mdm))
		return;
#endif
	__dial_mngr_daemon_dial(dial);		

}

/*must run at daemon.
* 
* deciding the dial args and deciding to dial or not by the modem's status.
*
*/
int  dial_mngr_daemon_dial(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;
	char delay[10] = {0};
	
	dial->undial_flag = 0;
	dial->dial_argc = 0;
	dial->dial_try = 0;

	dial_mngr_del_timers();

	/*save the args*/
	cdmg_argv_to_cmd(argc, argv, dial->dial_opts_buf, CDMG_CMD_LINE_LEN);
	cdmg_cmd_to_argv(dial->dial_opts_buf, &dial->dial_argc, dial->dial_argv);
	

	/*get delay*/
	if (CDMG_GET_ARG("delay", delay)) {
		dial->delay = strtoul(delay, 0,10);
	}
	else
		dial->delay = 0;


	if (mn->mdm->status != SEARCH_FINISHED)
		return 0;

	if (!modem_pin_is_ready(mn->mdm))
		return 0;

	if (!modem_reg_is_ready(mn->mdm))
		return 0;

	if (dial->delay) {
		timer_set(dial->delay , 
			"dail_mngr_delay_timer", 
			dail_mngr_delay_timer, 
			(void *)dial);
		return 0;
	}
	
	__dial_mngr_daemon_dial(dial);

	return 0;
}

/*
* the chat task end, do the last dial action
*/
static int dial_mngr_dial_chat_end(int argc, char *argv[])
{
	__dial_mngr_t *__dial = GET_PRI(mn->dial, __dial_mngr_t);

	d_printf("Chat end\n");
	
	/*delete the timeout timer*/
	if (__dial->chat_timer) {
		timer_del(__dial->chat_timer);
		__dial->chat_timer = 0;
	}
	
	if (CDMG_GET_ARG("0", 0)) {
		d_printf("chat fail\n");
	} else
		d_printf("chat success\n");
	
	if (mn->dial->undial_flag) {
		d_printf("have undial\n");
		return 0;
	}

	/*update modem info from the chat task*/
	modem_read_info(mn);

	__dial->do_chat = 0;

	if (modem_get_ip_port(mn->mdm, 0) <= 0) {
		printf_3g("", "can not get tty for dial\n");
		CDMG_SEND_MSG(dialfail, "%s", "");
		return 0;
	}
	
	param_product_pppd_cfg(mn->par, 0);

	d_printf("Start t dial...");
	dial_mngr_do_dial(mn->dial, 1);

	return 0;
}
__CDMG_SETUP_MSG(dial_mngr_dial_chat_end, 0, 1, 
		dial_mngr_dial_chat_end, "");

/*chat timeout timer*/
static void dial_chat_timeout(void *date)
{
	__dial_mngr_t *__dial = (__dial_mngr_t *)date;

	__dial->chat_timer = 0;

	/*kill chat */
	if (__dial->do_chat) {
		d_printf("***error chat timeout! kill the chat task\n");
		kill(__dial->do_chat, SIGKILL);
		__dial->do_chat = 0;
		CDMG_SEND_MSG(dialfail, "%s", "");
	}
}

static int process_connect_end(int argc, char *argv[])
{   
    timer_del_by_token("connect_timeout_timer");
    mn->do_connect = 0;
    //printf("%s:result = %s\n", __func__, argv[1]);
    if (argv[1][0] == '1')
        dial_mngr_do_dial(mn->dial, 0);
    else
        CDMG_SEND_MSG(dialfail, "%s", "");
    return 0; 
}
CDMG_SETUP_MSG(connectend, process_connect_end, "");

/* ִ�����ӳ�ʱ������Ҫɱ������ */
static void connect_timeout_timer(void *data)
{
	d_printf("connect timeout, kill the task %d\n", mn->do_connect);
	kill(mn->do_connect, SIGKILL);
	mn->do_connect = 0;
    CDMG_SEND_MSG(dialfail, "%s", "");
}
/*do the  really dial action*/
static int __dial_mngr_dial(dial_mngr_t *dial, int argc, char *argv[])
{
	int get_ip_port = 0;
	char demand[10] = {0};	
	__dial_mngr_t *__dial;
    UBOOL8 enblNDIS = 0;
    WAN_CONFIG_TYPE type = TYPE_PPP;
    char rbuf[10] = {0};

    if (!dial)
    {
        printf_3g("", "dial is null\n");
        return -1;
    }

	if (dial_mngr_dial_check(dial) != 0)
		return -1;


	d_printf("creat chat script\n");
	at_product_chat_script(MN(dial)->at, argc, argv);


	param_init(MN(dial)->par);
	param_get_from_user(MN(dial)->par, argc, argv);
	param_get_item(MN(dial)->par, "demand", demand);
	param_get(MN(dial)->par);
	
	if (demand[0])
		dial->demand_dial = 1;
	else 
		dial->demand_dial = 0;
	
	if (cdmg_get_arg(argv, "m", 0, 0)) {
		d_printf("try do chat at pppd\n");
		dial->chat_at_pppd = 1;
	} else
		dial->chat_at_pppd = 0;
	
    if (cdmg_get_arg(argv, "ndis", rbuf, sizeof(rbuf) - 1)) {
        enblNDIS = ((rbuf[0] == '0')?0:1);
    }
    
    if (cdmg_get_arg(argv, "type", rbuf, sizeof(rbuf) - 1)) {
        type = atoi(rbuf);
    }
    printf("%s:enblNDIS = %d, type = %d\n", __func__, enblNDIS, type);
    record_3g("enblNDIS = %d, type = %d\n", enblNDIS, type);
    if (enblNDIS && (type == TYPE_IPOE))
    {
        struct USB_MODERM_DEVICE *dev = usb_moderm_get_device(MN(dial)->mdm->idVendor, MN(dial)->mdm->idProduct);

        if (dev == NULL)
        {
            dev = usb_moderm_get_device(0x00, 0x00);    /* do generic connect */
        }
        d_printf("MN(dial)->mdm->idVendor = %04x, MN(dial)->mdm->idProduct = %04x\n",
                MN(dial)->mdm->idVendor, MN(dial)->mdm->idProduct);
        if ((   mn->do_connect = fork_3g()) == 0) {
            int result = 0;
            
            if (dev && dev->connect)
            {
                if (dev->connect(MN(dial)->mdm) < 0)
                {
                    result = 0;
                }
                else
                {
                    result = 1;
                }
            }
            
            set_ndis_interface(1);
            
            CDMG_SEND_MSG(connectend, "%d", result);
            exit(0);
     	} else if (mn->do_connect  > 0) {
    		timer_set(30, 
    			"connect_timeout_timer",
    			connect_timeout_timer, (void *)mn);
    	}       
        /*
        set_ndis_interface(1);
        if (dev && dev->connect)
        {
            if (dev->connect(MN(dial)->mdm) < 0)
            {
                CDMG_SEND_MSG(dialfail, "%s", "");
                return -1;
            }
        }
        dial_mngr_do_dial(dial, 0);
        */
        return 0;       
    }
    if (!enblNDIS)
    {
	get_ip_port = modem_get_ip_port(MN(dial)->mdm, 0);

	/*scb+ 2012-2-20 for default, let chat at pppd*/
	if(get_ip_port) {
		d_printf("Get ip port, chat at pppd\n");
		dial->chat_at_pppd = 1;
	} else {
		d_printf("Not point out chat tty or "
			"No interrupt endpoint end at the usb interfaces,"
			"so chat before pppd session\n");
	}

	if (get_ip_port && dial->chat_at_pppd ) {
		param_product_pppd_cfg(MN(dial)->par, 1);	
    		dial_mngr_do_dial(dial, 1);
		return 0;
    	}
	}

	if (!mn->run_on_diald) {
		if (modem_do_chat(MN(dial)->mdm, dial->demand_dial) != 0) {
			printf_3g("", "chat failse\n");
			CDMG_SEND_MSG(dialfail, "%s", "");
			return -1;
		}	

		param_product_pppd_cfg(MN(dial)->par, 0);	

		dial_mngr_do_dial(dial, 1);
		return 0;
	}

	wan_mngr_set_3g_link_info(WAN_S_DIALING);
	
	__dial = GET_PRI(dial, __dial_mngr_t);

	d_printf("Before chat, set timer\n");
	__dial->chat_timer = timer_set(60, "dial_chat_timeout", 
		dial_chat_timeout, 
		(void*)__dial);
	
	__dial->do_chat = fork_3g();
	
	if (__dial->do_chat > 0) {
		d_printf("fork %d to chat \n", __dial->do_chat);
		return 0;	
	} else if (__dial->do_chat < 0) {
		CDMG_SEND_MSG(dialfail, "%s", "");
		return -1;	
	}
	

	/*sub process for try chat*/
	pid_t chat_pid = getpid();	
	d_printf("No ip tty,%d start "
		"to chat to select the tty for pppd session\n", 
		chat_pid);	
	if (modem_do_chat(MN(dial)->mdm, dial->demand_dial) != 0) {
		printf_3g("", "chat failse\n");
		modem_write_info();
		CDMG_SEND_MSG(dial_mngr_dial_chat_end, "%s", " -0");
		exit(0);
	}
	modem_write_info();
	CDMG_SEND_MSG(dial_mngr_dial_chat_end, "%s", " -1");
	exit(0);
}

static void dial_mngr_dial(int argc, char *argv[])
{
	record_3g("dial start %s", "");
    
	/*if no mn, create it*/
	mngr_start(&mn, 
		MNGR_START_CREATE_MODEM|
		MNGR_START_CREATE_DIAL|
		MNGR_START_CREATE_AT|
		MNGR_START_CREATE_PAR|
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB	
		MNGR_START_CREATE_WEB|
#endif		
		MNGR_START_CREATE_PIN);

	if (!mn->run_on_diald) 
		lib3g_install_modules();

	

#ifdef SUPPORT_IP_CONNECT_CHECK
	if (mn->cnn)
		conn_mngr_cancel(mn->cnn);
#endif

	__dial_mngr_dial(mn->dial, argc, argv);

#ifdef SUPPORT_IP_CONNECT_CHECK
	if (mn->cnn)
		conn_mngr_set(mn->cnn);
#endif
}

FUNC(dial, "dial to the internet\n"
                   " args: -m --demand=1 --delay=0 --idle=0 --apn=Unicom --number=*99# --nettype=xx --user=xx --password=xx\n"
                   "	-m: do chat at pppd\n")
{
	int ret = CDMG_FORK(0, 0, 0);

	if (ret == CDMG_ENV_DAEMON) {
		/*at daemon*/
		dial_mngr_daemon_dial(argc, argv);
	}  else if (ret == CDMG_ENV_USER) {
		/*the user call dial cmd, not uses arg: '-s', so do dial here*/
		dial_mngr_dial(argc, argv);
	}

	/*the user usd arg: '-s', to let the cmd to run at daemon*/
	return 0;
}



FUNC(wait, "wait the dial or undial finished\n"
		    "args: --action=dial/undial --time=xx(unit:s)")
{

	int i = 0;
	int time = 0;
	char act[12] = {0};
	char ti[12] = {0};		
	char buf[1024] = {0};
	char rbuf[10] = {0};
	char cmd[128] = {0};
	char tmp[] = "/var/wait_tmp_f";
	
	d_printf("enter\n");

	cdmg_get_arg(argv, "time", ti, sizeof(ti)-1);
	cdmg_get_arg(argv, "action", act, sizeof(act)-1);	

	if (strcmp(act, "dial") != 0 && 
			strcmp(act, "undial") != 0)
		strcpy(act, "dial");
	
	time = strtoul(ti, 0, 10);
	if (time < 0)
		time = 1;

	/*wait for finishing */   
	for (i = 0; i < (time * 5); i++) {
		/*0.2 second*/
		usleep(100000);
		
		snprintf(cmd, sizeof(cmd),  
			"ifconfig %s>%s 2>/dev/null", 
			g_usb_dongle_ifname, tmp);		
		system(cmd);
		
		usleep(100000);

		memset(buf, 0, sizeof(buf));
		if (lib3g_read_file(tmp, buf, 1024) != 0) {
			unlink(tmp);
			ERR("can not read file %s\n", tmp);
			
			if (strcmp(act, "dial") == 0 )
				CDMG_SEND_MSG(dialfail, "%s", "");

			
			return -1;
		}
		unlink(tmp);
		
		if (strcmp(act, "dial") == 0) {	
			lib3g_reg_exec(buf, "/[\n\r\t ]UP[\n\t ]/", 
				rbuf, 10);
			
			if ( rbuf[0]) {
				printf("OK");
				return 0;
			}
		} else {
			if (!buf[0]) {
				CDMG_SEND_MSG(undialok, "%s", "");
				printf("OK");
				return 0;
			}
		}
	}
	if (strcmp(act, "dial") == 0 )
		CDMG_SEND_MSG(dialfail, "%s", "");
	
	printf("FAILSE");
	return -1;
}


static void dial_mngr_daemon_do_undial()
{
	__dial_mngr_t *__dial = GET_PRI(mn->dial, __dial_mngr_t);
    struct wan_config *config = wan_mngr_get_config();

    d_printf("%s:config->enblNDIS = %d, config->type = %d\n", __func__, config->enblNDIS, config->type);
    if (config && config->enblNDIS && (config->type == TYPE_IPOE))
    {
        struct USB_MODERM_DEVICE *dev = usb_moderm_get_device(mn->mdm->idVendor, mn->mdm->idProduct);

        if (dev == NULL)
        {
            dev = usb_moderm_get_device(0x00, 0x00);
        }
        d_printf("mn->mdm->idVendor = %04x, mn->mdm->idProduct = %04x",
                mn->mdm->idVendor, mn->mdm->idProduct);
        if (dev && dev->disconneted)
        {
            if (fork_3g() == 0) {
                dev->disconneted(mn->mdm);
                exit(0);
            }else{
                sleep(3);
            }

        }    
    }   
	debug_3g("", "start to undial\n");

	wan_mngr_set_3g_link_info(WAN_S_UNDIALING);
	
	if (__dial->do_chat) {
		kill(__dial->do_chat, SIGKILL);
		__dial->do_chat = 0;
	}

	dial_mngr_do_undial();	
}

/*the undial action's part done at daemon*/
static void __dial_mngr_daemon_undial(dial_mngr_t *dial)
{
	struct dial_state *s;

	s = &DIAL_GET_STAT(dial);	

	if ( dial_stat(s) == DAIL_STAT_UNDAIL) {
		
		lib3g_send_mobile_chage_msg(MNGR_MSG_UNDIALOK);
		
		wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);

		d_printf("cancel againdial timer\n");

		debug_3g("","not in dial\n");
		
		return;
	}

	if ( dial_stat(s) == DAIL_STAT_DAILING) {
		
		debug_3g("","in dialing\n");
		
		return;
		
	}

	if ( dial_stat(s) == DAIL_STAT_UNDAILING) {
		
		debug_3g("","already undialing\n");
		
		return;
		
	}

	change_dial_stat(s, DAIL_STAT_UNDAILING);

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB		
	web_mngr_event	(mn->web, WEB_EVENT_STOP);
#endif
	
	debug_3g("","start to undial\n");

	dial_mngr_daemon_do_undial();
}

/*the undial action's part done at daemon*/
int  dial_mngr_daemon_undial(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;
	
	dial->undial_flag = 1;

	dial_mngr_del_timers();

	/*do continue*/
	__dial_mngr_daemon_undial(dial);

	return 0;
}

static void dial_mngr_do_undial()
{
	int i = 0;
	pid_t *pid_list  = 0;
    struct stat st;
	
	int qmiModule = 0;
	
      qmiModule = usb_moderm_match_qmi_module(MN(mn->dial)->mdm->idVendor, MN(mn->dial)->mdm->idProduct); 

	if(qmiModule)
	 {
          qmi_module_disconnect();
	 }
	d_printf("undial...\n");
    /* dhcp��ʽ��û�б�Ҫȥ�ȴ���ֱ�ӷ��سɹ��Ϳ����� */
    if (stat(DHCP_PID_FILE, &st) ==0)
    {
        pid_list = lib3g_find_pid_by_name(DHCP_PID_FILE);
        for( i = 0; pid_list && pid_list[i] > 0; i++) 
            kill(pid_list[i], SIGTERM);
        
        if(pid_list )
            free(pid_list);
        set_ndis_interface(0);
        CDMG_SEND_MSG(undialok, "%s", "");       
        return;
    }

	pid_list = lib3g_find_pid_by_name(PPPD_CMD);
	for( i = 0; pid_list && pid_list[i] > 0; i++) 
		kill(pid_list[i], SIGTERM);

	if(pid_list )
		free(pid_list);
	
	if (fork_3g() == 0) { 
		CDMG_DO_FUNC(wait, "--action=undial --time=15");
		exit(0);		
	}
}

FUNC(undial,"dis_connect to the inetnet\n"
			  "\targs: -s --force  let daemon to force undial" )
{	
	int ret = CDMG_FORK(0, 0, 0);
	
	if (ret == CDMG_ENV_DAEMON) {
		/*call at deamon*/
		if (CDMG_GET_ARG("force", 0))
			dial_mngr_daemon_do_undial();
		else
			dial_mngr_daemon_undial(argc, argv);
	} else if (ret == CDMG_ENV_USER) {
		dial_mngr_do_undial();
	}

	return 0;
}


FUNC(hungup,"hugup the modem\n")
{
	if (CDMG_FORK(0,0,0) == CDMG_ENV_USER_SENT)
		return 0;
	
	mngr_start(&mn, MNGR_START_CREATE_MODEM
		|MNGR_START_CREATE_DIAL
		|MNGR_START_CREATE_AT
		|MNGR_START_CREATE_PAR);

	modem_hangup(mn->mdm);

	return 0;
}

/***************************************************************************/
static void change_dial_stat(struct dial_state *s, dialstat_t newstat)
{

	if (gettimeofday (&s->tv , 0 ) != 0) {
		printf("clock_gettime failed, set timestamp to 0");
		s->tv.tv_sec = 0;
		s->tv.tv_usec = 0;
	}

	d_printf("dial stat chang<%s-->%s>\n", 
		dialstat_name(s->dialstat), 
		dialstat_name(newstat));
	
	s->dialstat = newstat;	

#ifdef SUPPORT_3G_WAN_MANAGEMENT	
	/*note:connect status is change at linkup msg,because it needs dns.*/
	if (newstat == DAIL_STAT_DAILING)
		wan_mngr_set_3g_link_info(WAN_S_DIALING);
	else if (newstat == DAIL_STAT_UNDAILING)
		wan_mngr_set_3g_link_info(WAN_S_UNDIALING);				
#endif	
	
}

static int pass_time(struct dial_state *s)
{
	struct timeval _tv  = {0,0};

	gettimeofday(&_tv, 0);

	return ((_tv.tv_sec >s->tv.tv_sec)?
		(_tv.tv_sec -s->tv.tv_sec):
		(_tv.tv_sec + (0xffffffff - s->tv.tv_sec)));
	
}

static dialstat_t dial_stat(struct dial_state *s)
{
	return s->dialstat;	
}

static void fix_dial_stat(struct dial_state *s)
{
	char buf[1024] = {0};
	char cmd[80] = {0};

	snprintf(cmd, sizeof(cmd),  
		"ifconfig %s>/var/fix_dial_stat_f 2>/dev/null",
		g_usb_dongle_ifname);
	system(cmd);

	if ((lib3g_read_file("/var/fix_dial_stat_f", buf, 1024)) == 0 && 
				buf[0]) {		
		/*there is 3g interface */
		if ((s->dialstat == DAIL_STAT_UNDAIL) && (strcmp(g_usb_dongle_ifname, IF_PPP_NAME) == 0)) {
			/*when diald start, the 3g modem is aleady dialed */
			s->dialstat = DAIL_STAT_DAILED;
            d_printf("exist 3g interface, set dialstat to DAIL_STAT_DAILED\n");
			goto _end;
		} else if (s->dialstat == DAIL_STAT_DAILING) {
			/* dial success,but linkup msg is not send success*/
			if (pass_time(s) > 20) {
				s->dialstat = DAIL_STAT_DAILED;
				goto _end;
			}
		} else if (s->dialstat == DAIL_STAT_UNDAILING) {
			/*undial failed*/
			if (pass_time(s) > 5) {
				s->dialstat = DAIL_STAT_DAILED;
				goto _end;
			}
		}
	}
	else 
	{
		/*no 3g interface*/		
		if (s->dialstat == DAIL_STAT_DAILED) {
			/*when start*/
			s->dialstat = DAIL_STAT_UNDAIL;
			goto _end;	
		} else if (s->dialstat == DAIL_STAT_DAILING) {
			/* dial failed */
			if (pass_time(s) > 20) {
				s->dialstat = DAIL_STAT_UNDAIL;
				goto _end;
			}
		} else if (s->dialstat == DAIL_STAT_UNDAILING) {
			/* undial success, but not receive the linkdown msg */
			if (pass_time(s) > 5) {
				s->dialstat = DAIL_STAT_UNDAIL;
				goto _end;
			}
		}
		
	}

	_end:
		unlink("/var/fix_dial_stat_f");

}


/********************************************************/

static int  dial_mngr_process_demandok(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;
	
	change_dial_stat(&DIAL_GET_STAT(dial), DAIL_STAT_DAILED);	
	CDMG_DO_FUNC(wanlinkinfo, " --act=set --wanname=%s""  --link=%d"
		" --dns=2.2.2.2,1.1.1.1",
		g_usb_dongle_ifname, WAN_S_CONNECTING);
	lib3g_send_mobile_chage_msg(MNGR_MSG_DEMANDOK);

	return 0;
}
__CDMG_SETUP_MSG(demandok, 0, 1, dial_mngr_process_demandok, "");

/*for chat at syn mode*/
static int diald_msg_action_connect_start(int argc, char *argv[], 
			char *rbuf, int rlen)
{
	if (mn->dial->undial_flag) {
		d_printf("have undial\n");
		
		if (rbuf && rlen > 0) {
			memset(rbuf, 0, rlen);
			strncpy(rbuf, "undial", rlen - 1);
			return strlen(rbuf) + 1;
		} else
			return 0;
	}
	
#ifdef SUPPORT_IP_CONNECT_CHECK
	conn_mngr_cancel(mn->cnn);
#endif	

	if (rlen > 0 && rbuf) {
		memset(rbuf, 0, rlen);
		strncpy(rbuf, "connect_start_ok", rlen - 1);
		return (strlen(rbuf) +1);
	} else
		return 0;
}
__CDMG_SETUP_GET(connect_start, 1, diald_msg_action_connect_start, 
			0, 0, "");


/*diald msg system do it at asyn mode, because it will take some time*/
static int diald_msg_action_connect_chat(int argc, char *argv[], 
			char *rbuf, int rlen)
{
	int ret; 

	if (mn->dial->undial_flag) {
		d_printf("have undial\n");
		if (rlen > 0 && rbuf) {
			memset(rbuf, 0, rlen);
			strncpy(rbuf, "undial", rlen - 1);
			return (strlen(rbuf) +1);
		} else
			return 0;		
	}
		
	
	ret = modem_try_chat(mn->mdm);
	
	if (ret == 0) {
		if (rlen > 0 && rbuf) {
			memset(rbuf, 0, rlen);
			strncpy(rbuf, "chat_OK", rlen - 1);
			return (strlen(rbuf) +1);
		} else
			return 0;
	} else {
		if (rlen > 0 && rbuf) {
			memset(rbuf, 0, rlen);
			strncpy(rbuf, "chat_ERROR", rlen - 1);
			return (strlen(rbuf) +1);
		} else
			return 0;
	}
}
__CDMG_SETUP_GET(connect_chat, 1, diald_msg_action_connect_chat, 
						1, 10, "");

static int diald_msg_action_connect_end(int argc, char *argv[], 
			char *rbuf, int rlen)
{
	if (mn->dial->undial_flag) {
		d_printf("have undial\n");
		if (rlen > 0 && rbuf) {
			memset(rbuf, 0, rlen);
			strncpy(rbuf, "undial", rlen - 1);
			return (strlen(rbuf) +1);
		} else
			return 0;	
	}


#ifdef SUPPORT_IP_CONNECT_CHECK
	conn_mngr_set(mn->cnn);
#endif

	timer_token_set(60, "demandfail");

	if (rlen > 0 && rbuf) {
		memset(rbuf, 0, rlen);
		strncpy(rbuf, "connectok", rlen - 1);
		return (strlen(rbuf) +1);
	} else
		return 0;	
}
__CDMG_SETUP_GET(connect_end, 1,	diald_msg_action_connect_end, 
			0, 0, "");

CDMG_FUNC(connect, 0, 0, 1, 0, 0, 0,
				"connect to network by at cmd to get the data tty name.\n"
				"call by pppd before connectting\n")
{
	char *rbuf = 0;

	/*Can not do at daemon*/
	if (CDMG_FORK(0, 0, 0) != CDMG_ENV_USER)
		return 0;

	/*let diald to do connect_start for syn mode*/
	if (CDMG_SEND_AND_GET(rbuf, 5000000, connect_start, "%s", "") >= 0 && rbuf) {
		d_printf("%s\n", rbuf);
		free(rbuf);
		rbuf = 0;
	}

	/*let diald to do chat for asyn mode*/
	if (CDMG_SEND_AND_GET(rbuf, 5000000, connect_chat, "%s", "") >= 0 && rbuf) {
		d_printf("%s\n", rbuf);
		free(rbuf);
		rbuf = 0;
	}

	/*let diald to do connect_end for synch mode*/
	if (CDMG_SEND_AND_GET(rbuf, 5000000, connect_end,"%s", "") >= 0 && rbuf) {
		d_printf("%s\n", rbuf);
		free(rbuf);
		rbuf = 0;
	}
	
	return 0;
}

/*
** This is the inner message, when ipup command is done call this command
** to do the remaind things.
**
*/
static int dial_mngr_process_msg_linkup(int argc, char *argv[])
{
	char buf[1024] = {0};
	dial_mngr_t *dial = mn->dial;

	d_printf("enter\n");
	
	dial_mngr_del_timers();
	
	if (dial->demand_dial )
		timer_token_set(0, "demandfail");
	else {
		change_dial_stat(&DIAL_GET_STAT(dial), 
			DAIL_STAT_DAILED);
	}

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB		
	web_mngr_event	(mn->web, WEB_EVENT_DIAL_SUCCESS);
#endif


	if (dial->undial_flag) {
		/*at dialing, the user set undial, so need to undial"*/
		dial->undial_flag = 0;
		d_printf("undial...\n");
		__dial_mngr_daemon_undial(dial);
	} else {	
		char dns1[IFNAME_LEN+1] = {0};
		char dns2[IFNAME_LEN+1] = {0};
        char ip[32] = {0};
        char gateway[32] = {0};
        char netmask[32] = {0};
		char sessid[8] = {0};

		CDMG_GET_ARG("dns1", dns1);
		CDMG_GET_ARG("dns2", dns2);
		CDMG_GET_ARG("sessid", sessid);
        CDMG_GET_ARG("ip", ip);
        CDMG_GET_ARG("gateway", gateway);
        CDMG_GET_ARG("netmask", netmask);

		CDMG_DO_FUNC(wanlinkinfo, "--wanname=%s --act=set --link=%d --dns=%s,%s",
			g_usb_dongle_ifname, WAN_S_CONNECTED, dns1, dns2);

		/*send the msg to ssk or logic*/
        strcpy(buf, "linkup");
        if (dns1[0])
            lib3g_fstrncat(buf, sizeof(buf), " --dns1=%s", dns1);
        if (dns2[0])
            lib3g_fstrncat(buf, sizeof(buf), " --dns2=%s", dns2);
        if (ip[0])
            lib3g_fstrncat(buf, sizeof(buf), " --ip=%s", ip);
        if (gateway[0])
            lib3g_fstrncat(buf, sizeof(buf), " --gateway=%s", gateway);
        if (netmask[0])
            lib3g_fstrncat(buf, sizeof(buf), " --netmask=%s", netmask);
		lib3g_send_mobile_chage_msg(buf);
	}

	return 0;
}
__CDMG_SETUP_MSG(linkup, 1, 1, dial_mngr_process_msg_linkup, 
		"Do the remaind things of the cmd 'ipup'\n");

#ifdef	SUPPORT_ALLWAYS_CONNECTED
/*scb+ 2012-6-8
* when theminal by peer, the interface maybe exist, 
* so need to wait untill it disapear.this timer is used for that.
*/
static void dial_mngr_wait_intf_disappear_timer(void *data)
{
	int can_dial = 0;
	int sock = 0;
	dial_mngr_t *dial = mn->dial;
	struct ifreq ifreq;

	if (!wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_PIN_READY|
			WAN_COND_CHECK_NETWORK)) {
		d_printf("3g not valid\n");
		return;
	}

	if (dial->undial_flag) {
		d_printf("user said undial\n");
		return;
	}

	/*check if the inteface if is exist*/
	memset(&ifreq, 0, sizeof(ifreq));
	strncpy(ifreq.ifr_ifrn.ifrn_name, g_usb_dongle_ifname, IFNAMSIZ-1);
	if ((sock = socket(PF_INET, SOCK_DGRAM, 0)) == -1)
		debug_3g("3g-mngr-dial.c", "DIAL", 
			"create socke error:%s\n", 
			strerror(errno));
	else {
		if (ioctl(sock, SIOCGIFADDR, &ifreq, sizeof(ifreq)) == -1 && 
				errno == ENODEV) {
			can_dial = 1;
		}
		close(sock);
	}

	if (!can_dial) {
		d_printf("3g intf exist, try later\n");
		timer_set(3, 
			"dial_mngr_wait_intf_disappear_timer", 
			dial_mngr_wait_intf_disappear_timer,
			(void*)0);
	} else {
		d_printf("3g intf not exist, dail again\n");
		wan_mngr_linkdown_dial();
	}
}
#endif

static int dial_mngr_process_msg_linkdown(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;
	
	if (dial->demand_dial == 0) {
#ifdef	SUPPORT_ALLWAYS_CONNECTED
		if (!dial->undial_flag) {
			dial->dial_try = 0;
			
			/*wait the old 3g interface disappear, then dial again*/
			timer_set(5, 
				"dial_mngr_wait_intf_disappear_timer",
				dial_mngr_wait_intf_disappear_timer,
				(void *)0);
		}
#endif
		change_dial_stat(&DIAL_GET_STAT(dial),
			DAIL_STAT_UNDAIL);
		wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);
		lib3g_send_mobile_chage_msg(MNGR_MSG_LINKDOWN);	
	}
	else {
		lib3g_send_mobile_chage_msg(MNGR_MSG_DEMANDDOWN);
		wan_mngr_set_3g_link_info(WAN_S_CONNECTING);
	}

	return 0;
}
CDMG_SETUP_MSG(linkdown, dial_mngr_process_msg_linkdown, 
		"process the cmd 'ipdown' send by pppd\n");

static int dial_mngr_process_demandfail(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;

    if (!dial)
    {
        printf_3g("", "dial is null\n");
        return -1;
    }
    
	if (dial->undial_flag || !modem_is_ready(MN(dial)->mdm) ) {
		change_dial_stat(&DIAL_GET_STAT(dial), 
			DAIL_STAT_UNDAIL);
		wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);
		CDMG_DO_FUNC(undial, "%s", "");
		lib3g_send_mobile_chage_msg(MNGR_MSG_DEMANDFAIL);
		asyn_modem_hangup(MN(dial)->mdm);	
	} else
		d_printf("demand failse\n");
	
	return 0;
}		
CDMG_SETUP_MSG(demandfail, dial_mngr_process_demandfail, "");

static void dial_mngr_process_againdial_timer(void *data)
{
	dial_mngr_t *dial = (dial_mngr_t *)data;
		
	if (dial->undial_flag) 
		d_printf("undial flag have been set, not need to dial again\n");
	else {		
		lib3g_send_mobile_chage_msg(MNGR_MSG_DIALAGAIN);
        /* dhcp process must be killed here*/
        {
            int i = 0;
            pid_t *pid_list  = 0;
            struct stat st;
            if (stat(DHCP_PID_FILE, &st) ==0)
            {
                pid_list = lib3g_find_pid_by_name(DHCP_PID_FILE);
                for( i = 0; pid_list && pid_list[i] > 0; i++) {
                    printf("%s %d kill pid:%d\r\n", __FUNCTION__, __LINE__, pid_list[i]);
                    kill(pid_list[i], SIGTERM);
                }

                if(pid_list)free(pid_list);
                
                unlink(DHCP_PID_FILE);
            }
        }
		
		__dial_mngr_daemon_dial(dial);
	}
}

static int dial_mngr_process_dialfail(int argc, char *argv[])
{
	dial_mngr_t *dial = mn->dial;
    struct wan_config *config = wan_mngr_get_config();    
	
    if (!dial)
    {
        printf_3g("", "dial is null\n");
        return 0;
    }

	change_dial_stat(&DIAL_GET_STAT(dial), DAIL_STAT_UNDAIL);
	
	asyn_modem_hangup(MN(dial)->mdm);

	timer_del_by_token("wan_mngr_manual_dial_timer");
	timer_del_by_token("dial_mngr_process_againdial_timer");

    d_printf("%s:config->enblNDIS = %d, config->type = %d\n", __func__, config->enblNDIS, config->type);
    if (config && config->enblNDIS && (config->type == TYPE_IPOE))
    {
        struct USB_MODERM_DEVICE *dev = usb_moderm_get_device(mn->mdm->idVendor, mn->mdm->idProduct);

        d_printf("mn->mdm->idVendor = %04x, mn->mdm->idProduct = %04x",
                mn->mdm->idVendor, mn->mdm->idProduct);
        if (dev == NULL)
        {
            dev = usb_moderm_get_device(0x00, 0x00);
        }
        if (dev && dev->disconneted)
        {
            if (fork_3g() == 0) {
                dev->disconneted(mn->mdm);
                exit(0);
            }else{
                sleep(4);
            }

        }
    }
	if (!wan_mngr_cond_check(
			WAN_COND_CHECK_3G_ENBL|
			WAN_COND_CHECK_MODEM_READY|
			WAN_COND_CHECK_3G_CONN_EXIST|
			WAN_COND_CHECK_PIN_READY|			
			WAN_COND_CHECK_NETWORK)) {
		lib3g_send_mobile_chage_msg(MNGR_MSG_DIALFAIL);
		wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);
		d_printf("3g not valid\n");
		return 0;
	}

	if (!dial->undial_flag) {
		int tick = 0;
		
		++dial->dial_try;
		tick = 1+(dial->dial_try-1)*4;
		if (tick > 30)
			tick = 30;
		
		timer_set(tick, "dial_mngr_process_againdial_timer", 
			dial_mngr_process_againdial_timer, 
			(void *)dial);		
			
		lib3g_send_mobile_chage_msg(MNGR_MSG_DIALWAITING);
		wan_mngr_set_3g_link_info(WAN_S_DIALWAITING);	

#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB		
		web_mngr_event	(mn->web, WEB_EVENT_DIAL_WAITING);
#endif
	} 
	else  {
#if 0		
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB		
		web_mngr_event	(mn->web, WEB_EVENT_DIAL_FAILE);
#endif	
		lib3g_send_mobile_chage_msg(MNGR_MSG_DIALFAIL);
		d_printf("dial faise, change the 3g wan status to disconnect\n");
#endif	
		wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);
	}
	
	return 0;
}		
__CDMG_SETUP_MSG(dialfail, 0, 1, dial_mngr_process_dialfail, "");

static int  dial_mngr_process_undialok(int argc, char *argv[])
{	
	dial_mngr_t *dial = mn->dial;
	
	d_printf("enter\n");

    if (!dial)
    {
        printf_3g("", "dial is null\n");
        return 0;
    }
    
	dial->undial_flag = 0;
	change_dial_stat(&DIAL_GET_STAT(dial), DAIL_STAT_UNDAIL);
	wan_mngr_set_3g_link_info(WAN_S_DISCONNECTED);

	/*if hotunplug, need not to do this*/
	if (MN(dial)->mdm->status == SEARCH_FINISHED) {
		d_printf("do modem_hangup\n");
		asyn_modem_hangup(MN(dial)->mdm);
		
#ifdef SUPPORT_POP_ENTER_PIN_CODE_WEB		
		web_mngr_event	(mn->web, WEB_EVENT_STOP);
#endif
#ifdef SUPPORT_IP_CONNECT_CHECK
        wan_mngr_ping_for_undial_notify();
#endif  
		lib3g_send_mobile_chage_msg(MNGR_MSG_UNDIALOK);
	}

	return 0;
}
__CDMG_SETUP_MSG(undialok, 0, 1, dial_mngr_process_undialok, "");

int dial_mngr_is_busy(dial_mngr_t *dial)
{
	struct dial_state *s;
	s = &DIAL_GET_STAT(dial);
		
	if (s->dialstat != DAIL_STAT_UNDAIL  && s->dialstat != DAIL_STAT_UNDAILING)
		return 1;

	return 0;
}

void dial_mngr_del_timers()
{
	//printf("enter\n");
	timer_del_by_token("dial_mngr_process_againdial_timer");
	timer_del_by_token("ready");
	timer_del_by_token("wan_mngr_manual_dial_timer");
	timer_del_by_token("dail_mngr_delay_timer");	
	timer_del_by_token("wan_mngr_switch_action_timer");
}


//if return FALSE, means interface is down
//if return TRUE, means interface is up
UBOOL8 isInterfaceUp(const char *devname) 
{

   UBOOL8  ret = 0;
   int  skfd;
   struct ifreq intf;

   if (devname == NULL || (skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
   {
      return ret;
   }
   
   strcpy(intf.ifr_name, devname);

#ifndef IFF_UP
#define	IFF_UP		0x1		/* interface is up */
#endif

   // if interface flag is down then return down
   if (ioctl(skfd, SIOCGIFFLAGS, &intf) != -1) 
   {
      if ((intf.ifr_flags & IFF_UP) != 0)
         ret = 1;
   }

   close(skfd);

   return ret;
}


