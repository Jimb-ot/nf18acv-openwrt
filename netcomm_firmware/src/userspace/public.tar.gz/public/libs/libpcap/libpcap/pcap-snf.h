pcap_t *snf_create(const char *, char *);
int snf_platform_finddevs(pcap_if_t **devlistp, char *errbuf);
