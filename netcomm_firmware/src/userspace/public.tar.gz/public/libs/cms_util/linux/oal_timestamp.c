/***********************************************************************
 *
<:copyright-BRCM:2007:DUAL/GPL:standard

   Copyright (c) 2007 Broadcom 
   All Rights Reserved

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as published by
the Free Software Foundation (the "GPL").

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


A copy of the GPL is available at http://www.broadcom.com/licenses/GPLv2.php, or by
writing to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

:>
 *
************************************************************************/

#include "../oal.h"
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <unistd.h>
//#include <linux/time.h>
/** OS dependent timestamp functions go in this file.
 */
void oalTms_get(CmsTimestamp *tms)
{
   struct timespec ts;
   SINT32 rc;

   if (tms == NULL)
   {
      return;
   }
//   printf("oalTms_get s=%d,C=%d\n",sizeof(CmsTimestamp),CLOCK_MONOTONIC);
//   rc = clock_gettime(CLOCK_MONOTONIC, &ts);
   rc = syscall(__NR_clock_gettime, CLOCK_MONOTONIC, &ts);
   if (rc == 0)
   {
      tms->sec = ts.tv_sec;
      tms->nsec = ts.tv_nsec;
//      printf("oalTms_get tms->sec:%d\n",tms->sec);
   }
   else
   {
      cmsLog_error("clock_gettime failed, set timestamp to 0");
      tms->sec = 0;
      tms->nsec = 0;
   }
}


CmsRet oalTms_getXSIDateTime(UINT32 t, char *buf, UINT32 bufLen)
{
	int          c;
   time_t       now;
	struct tm   *tmp;

   if (t == 0)
   {
      now = time(NULL);
   }
   else
   {
      now = t;
   }

   tmp = localtime(&now);
   if (!tmp)
   {
      cmsLog_error("localtime failed");
      return CMSRET_INTERNAL_ERROR;
   }
   memset(buf, 0, bufLen);
	//c = strftime(buf, bufLen, "%Y-%m-%dT%H:%M:%S%z", tmp);
	c = strftime(buf, bufLen, "%Y-%m-%dT%H:%M:%S", tmp);
   if ((c == 0) || (c+1 > (int) bufLen))
   {
      /* buf was not long enough */
      return CMSRET_RESOURCE_EXCEEDED;
   }
	
	FILE *fp = NULL;
	char line[256] = {0};
	if ((fp = fopen("/var/nc_sntptimezone", "r")) != NULL)
	{
		if(fgets(line, 256, fp) > 0)
		{
			line[strlen(line)] = '\0';
			if(line[0] == ' ')
				line[0] = '+';
		}
		else
		{
			strcpy(line, "+00:00");
		}
		strcat(buf, line);
		fclose(fp);
	}
#if 0

	/* fix missing : in time-zone offset-- change -500 to -5:00 */
   buf[c+1] = '\0';
   buf[c] = buf[c-1];
   buf[c-1] = buf[c-2];
   buf[c-2]=':';
#endif

   return CMSRET_SUCCESS;
}

CmsRet oalTms_getXSIDateTimeMicroseconds(UINT32 t, char *buf, UINT32 bufLen)
{
	int          c;
   time_t       now;
	struct tm   *tmp;
   struct timeval tv;
   char *format;

   if (t == 0)
   {
      now = time(NULL);
   }
   else
   {
      now = t;
   }

   gettimeofday(&tv, NULL);
   tmp = localtime(&now);
   if (!tmp)
      return CMSRET_INTERNAL_ERROR;
   format = (char *) malloc(bufLen);
   if (!format) 
      return CMSRET_RESOURCE_EXCEEDED;
   memset(buf, 0, bufLen);
   memset(format, 0, bufLen);
	c = strftime(format, bufLen, "%Y-%m-%dT%H:%M:%S.%%06u", tmp);
   snprintf(buf, bufLen, format, tv.tv_usec);
   free(format);
   if ((c == 0) || (c+1 > (int) bufLen))
   {
      /* buf was not long enough */
      return CMSRET_RESOURCE_EXCEEDED;
   }

   return CMSRET_SUCCESS;
}
