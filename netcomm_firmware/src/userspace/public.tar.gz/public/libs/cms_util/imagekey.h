
#ifndef _IMAGE_KEY_H
#define _IMAGE_KEY_H

#define KEY_256 "he9-4+M!)d6=m~we1,q2a3d1n&2*Z^%8$"
#define NOR_IV  "J%1iQl8$=lm-;8AE@"

#endif