#include <sys/socket.h>
#include <netinet/in.h>

#define DNS_DYN_CACHE_MAX_ENTRIES 100

typedef struct dns_dyn_list_struct
{
  struct dns_dyn_list_struct *prev;
  struct dns_dyn_list_struct *next;
  time_t expiry;
  struct in_addr addr;
  char cname[0];
} dns_dyn_list_t;

/* Entries from /var/hosts */
extern dns_dyn_list_t *dns_dyn_hosts;
/* Entries from dhcpd leases */
extern dns_dyn_list_t *dns_dyn_dhcp_leases;
/* Cahced responses */
extern dns_dyn_list_t *dns_dyn_cache;
extern int dns_dyn_cache_count;

/* Look up a list entry by CNAME and/or IP address in specified list */
dns_dyn_list_t *dns_dyn_list_find(dns_dyn_list_t *list, char *cname,
				  struct in_addr *addr);

/* Look up a list entry by CNAME and/or IP address in all lists. The search
 * order is hosts, DHCP leases, and cache */
dns_dyn_list_t *dns_dyn_find(dns_request_t *m);

/* Add an entry to specified list. -1 of expiry means infinite (for hosts) */
int dns_dyn_list_add(dns_dyn_list_t **list, char *cname, char *ip, int expiry);

/* Add a response to cache list */
int dns_dyn_cache_add(dns_request_t *m);

/* Add entries in /var/hosts to hosts list */
int dns_dyn_hosts_add(void);

/* Add entries in /var/udhcpd/udhcpd.leases to dhcp leases list */ 
//int dns_dyn_dhcp_leases_add(void);

/* Remove an entry from a specified list */
int dns_dyn_list_remove(dns_dyn_list_t **list, dns_dyn_list_t *entry);

/* Purge a list */
void dns_dyn_list_purge(dns_dyn_list_t **list);

/* Remove timeouted entries in the cache list */
int dns_dyn_cache_timeout(void);

/* Print out a list */
void dns_dyn_list_print(dns_dyn_list_t *list);

/* Print out all lists */
void dns_dyn_print(void);

#ifdef SUPPORT_DNS_POLICY
#define MAX_RECORDS     8   /* ���ֻ��8��wan���� */
#define MAX_POLICY_ROUTE_NUM     8
#define INVALID_MARK	0
struct BIND_DNS_INFO {
   char 	dns[80];
   UINT32	mark;	 /* record the mark value set by ebtables -t broute while config interface grouping(PMAP) or policy route */
   char 	ifName[BUFLEN_32];
   int		isIPv4;
   int		action;
   int		isPR;	 /* policy route */
};

typedef struct dns_server_list_struct
{
  struct dns_server_list_struct *pre;
  struct dns_server_list_struct *next;
  char if_name[32];
  struct in_addr primary_dns;
  struct in_addr second_dns;
  unsigned int mark;
  unsigned int pr_mark[MAX_POLICY_ROUTE_NUM];
  unsigned int count;
} dns_server_list_t;


typedef struct dns_server_struct_head
{
  struct dns_server_list_struct *head;
  struct dns_server_list_struct *tail;
  unsigned int nums;
} dns_server_head_t;

int add_dns_sever(dns_server_list_t *member);

int del_dns_sever(struct BIND_DNS_INFO *info);


int get_dns_server_by_mark(unsigned int mark, struct in_addr *primary_dns, struct in_addr *second_dns);

dns_server_list_t *get_member_by_ifname(const char *if_name);

#ifdef DMP_X_BROADCOM_COM_IPV6_1
#if 0
typedef struct dns_server_list_struct6
{
  struct dns_server_list_struct *pre;
  struct dns_server_list_struct *next;
  char if_name[32];
  struct in6_addr primary_dns;
  struct in6_addr second_dns;
  unsigned int mark[LAN_PORT_NUMS];
} dns_server_list_t6;

typedef struct dns_server_struct_head6
{
  struct dns_server_list_struct6 *head;
  struct dns_server_list_struct6 *tail;
  unsigned int nums;
} dns_server_head_t6;

int add_dns_sever6(dns_server_list_t6 *member);

int del_dns_sever_by_ifname6(const char *if_name);

int get_dns_server_by_mark6(unsigned int mark, struct in6_addr *primary_dns, struct in6_addr *second_dns);
#endif
#endif
#endif


