#include <sys/socket.h>
#include <sys/uio.h>
#include <linux/sockios.h>
#include <linux/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "dns_io.h"
#include "dns_decode.h"

/*****************************************************************************/
void *get_in_addr( struct sockaddr_storage *sa )
{
   if (sa->ss_family == AF_INET)
      return &(((struct sockaddr_in *)sa)->sin_addr);

   return &(((struct sockaddr_in6 *)sa)->sin6_addr);
}

int dns_read_packet(int sock, dns_request_t *m)
{
  struct sockaddr_storage sa;
  socklen_t salen;
  char remoteIP[INET6_ADDRSTRLEN];
  
  /* Read in the actual packet */
  salen = sizeof(sa);

#ifndef SUPPORT_DNS_POLICY  
  m->numread = recvfrom(sock, m->original_buf, MAX_PACKET_SIZE, 0,
		     (struct sockaddr *)&sa, &salen);
#else
#ifndef IP_MARK
#define IP_MARK 23
#endif
  char ctrl[MAX_PACKET_SIZE];
  struct msghdr msg;
  struct iovec iov;
  struct cmsghdr *cmsg;  
  void *pmark = NULL;

  iov.iov_base = (char *)m->original_buf;
  iov.iov_len = MAX_PACKET_SIZE;
  msg.msg_iov = &iov;
  msg.msg_iovlen= 1;
  msg.msg_control = ctrl;
  msg.msg_controllen = MAX_PACKET_SIZE; /*sizeof(struct cmsghdr) + sizeof(unsigned int)*/
  msg.msg_name = &sa;
  msg.msg_namelen = salen;

  m->numread = recvmsg(sock, &msg, MSG_WAITALL); 
  
  if ( m->numread < 0 ) {
    debug_perror("dns_read_packet: recvmsg\n");
    return -1;
  }
 
  for(cmsg=CMSG_FIRSTHDR(&msg); cmsg != NULL;cmsg =CMSG_NXTHDR(&msg,cmsg)) 
  {
      //printf("%s:cmsg->cmsg_type = %d\n", __func__, cmsg->cmsg_type);
      if (cmsg->cmsg_type == IP_MARK)
      {
          pmark = CMSG_DATA(cmsg);
          m->mark = *((unsigned int*)pmark);
          //printf("----------->%s:return mark = %04x\n", __func__, m->mark);
      }
      else 
      {
          debug("^^^^ BAD CMSG_HDR ^^^^^^^^\n");
      }
  }

#endif

  if(m->numread==MAX_PACKET_SIZE)
  {
    printf("dns_read_packet recv package size overflow\n");
  }
  
  if ( m->numread < 0) {
    debug_perror("dns_read_packet: recvfrom\n");
    return -1;
  }
  
  /* TODO: check source addr against list of allowed hosts */

  /* record where it came from */
  memcpy( (void *)&m->src_info, (void *)&sa, sizeof(sa));
  inet_ntop(sa.ss_family, get_in_addr(&sa), 
            remoteIP, INET6_ADDRSTRLEN);
  debug("received pkt from %s:%d len %d", 
        remoteIP, ((struct sockaddr_in *)&sa)->sin_port, m->numread);

  /* check that the message is long enough */
  if( m->numread < sizeof (m->message.header) )
  {
    debug("dns_read_packet: packet too short to be dns packet");
    return -1;
  }

  /* pass on for full decode */
  dns_decode_request( m );

  return 0;
}
/*****************************************************************************/
int dns_write_packet(int sock, struct sockaddr_storage *sa, dns_request_t *m)
{
  int retval;
  char dstIp[INET6_ADDRSTRLEN];

  inet_ntop(sa->ss_family, get_in_addr(sa), dstIp, INET6_ADDRSTRLEN);

  if (sa->ss_family == AF_INET)
  {
    retval = sendto(sock, m->original_buf, m->numread, 0, 
                    (struct sockaddr *)sa, sizeof(struct sockaddr_in));
  }
  else
  {
    retval = sendto(sock, m->original_buf, m->numread, 0, 
                    (struct sockaddr *)sa, sizeof(struct sockaddr_in6));
  }
  
  if( retval < 0 )
  {
    debug_perror("dns_write_packet: sendto");
  }

  return retval;
}
