#include "dproxy.h"

void dns_construct_reply( dns_request_t *m );
void dns_construct_error_reply(dns_request_t *m);
