/* libbridge/config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE_NAME "bridge-utils"

/* Version number of package */
#define PACKAGE_VERSION "1.2"

